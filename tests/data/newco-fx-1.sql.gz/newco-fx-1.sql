--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Name: note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('note_id_seq', 1, false);


--
-- Name: id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('id', 2, true);


--
-- Name: acc_trans_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('acc_trans_entry_id_seq', 9, true);


--
-- Name: account_checkpoint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('account_checkpoint_id_seq', 1, false);


--
-- Name: account_heading_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('account_heading_id_seq', 12, true);


--
-- Name: account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('account_id_seq', 50, true);


--
-- Name: asset_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('asset_class_id_seq', 1, false);


--
-- Name: asset_dep_method_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('asset_dep_method_id_seq', 3, true);


--
-- Name: asset_disposal_method_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('asset_disposal_method_id_seq', 2, true);


--
-- Name: asset_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('asset_item_id_seq', 1, false);


--
-- Name: asset_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('asset_report_id_seq', 1, false);


--
-- Name: audittrail_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('audittrail_entry_id_seq', 4, true);


--
-- Name: batch_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('batch_class_id_seq', 6, true);


--
-- Name: batch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('batch_id_seq', 1, false);


--
-- Name: business_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('business_id_seq', 1, false);


--
-- Name: company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('company_id_seq', 3, true);


--
-- Name: contact_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('contact_class_id_seq', 17, true);


--
-- Name: country_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('country_id_seq', 250, true);


--
-- Name: country_tax_form_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('country_tax_form_id_seq', 1, false);


--
-- Name: cr_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('cr_report_id_seq', 1, false);


--
-- Name: cr_report_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('cr_report_line_id_seq', 1, false);


--
-- Name: custom_field_catalog_field_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('custom_field_catalog_field_id_seq', 1, false);


--
-- Name: custom_table_catalog_table_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('custom_table_catalog_table_id_seq', 1, false);


--
-- Name: department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('department_id_seq', 1, false);


--
-- Name: entity_bank_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('entity_bank_account_id_seq', 1, false);


--
-- Name: entity_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('entity_class_id_seq', 7, true);


--
-- Name: entity_credit_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('entity_credit_account_id_seq', 4, true);


--
-- Name: entity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('entity_id_seq', 3, true);


--
-- Name: file_base_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('file_base_id_seq', 1, false);


--
-- Name: file_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('file_class_id_seq', 1, false);


--
-- Name: inventory_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('inventory_entry_id_seq', 1, false);


--
-- Name: invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('invoice_id_seq', 2, true);


--
-- Name: jcitems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('jcitems_id_seq', 1, false);


--
-- Name: location_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('location_class_id_seq', 4, true);


--
-- Name: location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('location_id_seq', 1, false);


--
-- Name: menu_acl_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('menu_acl_id_seq', 293, true);


--
-- Name: menu_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('menu_attribute_id_seq', 649, true);


--
-- Name: menu_node_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('menu_node_id_seq', 242, true);


--
-- Name: mime_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('mime_type_id_seq', 684, true);


--
-- Name: new_shipto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('new_shipto_id_seq', 1, false);


--
-- Name: note_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('note_class_id_seq', 1, false);


--
-- Name: oe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('oe_id_seq', 1, false);


--
-- Name: open_forms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('open_forms_id_seq', 22, true);


--
-- Name: orderitems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('orderitems_id_seq', 1, false);


--
-- Name: parts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('parts_id_seq', 2, true);


--
-- Name: partscustomer_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('partscustomer_entry_id_seq', 1, false);


--
-- Name: partsgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('partsgroup_id_seq', 1, false);


--
-- Name: partsvendor_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('partsvendor_entry_id_seq', 1, false);


--
-- Name: payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('payment_id_seq', 2, true);


--
-- Name: payment_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('payment_type_id_seq', 1, false);


--
-- Name: pending_job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('pending_job_id_seq', 1, false);


--
-- Name: person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('person_id_seq', 1, true);


--
-- Name: pricegroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('pricegroup_id_seq', 1, false);


--
-- Name: project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('project_id_seq', 1, false);


--
-- Name: salutation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('salutation_id_seq', 7, true);


--
-- Name: session_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('session_session_id_seq', 1, true);


--
-- Name: taxcategory_taxcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('taxcategory_taxcategory_id_seq', 1, false);


--
-- Name: taxmodule_taxmodule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('taxmodule_taxmodule_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_id_seq', 1, true);


--
-- Name: voucher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('voucher_id_seq', 1, false);


--
-- Name: warehouse_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('warehouse_id_seq', 1, false);


--
-- Data for Name: account_heading; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO account_heading (id, accno, parent_id, description) VALUES (1, '1000', NULL, 'CURRENT ASSETS');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (2, '1500', NULL, 'INVENTORY ASSETS');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (3, '1800', NULL, 'CAPITAL ASSETS');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (4, '2000', NULL, 'CURRENT LIABILITIES');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (5, '2400', NULL, 'PAYROLL DEDUCTIONS');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (6, '2600', NULL, 'LONG TERM LIABILITIES');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (7, '3300', NULL, 'SHARE CAPITAL');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (8, '4000', NULL, 'SALES REVENUE');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (9, '4400', NULL, 'OTHER REVENUE');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (10, '5000', NULL, 'COST OF GOODS SOLD');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (11, '5400', NULL, 'PAYROLL EXPENSES');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (12, '5600', NULL, 'GENERAL & ADMINISTRATIVE EXPENSES');


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (1, '1060', 'Chequing Account', 'A', '1002', 1, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (2, '1065', 'Petty Cash', 'A', '1001', 1, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (3, '1200', 'Accounts Receivables', 'A', '1060', 1, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (4, '1205', 'Allowance for doubtful accounts', 'A', '1063', 1, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (5, '1520', 'Inventory / General', 'A', '1122', 2, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (6, '1530', 'Inventory / Aftermarket Parts', 'A', '1122', 2, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (7, '1540', 'Inventory / Raw Materials', 'A', '1122', 2, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (8, '1820', 'Office Furniture & Equipment', 'A', '1787', 3, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (9, '1825', 'Accum. Amort. -Furn. & Equip.', 'A', '1788', 3, true, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (10, '1840', 'Vehicle', 'A', '1742', 3, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (11, '1845', 'Accum. Amort. -Vehicle', 'A', '1743', 3, true, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (12, '2100', 'Accounts Payable', 'L', '2621', 4, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (13, '2160', 'Federal Taxes Payable', 'L', '2683', 4, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (14, '2170', 'Provincial Taxes Payable', 'L', '2684', 4, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (17, '2380', 'Vacation Pay Payable', 'L', '2624', 4, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (18, '2390', 'WCB Payable', 'L', '2627', 4, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (19, '2410', 'EI Payable', 'L', '2627', 5, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (20, '2420', 'CPP Payable', 'L', '2627', 5, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (21, '2450', 'Income Tax Payable', 'L', '2628', 5, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (22, '2620', 'Bank Loans', 'L', '2701', 6, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (23, '2680', 'Loans from Shareholders', 'L', '2780', 6, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (24, '3350', 'Common Shares', 'Q', '3500', 7, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (25, '4020', 'General Sales', 'I', '8000', 8, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (26, '4030', 'Aftermarket Parts', 'I', '8000', 8, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (27, '4430', 'Shipping & Handling', 'I', '8457', 9, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (28, '4440', 'Interest', 'I', '8090', 9, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (29, '4450', 'Foreign Exchange Gain / (Loss)', 'I', '8231', 9, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (30, '5010', 'Purchases', 'E', '8320', 10, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (31, '5050', 'Aftermarket Parts', 'E', '8320', 10, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (32, '5100', 'Freight', 'E', '8457', 10, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (33, '5410', 'Wages & Salaries', 'E', '9060', 11, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (34, '5420', 'EI Expense', 'E', '8622', 11, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (35, '5430', 'CPP Expense', 'E', '8622', 11, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (36, '5440', 'WCB Expense', 'E', '8622', 11, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (37, '5610', 'Accounting & Legal', 'E', '8862', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (38, '5615', 'Advertising & Promotions', 'E', '8520', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (39, '5620', 'Bad Debts', 'E', '8590', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (40, '5660', 'Amortization Expense', 'E', '8670', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (41, '5680', 'Income Taxes', 'E', '9990', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (42, '5685', 'Insurance', 'E', '9804', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (43, '5690', 'Interest & Bank Charges', 'E', '9805', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (44, '5700', 'Office Supplies', 'E', '8811', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (45, '5760', 'Rent', 'E', '9811', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (46, '5765', 'Repair & Maintenance', 'E', '8964', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (47, '5780', 'Telephone', 'E', '9225', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (48, '5785', 'Travel & Entertainment', 'E', '8523', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (49, '5790', 'Utilities', 'E', '8812', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (50, '5800', 'Licenses', 'E', '8760', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (16, '2320', 'PST', 'L', '2686', 4, false, true);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (15, '2310', 'GST', 'L', '2685', 4, false, true);


--
-- Data for Name: batch_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO batch_class (id, class) VALUES (1, 'ap');
INSERT INTO batch_class (id, class) VALUES (2, 'ar');
INSERT INTO batch_class (id, class) VALUES (3, 'payment');
INSERT INTO batch_class (id, class) VALUES (4, 'payment_reversal');
INSERT INTO batch_class (id, class) VALUES (5, 'gl');
INSERT INTO batch_class (id, class) VALUES (6, 'receipt');


--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO country (id, name, short_name, itu) VALUES (1, 'Ascension Island', 'AC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (2, 'Andorra', 'AD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (3, 'United Arab Emirates', 'AE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (4, 'Afghanistan', 'AF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (5, 'Antigua and Barbuda', 'AG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (6, 'Anguilla', 'AI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (7, 'Albania', 'AL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (8, 'Armenia', 'AM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (9, 'Netherlands Antilles', 'AN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (10, 'Angola', 'AO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (11, 'Antarctica', 'AQ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (12, 'Argentina', 'AR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (13, 'American Samoa', 'AS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (14, 'Austria', 'AT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (15, 'Australia', 'AU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (16, 'Aruba', 'AW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (17, 'Aland Islands', 'AX', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (18, 'Azerbaijan', 'AZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (19, 'Bosnia and Herzegovina', 'BA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (20, 'Barbados', 'BB', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (21, 'Bangladesh', 'BD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (22, 'Belgium', 'BE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (23, 'Burkina Faso', 'BF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (24, 'Bulgaria', 'BG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (25, 'Bahrain', 'BH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (26, 'Burundi', 'BI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (27, 'Benin', 'BJ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (28, 'Bermuda', 'BM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (29, 'Brunei Darussalam', 'BN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (30, 'Bolivia', 'BO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (31, 'Brazil', 'BR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (32, 'Bahamas', 'BS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (33, 'Bhutan', 'BT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (34, 'Bouvet Island', 'BV', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (35, 'Botswana', 'BW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (36, 'Belarus', 'BY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (37, 'Belize', 'BZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (38, 'Canada', 'CA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (39, 'Cocos (Keeling) Islands', 'CC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (40, 'Congo, Democratic Republic', 'CD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (41, 'Central African Republic', 'CF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (42, 'Congo', 'CG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (43, 'Switzerland', 'CH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (44, 'Cote D''Ivoire (Ivory Coast)', 'CI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (45, 'Cook Islands', 'CK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (46, 'Chile', 'CL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (47, 'Cameroon', 'CM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (48, 'China', 'CN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (49, 'Colombia', 'CO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (50, 'Costa Rica', 'CR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (51, 'Czechoslovakia (former)', 'CS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (52, 'Cuba', 'CU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (53, 'Cape Verde', 'CV', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (54, 'Christmas Island', 'CX', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (55, 'Cyprus', 'CY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (56, 'Czech Republic', 'CZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (57, 'Germany', 'DE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (58, 'Djibouti', 'DJ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (59, 'Denmark', 'DK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (60, 'Dominica', 'DM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (61, 'Dominican Republic', 'DO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (62, 'Algeria', 'DZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (63, 'Ecuador', 'EC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (64, 'Estonia', 'EE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (65, 'Egypt', 'EG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (66, 'Western Sahara', 'EH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (67, 'Eritrea', 'ER', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (68, 'Spain', 'ES', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (69, 'Ethiopia', 'ET', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (70, 'Finland', 'FI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (71, 'Fiji', 'FJ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (72, 'Falkland Islands (Malvinas)', 'FK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (73, 'Micronesia', 'FM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (74, 'Faroe Islands', 'FO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (75, 'France', 'FR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (76, 'France, Metropolitan', 'FX', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (77, 'Gabon', 'GA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (78, 'Great Britain (UK)', 'GB', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (79, 'Grenada', 'GD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (80, 'Georgia', 'GE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (81, 'French Guiana', 'GF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (82, 'Ghana', 'GH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (83, 'Gibraltar', 'GI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (84, 'Greenland', 'GL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (85, 'Gambia', 'GM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (86, 'Guinea', 'GN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (87, 'Guadeloupe', 'GP', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (88, 'Equatorial Guinea', 'GQ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (89, 'Greece', 'GR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (90, 'S. Georgia and S. Sandwich Isls.', 'GS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (91, 'Guatemala', 'GT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (92, 'Guam', 'GU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (93, 'Guinea-Bissau', 'GW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (94, 'Guyana', 'GY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (95, 'Hong Kong', 'HK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (96, 'Heard and McDonald Islands', 'HM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (97, 'Honduras', 'HN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (98, 'Croatia (Hrvatska)', 'HR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (99, 'Haiti', 'HT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (100, 'Hungary', 'HU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (101, 'Indonesia', 'ID', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (102, 'Ireland', 'IE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (103, 'Israel', 'IL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (104, 'Isle of Man', 'IM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (105, 'India', 'IN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (106, 'British Indian Ocean Territory', 'IO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (107, 'Iraq', 'IQ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (108, 'Iran', 'IR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (109, 'Iceland', 'IS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (110, 'Italy', 'IT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (111, 'Jersey', 'JE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (112, 'Jamaica', 'JM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (113, 'Jordan', 'JO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (114, 'Japan', 'JP', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (115, 'Kenya', 'KE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (116, 'Kyrgyzstan', 'KG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (117, 'Cambodia', 'KH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (118, 'Kiribati', 'KI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (119, 'Comoros', 'KM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (120, 'Saint Kitts and Nevis', 'KN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (121, 'Korea (North)', 'KP', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (122, 'Korea (South)', 'KR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (123, 'Kuwait', 'KW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (124, 'Cayman Islands', 'KY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (125, 'Kazakhstan', 'KZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (126, 'Laos', 'LA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (127, 'Lebanon', 'LB', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (128, 'Saint Lucia', 'LC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (129, 'Liechtenstein', 'LI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (130, 'Sri Lanka', 'LK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (131, 'Liberia', 'LR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (132, 'Lesotho', 'LS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (133, 'Lithuania', 'LT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (134, 'Luxembourg', 'LU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (135, 'Latvia', 'LV', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (136, 'Libya', 'LY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (137, 'Morocco', 'MA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (138, 'Monaco', 'MC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (139, 'Moldova', 'MD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (140, 'Madagascar', 'MG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (141, 'Marshall Islands', 'MH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (142, 'F.Y.R.O.M. (Macedonia)', 'MK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (143, 'Mali', 'ML', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (144, 'Myanmar', 'MM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (145, 'Mongolia', 'MN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (146, 'Macau', 'MO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (147, 'Northern Mariana Islands', 'MP', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (148, 'Martinique', 'MQ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (149, 'Mauritania', 'MR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (150, 'Montserrat', 'MS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (151, 'Malta', 'MT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (152, 'Mauritius', 'MU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (153, 'Maldives', 'MV', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (154, 'Malawi', 'MW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (155, 'Mexico', 'MX', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (156, 'Malaysia', 'MY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (157, 'Mozambique', 'MZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (158, 'Namibia', 'NA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (159, 'New Caledonia', 'NC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (160, 'Niger', 'NE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (161, 'Norfolk Island', 'NF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (162, 'Nigeria', 'NG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (163, 'Nicaragua', 'NI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (164, 'Netherlands', 'NL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (165, 'Norway', 'NO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (166, 'Nepal', 'NP', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (167, 'Nauru', 'NR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (168, 'Neutral Zone', 'NT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (169, 'Niue', 'NU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (170, 'New Zealand (Aotearoa)', 'NZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (171, 'Oman', 'OM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (172, 'Panama', 'PA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (173, 'Peru', 'PE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (174, 'French Polynesia', 'PF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (175, 'Papua New Guinea', 'PG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (176, 'Philippines', 'PH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (177, 'Pakistan', 'PK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (178, 'Poland', 'PL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (179, 'St. Pierre and Miquelon', 'PM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (180, 'Pitcairn', 'PN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (181, 'Puerto Rico', 'PR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (182, 'Palestinian Territory, Occupied', 'PS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (183, 'Portugal', 'PT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (184, 'Palau', 'PW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (185, 'Paraguay', 'PY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (186, 'Qatar', 'QA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (187, 'Reunion', 'RE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (188, 'Romania', 'RO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (189, 'Serbia', 'RS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (190, 'Russian Federation', 'RU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (191, 'Rwanda', 'RW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (192, 'Saudi Arabia', 'SA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (193, 'Solomon Islands', 'SB', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (194, 'Seychelles', 'SC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (195, 'Sudan', 'SD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (196, 'Sweden', 'SE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (197, 'Singapore', 'SG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (198, 'St. Helena', 'SH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (199, 'Slovenia', 'SI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (200, 'Svalbard & Jan Mayen Islands', 'SJ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (201, 'Slovak Republic', 'SK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (202, 'Sierra Leone', 'SL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (203, 'San Marino', 'SM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (204, 'Senegal', 'SN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (205, 'Somalia', 'SO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (206, 'Suriname', 'SR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (207, 'Sao Tome and Principe', 'ST', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (208, 'USSR (former)', 'SU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (209, 'El Salvador', 'SV', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (210, 'Syria', 'SY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (211, 'Swaziland', 'SZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (212, 'Turks and Caicos Islands', 'TC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (213, 'Chad', 'TD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (214, 'French Southern Territories', 'TF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (215, 'Togo', 'TG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (216, 'Thailand', 'TH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (217, 'Tajikistan', 'TJ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (218, 'Tokelau', 'TK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (219, 'Turkmenistan', 'TM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (220, 'Tunisia', 'TN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (221, 'Tonga', 'TO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (222, 'East Timor', 'TP', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (223, 'Turkey', 'TR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (224, 'Trinidad and Tobago', 'TT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (225, 'Tuvalu', 'TV', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (226, 'Taiwan', 'TW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (227, 'Tanzania', 'TZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (228, 'Ukraine', 'UA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (229, 'Uganda', 'UG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (230, 'United Kingdom', 'UK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (231, 'US Minor Outlying Islands', 'UM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (232, 'United States', 'US', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (233, 'Uruguay', 'UY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (234, 'Uzbekistan', 'UZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (235, 'Vatican City State (Holy See)', 'VA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (236, 'Saint Vincent & the Grenadines', 'VC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (237, 'Venezuela', 'VE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (238, 'British Virgin Islands', 'VG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (239, 'Virgin Islands (U.S.)', 'VI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (240, 'Viet Nam', 'VN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (241, 'Vanuatu', 'VU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (242, 'Wallis and Futuna Islands', 'WF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (243, 'Samoa', 'WS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (244, 'Yemen', 'YE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (245, 'Mayotte', 'YT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (246, 'Yugoslavia (former)', 'YU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (247, 'South Africa', 'ZA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (248, 'Zambia', 'ZM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (249, 'Zaire', 'ZR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (250, 'Zimbabwe', 'ZW', NULL);


--
-- Data for Name: entity_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO entity_class (id, class, country_id, active) VALUES (1, 'Vendor', NULL, true);
INSERT INTO entity_class (id, class, country_id, active) VALUES (2, 'Customer', NULL, true);
INSERT INTO entity_class (id, class, country_id, active) VALUES (3, 'Employee', NULL, true);
INSERT INTO entity_class (id, class, country_id, active) VALUES (4, 'Contact', NULL, true);
INSERT INTO entity_class (id, class, country_id, active) VALUES (5, 'Lead', NULL, true);
INSERT INTO entity_class (id, class, country_id, active) VALUES (6, 'Referral', NULL, true);


--
-- Data for Name: entity; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO entity (id, name, entity_class, created, control_code, country_id) VALUES (0, 'Inventory Entity', 1, '2012-03-10', 'AUTO-01', 232);
INSERT INTO entity (id, name, entity_class, created, control_code, country_id) VALUES (1, 'Guy Smiley', 3, '2012-03-10', 'A-00002', 38);
INSERT INTO entity (id, name, entity_class, created, control_code, country_id) VALUES (2, 'Canadian Customer', 2, '2012-03-10', 'A-00003', 38);
INSERT INTO entity (id, name, entity_class, created, control_code, country_id) VALUES (3, 'US Customer', 2, '2012-03-10', 'A-00004', 232);


--
-- Data for Name: entity_employee; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO entity_employee (entity_id, startdate, enddate, role, ssn, sales, manager_id, employeenumber, dob) VALUES (1, '2012-03-10', NULL, 'user', NULL, false, NULL, NULL, NULL);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO users (id, username, notify_password, entity_id) VALUES (1, 'guy', '7 days', 1);


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO session (session_id, token, last_used, ttl, users_id, notify_pasword) VALUES (1, '3c6d9e460f1df5dced00bbac8532f19e', '2012-03-10 21:00:06.458088', 3600, 1, '7 days');


--
-- Data for Name: batch; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO transactions (id, table_name, locked_by, approved_by, approved_at) VALUES (1, 'ar', NULL, NULL, NULL);
INSERT INTO transactions (id, table_name, locked_by, approved_by, approved_at) VALUES (2, 'ar', NULL, NULL, NULL);


--
-- Data for Name: voucher; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: acc_trans; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (1, 25, 100, '2012-03-10', NULL, false, false, NULL, NULL, 1, true, NULL, NULL, NULL, 1);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (1, 3, -100, '2012-03-10', NULL, false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 2);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (2, 25, 246.91, '2012-03-10', NULL, false, false, NULL, NULL, 2, true, NULL, NULL, NULL, 3);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (2, 3, -246.91, '2012-03-10', NULL, false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 4);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (1, 1, -100, '2012-03-10', 'check 0002345', false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 5);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (1, 3, 100, '2012-03-10', 'check 0002345', false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 6);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (2, 1, -253.357600, '2012-03-11', 'check 900234', false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 7);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (2, 3, 246.91000, '2012-03-11', 'check 900234', false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 8);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (2, 29, 6.447600, '2012-03-11', 'check 900234', false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 9);


--
-- Data for Name: ac_tax_form; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: account_checkpoint; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: account_link_description; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO account_link_description (description, summary, custom) VALUES ('AR', true, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP', true, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC', true, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AR_amount', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AR_tax', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AR_paid', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AR_overpayment', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AR_discount', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP_amount', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP_expense', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP_tax', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP_paid', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP_overpayment', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP_discount', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_sale', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_tax', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_cogs', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_taxpart', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_taxservice', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_income', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_expense', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('Asset_Dep', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('Fixed_Asset', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('asset_expense', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('asset_gain', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('asset_loss', false, false);


--
-- Data for Name: account_link; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO account_link (account_id, description) VALUES (1, 'AR_paid');
INSERT INTO account_link (account_id, description) VALUES (1, 'AP_paid');
INSERT INTO account_link (account_id, description) VALUES (2, 'AR_paid');
INSERT INTO account_link (account_id, description) VALUES (2, 'AP_paid');
INSERT INTO account_link (account_id, description) VALUES (3, 'AR');
INSERT INTO account_link (account_id, description) VALUES (5, 'IC');
INSERT INTO account_link (account_id, description) VALUES (6, 'IC');
INSERT INTO account_link (account_id, description) VALUES (7, 'IC');
INSERT INTO account_link (account_id, description) VALUES (12, 'AP');
INSERT INTO account_link (account_id, description) VALUES (15, 'AR_tax');
INSERT INTO account_link (account_id, description) VALUES (15, 'AP_tax');
INSERT INTO account_link (account_id, description) VALUES (15, 'IC_taxpart');
INSERT INTO account_link (account_id, description) VALUES (15, 'IC_taxservice');
INSERT INTO account_link (account_id, description) VALUES (16, 'AR_tax');
INSERT INTO account_link (account_id, description) VALUES (16, 'AP_tax');
INSERT INTO account_link (account_id, description) VALUES (16, 'IC_taxpart');
INSERT INTO account_link (account_id, description) VALUES (16, 'IC_taxservice');
INSERT INTO account_link (account_id, description) VALUES (23, 'AP_paid');
INSERT INTO account_link (account_id, description) VALUES (25, 'AR_amount');
INSERT INTO account_link (account_id, description) VALUES (25, 'IC_sale');
INSERT INTO account_link (account_id, description) VALUES (25, 'IC_income');
INSERT INTO account_link (account_id, description) VALUES (26, 'AR_amount');
INSERT INTO account_link (account_id, description) VALUES (26, 'IC_sale');
INSERT INTO account_link (account_id, description) VALUES (27, 'IC_income');
INSERT INTO account_link (account_id, description) VALUES (28, 'IC_income');
INSERT INTO account_link (account_id, description) VALUES (30, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (30, 'IC_cogs');
INSERT INTO account_link (account_id, description) VALUES (30, 'IC_expense');
INSERT INTO account_link (account_id, description) VALUES (31, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (31, 'IC_cogs');
INSERT INTO account_link (account_id, description) VALUES (32, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (32, 'IC_expense');
INSERT INTO account_link (account_id, description) VALUES (37, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (38, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (42, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (44, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (45, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (46, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (47, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (49, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (50, 'AP_amount');


--
-- Data for Name: country_tax_form; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: entity_bank_account; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: language; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO language (code, description) VALUES ('ar_EG', 'Arabic (Egypt)');
INSERT INTO language (code, description) VALUES ('bg', 'Bulgarian');
INSERT INTO language (code, description) VALUES ('ca', 'Catalan');
INSERT INTO language (code, description) VALUES ('cs', 'Czech');
INSERT INTO language (code, description) VALUES ('da', 'Danish');
INSERT INTO language (code, description) VALUES ('de', 'German');
INSERT INTO language (code, description) VALUES ('de_CH', 'German (Switzerland)');
INSERT INTO language (code, description) VALUES ('el', 'Greek');
INSERT INTO language (code, description) VALUES ('en', 'English');
INSERT INTO language (code, description) VALUES ('en_US', 'English (US)');
INSERT INTO language (code, description) VALUES ('en_GB', 'English (UK)');
INSERT INTO language (code, description) VALUES ('es', 'Spanish');
INSERT INTO language (code, description) VALUES ('es_CO', 'Spanish (Colombia)');
INSERT INTO language (code, description) VALUES ('es_EC', 'Spanish (Ecuador)');
INSERT INTO language (code, description) VALUES ('es_MX', 'Spanish (Mexico)');
INSERT INTO language (code, description) VALUES ('es_PA', 'Spanish (Panama)');
INSERT INTO language (code, description) VALUES ('es_PY', 'Spanish (Paraguay)');
INSERT INTO language (code, description) VALUES ('es_VE', 'Spanish (Venezuela)');
INSERT INTO language (code, description) VALUES ('et', 'Estonian');
INSERT INTO language (code, description) VALUES ('fi', 'Finnish');
INSERT INTO language (code, description) VALUES ('fr', 'French');
INSERT INTO language (code, description) VALUES ('fr_BE', 'French (Belgium)');
INSERT INTO language (code, description) VALUES ('fr_CA', 'French (Canada)');
INSERT INTO language (code, description) VALUES ('hu', 'Hungarian');
INSERT INTO language (code, description) VALUES ('id', 'Indonesian');
INSERT INTO language (code, description) VALUES ('is', 'Icelandic');
INSERT INTO language (code, description) VALUES ('it', 'Italian');
INSERT INTO language (code, description) VALUES ('lt', 'Latvian');
INSERT INTO language (code, description) VALUES ('nb', 'Norwegian');
INSERT INTO language (code, description) VALUES ('nl', 'Dutch');
INSERT INTO language (code, description) VALUES ('nl_BE', 'Dutch (Belgium)');
INSERT INTO language (code, description) VALUES ('pl', 'Polish');
INSERT INTO language (code, description) VALUES ('pt', 'Portuguese');
INSERT INTO language (code, description) VALUES ('pt_BR', 'Portuguese (Brazil)');
INSERT INTO language (code, description) VALUES ('ru', 'Russian');
INSERT INTO language (code, description) VALUES ('sv', 'Swedish');
INSERT INTO language (code, description) VALUES ('tr', 'Turkish');
INSERT INTO language (code, description) VALUES ('uk', 'Ukranian');
INSERT INTO language (code, description) VALUES ('zh_CN', 'Chinese (China)');
INSERT INTO language (code, description) VALUES ('zh_TW', 'Chinese (Taiwan)');


--
-- Data for Name: salutation; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO salutation (id, salutation) VALUES (1, 'Dr.');
INSERT INTO salutation (id, salutation) VALUES (2, 'Miss.');
INSERT INTO salutation (id, salutation) VALUES (3, 'Mr.');
INSERT INTO salutation (id, salutation) VALUES (4, 'Mrs.');
INSERT INTO salutation (id, salutation) VALUES (5, 'Ms.');
INSERT INTO salutation (id, salutation) VALUES (6, 'Sir.');


--
-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO person (id, entity_id, salutation_id, first_name, middle_name, last_name, created) VALUES (1, 1, 3, 'Guy', NULL, 'Smiley', '2012-03-10');


--
-- Data for Name: pricegroup; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: entity_credit_account; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO entity_credit_account (id, entity_id, entity_class, pay_to_name, discount, description, discount_terms, discount_account_id, taxincluded, creditlimit, terms, meta_number, business_id, language_code, pricegroup_id, curr, startdate, enddate, threshold, employee_id, primary_contact, ar_ap_account_id, cash_account_id, bank_account, taxform_id) VALUES (1, 0, 1, NULL, NULL, NULL, 0, NULL, false, 0, 0, '00000', NULL, 'en', NULL, NULL, '2012-03-10', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO entity_credit_account (id, entity_id, entity_class, pay_to_name, discount, description, discount_terms, discount_account_id, taxincluded, creditlimit, terms, meta_number, business_id, language_code, pricegroup_id, curr, startdate, enddate, threshold, employee_id, primary_contact, ar_ap_account_id, cash_account_id, bank_account, taxform_id) VALUES (2, 0, 2, NULL, NULL, NULL, 0, NULL, false, 0, 0, '00000', NULL, 'en', NULL, NULL, '2012-03-10', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO entity_credit_account (id, entity_id, entity_class, pay_to_name, discount, description, discount_terms, discount_account_id, taxincluded, creditlimit, terms, meta_number, business_id, language_code, pricegroup_id, curr, startdate, enddate, threshold, employee_id, primary_contact, ar_ap_account_id, cash_account_id, bank_account, taxform_id) VALUES (3, 2, 2, NULL, NULL, 'Canadian Customer', NULL, NULL, NULL, NULL, NULL, '1', NULL, 'en_US', NULL, 'CAD', NULL, NULL, 0, NULL, NULL, 3, 1, NULL, NULL);
INSERT INTO entity_credit_account (id, entity_id, entity_class, pay_to_name, discount, description, discount_terms, discount_account_id, taxincluded, creditlimit, terms, meta_number, business_id, language_code, pricegroup_id, curr, startdate, enddate, threshold, employee_id, primary_contact, ar_ap_account_id, cash_account_id, bank_account, taxform_id) VALUES (4, 3, 2, NULL, NULL, 'US customer', NULL, NULL, NULL, NULL, NULL, '2', NULL, 'en_US', NULL, 'USD', NULL, NULL, 0, NULL, NULL, 3, 1, NULL, NULL);


--
-- Data for Name: ap; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ar; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO ar (id, invnumber, transdate, entity_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, shippingpoint, terms, notes, curr, ordnumber, person_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, on_hold, reverse, approved, entity_credit_account, force_closed, description) VALUES (1, '2', '2012-03-10', NULL, false, 100, 100, 0, '2012-03-10', '2012-03-10', true, '', 0, '', 'CAD', '', 1, NULL, '', '', 0, '', 'en_US', '', false, false, true, 3, NULL, NULL);
INSERT INTO ar (id, invnumber, transdate, entity_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, shippingpoint, terms, notes, curr, ordnumber, person_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, on_hold, reverse, approved, entity_credit_account, force_closed, description) VALUES (2, '3', '2012-03-10', NULL, false, 246.91, 246.91, 0, '2012-03-10', '2012-03-10', true, '', 0, '', 'USD', '', 1, NULL, '', '', 0, '', 'en_US', '', false, false, true, 4, NULL, NULL);


--
-- Data for Name: parts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO parts (id, partnumber, description, unit, listprice, sellprice, lastcost, priceupdate, weight, onhand, notes, makemodel, assembly, alternate, rop, inventory_accno_id, income_accno_id, expense_accno_id, bin, obsolete, bom, image, drawing, microfiche, partsgroup_id, project_id, avgcost) VALUES (1, 'consulting', '', '', 0, 0, 0, '2012-03-10', 0, 0, '', false, false, false, 0, NULL, 25, 30, NULL, false, false, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO parts (id, partnumber, description, unit, listprice, sellprice, lastcost, priceupdate, weight, onhand, notes, makemodel, assembly, alternate, rop, inventory_accno_id, income_accno_id, expense_accno_id, bin, obsolete, bom, image, drawing, microfiche, partsgroup_id, project_id, avgcost) VALUES (2, 'us-consult', '', '', 0, 0, 0, '2012-03-10', 0, 0, '', false, false, false, 0, NULL, 25, 30, NULL, false, false, NULL, NULL, NULL, 0, NULL, NULL);


--
-- Data for Name: assembly; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_unit_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO asset_unit_class (id, class) VALUES (1, 'time');
INSERT INTO asset_unit_class (id, class) VALUES (2, 'production');


--
-- Data for Name: asset_dep_method; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO asset_dep_method (id, method, sproc, unit_label, short_name, unit_class) VALUES (1, 'Annual Straight Line Daily', 'asset_dep_straight_line_yr_d', 'in years', 'SLYD', 1);
INSERT INTO asset_dep_method (id, method, sproc, unit_label, short_name, unit_class) VALUES (2, 'Whole Month Straight Line', 'asset_dep_straight_line_whl_m', 'in months', 'SLMM', 1);
INSERT INTO asset_dep_method (id, method, sproc, unit_label, short_name, unit_class) VALUES (3, 'Annual Straight Line Monthly', 'asset_dep_straight_line_yr_m', 'in years', 'SLYM', 1);


--
-- Data for Name: asset_class; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_disposal_method; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO asset_disposal_method (label, id, multiple, short_label) VALUES ('Abandonment', 1, 0, 'A');
INSERT INTO asset_disposal_method (label, id, multiple, short_label) VALUES ('Sale', 2, 1, 'S');


--
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: warehouse; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_item; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_note; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_report_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO asset_report_class (id, class) VALUES (1, 'depreciation');
INSERT INTO asset_report_class (id, class) VALUES (2, 'disposal');
INSERT INTO asset_report_class (id, class) VALUES (3, 'import');
INSERT INTO asset_report_class (id, class) VALUES (4, 'partial disposal');


--
-- Data for Name: gl; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_report; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_report_line; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_rl_to_disposal_method; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: audittrail; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO audittrail (trans_id, tablename, reference, formname, action, transdate, person_id, entry_id) VALUES (1, 'ar', 'Sat Mar 10 20:56:05 201230699', NULL, 'INSERT', '2012-03-10 20:56:05.155729', 1, 1);
INSERT INTO audittrail (trans_id, tablename, reference, formname, action, transdate, person_id, entry_id) VALUES (1, 'ar', 'Sat Mar 10 20:56:05 201230699', NULL, 'UPDATE', '2012-03-10 20:56:05.199057', 1, 2);
INSERT INTO audittrail (trans_id, tablename, reference, formname, action, transdate, person_id, entry_id) VALUES (2, 'ar', 'Sat Mar 10 20:56:53 201230857', NULL, 'INSERT', '2012-03-10 20:56:53.882872', 1, 3);
INSERT INTO audittrail (trans_id, tablename, reference, formname, action, transdate, person_id, entry_id) VALUES (2, 'ar', 'Sat Mar 10 20:56:53 201230857', NULL, 'UPDATE', '2012-03-10 20:56:53.934173', 1, 4);


--
-- Data for Name: business; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO company (id, entity_id, legal_name, tax_id, sic_code, created) VALUES (1, 0, 'Inventory Entity', NULL, NULL, '2012-03-10');
INSERT INTO company (id, entity_id, legal_name, tax_id, sic_code, created) VALUES (2, 2, 'Canadian Customer', NULL, NULL, '2012-03-10');
INSERT INTO company (id, entity_id, legal_name, tax_id, sic_code, created) VALUES (3, 3, 'US Customer', NULL, NULL, '2012-03-10');


--
-- Data for Name: contact_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO contact_class (id, class) VALUES (1, 'Primary Phone');
INSERT INTO contact_class (id, class) VALUES (2, 'Secondary Phone');
INSERT INTO contact_class (id, class) VALUES (3, 'Cell Phone');
INSERT INTO contact_class (id, class) VALUES (4, 'AIM');
INSERT INTO contact_class (id, class) VALUES (5, 'Yahoo');
INSERT INTO contact_class (id, class) VALUES (6, 'Gtalk');
INSERT INTO contact_class (id, class) VALUES (7, 'MSN');
INSERT INTO contact_class (id, class) VALUES (8, 'IRC');
INSERT INTO contact_class (id, class) VALUES (9, 'Fax');
INSERT INTO contact_class (id, class) VALUES (10, 'Generic Jabber');
INSERT INTO contact_class (id, class) VALUES (11, 'Home Phone');
INSERT INTO contact_class (id, class) VALUES (12, 'Email');
INSERT INTO contact_class (id, class) VALUES (13, 'CC');
INSERT INTO contact_class (id, class) VALUES (14, 'BCC');
INSERT INTO contact_class (id, class) VALUES (15, 'Billing Email');
INSERT INTO contact_class (id, class) VALUES (16, 'Billing CC');
INSERT INTO contact_class (id, class) VALUES (17, 'Billing BCC');


--
-- Data for Name: company_to_contact; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: company_to_entity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: location; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: location_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO location_class (id, class, authoritative) VALUES (1, 'Billing', true);
INSERT INTO location_class (id, class, authoritative) VALUES (2, 'Sales', true);
INSERT INTO location_class (id, class, authoritative) VALUES (3, 'Shipping', true);


--
-- Data for Name: company_to_location; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cr_coa_to_account; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO cr_coa_to_account (chart_id, account) VALUES (1, '1060--1060--Chequing Account');
INSERT INTO cr_coa_to_account (chart_id, account) VALUES (2, '1065--1065--Petty Cash');


--
-- Data for Name: cr_report; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cr_report_line; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: custom_table_catalog; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: custom_field_catalog; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: customertax; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: defaults; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO defaults (setting_key, value) VALUES ('timeout', '90 minutes');
INSERT INTO defaults (setting_key, value) VALUES ('yearend', '1');
INSERT INTO defaults (setting_key, value) VALUES ('version', '1.3.12');
INSERT INTO defaults (setting_key, value) VALUES ('closedto', NULL);
INSERT INTO defaults (setting_key, value) VALUES ('revtrans', '1');
INSERT INTO defaults (setting_key, value) VALUES ('ponumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('audittrail', '0');
INSERT INTO defaults (setting_key, value) VALUES ('queue_payments', '0');
INSERT INTO defaults (setting_key, value) VALUES ('poll_frequency', '1');
INSERT INTO defaults (setting_key, value) VALUES ('rcptnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('batch_cc', 'B-11111');
INSERT INTO defaults (setting_key, value) VALUES ('entity_control', 'A-00004');
INSERT INTO defaults (setting_key, value) VALUES ('glnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('vclimit', '200');
INSERT INTO defaults (setting_key, value) VALUES ('sonumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('vinumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('sqnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('rfqnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('partnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('projectnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('employeenumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('customernumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('vendornumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('check_prefix', 'CK');
INSERT INTO defaults (setting_key, value) VALUES ('password_duration', '');
INSERT INTO defaults (setting_key, value) VALUES ('default_email_to', '');
INSERT INTO defaults (setting_key, value) VALUES ('default_email_cc', '');
INSERT INTO defaults (setting_key, value) VALUES ('default_email_bcc', '');
INSERT INTO defaults (setting_key, value) VALUES ('default_email_from', '');
INSERT INTO defaults (setting_key, value) VALUES ('company_name', 'New Company');
INSERT INTO defaults (setting_key, value) VALUES ('company_address', '22 New Street');
INSERT INTO defaults (setting_key, value) VALUES ('company_phone', '');
INSERT INTO defaults (setting_key, value) VALUES ('company_fax', '');
INSERT INTO defaults (setting_key, value) VALUES ('businessnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('weightunit', 'kg');
INSERT INTO defaults (setting_key, value) VALUES ('separate_duties', '1');
INSERT INTO defaults (setting_key, value) VALUES ('default_language', 'ar_EG');
INSERT INTO defaults (setting_key, value) VALUES ('inventory_accno_id', '5');
INSERT INTO defaults (setting_key, value) VALUES ('income_accno_id', '25');
INSERT INTO defaults (setting_key, value) VALUES ('expense_accno_id', '30');
INSERT INTO defaults (setting_key, value) VALUES ('fxgain_accno_id', '29');
INSERT INTO defaults (setting_key, value) VALUES ('fxloss_accno_id', '29');
INSERT INTO defaults (setting_key, value) VALUES ('default_country', '');
INSERT INTO defaults (setting_key, value) VALUES ('templates', 'demo');
INSERT INTO defaults (setting_key, value) VALUES ('curr', 'CAD:USD:EUR');
INSERT INTO defaults (setting_key, value) VALUES ('sinumber', '3');
INSERT INTO defaults (setting_key, value) VALUES ('paynumber', '3');


--
-- Data for Name: dpt_trans; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: eca_note; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: eca_to_contact; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: eca_to_location; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: entity_class_to_entity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: entity_note; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: entity_other_name; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: exchangerate; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO exchangerate (curr, transdate, buy, sell) VALUES ('USD', '2012-03-10', 1.23455, 0);
INSERT INTO exchangerate (curr, transdate, buy, sell) VALUES ('USD', '2012-03-11', 1.266788, NULL);


--
-- Data for Name: file_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO file_class (id, class) VALUES (1, 'transaction');
INSERT INTO file_class (id, class) VALUES (2, 'order');
INSERT INTO file_class (id, class) VALUES (3, 'part');


--
-- Data for Name: mime_type; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO mime_type (id, mime_type) VALUES (1, 'all/all');
INSERT INTO mime_type (id, mime_type) VALUES (2, 'all/allfiles');
INSERT INTO mime_type (id, mime_type) VALUES (3, 'audio/x-flac');
INSERT INTO mime_type (id, mime_type) VALUES (4, 'audio/x-ape');
INSERT INTO mime_type (id, mime_type) VALUES (5, 'audio/x-scpls');
INSERT INTO mime_type (id, mime_type) VALUES (6, 'audio/mp4');
INSERT INTO mime_type (id, mime_type) VALUES (7, 'audio/mpeg');
INSERT INTO mime_type (id, mime_type) VALUES (8, 'audio/x-iriver-pla');
INSERT INTO mime_type (id, mime_type) VALUES (9, 'audio/x-speex+ogg');
INSERT INTO mime_type (id, mime_type) VALUES (10, 'audio/x-mod');
INSERT INTO mime_type (id, mime_type) VALUES (11, 'audio/x-tta');
INSERT INTO mime_type (id, mime_type) VALUES (12, 'audio/annodex');
INSERT INTO mime_type (id, mime_type) VALUES (13, 'audio/x-mo3');
INSERT INTO mime_type (id, mime_type) VALUES (14, 'audio/midi');
INSERT INTO mime_type (id, mime_type) VALUES (15, 'audio/mp2');
INSERT INTO mime_type (id, mime_type) VALUES (16, 'audio/x-musepack');
INSERT INTO mime_type (id, mime_type) VALUES (17, 'audio/x-minipsf');
INSERT INTO mime_type (id, mime_type) VALUES (18, 'audio/x-mpegurl');
INSERT INTO mime_type (id, mime_type) VALUES (19, 'audio/x-aiff');
INSERT INTO mime_type (id, mime_type) VALUES (20, 'audio/x-xm');
INSERT INTO mime_type (id, mime_type) VALUES (21, 'audio/x-aifc');
INSERT INTO mime_type (id, mime_type) VALUES (22, 'audio/x-m4b');
INSERT INTO mime_type (id, mime_type) VALUES (23, 'audio/aac');
INSERT INTO mime_type (id, mime_type) VALUES (24, 'audio/x-psflib');
INSERT INTO mime_type (id, mime_type) VALUES (25, 'audio/x-pn-realaudio-plugin');
INSERT INTO mime_type (id, mime_type) VALUES (26, 'audio/basic');
INSERT INTO mime_type (id, mime_type) VALUES (27, 'audio/x-ms-wma');
INSERT INTO mime_type (id, mime_type) VALUES (28, 'audio/AMR-WB');
INSERT INTO mime_type (id, mime_type) VALUES (29, 'audio/x-riff');
INSERT INTO mime_type (id, mime_type) VALUES (30, 'audio/x-psf');
INSERT INTO mime_type (id, mime_type) VALUES (31, 'audio/x-adpcm');
INSERT INTO mime_type (id, mime_type) VALUES (32, 'audio/ogg');
INSERT INTO mime_type (id, mime_type) VALUES (33, 'audio/x-wav');
INSERT INTO mime_type (id, mime_type) VALUES (34, 'audio/x-matroska');
INSERT INTO mime_type (id, mime_type) VALUES (35, 'audio/x-voc');
INSERT INTO mime_type (id, mime_type) VALUES (36, 'audio/ac3');
INSERT INTO mime_type (id, mime_type) VALUES (37, 'audio/x-flac+ogg');
INSERT INTO mime_type (id, mime_type) VALUES (38, 'audio/x-aiffc');
INSERT INTO mime_type (id, mime_type) VALUES (39, 'audio/x-it');
INSERT INTO mime_type (id, mime_type) VALUES (40, 'audio/AMR');
INSERT INTO mime_type (id, mime_type) VALUES (41, 'audio/x-s3m');
INSERT INTO mime_type (id, mime_type) VALUES (42, 'audio/x-speex');
INSERT INTO mime_type (id, mime_type) VALUES (43, 'audio/x-wavpack');
INSERT INTO mime_type (id, mime_type) VALUES (44, 'audio/x-xi');
INSERT INTO mime_type (id, mime_type) VALUES (45, 'audio/x-xmf');
INSERT INTO mime_type (id, mime_type) VALUES (46, 'audio/x-wavpack-correction');
INSERT INTO mime_type (id, mime_type) VALUES (47, 'audio/prs.sid');
INSERT INTO mime_type (id, mime_type) VALUES (48, 'audio/x-gsm');
INSERT INTO mime_type (id, mime_type) VALUES (49, 'audio/x-ms-asx');
INSERT INTO mime_type (id, mime_type) VALUES (50, 'audio/x-vorbis+ogg');
INSERT INTO mime_type (id, mime_type) VALUES (51, 'audio/x-stm');
INSERT INTO mime_type (id, mime_type) VALUES (52, 'x-epoc/x-sisx-app');
INSERT INTO mime_type (id, mime_type) VALUES (53, 'image/x-fpx');
INSERT INTO mime_type (id, mime_type) VALUES (54, 'image/x-panasonic-raw');
INSERT INTO mime_type (id, mime_type) VALUES (55, 'image/x-xwindowdump');
INSERT INTO mime_type (id, mime_type) VALUES (56, 'image/x-nikon-nef');
INSERT INTO mime_type (id, mime_type) VALUES (57, 'image/x-niff');
INSERT INTO mime_type (id, mime_type) VALUES (58, 'image/x-pict');
INSERT INTO mime_type (id, mime_type) VALUES (59, 'image/svg+xml-compressed');
INSERT INTO mime_type (id, mime_type) VALUES (60, 'image/jp2');
INSERT INTO mime_type (id, mime_type) VALUES (61, 'image/x-msod');
INSERT INTO mime_type (id, mime_type) VALUES (62, 'image/x-dds');
INSERT INTO mime_type (id, mime_type) VALUES (63, 'image/x-olympus-orf');
INSERT INTO mime_type (id, mime_type) VALUES (64, 'image/x-portable-graymap');
INSERT INTO mime_type (id, mime_type) VALUES (65, 'image/x-skencil');
INSERT INTO mime_type (id, mime_type) VALUES (66, 'image/x-sony-srf');
INSERT INTO mime_type (id, mime_type) VALUES (67, 'image/x-dib');
INSERT INTO mime_type (id, mime_type) VALUES (68, 'image/x-emf');
INSERT INTO mime_type (id, mime_type) VALUES (69, 'image/x-eps');
INSERT INTO mime_type (id, mime_type) VALUES (70, 'image/ief');
INSERT INTO mime_type (id, mime_type) VALUES (71, 'image/x-pcx');
INSERT INTO mime_type (id, mime_type) VALUES (72, 'image/x-gzeps');
INSERT INTO mime_type (id, mime_type) VALUES (73, 'image/x-xcf');
INSERT INTO mime_type (id, mime_type) VALUES (74, 'image/x-portable-pixmap');
INSERT INTO mime_type (id, mime_type) VALUES (75, 'image/x-kde-raw');
INSERT INTO mime_type (id, mime_type) VALUES (76, 'image/openraster');
INSERT INTO mime_type (id, mime_type) VALUES (77, 'image/x-macpaint');
INSERT INTO mime_type (id, mime_type) VALUES (78, 'image/x-wmf');
INSERT INTO mime_type (id, mime_type) VALUES (79, 'image/x-win-bitmap');
INSERT INTO mime_type (id, mime_type) VALUES (80, 'image/x-sgi');
INSERT INTO mime_type (id, mime_type) VALUES (81, 'image/x-ilbm');
INSERT INTO mime_type (id, mime_type) VALUES (82, 'image/x-sony-sr2');
INSERT INTO mime_type (id, mime_type) VALUES (83, 'image/x-sigma-x3f');
INSERT INTO mime_type (id, mime_type) VALUES (84, 'image/x-bzeps');
INSERT INTO mime_type (id, mime_type) VALUES (85, 'image/x-icns');
INSERT INTO mime_type (id, mime_type) VALUES (86, 'image/g3fax');
INSERT INTO mime_type (id, mime_type) VALUES (87, 'image/x-applix-graphics');
INSERT INTO mime_type (id, mime_type) VALUES (88, 'image/x-xcursor');
INSERT INTO mime_type (id, mime_type) VALUES (89, 'image/x-kodak-dcr');
INSERT INTO mime_type (id, mime_type) VALUES (90, 'image/x-hdr');
INSERT INTO mime_type (id, mime_type) VALUES (91, 'image/x-cmu-raster');
INSERT INTO mime_type (id, mime_type) VALUES (92, 'image/x-sun-raster');
INSERT INTO mime_type (id, mime_type) VALUES (93, 'image/fax-g3');
INSERT INTO mime_type (id, mime_type) VALUES (94, 'image/x-kodak-kdc');
INSERT INTO mime_type (id, mime_type) VALUES (95, 'image/jpeg');
INSERT INTO mime_type (id, mime_type) VALUES (96, 'image/tiff');
INSERT INTO mime_type (id, mime_type) VALUES (97, 'image/dpx');
INSERT INTO mime_type (id, mime_type) VALUES (98, 'image/x-dcraw');
INSERT INTO mime_type (id, mime_type) VALUES (99, 'image/x-adobe-dng');
INSERT INTO mime_type (id, mime_type) VALUES (100, 'image/x-canon-crw');
INSERT INTO mime_type (id, mime_type) VALUES (101, 'image/bmp');
INSERT INTO mime_type (id, mime_type) VALUES (102, 'image/x-xfig');
INSERT INTO mime_type (id, mime_type) VALUES (103, 'image/x-lwo');
INSERT INTO mime_type (id, mime_type) VALUES (104, 'image/x-fuji-raf');
INSERT INTO mime_type (id, mime_type) VALUES (105, 'image/x-xbitmap');
INSERT INTO mime_type (id, mime_type) VALUES (106, 'image/x-pentax-pef');
INSERT INTO mime_type (id, mime_type) VALUES (107, 'image/x-exr');
INSERT INTO mime_type (id, mime_type) VALUES (108, 'image/rle');
INSERT INTO mime_type (id, mime_type) VALUES (109, 'image/x-3ds');
INSERT INTO mime_type (id, mime_type) VALUES (110, 'image/svg+xml');
INSERT INTO mime_type (id, mime_type) VALUES (111, 'image/x-lws');
INSERT INTO mime_type (id, mime_type) VALUES (112, 'image/x-tga');
INSERT INTO mime_type (id, mime_type) VALUES (113, 'image/x-compressed-xcf');
INSERT INTO mime_type (id, mime_type) VALUES (114, 'image/fits');
INSERT INTO mime_type (id, mime_type) VALUES (115, 'image/x-kodak-k25');
INSERT INTO mime_type (id, mime_type) VALUES (116, 'image/x-portable-bitmap');
INSERT INTO mime_type (id, mime_type) VALUES (117, 'image/x-quicktime');
INSERT INTO mime_type (id, mime_type) VALUES (118, 'image/x-sony-arw');
INSERT INTO mime_type (id, mime_type) VALUES (119, 'image/x-xpixmap');
INSERT INTO mime_type (id, mime_type) VALUES (120, 'image/gif');
INSERT INTO mime_type (id, mime_type) VALUES (121, 'image/x-portable-anymap');
INSERT INTO mime_type (id, mime_type) VALUES (122, 'image/x-jng');
INSERT INTO mime_type (id, mime_type) VALUES (123, 'image/x-iff');
INSERT INTO mime_type (id, mime_type) VALUES (124, 'image/x-canon-cr2');
INSERT INTO mime_type (id, mime_type) VALUES (125, 'image/cgm');
INSERT INTO mime_type (id, mime_type) VALUES (126, 'image/x-photo-cd');
INSERT INTO mime_type (id, mime_type) VALUES (127, 'image/png');
INSERT INTO mime_type (id, mime_type) VALUES (128, 'image/x-minolta-mrw');
INSERT INTO mime_type (id, mime_type) VALUES (129, 'image/x-rgb');
INSERT INTO mime_type (id, mime_type) VALUES (130, 'image/x-pic');
INSERT INTO mime_type (id, mime_type) VALUES (131, 'message/disposition-notification');
INSERT INTO mime_type (id, mime_type) VALUES (132, 'message/news');
INSERT INTO mime_type (id, mime_type) VALUES (133, 'message/partial');
INSERT INTO mime_type (id, mime_type) VALUES (134, 'message/x-gnu-rmail');
INSERT INTO mime_type (id, mime_type) VALUES (135, 'message/delivery-status');
INSERT INTO mime_type (id, mime_type) VALUES (136, 'message/external-body');
INSERT INTO mime_type (id, mime_type) VALUES (137, 'message/rfc822');
INSERT INTO mime_type (id, mime_type) VALUES (138, 'uri/mmst');
INSERT INTO mime_type (id, mime_type) VALUES (139, 'uri/rtspu');
INSERT INTO mime_type (id, mime_type) VALUES (140, 'uri/pnm');
INSERT INTO mime_type (id, mime_type) VALUES (141, 'uri/mmsu');
INSERT INTO mime_type (id, mime_type) VALUES (142, 'uri/rtspt');
INSERT INTO mime_type (id, mime_type) VALUES (143, 'uri/mms');
INSERT INTO mime_type (id, mime_type) VALUES (144, 'text/x-tcl');
INSERT INTO mime_type (id, mime_type) VALUES (145, 'text/directory');
INSERT INTO mime_type (id, mime_type) VALUES (146, 'text/htmlh');
INSERT INTO mime_type (id, mime_type) VALUES (147, 'text/x-literate-haskell');
INSERT INTO mime_type (id, mime_type) VALUES (148, 'text/xmcd');
INSERT INTO mime_type (id, mime_type) VALUES (149, 'text/x-ms-regedit');
INSERT INTO mime_type (id, mime_type) VALUES (150, 'text/x-microdvd');
INSERT INTO mime_type (id, mime_type) VALUES (151, 'text/x-erlang');
INSERT INTO mime_type (id, mime_type) VALUES (152, 'text/x-ssa');
INSERT INTO mime_type (id, mime_type) VALUES (153, 'text/plain');
INSERT INTO mime_type (id, mime_type) VALUES (154, 'text/spreadsheet');
INSERT INTO mime_type (id, mime_type) VALUES (155, 'text/sgml');
INSERT INTO mime_type (id, mime_type) VALUES (156, 'text/x-uil');
INSERT INTO mime_type (id, mime_type) VALUES (157, 'text/x-troff-mm');
INSERT INTO mime_type (id, mime_type) VALUES (158, 'text/x-gettext-translation');
INSERT INTO mime_type (id, mime_type) VALUES (159, 'text/x-vhdl');
INSERT INTO mime_type (id, mime_type) VALUES (160, 'text/x-java');
INSERT INTO mime_type (id, mime_type) VALUES (161, 'text/x-nfo');
INSERT INTO mime_type (id, mime_type) VALUES (162, 'text/csv');
INSERT INTO mime_type (id, mime_type) VALUES (163, 'text/x-install');
INSERT INTO mime_type (id, mime_type) VALUES (164, 'text/x-c++src');
INSERT INTO mime_type (id, mime_type) VALUES (165, 'text/x-subviewer');
INSERT INTO mime_type (id, mime_type) VALUES (166, 'text/x-adasrc');
INSERT INTO mime_type (id, mime_type) VALUES (167, 'text/x-dsl');
INSERT INTO mime_type (id, mime_type) VALUES (168, 'text/x-chdr');
INSERT INTO mime_type (id, mime_type) VALUES (169, 'text/calendar');
INSERT INTO mime_type (id, mime_type) VALUES (170, 'text/x-csharp');
INSERT INTO mime_type (id, mime_type) VALUES (171, 'text/x-lua');
INSERT INTO mime_type (id, mime_type) VALUES (172, 'text/x-ocaml');
INSERT INTO mime_type (id, mime_type) VALUES (173, 'text/x-iMelody');
INSERT INTO mime_type (id, mime_type) VALUES (174, 'text/enriched');
INSERT INTO mime_type (id, mime_type) VALUES (175, 'text/richtext');
INSERT INTO mime_type (id, mime_type) VALUES (176, 'text/x-objchdr');
INSERT INTO mime_type (id, mime_type) VALUES (177, 'text/x-makefile');
INSERT INTO mime_type (id, mime_type) VALUES (178, 'text/x-copying');
INSERT INTO mime_type (id, mime_type) VALUES (179, 'text/x-pascal');
INSERT INTO mime_type (id, mime_type) VALUES (180, 'text/x-credits');
INSERT INTO mime_type (id, mime_type) VALUES (181, 'text/x-mup');
INSERT INTO mime_type (id, mime_type) VALUES (182, 'text/x-opml+xml');
INSERT INTO mime_type (id, mime_type) VALUES (183, 'text/x-rpm-spec');
INSERT INTO mime_type (id, mime_type) VALUES (184, 'text/x-xmi');
INSERT INTO mime_type (id, mime_type) VALUES (185, 'text/x-dsrc');
INSERT INTO mime_type (id, mime_type) VALUES (186, 'text/x-patch');
INSERT INTO mime_type (id, mime_type) VALUES (187, 'text/x-authors');
INSERT INTO mime_type (id, mime_type) VALUES (188, 'text/x-ldif');
INSERT INTO mime_type (id, mime_type) VALUES (189, 'text/x-moc');
INSERT INTO mime_type (id, mime_type) VALUES (190, 'text/x-tex');
INSERT INTO mime_type (id, mime_type) VALUES (191, 'text/x-dcl');
INSERT INTO mime_type (id, mime_type) VALUES (192, 'text/x-python');
INSERT INTO mime_type (id, mime_type) VALUES (193, 'text/x-lilypond');
INSERT INTO mime_type (id, mime_type) VALUES (194, 'text/x-katefilelist');
INSERT INTO mime_type (id, mime_type) VALUES (195, 'text/troff');
INSERT INTO mime_type (id, mime_type) VALUES (196, 'text/x-hex');
INSERT INTO mime_type (id, mime_type) VALUES (197, 'text/x-google-video-pointer');
INSERT INTO mime_type (id, mime_type) VALUES (198, 'text/x-haskell');
INSERT INTO mime_type (id, mime_type) VALUES (199, 'text/x-ocl');
INSERT INTO mime_type (id, mime_type) VALUES (200, 'text/x-idl');
INSERT INTO mime_type (id, mime_type) VALUES (201, 'text/x-troff-me');
INSERT INTO mime_type (id, mime_type) VALUES (202, 'text/x-bibtex');
INSERT INTO mime_type (id, mime_type) VALUES (203, 'text/x-sql');
INSERT INTO mime_type (id, mime_type) VALUES (204, 'text/x-emacs-lisp');
INSERT INTO mime_type (id, mime_type) VALUES (205, 'text/x-eiffel');
INSERT INTO mime_type (id, mime_type) VALUES (206, 'text/css');
INSERT INTO mime_type (id, mime_type) VALUES (207, 'text/x-fortran');
INSERT INTO mime_type (id, mime_type) VALUES (208, 'text/x-xslfo');
INSERT INTO mime_type (id, mime_type) VALUES (209, 'text/x-matlab');
INSERT INTO mime_type (id, mime_type) VALUES (210, 'text/x-uri');
INSERT INTO mime_type (id, mime_type) VALUES (211, 'text/x-setext');
INSERT INTO mime_type (id, mime_type) VALUES (212, 'text/x-readme');
INSERT INTO mime_type (id, mime_type) VALUES (213, 'text/x-troff-ms');
INSERT INTO mime_type (id, mime_type) VALUES (214, 'text/x-cmake');
INSERT INTO mime_type (id, mime_type) VALUES (215, 'text/tab-separated-values');
INSERT INTO mime_type (id, mime_type) VALUES (216, 'text/x-log');
INSERT INTO mime_type (id, mime_type) VALUES (217, 'text/x-mpsub');
INSERT INTO mime_type (id, mime_type) VALUES (218, 'text/x-mof');
INSERT INTO mime_type (id, mime_type) VALUES (219, 'text/html');
INSERT INTO mime_type (id, mime_type) VALUES (220, 'text/x-txt2tags');
INSERT INTO mime_type (id, mime_type) VALUES (221, 'text/x-csrc');
INSERT INTO mime_type (id, mime_type) VALUES (222, 'text/rfc822-headers');
INSERT INTO mime_type (id, mime_type) VALUES (223, 'text/x-mrml');
INSERT INTO mime_type (id, mime_type) VALUES (224, 'text/x-vala');
INSERT INTO mime_type (id, mime_type) VALUES (225, 'text/x-iptables');
INSERT INTO mime_type (id, mime_type) VALUES (226, 'text/x-c++hdr');
INSERT INTO mime_type (id, mime_type) VALUES (227, 'text/x-scheme');
INSERT INTO mime_type (id, mime_type) VALUES (228, 'text/x-texinfo');
INSERT INTO mime_type (id, mime_type) VALUES (229, 'text/x-objcsrc');
INSERT INTO mime_type (id, mime_type) VALUES (230, 'text/x-changelog');
INSERT INTO mime_type (id, mime_type) VALUES (231, 'x-content/audio-dvd');
INSERT INTO mime_type (id, mime_type) VALUES (232, 'x-content/video-svcd');
INSERT INTO mime_type (id, mime_type) VALUES (233, 'x-content/video-hddvd');
INSERT INTO mime_type (id, mime_type) VALUES (234, 'x-content/blank-dvd');
INSERT INTO mime_type (id, mime_type) VALUES (235, 'x-content/video-vcd');
INSERT INTO mime_type (id, mime_type) VALUES (236, 'x-content/unix-software');
INSERT INTO mime_type (id, mime_type) VALUES (237, 'x-content/blank-cd');
INSERT INTO mime_type (id, mime_type) VALUES (238, 'x-content/audio-cdda');
INSERT INTO mime_type (id, mime_type) VALUES (239, 'x-content/win32-software');
INSERT INTO mime_type (id, mime_type) VALUES (240, 'x-content/blank-hddvd');
INSERT INTO mime_type (id, mime_type) VALUES (241, 'x-content/audio-player');
INSERT INTO mime_type (id, mime_type) VALUES (242, 'x-content/video-dvd');
INSERT INTO mime_type (id, mime_type) VALUES (243, 'x-content/image-picturecd');
INSERT INTO mime_type (id, mime_type) VALUES (244, 'x-content/blank-bd');
INSERT INTO mime_type (id, mime_type) VALUES (245, 'x-content/video-bluray');
INSERT INTO mime_type (id, mime_type) VALUES (246, 'x-content/image-dcf');
INSERT INTO mime_type (id, mime_type) VALUES (247, 'x-content/software');
INSERT INTO mime_type (id, mime_type) VALUES (248, 'model/vrml');
INSERT INTO mime_type (id, mime_type) VALUES (249, 'fonts/package');
INSERT INTO mime_type (id, mime_type) VALUES (250, 'application/x-hwp');
INSERT INTO mime_type (id, mime_type) VALUES (251, 'application/x-pkcs7-certificates');
INSERT INTO mime_type (id, mime_type) VALUES (252, 'application/x-shockwave-flash');
INSERT INTO mime_type (id, mime_type) VALUES (253, 'application/x-turtle');
INSERT INTO mime_type (id, mime_type) VALUES (254, 'application/x-rar');
INSERT INTO mime_type (id, mime_type) VALUES (255, 'application/x-bittorrent');
INSERT INTO mime_type (id, mime_type) VALUES (256, 'application/prs.plucker');
INSERT INTO mime_type (id, mime_type) VALUES (257, 'application/smil');
INSERT INTO mime_type (id, mime_type) VALUES (258, 'application/x-abiword');
INSERT INTO mime_type (id, mime_type) VALUES (259, 'application/x-blender');
INSERT INTO mime_type (id, mime_type) VALUES (260, 'application/x-oleo');
INSERT INTO mime_type (id, mime_type) VALUES (261, 'application/x-font-sunos-news');
INSERT INTO mime_type (id, mime_type) VALUES (262, 'application/x-tex-gf');
INSERT INTO mime_type (id, mime_type) VALUES (263, 'application/x-netshow-channel');
INSERT INTO mime_type (id, mime_type) VALUES (264, 'application/x-m4');
INSERT INTO mime_type (id, mime_type) VALUES (265, 'application/x-kexiproject-sqlite2');
INSERT INTO mime_type (id, mime_type) VALUES (266, 'application/x-kpovmodeler');
INSERT INTO mime_type (id, mime_type) VALUES (267, 'application/illustrator');
INSERT INTO mime_type (id, mime_type) VALUES (268, 'application/x-font-snf');
INSERT INTO mime_type (id, mime_type) VALUES (269, 'application/x-gedcom');
INSERT INTO mime_type (id, mime_type) VALUES (270, 'application/x-kexiproject-shortcut');
INSERT INTO mime_type (id, mime_type) VALUES (271, 'application/andrew-inset');
INSERT INTO mime_type (id, mime_type) VALUES (272, 'application/x-bzdvi');
INSERT INTO mime_type (id, mime_type) VALUES (273, 'application/x-siag');
INSERT INTO mime_type (id, mime_type) VALUES (274, 'application/x-ktheme');
INSERT INTO mime_type (id, mime_type) VALUES (275, 'application/x-kspread');
INSERT INTO mime_type (id, mime_type) VALUES (276, 'application/x-cbr');
INSERT INTO mime_type (id, mime_type) VALUES (277, 'application/x-cmakecache');
INSERT INTO mime_type (id, mime_type) VALUES (278, 'application/x-font-framemaker');
INSERT INTO mime_type (id, mime_type) VALUES (279, 'application/x-msx-rom');
INSERT INTO mime_type (id, mime_type) VALUES (280, 'application/x-font-vfont');
INSERT INTO mime_type (id, mime_type) VALUES (281, 'application/x-font-ttx');
INSERT INTO mime_type (id, mime_type) VALUES (282, 'application/x-uml');
INSERT INTO mime_type (id, mime_type) VALUES (283, 'application/x-cdrdao-toc');
INSERT INTO mime_type (id, mime_type) VALUES (284, 'application/x-kpresenter');
INSERT INTO mime_type (id, mime_type) VALUES (285, 'application/x-kseg');
INSERT INTO mime_type (id, mime_type) VALUES (286, 'application/x-dvi');
INSERT INTO mime_type (id, mime_type) VALUES (287, 'application/x-java-applet');
INSERT INTO mime_type (id, mime_type) VALUES (288, 'application/x-palm-database');
INSERT INTO mime_type (id, mime_type) VALUES (289, 'application/pgp-encrypted');
INSERT INTO mime_type (id, mime_type) VALUES (290, 'application/x-pocket-word');
INSERT INTO mime_type (id, mime_type) VALUES (291, 'application/x-kmplot');
INSERT INTO mime_type (id, mime_type) VALUES (292, 'application/x-core');
INSERT INTO mime_type (id, mime_type) VALUES (293, 'application/x-profile');
INSERT INTO mime_type (id, mime_type) VALUES (294, 'application/x-mswinurl');
INSERT INTO mime_type (id, mime_type) VALUES (295, 'application/x-lha');
INSERT INTO mime_type (id, mime_type) VALUES (296, 'application/x-netcdf');
INSERT INTO mime_type (id, mime_type) VALUES (297, 'application/msword');
INSERT INTO mime_type (id, mime_type) VALUES (298, 'application/x-dar');
INSERT INTO mime_type (id, mime_type) VALUES (299, 'application/pgp-signature');
INSERT INTO mime_type (id, mime_type) VALUES (300, 'application/x-dmod');
INSERT INTO mime_type (id, mime_type) VALUES (301, 'application/x-fictionbook+xml');
INSERT INTO mime_type (id, mime_type) VALUES (302, 'application/x-gettext-translation');
INSERT INTO mime_type (id, mime_type) VALUES (303, 'application/x-ace');
INSERT INTO mime_type (id, mime_type) VALUES (304, 'application/x-macbinary');
INSERT INTO mime_type (id, mime_type) VALUES (305, 'application/x-nintendo-ds-rom');
INSERT INTO mime_type (id, mime_type) VALUES (306, 'application/x-troff-man-compressed');
INSERT INTO mime_type (id, mime_type) VALUES (307, 'application/x-java');
INSERT INTO mime_type (id, mime_type) VALUES (308, 'application/x-mimearchive');
INSERT INTO mime_type (id, mime_type) VALUES (309, 'application/xml-dtd');
INSERT INTO mime_type (id, mime_type) VALUES (310, 'application/x-smaf');
INSERT INTO mime_type (id, mime_type) VALUES (311, 'application/x-pw');
INSERT INTO mime_type (id, mime_type) VALUES (312, 'application/x-lhz');
INSERT INTO mime_type (id, mime_type) VALUES (313, 'application/x-dia-diagram');
INSERT INTO mime_type (id, mime_type) VALUES (314, 'application/x-kugar');
INSERT INTO mime_type (id, mime_type) VALUES (315, 'application/x-sv4cpio');
INSERT INTO mime_type (id, mime_type) VALUES (316, 'application/x-kcachegrind');
INSERT INTO mime_type (id, mime_type) VALUES (317, 'application/x-gnumeric');
INSERT INTO mime_type (id, mime_type) VALUES (318, 'application/x-fluid');
INSERT INTO mime_type (id, mime_type) VALUES (319, 'application/x-quattropro');
INSERT INTO mime_type (id, mime_type) VALUES (320, 'application/x-gzip');
INSERT INTO mime_type (id, mime_type) VALUES (321, 'application/x-shared-library-la');
INSERT INTO mime_type (id, mime_type) VALUES (322, 'application/x-gba-rom');
INSERT INTO mime_type (id, mime_type) VALUES (323, 'application/x-sc');
INSERT INTO mime_type (id, mime_type) VALUES (324, 'application/x-glade');
INSERT INTO mime_type (id, mime_type) VALUES (325, 'application/x-catalog');
INSERT INTO mime_type (id, mime_type) VALUES (326, 'application/x-php');
INSERT INTO mime_type (id, mime_type) VALUES (327, 'application/x-kexiproject-sqlite3');
INSERT INTO mime_type (id, mime_type) VALUES (328, 'application/x-asp');
INSERT INTO mime_type (id, mime_type) VALUES (329, 'application/x-sqlite2');
INSERT INTO mime_type (id, mime_type) VALUES (330, 'application/x-tzo');
INSERT INTO mime_type (id, mime_type) VALUES (331, 'application/x-wais-source');
INSERT INTO mime_type (id, mime_type) VALUES (332, 'application/x-jbuilder-project');
INSERT INTO mime_type (id, mime_type) VALUES (333, 'application/x-package-list');
INSERT INTO mime_type (id, mime_type) VALUES (334, 'application/annodex');
INSERT INTO mime_type (id, mime_type) VALUES (335, 'application/x-toutdoux');
INSERT INTO mime_type (id, mime_type) VALUES (336, 'application/x-stuffit');
INSERT INTO mime_type (id, mime_type) VALUES (337, 'application/pkcs10');
INSERT INTO mime_type (id, mime_type) VALUES (338, 'application/x-sv4crc');
INSERT INTO mime_type (id, mime_type) VALUES (339, 'application/x-java-keystore');
INSERT INTO mime_type (id, mime_type) VALUES (340, 'application/x-kommander');
INSERT INTO mime_type (id, mime_type) VALUES (341, 'application/x-sami');
INSERT INTO mime_type (id, mime_type) VALUES (342, 'application/xspf+xml');
INSERT INTO mime_type (id, mime_type) VALUES (343, 'application/x-killustrator');
INSERT INTO mime_type (id, mime_type) VALUES (344, 'application/x-kgetlist');
INSERT INTO mime_type (id, mime_type) VALUES (345, 'application/x-hdf');
INSERT INTO mime_type (id, mime_type) VALUES (346, 'application/x-mobipocket-ebook');
INSERT INTO mime_type (id, mime_type) VALUES (347, 'application/x-shellscript');
INSERT INTO mime_type (id, mime_type) VALUES (348, 'application/xhtml+xml');
INSERT INTO mime_type (id, mime_type) VALUES (349, 'application/x-compressed-tar');
INSERT INTO mime_type (id, mime_type) VALUES (350, 'application/x-nzb');
INSERT INTO mime_type (id, mime_type) VALUES (351, 'application/x-markaby');
INSERT INTO mime_type (id, mime_type) VALUES (352, 'application/x-sms-rom');
INSERT INTO mime_type (id, mime_type) VALUES (353, 'application/rtf');
INSERT INTO mime_type (id, mime_type) VALUES (354, 'application/x-tuberling');
INSERT INTO mime_type (id, mime_type) VALUES (355, 'application/x-kgeo');
INSERT INTO mime_type (id, mime_type) VALUES (356, 'application/x-n64-rom');
INSERT INTO mime_type (id, mime_type) VALUES (357, 'application/x-smb-server');
INSERT INTO mime_type (id, mime_type) VALUES (358, 'application/pkix-crl');
INSERT INTO mime_type (id, mime_type) VALUES (359, 'application/x-dbf');
INSERT INTO mime_type (id, mime_type) VALUES (360, 'application/x-webarchive');
INSERT INTO mime_type (id, mime_type) VALUES (361, 'application/x-smb-workgroup');
INSERT INTO mime_type (id, mime_type) VALUES (362, 'application/x-gnome-theme-package');
INSERT INTO mime_type (id, mime_type) VALUES (363, 'application/epub+zip');
INSERT INTO mime_type (id, mime_type) VALUES (364, 'application/x-kchart');
INSERT INTO mime_type (id, mime_type) VALUES (365, 'application/x-aportisdoc');
INSERT INTO mime_type (id, mime_type) VALUES (366, 'application/x-cisco-vpn-settings');
INSERT INTO mime_type (id, mime_type) VALUES (367, 'application/x-egon');
INSERT INTO mime_type (id, mime_type) VALUES (368, 'application/x-kword');
INSERT INTO mime_type (id, mime_type) VALUES (369, 'application/x-xbel');
INSERT INTO mime_type (id, mime_type) VALUES (370, 'application/x-font-type1');
INSERT INTO mime_type (id, mime_type) VALUES (371, 'application/x-lzip');
INSERT INTO mime_type (id, mime_type) VALUES (372, 'application/x-gdbm');
INSERT INTO mime_type (id, mime_type) VALUES (373, 'application/x-executable');
INSERT INTO mime_type (id, mime_type) VALUES (374, 'application/x-font-linux-psf');
INSERT INTO mime_type (id, mime_type) VALUES (375, 'application/x-font-tex-tfm');
INSERT INTO mime_type (id, mime_type) VALUES (376, 'application/x-font-afm');
INSERT INTO mime_type (id, mime_type) VALUES (377, 'application/x-kcsrc');
INSERT INTO mime_type (id, mime_type) VALUES (378, 'application/x-kontour');
INSERT INTO mime_type (id, mime_type) VALUES (379, 'application/x-msi');
INSERT INTO mime_type (id, mime_type) VALUES (380, 'application/x-cd-image');
INSERT INTO mime_type (id, mime_type) VALUES (381, 'application/x-font-libgrx');
INSERT INTO mime_type (id, mime_type) VALUES (382, 'application/x-designer');
INSERT INTO mime_type (id, mime_type) VALUES (383, 'application/x-nautilus-link');
INSERT INTO mime_type (id, mime_type) VALUES (384, 'application/x-zerosize');
INSERT INTO mime_type (id, mime_type) VALUES (385, 'application/x-superkaramba');
INSERT INTO mime_type (id, mime_type) VALUES (386, 'application/x-quanta');
INSERT INTO mime_type (id, mime_type) VALUES (387, 'application/ram');
INSERT INTO mime_type (id, mime_type) VALUES (388, 'application/javascript');
INSERT INTO mime_type (id, mime_type) VALUES (389, 'application/rdf+xml');
INSERT INTO mime_type (id, mime_type) VALUES (390, 'application/x-spss-por');
INSERT INTO mime_type (id, mime_type) VALUES (391, 'application/x-gnuplot');
INSERT INTO mime_type (id, mime_type) VALUES (392, 'application/x-kformula');
INSERT INTO mime_type (id, mime_type) VALUES (393, 'application/x-mif');
INSERT INTO mime_type (id, mime_type) VALUES (394, 'application/x-amipro');
INSERT INTO mime_type (id, mime_type) VALUES (395, 'application/x-slp');
INSERT INTO mime_type (id, mime_type) VALUES (396, 'application/x-audacity-project');
INSERT INTO mime_type (id, mime_type) VALUES (397, 'application/x-archive');
INSERT INTO mime_type (id, mime_type) VALUES (398, 'application/x-windows-themepack');
INSERT INTO mime_type (id, mime_type) VALUES (399, 'application/x-t602');
INSERT INTO mime_type (id, mime_type) VALUES (400, 'application/x-mswrite');
INSERT INTO mime_type (id, mime_type) VALUES (401, 'application/dicom');
INSERT INTO mime_type (id, mime_type) VALUES (402, 'application/x-gzdvi');
INSERT INTO mime_type (id, mime_type) VALUES (403, 'application/x-chm');
INSERT INTO mime_type (id, mime_type) VALUES (404, 'application/x-lzma-compressed-tar');
INSERT INTO mime_type (id, mime_type) VALUES (405, 'application/x-7z-compressed');
INSERT INTO mime_type (id, mime_type) VALUES (406, 'application/postscript');
INSERT INTO mime_type (id, mime_type) VALUES (407, 'application/x-gtktalog');
INSERT INTO mime_type (id, mime_type) VALUES (408, 'application/x-alz');
INSERT INTO mime_type (id, mime_type) VALUES (409, 'application/x-ustar');
INSERT INTO mime_type (id, mime_type) VALUES (410, 'application/x-troff-man');
INSERT INTO mime_type (id, mime_type) VALUES (411, 'application/xml');
INSERT INTO mime_type (id, mime_type) VALUES (412, 'application/sieve');
INSERT INTO mime_type (id, mime_type) VALUES (413, 'application/x-konsole');
INSERT INTO mime_type (id, mime_type) VALUES (414, 'application/x-dc-rom');
INSERT INTO mime_type (id, mime_type) VALUES (415, 'application/xsd');
INSERT INTO mime_type (id, mime_type) VALUES (416, 'application/pkcs7-mime');
INSERT INTO mime_type (id, mime_type) VALUES (417, 'application/x-xz');
INSERT INTO mime_type (id, mime_type) VALUES (418, 'application/x-cda');
INSERT INTO mime_type (id, mime_type) VALUES (419, 'application/x-abicollab');
INSERT INTO mime_type (id, mime_type) VALUES (420, 'application/x-cpio');
INSERT INTO mime_type (id, mime_type) VALUES (421, 'application/x-tgif');
INSERT INTO mime_type (id, mime_type) VALUES (422, 'application/x-class-file');
INSERT INTO mime_type (id, mime_type) VALUES (423, 'application/x-desktop');
INSERT INTO mime_type (id, mime_type) VALUES (424, 'application/x-reject');
INSERT INTO mime_type (id, mime_type) VALUES (425, 'application/x-xz-compressed-tar');
INSERT INTO mime_type (id, mime_type) VALUES (426, 'application/x-kivio');
INSERT INTO mime_type (id, mime_type) VALUES (427, 'application/x-kopete-emoticons');
INSERT INTO mime_type (id, mime_type) VALUES (428, 'application/x-kexi-connectiondata');
INSERT INTO mime_type (id, mime_type) VALUES (429, 'application/x-compress');
INSERT INTO mime_type (id, mime_type) VALUES (430, 'application/x-gmc-link');
INSERT INTO mime_type (id, mime_type) VALUES (431, 'application/x-krita');
INSERT INTO mime_type (id, mime_type) VALUES (432, 'application/x-java-archive');
INSERT INTO mime_type (id, mime_type) VALUES (433, 'application/x-theme');
INSERT INTO mime_type (id, mime_type) VALUES (434, 'application/x-deb');
INSERT INTO mime_type (id, mime_type) VALUES (435, 'application/x-gnucash');
INSERT INTO mime_type (id, mime_type) VALUES (436, 'application/x-cabri');
INSERT INTO mime_type (id, mime_type) VALUES (437, 'application/x-font-otf');
INSERT INTO mime_type (id, mime_type) VALUES (438, 'application/x-kexiproject-sqlite');
INSERT INTO mime_type (id, mime_type) VALUES (439, 'application/x-lzma');
INSERT INTO mime_type (id, mime_type) VALUES (440, 'application/rss+xml');
INSERT INTO mime_type (id, mime_type) VALUES (441, 'application/x-khtml-adaptor');
INSERT INTO mime_type (id, mime_type) VALUES (442, 'application/x-gzpostscript');
INSERT INTO mime_type (id, mime_type) VALUES (443, 'application/x-bzip');
INSERT INTO mime_type (id, mime_type) VALUES (444, 'application/mathml+xml');
INSERT INTO mime_type (id, mime_type) VALUES (445, 'application/x-chess-pgn');
INSERT INTO mime_type (id, mime_type) VALUES (446, 'application/x-remote-connection');
INSERT INTO mime_type (id, mime_type) VALUES (447, 'application/x-gameboy-rom');
INSERT INTO mime_type (id, mime_type) VALUES (448, 'application/pkix-pkipath');
INSERT INTO mime_type (id, mime_type) VALUES (449, 'application/x-shorten');
INSERT INTO mime_type (id, mime_type) VALUES (450, 'application/x-snes-rom');
INSERT INTO mime_type (id, mime_type) VALUES (451, 'application/x-quicktime-media-link');
INSERT INTO mime_type (id, mime_type) VALUES (452, 'application/x-ruby');
INSERT INTO mime_type (id, mime_type) VALUES (453, 'application/x-tarz');
INSERT INTO mime_type (id, mime_type) VALUES (454, 'application/ogg');
INSERT INTO mime_type (id, mime_type) VALUES (455, 'application/x-ole-storage');
INSERT INTO mime_type (id, mime_type) VALUES (456, 'application/x-shar');
INSERT INTO mime_type (id, mime_type) VALUES (457, 'application/x-ksysv-package');
INSERT INTO mime_type (id, mime_type) VALUES (458, 'application/x-x509-ca-cert');
INSERT INTO mime_type (id, mime_type) VALUES (459, 'application/x-par2');
INSERT INTO mime_type (id, mime_type) VALUES (460, 'application/x-linguist');
INSERT INTO mime_type (id, mime_type) VALUES (461, 'application/x-trig');
INSERT INTO mime_type (id, mime_type) VALUES (462, 'application/mac-binhex40');
INSERT INTO mime_type (id, mime_type) VALUES (463, 'application/x-qw');
INSERT INTO mime_type (id, mime_type) VALUES (464, 'application/xml-external-parsed-entity');
INSERT INTO mime_type (id, mime_type) VALUES (465, 'application/octet-stream');
INSERT INTO mime_type (id, mime_type) VALUES (466, 'application/x-matroska');
INSERT INTO mime_type (id, mime_type) VALUES (467, 'application/x-applix-spreadsheet');
INSERT INTO mime_type (id, mime_type) VALUES (468, 'application/x-plasma');
INSERT INTO mime_type (id, mime_type) VALUES (469, 'application/x-e-theme');
INSERT INTO mime_type (id, mime_type) VALUES (470, 'application/x-cbz');
INSERT INTO mime_type (id, mime_type) VALUES (471, 'application/x-java-jnlp-file');
INSERT INTO mime_type (id, mime_type) VALUES (472, 'application/x-kns');
INSERT INTO mime_type (id, mime_type) VALUES (473, 'application/x-win-lnk');
INSERT INTO mime_type (id, mime_type) VALUES (474, 'application/x-ufraw');
INSERT INTO mime_type (id, mime_type) VALUES (475, 'application/x-drgeo');
INSERT INTO mime_type (id, mime_type) VALUES (476, 'application/x-perl');
INSERT INTO mime_type (id, mime_type) VALUES (477, 'application/pkcs7-signature');
INSERT INTO mime_type (id, mime_type) VALUES (478, 'application/x-ms-dos-executable');
INSERT INTO mime_type (id, mime_type) VALUES (479, 'application/x-font-tex');
INSERT INTO mime_type (id, mime_type) VALUES (480, 'application/x-kolf');
INSERT INTO mime_type (id, mime_type) VALUES (481, 'application/x-planperfect');
INSERT INTO mime_type (id, mime_type) VALUES (482, 'application/x-go-sgf');
INSERT INTO mime_type (id, mime_type) VALUES (483, 'application/x-kwallet');
INSERT INTO mime_type (id, mime_type) VALUES (484, 'application/x-rpm');
INSERT INTO mime_type (id, mime_type) VALUES (485, 'application/sdp');
INSERT INTO mime_type (id, mime_type) VALUES (486, 'application/x-java-pack200');
INSERT INTO mime_type (id, mime_type) VALUES (487, 'application/relaxng');
INSERT INTO mime_type (id, mime_type) VALUES (488, 'application/x-servicepack');
INSERT INTO mime_type (id, mime_type) VALUES (489, 'application/x-font-bdf');
INSERT INTO mime_type (id, mime_type) VALUES (490, 'application/pkix-cert');
INSERT INTO mime_type (id, mime_type) VALUES (491, 'application/x-ipod-firmware');
INSERT INTO mime_type (id, mime_type) VALUES (492, 'application/x-object');
INSERT INTO mime_type (id, mime_type) VALUES (493, 'application/x-ica');
INSERT INTO mime_type (id, mime_type) VALUES (494, 'application/x-it87');
INSERT INTO mime_type (id, mime_type) VALUES (495, 'application/x-zoo');
INSERT INTO mime_type (id, mime_type) VALUES (496, 'application/x-gzpdf');
INSERT INTO mime_type (id, mime_type) VALUES (497, 'application/x-magicpoint');
INSERT INTO mime_type (id, mime_type) VALUES (498, 'application/docbook+xml');
INSERT INTO mime_type (id, mime_type) VALUES (499, 'application/x-csh');
INSERT INTO mime_type (id, mime_type) VALUES (500, 'application/x-nes-rom');
INSERT INTO mime_type (id, mime_type) VALUES (501, 'application/x-graphite');
INSERT INTO mime_type (id, mime_type) VALUES (502, 'application/x-spss-sav');
INSERT INTO mime_type (id, mime_type) VALUES (503, 'application/x-tar');
INSERT INTO mime_type (id, mime_type) VALUES (504, 'application/x-kvtml');
INSERT INTO mime_type (id, mime_type) VALUES (505, 'application/metalink+xml');
INSERT INTO mime_type (id, mime_type) VALUES (506, 'application/ecmascript');
INSERT INTO mime_type (id, mime_type) VALUES (507, 'application/x-hwt');
INSERT INTO mime_type (id, mime_type) VALUES (508, 'application/x-pak');
INSERT INTO mime_type (id, mime_type) VALUES (509, 'application/x-sqlite3');
INSERT INTO mime_type (id, mime_type) VALUES (510, 'application/x-trash');
INSERT INTO mime_type (id, mime_type) VALUES (511, 'application/x-arj');
INSERT INTO mime_type (id, mime_type) VALUES (512, 'application/x-k3b');
INSERT INTO mime_type (id, mime_type) VALUES (513, 'application/x-font-pcf');
INSERT INTO mime_type (id, mime_type) VALUES (514, 'application/oda');
INSERT INTO mime_type (id, mime_type) VALUES (515, 'application/x-genesis-rom');
INSERT INTO mime_type (id, mime_type) VALUES (516, 'application/x-font-ttf');
INSERT INTO mime_type (id, mime_type) VALUES (517, 'application/zip');
INSERT INTO mime_type (id, mime_type) VALUES (518, 'application/x-cbt');
INSERT INTO mime_type (id, mime_type) VALUES (519, 'application/x-kspread-crypt');
INSERT INTO mime_type (id, mime_type) VALUES (520, 'application/x-pef-executable');
INSERT INTO mime_type (id, mime_type) VALUES (521, 'application/x-brasero');
INSERT INTO mime_type (id, mime_type) VALUES (522, 'application/x-cb7');
INSERT INTO mime_type (id, mime_type) VALUES (523, 'application/x-frame');
INSERT INTO mime_type (id, mime_type) VALUES (524, 'application/x-lyx');
INSERT INTO mime_type (id, mime_type) VALUES (525, 'application/x-lzop');
INSERT INTO mime_type (id, mime_type) VALUES (526, 'application/x-planner');
INSERT INTO mime_type (id, mime_type) VALUES (527, 'application/x-vnc');
INSERT INTO mime_type (id, mime_type) VALUES (528, 'application/atom+xml');
INSERT INTO mime_type (id, mime_type) VALUES (529, 'application/x-gz-font-linux-psf');
INSERT INTO mime_type (id, mime_type) VALUES (530, 'application/x-xliff');
INSERT INTO mime_type (id, mime_type) VALUES (531, 'application/mathematica');
INSERT INTO mime_type (id, mime_type) VALUES (532, 'application/xslt+xml');
INSERT INTO mime_type (id, mime_type) VALUES (533, 'application/x-sharedlib');
INSERT INTO mime_type (id, mime_type) VALUES (534, 'application/x-kwordquiz');
INSERT INTO mime_type (id, mime_type) VALUES (535, 'application/x-bzpostscript');
INSERT INTO mime_type (id, mime_type) VALUES (536, 'application/x-pkcs12');
INSERT INTO mime_type (id, mime_type) VALUES (537, 'application/x-mozilla-bookmarks');
INSERT INTO mime_type (id, mime_type) VALUES (538, 'application/x-awk');
INSERT INTO mime_type (id, mime_type) VALUES (539, 'application/x-navi-animation');
INSERT INTO mime_type (id, mime_type) VALUES (540, 'application/x-cpio-compressed');
INSERT INTO mime_type (id, mime_type) VALUES (541, 'application/x-arc');
INSERT INTO mime_type (id, mime_type) VALUES (542, 'application/x-icq');
INSERT INTO mime_type (id, mime_type) VALUES (543, 'application/x-bzpdf');
INSERT INTO mime_type (id, mime_type) VALUES (544, 'application/mbox');
INSERT INTO mime_type (id, mime_type) VALUES (545, 'application/x-ksysguard');
INSERT INTO mime_type (id, mime_type) VALUES (546, 'application/x-java-jce-keystore');
INSERT INTO mime_type (id, mime_type) VALUES (547, 'application/x-subrip');
INSERT INTO mime_type (id, mime_type) VALUES (548, 'application/x-karbon');
INSERT INTO mime_type (id, mime_type) VALUES (549, 'application/x-python-bytecode');
INSERT INTO mime_type (id, mime_type) VALUES (550, 'application/x-font-dos');
INSERT INTO mime_type (id, mime_type) VALUES (551, 'application/pgp-keys');
INSERT INTO mime_type (id, mime_type) VALUES (552, 'application/x-font-speedo');
INSERT INTO mime_type (id, mime_type) VALUES (553, 'application/pdf');
INSERT INTO mime_type (id, mime_type) VALUES (554, 'application/x-cue');
INSERT INTO mime_type (id, mime_type) VALUES (555, 'application/x-gnome-saved-search');
INSERT INTO mime_type (id, mime_type) VALUES (556, 'application/x-bcpio');
INSERT INTO mime_type (id, mime_type) VALUES (557, 'application/x-applix-word');
INSERT INTO mime_type (id, mime_type) VALUES (558, 'application/mxf');
INSERT INTO mime_type (id, mime_type) VALUES (559, 'application/x-wpg');
INSERT INTO mime_type (id, mime_type) VALUES (560, 'application/x-bzip-compressed-tar');
INSERT INTO mime_type (id, mime_type) VALUES (561, 'application/x-kword-crypt');
INSERT INTO mime_type (id, mime_type) VALUES (562, 'application/x-kig');
INSERT INTO mime_type (id, mime_type) VALUES (563, 'application/gnunet-directory');
INSERT INTO mime_type (id, mime_type) VALUES (564, 'application/x-kourse');
INSERT INTO mime_type (id, mime_type) VALUES (565, 'application/x-kudesigner');
INSERT INTO mime_type (id, mime_type) VALUES (566, 'application/x-tex-pk');
INSERT INTO mime_type (id, mime_type) VALUES (567, 'video/x-ms-asf');
INSERT INTO mime_type (id, mime_type) VALUES (568, 'video/mp4');
INSERT INTO mime_type (id, mime_type) VALUES (569, 'video/mpeg');
INSERT INTO mime_type (id, mime_type) VALUES (570, 'video/annodex');
INSERT INTO mime_type (id, mime_type) VALUES (571, 'video/x-sgi-movie');
INSERT INTO mime_type (id, mime_type) VALUES (572, 'video/isivideo');
INSERT INTO mime_type (id, mime_type) VALUES (573, 'video/x-ogm+ogg');
INSERT INTO mime_type (id, mime_type) VALUES (574, 'video/x-mng');
INSERT INTO mime_type (id, mime_type) VALUES (575, 'video/x-flv');
INSERT INTO mime_type (id, mime_type) VALUES (576, 'video/x-flic');
INSERT INTO mime_type (id, mime_type) VALUES (577, 'video/x-theora+ogg');
INSERT INTO mime_type (id, mime_type) VALUES (578, 'video/3gpp');
INSERT INTO mime_type (id, mime_type) VALUES (579, 'video/x-ms-wmv');
INSERT INTO mime_type (id, mime_type) VALUES (580, 'video/ogg');
INSERT INTO mime_type (id, mime_type) VALUES (581, 'video/dv');
INSERT INTO mime_type (id, mime_type) VALUES (582, 'video/x-matroska');
INSERT INTO mime_type (id, mime_type) VALUES (583, 'video/vivo');
INSERT INTO mime_type (id, mime_type) VALUES (584, 'video/quicktime');
INSERT INTO mime_type (id, mime_type) VALUES (585, 'video/x-ms-wmp');
INSERT INTO mime_type (id, mime_type) VALUES (586, 'video/x-msvideo');
INSERT INTO mime_type (id, mime_type) VALUES (587, 'video/x-anim');
INSERT INTO mime_type (id, mime_type) VALUES (588, 'video/wavelet');
INSERT INTO mime_type (id, mime_type) VALUES (589, 'video/x-nsv');
INSERT INTO mime_type (id, mime_type) VALUES (590, 'interface/x-winamp-skin');
INSERT INTO mime_type (id, mime_type) VALUES (591, 'multipart/encrypted');
INSERT INTO mime_type (id, mime_type) VALUES (592, 'multipart/x-mixed-replace');
INSERT INTO mime_type (id, mime_type) VALUES (593, 'multipart/related');
INSERT INTO mime_type (id, mime_type) VALUES (594, 'multipart/report');
INSERT INTO mime_type (id, mime_type) VALUES (595, 'multipart/signed');
INSERT INTO mime_type (id, mime_type) VALUES (596, 'multipart/appledouble');
INSERT INTO mime_type (id, mime_type) VALUES (597, 'multipart/mixed');
INSERT INTO mime_type (id, mime_type) VALUES (598, 'multipart/alternative');
INSERT INTO mime_type (id, mime_type) VALUES (599, 'multipart/digest');
INSERT INTO mime_type (id, mime_type) VALUES (600, 'audio/vnd.rn-realaudio');
INSERT INTO mime_type (id, mime_type) VALUES (601, 'image/vnd.dwg');
INSERT INTO mime_type (id, mime_type) VALUES (602, 'image/vnd.djvu');
INSERT INTO mime_type (id, mime_type) VALUES (603, 'image/vnd.rn-realpix');
INSERT INTO mime_type (id, mime_type) VALUES (604, 'image/vnd.dxf');
INSERT INTO mime_type (id, mime_type) VALUES (605, 'image/vnd.wap.wbmp');
INSERT INTO mime_type (id, mime_type) VALUES (606, 'image/vnd.ms-modi');
INSERT INTO mime_type (id, mime_type) VALUES (607, 'image/vnd.microsoft.icon');
INSERT INTO mime_type (id, mime_type) VALUES (608, 'image/vnd.adobe.photoshop');
INSERT INTO mime_type (id, mime_type) VALUES (609, 'text/vnd.wap.wml');
INSERT INTO mime_type (id, mime_type) VALUES (610, 'text/vnd.wap.wmlscript');
INSERT INTO mime_type (id, mime_type) VALUES (611, 'text/vnd.sun.j2me.app-descriptor');
INSERT INTO mime_type (id, mime_type) VALUES (612, 'text/vnd.abc');
INSERT INTO mime_type (id, mime_type) VALUES (613, 'text/vnd.rn-realtext');
INSERT INTO mime_type (id, mime_type) VALUES (614, 'text/vnd.graphviz');
INSERT INTO mime_type (id, mime_type) VALUES (615, 'application/vnd.mozilla.xul+xml');
INSERT INTO mime_type (id, mime_type) VALUES (616, 'application/vnd.oasis.opendocument.text-web');
INSERT INTO mime_type (id, mime_type) VALUES (617, 'application/x-vnd.kde.kexi');
INSERT INTO mime_type (id, mime_type) VALUES (618, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
INSERT INTO mime_type (id, mime_type) VALUES (619, 'application/vnd.ms-word.document.macroenabled.12');
INSERT INTO mime_type (id, mime_type) VALUES (620, 'application/vnd.scribus');
INSERT INTO mime_type (id, mime_type) VALUES (621, 'application/vnd.sun.xml.writer.global');
INSERT INTO mime_type (id, mime_type) VALUES (622, 'application/vnd.emusic-emusic_package');
INSERT INTO mime_type (id, mime_type) VALUES (623, 'application/vnd.hp-pcl');
INSERT INTO mime_type (id, mime_type) VALUES (624, 'application/vnd.stardivision.mail');
INSERT INTO mime_type (id, mime_type) VALUES (625, 'application/vnd.google-earth.kml+xml');
INSERT INTO mime_type (id, mime_type) VALUES (626, 'application/x-vnd.kde.plan');
INSERT INTO mime_type (id, mime_type) VALUES (627, 'application/vnd.kde.okular-archive');
INSERT INTO mime_type (id, mime_type) VALUES (628, 'application/vnd.openxmlformats-officedocument.presentationml.presentation');
INSERT INTO mime_type (id, mime_type) VALUES (629, 'application/vnd.ms-wpl');
INSERT INTO mime_type (id, mime_type) VALUES (630, 'application/vnd.oasis.opendocument.formula');
INSERT INTO mime_type (id, mime_type) VALUES (631, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
INSERT INTO mime_type (id, mime_type) VALUES (632, 'application/vnd.oasis.opendocument.text-flat-xml');
INSERT INTO mime_type (id, mime_type) VALUES (633, 'application/vnd.oasis.opendocument.chart');
INSERT INTO mime_type (id, mime_type) VALUES (634, 'application/x-vnd.kde.plan.work');
INSERT INTO mime_type (id, mime_type) VALUES (635, 'application/vnd.ms-excel.sheet.macroenabled.12');
INSERT INTO mime_type (id, mime_type) VALUES (636, 'application/vnd.lotus-1-2-3');
INSERT INTO mime_type (id, mime_type) VALUES (637, 'application/vnd.hp-hpgl');
INSERT INTO mime_type (id, mime_type) VALUES (638, 'application/vnd.sun.xml.writer');
INSERT INTO mime_type (id, mime_type) VALUES (639, 'application/vnd.oasis.opendocument.text-master');
INSERT INTO mime_type (id, mime_type) VALUES (640, 'application/vnd.corel-draw');
INSERT INTO mime_type (id, mime_type) VALUES (641, 'application/vnd.stardivision.draw');
INSERT INTO mime_type (id, mime_type) VALUES (642, 'application/vnd.oasis.opendocument.spreadsheet');
INSERT INTO mime_type (id, mime_type) VALUES (643, 'application/vnd.stardivision.calc');
INSERT INTO mime_type (id, mime_type) VALUES (644, 'application/vnd.ms-powerpoint.presentation.macroenabled.12');
INSERT INTO mime_type (id, mime_type) VALUES (645, 'application/x-vnd.kde.kplato');
INSERT INTO mime_type (id, mime_type) VALUES (646, 'application/vnd.oasis.opendocument.text');
INSERT INTO mime_type (id, mime_type) VALUES (647, 'application/vnd.stardivision.math');
INSERT INTO mime_type (id, mime_type) VALUES (648, 'application/vnd.stardivision.writer');
INSERT INTO mime_type (id, mime_type) VALUES (649, 'application/vnd.oasis.opendocument.graphics-flat-xml');
INSERT INTO mime_type (id, mime_type) VALUES (650, 'application/vnd.sun.xml.impress');
INSERT INTO mime_type (id, mime_type) VALUES (651, 'application/vnd.oasis.opendocument.spreadsheet-flat-xml');
INSERT INTO mime_type (id, mime_type) VALUES (652, 'application/vnd.htmldoc-book');
INSERT INTO mime_type (id, mime_type) VALUES (653, 'application/vnd.symbian.install');
INSERT INTO mime_type (id, mime_type) VALUES (654, 'application/vnd.ms-excel.sheet.binary.macroenabled.12');
INSERT INTO mime_type (id, mime_type) VALUES (655, 'application/vnd.google-earth.kmz');
INSERT INTO mime_type (id, mime_type) VALUES (656, 'application/x-vnd.kde.kplato.work');
INSERT INTO mime_type (id, mime_type) VALUES (657, 'application/vnd.ms-excel');
INSERT INTO mime_type (id, mime_type) VALUES (658, 'application/vnd.kde.kphotoalbum-import');
INSERT INTO mime_type (id, mime_type) VALUES (659, 'application/vnd.sun.xml.draw');
INSERT INTO mime_type (id, mime_type) VALUES (660, 'application/vnd.openxmlformats-officedocument.presentationml.slideshow');
INSERT INTO mime_type (id, mime_type) VALUES (661, 'application/vnd.sun.xml.calc');
INSERT INTO mime_type (id, mime_type) VALUES (662, 'application/vnd.ms-cab-compressed');
INSERT INTO mime_type (id, mime_type) VALUES (663, 'application/vnd.sun.xml.base');
INSERT INTO mime_type (id, mime_type) VALUES (664, 'application/vnd.sun.xml.math');
INSERT INTO mime_type (id, mime_type) VALUES (665, 'application/vnd.ms-powerpoint');
INSERT INTO mime_type (id, mime_type) VALUES (666, 'application/vnd.apple.mpegurl');
INSERT INTO mime_type (id, mime_type) VALUES (667, 'application/vnd.ms-works');
INSERT INTO mime_type (id, mime_type) VALUES (668, 'application/vnd.oasis.opendocument.image');
INSERT INTO mime_type (id, mime_type) VALUES (669, 'application/x-vnd.kde.contactgroup');
INSERT INTO mime_type (id, mime_type) VALUES (670, 'application/vnd.oasis.opendocument.presentation');
INSERT INTO mime_type (id, mime_type) VALUES (671, 'application/vnd.rn-realmedia');
INSERT INTO mime_type (id, mime_type) VALUES (672, 'application/vnd.oasis.opendocument.database');
INSERT INTO mime_type (id, mime_type) VALUES (673, 'application/vnd.stardivision.impress');
INSERT INTO mime_type (id, mime_type) VALUES (674, 'application/vnd.ms-access');
INSERT INTO mime_type (id, mime_type) VALUES (675, 'application/vnd.openofficeorg.extension');
INSERT INTO mime_type (id, mime_type) VALUES (676, 'application/vnd.ms-xpsdocument');
INSERT INTO mime_type (id, mime_type) VALUES (677, 'application/vnd.oasis.opendocument.presentation-flat-xml');
INSERT INTO mime_type (id, mime_type) VALUES (678, 'application/vnd.stardivision.chart');
INSERT INTO mime_type (id, mime_type) VALUES (679, 'application/vnd.wordperfect');
INSERT INTO mime_type (id, mime_type) VALUES (680, 'application/x-vnd.kde.kugar.mixed');
INSERT INTO mime_type (id, mime_type) VALUES (681, 'application/vnd.iccprofile');
INSERT INTO mime_type (id, mime_type) VALUES (682, 'application/vnd.oasis.opendocument.graphics');
INSERT INTO mime_type (id, mime_type) VALUES (683, 'application/vnd.ms-tnef');
INSERT INTO mime_type (id, mime_type) VALUES (684, 'video/vnd.rn-realvideo');


--
-- Data for Name: file_base; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oe_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO oe_class (id, oe_class) VALUES (1, 'Sales Order');
INSERT INTO oe_class (id, oe_class) VALUES (2, 'Purchase Order');
INSERT INTO oe_class (id, oe_class) VALUES (3, 'Quotation');
INSERT INTO oe_class (id, oe_class) VALUES (4, 'RFQ');


--
-- Data for Name: oe; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_order; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_order_to_order; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_order_to_tx; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_part; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_secondary_attachment; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_transaction; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_tx_to_order; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_view_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO file_view_catalog (file_class, view_name) VALUES (1, 'file_tx_links');
INSERT INTO file_view_catalog (file_class, view_name) VALUES (2, 'file_order_links');


--
-- Data for Name: gifi; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO invoice (id, trans_id, parts_id, description, qty, allocated, sellprice, "precision", fxsellprice, discount, assemblyitem, unit, project_id, deliverydate, serialnumber, notes) VALUES (1, 1, 1, '', 1, 0, 100, 2, 100, 0, false, '20', NULL, NULL, '', '');
INSERT INTO invoice (id, trans_id, parts_id, description, qty, allocated, sellprice, "precision", fxsellprice, discount, assemblyitem, unit, project_id, deliverydate, serialnumber, notes) VALUES (2, 2, 2, '', 1, 0, 246.91, 2, 200, 0, false, '30', NULL, NULL, '', '');


--
-- Data for Name: invoice_note; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: invoice_tax_form; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO invoice_tax_form (invoice_id, reportable) VALUES (1, false);
INSERT INTO invoice_tax_form (invoice_id, reportable) VALUES (2, false);


--
-- Data for Name: jcitems; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: lsmb_roles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__account_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__account_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__account_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_all_transactions');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_all_vouchers');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_invoice_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_invoice_create_voucher');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_transaction_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_transaction_create_voucher');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_transaction_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ar_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ar_invoice_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ar_transaction_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ar_transaction_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ar_transaction_create_voucher');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ar_transaction_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__assembly_stock');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__assets_administer');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__assets_approve');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__assets_depreciate');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__assets_enter');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__audit_trail_maintenance');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__auditor');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__backup');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__batch_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__batch_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__batch_post');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__business_type_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__business_type_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__business_type_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__cash_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__close_till');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__contact_all_rights');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__contact_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__contact_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__contact_read');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__department_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__department_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__department_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__draft_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__employees_manage');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__exchangerate_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__file_attach_order');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__file_attach_part');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__file_attach_tx');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__file_read');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__financial_reports');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__gifi_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__gifi_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__gl_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__gl_reports');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__gl_transaction_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__gl_voucher_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__inventory_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__inventory_receive');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__inventory_reports');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__inventory_ship');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__inventory_transfer');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__language_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__language_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__list_all_open');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__manual_translation_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__orders_generate');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__orders_manage');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__orders_purchase_consolidate');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__orders_sales_consolidate');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__orders_sales_to_purchase');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__part_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__part_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__part_translation_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__partsgroup_translation_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__payment_process');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__pos_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__pos_cashier');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__pos_enter');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__pricegroup_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__pricegroup_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__print_jobs');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__print_jobs_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__project_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__project_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__project_order_generate');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__project_timecard_add');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__project_timecard_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__project_translation_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__purchase_order_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__purchase_order_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__purchase_order_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__receipt_process');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__reconciliation_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__reconciliation_approve');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__reconciliation_enter');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__recurring');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__rfq_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__rfq_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sales_order_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sales_order_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sales_order_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sales_quotation_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sales_quotation_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sic_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sic_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sic_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__system_admin');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__system_settings_change');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__system_settings_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__tax_form_save');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__taxes_set');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__template_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__users_manage');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__voucher_delete');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__warehouse_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__warehouse_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__yearend_run');


--
-- Data for Name: makemodel; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: menu_node; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO menu_node (id, label, parent, "position") VALUES (205, 'Transaction Approval', 0, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (206, 'Batches', 205, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (46, 'HR', 0, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (50, 'Order Entry', 0, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (63, 'Shipping', 0, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (67, 'Quotations', 0, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (73, 'General Journal', 0, 10);
INSERT INTO menu_node (id, label, parent, "position") VALUES (77, 'Goods and Services', 0, 11);
INSERT INTO menu_node (id, label, parent, "position") VALUES (0, 'Top-level', NULL, 0);
INSERT INTO menu_node (id, label, parent, "position") VALUES (1, 'AR', 0, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (2, 'Add Transaction', 1, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (5, 'Transactions', 4, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (6, 'Outstanding', 4, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (7, 'AR Aging', 4, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (9, 'Taxable Sales', 4, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (10, 'Non-Taxable', 4, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (12, 'Add Customer', 11, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (13, 'Reports', 11, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (14, 'Search', 13, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (15, 'History', 13, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (16, 'Point of Sale', 0, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (17, 'Sale', 16, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (18, 'Open', 16, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (19, 'Receipts', 16, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (20, 'Close Till', 16, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (21, 'AP', 0, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (22, 'Add Transaction', 21, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (145, 'Add Department', 144, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (25, 'Transactions', 24, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (26, 'Outstanding', 24, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (27, 'AP Aging', 24, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (28, 'Taxable', 24, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (29, 'Non-taxable', 24, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (31, 'Add Vendor', 30, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (32, 'Reports', 30, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (33, 'Search', 32, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (34, 'History', 32, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (35, 'Cash', 0, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (36, 'Receipt', 35, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (38, 'Payment', 35, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (223, 'Use Overpayment', 35, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (37, 'Use AR Overpayment', 35, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (146, 'List Departments', 144, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (42, 'Receipts', 41, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (43, 'Payments', 41, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (44, 'Reconciliation', 41, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (47, 'Employees', 46, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (48, 'Add Employee', 47, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (49, 'Search', 47, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (51, 'Sales Order', 50, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (52, 'Purchase Order', 50, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (53, 'Reports', 50, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (54, 'Sales Orders', 53, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (55, 'Purchase Orders', 53, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (57, 'Sales Orders', 56, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (58, 'Purchase Orders', 56, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (56, 'Generate', 50, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (60, 'Consolidate', 50, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (61, 'Sales Orders', 60, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (62, 'Purchase Orders', 60, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (64, 'Ship', 63, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (65, 'Receive', 63, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (66, 'Transfer', 63, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (68, 'Quotation', 67, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (69, 'RFQ', 67, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (70, 'Reports', 67, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (71, 'Quotations', 70, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (72, 'RFQs', 70, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (74, 'Journal Entry', 73, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (75, 'Adjust Till', 73, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (76, 'Reports', 73, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (78, 'Add Part', 77, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (79, 'Add Service', 77, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (80, 'Add Assembly', 77, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (81, 'Add Overhead', 77, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (82, 'Add Group', 77, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (83, 'Add Pricegroup', 77, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (84, 'Stock Assembly', 77, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (85, 'Reports', 77, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (86, 'All Items', 85, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (87, 'Parts', 85, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (88, 'Requirements', 85, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (89, 'Services', 85, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (90, 'Labor', 85, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (91, 'Groups', 85, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (92, 'Pricegroups', 85, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (93, 'Assembly', 85, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (94, 'Components', 85, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (95, 'Translations', 77, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (96, 'Description', 95, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (97, 'Partsgroup', 95, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (99, 'Add Project', 98, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (100, 'Add Timecard', 98, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (101, 'Generate', 98, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (102, 'Sales Orders', 101, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (103, 'Reports', 98, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (104, 'Search', 103, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (105, 'Transactions', 103, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (106, 'Time Cards', 103, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (107, 'Translations', 98, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (108, 'Description', 107, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (110, 'Chart of Accounts', 109, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (111, 'Trial Balance', 109, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (112, 'Income Statement', 109, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (113, 'Balance Sheet', 109, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (114, 'Inventory Activity', 109, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (117, 'Sales Invoices', 116, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (118, 'Sales Orders', 116, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (119, 'Checks', 116, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (120, 'Work Orders', 116, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (121, 'Quotations', 116, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (122, 'Packing Lists', 116, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (123, 'Pick Lists', 116, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (124, 'Purchase Orders', 116, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (125, 'Bin Lists', 116, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (126, 'RFQs', 116, 10);
INSERT INTO menu_node (id, label, parent, "position") VALUES (127, 'Time Cards', 116, 11);
INSERT INTO menu_node (id, label, parent, "position") VALUES (129, 'Audit Control', 128, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (130, 'Taxes', 128, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (131, 'Defaults', 128, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (132, 'Yearend', 128, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (137, 'Add Accounts', 136, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (138, 'List Accounts', 136, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (139, 'Add GIFI', 136, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (140, 'List GIFI', 136, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (142, 'Add Warehouse', 141, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (143, 'List Warehouse', 141, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (148, 'Add Business', 147, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (149, 'List Businesses', 147, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (151, 'Add Language', 150, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (152, 'List Languages', 150, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (154, 'Add SIC', 153, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (155, 'List SIC', 153, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (157, 'Income Statement', 156, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (158, 'Balance Sheet', 156, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (159, 'Invoice', 156, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (160, 'AR Transaction', 156, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (161, 'AP Transaction', 156, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (162, 'Packing List', 156, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (163, 'Pick List', 156, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (164, 'Sales Order', 156, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (165, 'Work Order', 156, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (166, 'Purchase Order', 156, 10);
INSERT INTO menu_node (id, label, parent, "position") VALUES (167, 'Bin List', 156, 11);
INSERT INTO menu_node (id, label, parent, "position") VALUES (168, 'Statement', 156, 12);
INSERT INTO menu_node (id, label, parent, "position") VALUES (169, 'Quotation', 156, 13);
INSERT INTO menu_node (id, label, parent, "position") VALUES (170, 'RFQ', 156, 14);
INSERT INTO menu_node (id, label, parent, "position") VALUES (171, 'Timecard', 156, 15);
INSERT INTO menu_node (id, label, parent, "position") VALUES (241, 'Letterhead', 156, 16);
INSERT INTO menu_node (id, label, parent, "position") VALUES (173, 'Invoice', 172, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (174, 'AR Transaction', 172, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (175, 'AP Transaction', 172, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (176, 'Packing List', 172, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (177, 'Pick List', 172, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (178, 'Sales Order', 172, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (179, 'Work Order', 172, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (180, 'Purchase Order', 172, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (181, 'Bin List', 172, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (182, 'Statement', 172, 10);
INSERT INTO menu_node (id, label, parent, "position") VALUES (183, 'Check', 172, 11);
INSERT INTO menu_node (id, label, parent, "position") VALUES (184, 'Receipt', 172, 12);
INSERT INTO menu_node (id, label, parent, "position") VALUES (185, 'Quotation', 172, 13);
INSERT INTO menu_node (id, label, parent, "position") VALUES (186, 'RFQ', 172, 14);
INSERT INTO menu_node (id, label, parent, "position") VALUES (187, 'Timecard', 172, 15);
INSERT INTO menu_node (id, label, parent, "position") VALUES (242, 'Letterhead', 172, 16);
INSERT INTO menu_node (id, label, parent, "position") VALUES (189, 'POS Invoice', 188, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (198, 'AR Voucher', 1, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (3, 'Sales Invoice', 1, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (11, 'Customers', 1, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (4, 'Reports', 1, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (194, 'Credit Note', 1, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (195, 'Credit Invoice', 1, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (199, 'AP Voucher', 21, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (23, 'Vendor Invoice', 21, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (24, 'Reports', 21, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (30, 'Vendors', 21, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (196, 'Debit Note', 21, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (197, 'Debit Invoice', 21, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (200, 'Vouchers', 35, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (40, 'Transfer', 35, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (41, 'Reports', 35, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (45, 'Reconciliation', 35, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (203, 'Receipts', 200, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (204, 'Reverse Receipts', 200, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (201, 'Payments', 200, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (202, 'Reverse Payment', 200, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (98, 'Projects', 0, 12);
INSERT INTO menu_node (id, label, parent, "position") VALUES (109, 'Reports', 0, 13);
INSERT INTO menu_node (id, label, parent, "position") VALUES (115, 'Recurring Transactions', 0, 14);
INSERT INTO menu_node (id, label, parent, "position") VALUES (210, 'Drafts', 205, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (211, 'Reconciliation', 205, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (217, 'Tax Forms', 0, 15);
INSERT INTO menu_node (id, label, parent, "position") VALUES (218, 'Add Tax Form', 217, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (219, 'Admin Users', 128, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (188, 'Text Templates', 128, 15);
INSERT INTO menu_node (id, label, parent, "position") VALUES (172, 'LaTeX Templates', 128, 14);
INSERT INTO menu_node (id, label, parent, "position") VALUES (156, 'HTML Templates', 128, 13);
INSERT INTO menu_node (id, label, parent, "position") VALUES (153, 'SIC', 128, 12);
INSERT INTO menu_node (id, label, parent, "position") VALUES (150, 'Language', 128, 11);
INSERT INTO menu_node (id, label, parent, "position") VALUES (147, 'Type of Business', 128, 10);
INSERT INTO menu_node (id, label, parent, "position") VALUES (144, 'Departments', 128, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (141, 'Warehouses', 128, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (136, 'Chart of Accounts', 128, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (220, 'Add User', 219, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (221, 'Search Users', 219, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (222, 'Sessions', 219, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (225, 'List Tax Forms', 217, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (226, 'Reports', 217, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (227, 'Fixed Assets', 0, 17);
INSERT INTO menu_node (id, label, parent, "position") VALUES (193, 'Logout', 0, 23);
INSERT INTO menu_node (id, label, parent, "position") VALUES (192, 'New Window', 0, 22);
INSERT INTO menu_node (id, label, parent, "position") VALUES (191, 'Preferences', 0, 21);
INSERT INTO menu_node (id, label, parent, "position") VALUES (190, 'Stylesheet', 0, 20);
INSERT INTO menu_node (id, label, parent, "position") VALUES (128, 'System', 0, 19);
INSERT INTO menu_node (id, label, parent, "position") VALUES (116, 'Batch Printing', 0, 18);
INSERT INTO menu_node (id, label, parent, "position") VALUES (228, 'Asset Classes', 227, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (229, 'Assets', 227, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (230, 'Add Class', 228, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (231, 'List Classes', 228, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (232, 'Add Assets', 229, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (233, 'Search Assets', 229, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (235, 'Import', 229, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (234, 'Depreciate', 229, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (237, 'Net Book Value', 236, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (238, 'Disposal', 229, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (236, 'Reports', 229, 11);
INSERT INTO menu_node (id, label, parent, "position") VALUES (239, 'Depreciation', 236, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (240, 'Disposal', 236, 3);


--
-- Data for Name: menu_acl; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (1, 'lsmb_newco__contact_read', 'allow', 1);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (2, 'lsmb_newco__contact_read', 'allow', 11);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (3, 'lsmb_newco__contact_read', 'allow', 14);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (4, 'lsmb_newco__contact_read', 'allow', 21);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (5, 'lsmb_newco__contact_read', 'allow', 30);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (6, 'lsmb_newco__contact_read', 'allow', 33);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (7, 'lsmb_newco__contact_create', 'allow', 1);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (8, 'lsmb_newco__contact_create', 'allow', 11);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (9, 'lsmb_newco__contact_create', 'allow', 12);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (10, 'lsmb_newco__contact_create', 'allow', 21);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (11, 'lsmb_newco__contact_create', 'allow', 30);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (12, 'lsmb_newco__contact_create', 'allow', 31);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (13, 'lsmb_newco__employees_manage', 'allow', 48);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (14, 'lsmb_newco__ar_transaction_create', 'allow', 1);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (15, 'lsmb_newco__ar_transaction_create', 'allow', 2);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (16, 'lsmb_newco__ar_transaction_create', 'allow', 194);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (17, 'lsmb_newco__ar_transaction_create', 'allow', 4);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (18, 'lsmb_newco__ar_transaction_create_voucher', 'allow', 198);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (19, 'lsmb_newco__ar_invoice_create', 'allow', 3);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (20, 'lsmb_newco__ar_invoice_create', 'allow', 195);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (21, 'lsmb_newco__ar_transaction_list', 'allow', 1);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (22, 'lsmb_newco__ar_transaction_list', 'allow', 4);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (23, 'lsmb_newco__ar_transaction_list', 'allow', 5);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (24, 'lsmb_newco__ar_transaction_list', 'allow', 6);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (25, 'lsmb_newco__ar_transaction_list', 'allow', 7);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (26, 'lsmb_newco__ar_transaction_list', 'allow', 9);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (27, 'lsmb_newco__ar_transaction_list', 'allow', 10);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (28, 'lsmb_newco__ar_transaction_list', 'allow', 11);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (29, 'lsmb_newco__ar_transaction_list', 'allow', 13);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (30, 'lsmb_newco__ar_transaction_list', 'allow', 15);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (31, 'lsmb_newco__sales_order_create', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (32, 'lsmb_newco__sales_order_create', 'allow', 51);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (33, 'lsmb_newco__sales_quotation_create', 'allow', 67);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (34, 'lsmb_newco__sales_quotation_create', 'allow', 68);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (35, 'lsmb_newco__sales_order_list', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (36, 'lsmb_newco__sales_order_list', 'allow', 53);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (37, 'lsmb_newco__sales_order_list', 'allow', 54);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (38, 'lsmb_newco__sales_quotation_list', 'allow', 67);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (39, 'lsmb_newco__sales_quotation_list', 'allow', 70);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (40, 'lsmb_newco__sales_quotation_list', 'allow', 71);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (41, 'lsmb_newco__ap_transaction_create', 'allow', 21);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (42, 'lsmb_newco__ap_transaction_create', 'allow', 22);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (43, 'lsmb_newco__ap_transaction_create', 'allow', 196);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (44, 'lsmb_newco__ap_transaction_create_voucher', 'allow', 199);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (45, 'lsmb_newco__ap_invoice_create', 'allow', 23);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (46, 'lsmb_newco__ap_transaction_create', 'allow', 197);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (47, 'lsmb_newco__ap_transaction_list', 'allow', 21);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (48, 'lsmb_newco__ap_transaction_list', 'allow', 24);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (49, 'lsmb_newco__ap_transaction_list', 'allow', 25);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (50, 'lsmb_newco__ap_transaction_list', 'allow', 26);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (51, 'lsmb_newco__ap_transaction_list', 'allow', 27);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (52, 'lsmb_newco__ap_transaction_list', 'allow', 28);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (53, 'lsmb_newco__ap_transaction_list', 'allow', 29);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (54, 'lsmb_newco__ap_transaction_list', 'allow', 30);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (55, 'lsmb_newco__ap_transaction_list', 'allow', 32);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (56, 'lsmb_newco__ap_transaction_list', 'allow', 34);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (57, 'lsmb_newco__purchase_order_create', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (58, 'lsmb_newco__purchase_order_create', 'allow', 52);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (59, 'lsmb_newco__rfq_create', 'allow', 67);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (60, 'lsmb_newco__rfq_create', 'allow', 69);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (61, 'lsmb_newco__purchase_order_list', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (62, 'lsmb_newco__purchase_order_list', 'allow', 53);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (63, 'lsmb_newco__purchase_order_list', 'allow', 55);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (64, 'lsmb_newco__rfq_list', 'allow', 67);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (65, 'lsmb_newco__rfq_list', 'allow', 70);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (66, 'lsmb_newco__rfq_list', 'allow', 72);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (67, 'lsmb_newco__pos_enter', 'allow', 16);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (68, 'lsmb_newco__pos_enter', 'allow', 17);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (69, 'lsmb_newco__pos_enter', 'allow', 18);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (70, 'lsmb_newco__close_till', 'allow', 16);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (71, 'lsmb_newco__close_till', 'allow', 20);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (72, 'lsmb_newco__list_all_open', 'allow', 16);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (73, 'lsmb_newco__list_all_open', 'allow', 18);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (74, 'lsmb_newco__reconciliation_enter', 'allow', 35);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (75, 'lsmb_newco__reconciliation_enter', 'allow', 45);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (76, 'lsmb_newco__reconciliation_approve', 'allow', 35);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (77, 'lsmb_newco__reconciliation_approve', 'allow', 41);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (78, 'lsmb_newco__reconciliation_approve', 'allow', 44);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (79, 'lsmb_newco__reconciliation_approve', 'allow', 211);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (80, 'lsmb_newco__payment_process', 'allow', 35);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (81, 'lsmb_newco__payment_process', 'allow', 38);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (82, 'lsmb_newco__payment_process', 'allow', 43);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (83, 'lsmb_newco__payment_process', 'allow', 201);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (84, 'lsmb_newco__payment_process', 'allow', 202);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (85, 'lsmb_newco__payment_process', 'allow', 223);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (86, 'lsmb_newco__receipt_process', 'allow', 35);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (87, 'lsmb_newco__receipt_process', 'allow', 36);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (88, 'lsmb_newco__receipt_process', 'allow', 37);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (89, 'lsmb_newco__receipt_process', 'allow', 42);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (90, 'lsmb_newco__receipt_process', 'allow', 47);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (91, 'lsmb_newco__receipt_process', 'allow', 203);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (92, 'lsmb_newco__receipt_process', 'allow', 204);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (93, 'lsmb_newco__part_create', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (94, 'lsmb_newco__part_create', 'allow', 78);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (95, 'lsmb_newco__part_create', 'allow', 79);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (96, 'lsmb_newco__part_create', 'allow', 80);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (97, 'lsmb_newco__part_create', 'allow', 81);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (98, 'lsmb_newco__part_create', 'allow', 82);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (99, 'lsmb_newco__part_edit', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (100, 'lsmb_newco__part_edit', 'allow', 85);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (101, 'lsmb_newco__part_edit', 'allow', 86);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (102, 'lsmb_newco__part_edit', 'allow', 87);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (103, 'lsmb_newco__part_edit', 'allow', 88);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (104, 'lsmb_newco__part_edit', 'allow', 89);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (105, 'lsmb_newco__part_edit', 'allow', 90);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (106, 'lsmb_newco__part_edit', 'allow', 91);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (107, 'lsmb_newco__part_edit', 'allow', 93);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (108, 'lsmb_newco__inventory_reports', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (109, 'lsmb_newco__inventory_reports', 'allow', 85);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (110, 'lsmb_newco__inventory_reports', 'allow', 88);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (111, 'lsmb_newco__inventory_reports', 'allow', 94);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (112, 'lsmb_newco__pricegroup_create', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (113, 'lsmb_newco__pricegroup_create', 'allow', 83);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (114, 'lsmb_newco__pricegroup_edit', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (115, 'lsmb_newco__pricegroup_edit', 'allow', 85);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (116, 'lsmb_newco__pricegroup_edit', 'allow', 92);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (117, 'lsmb_newco__assembly_stock', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (118, 'lsmb_newco__assembly_stock', 'allow', 84);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (119, 'lsmb_newco__inventory_ship', 'allow', 63);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (120, 'lsmb_newco__inventory_ship', 'allow', 64);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (121, 'lsmb_newco__inventory_receive', 'allow', 63);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (122, 'lsmb_newco__inventory_receive', 'allow', 65);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (123, 'lsmb_newco__inventory_transfer', 'allow', 63);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (124, 'lsmb_newco__inventory_transfer', 'allow', 66);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (125, 'lsmb_newco__warehouse_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (126, 'lsmb_newco__warehouse_create', 'allow', 141);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (127, 'lsmb_newco__warehouse_create', 'allow', 142);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (128, 'lsmb_newco__warehouse_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (129, 'lsmb_newco__warehouse_edit', 'allow', 141);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (130, 'lsmb_newco__warehouse_edit', 'allow', 143);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (131, 'lsmb_newco__gl_transaction_create', 'allow', 73);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (132, 'lsmb_newco__gl_transaction_create', 'allow', 74);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (133, 'lsmb_newco__gl_transaction_create', 'allow', 75);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (134, 'lsmb_newco__gl_transaction_create', 'allow', 35);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (135, 'lsmb_newco__gl_transaction_create', 'allow', 40);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (136, 'lsmb_newco__gl_reports', 'allow', 73);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (137, 'lsmb_newco__gl_reports', 'allow', 76);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (138, 'lsmb_newco__gl_reports', 'allow', 105);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (139, 'lsmb_newco__gl_reports', 'allow', 114);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (140, 'lsmb_newco__yearend_run', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (141, 'lsmb_newco__yearend_run', 'allow', 132);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (142, 'lsmb_newco__project_create', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (143, 'lsmb_newco__project_create', 'allow', 99);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (144, 'lsmb_newco__project_edit', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (145, 'lsmb_newco__project_edit', 'allow', 103);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (146, 'lsmb_newco__project_edit', 'allow', 104);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (147, 'lsmb_newco__project_timecard_add', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (148, 'lsmb_newco__project_timecard_add', 'allow', 100);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (149, 'lsmb_newco__project_timecard_add', 'allow', 103);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (150, 'lsmb_newco__project_timecard_add', 'allow', 106);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (151, 'lsmb_newco__project_timecard_list', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (152, 'lsmb_newco__project_timecard_list', 'allow', 103);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (153, 'lsmb_newco__project_timecard_list', 'allow', 106);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (154, 'lsmb_newco__project_order_generate', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (155, 'lsmb_newco__project_order_generate', 'allow', 101);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (156, 'lsmb_newco__project_order_generate', 'allow', 102);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (157, 'lsmb_newco__orders_sales_to_purchase', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (158, 'lsmb_newco__orders_sales_to_purchase', 'allow', 56);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (159, 'lsmb_newco__orders_sales_to_purchase', 'allow', 57);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (160, 'lsmb_newco__orders_sales_to_purchase', 'allow', 58);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (161, 'lsmb_newco__orders_purchase_consolidate', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (162, 'lsmb_newco__orders_purchase_consolidate', 'allow', 60);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (163, 'lsmb_newco__orders_purchase_consolidate', 'allow', 62);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (164, 'lsmb_newco__orders_sales_consolidate', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (165, 'lsmb_newco__orders_sales_consolidate', 'allow', 60);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (166, 'lsmb_newco__orders_sales_consolidate', 'allow', 61);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (167, 'lsmb_newco__financial_reports', 'allow', 109);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (168, 'lsmb_newco__financial_reports', 'allow', 110);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (169, 'lsmb_newco__financial_reports', 'allow', 111);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (170, 'lsmb_newco__financial_reports', 'allow', 112);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (171, 'lsmb_newco__financial_reports', 'allow', 113);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (172, 'lsmb_newco__financial_reports', 'allow', 114);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (173, 'lsmb_newco__print_jobs_list', 'allow', 115);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (174, 'lsmb_newco__print_jobs_list', 'allow', 116);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (175, 'lsmb_newco__print_jobs_list', 'allow', 117);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (176, 'lsmb_newco__print_jobs_list', 'allow', 118);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (177, 'lsmb_newco__print_jobs_list', 'allow', 119);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (178, 'lsmb_newco__print_jobs_list', 'allow', 120);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (179, 'lsmb_newco__print_jobs_list', 'allow', 121);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (180, 'lsmb_newco__print_jobs_list', 'allow', 122);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (181, 'lsmb_newco__print_jobs_list', 'allow', 123);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (182, 'lsmb_newco__print_jobs_list', 'allow', 124);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (183, 'lsmb_newco__print_jobs_list', 'allow', 125);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (184, 'lsmb_newco__print_jobs_list', 'allow', 126);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (185, 'lsmb_newco__print_jobs_list', 'allow', 127);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (186, 'lsmb_newco__tax_form_save', 'allow', 218);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (187, 'lsmb_newco__tax_form_save', 'allow', 225);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (188, 'lsmb_newco__tax_form_save', 'allow', 226);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (189, 'lsmb_newco__system_settings_list', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (190, 'lsmb_newco__system_settings_list', 'allow', 129);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (191, 'lsmb_newco__system_settings_list', 'allow', 131);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (192, 'lsmb_newco__taxes_set', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (193, 'lsmb_newco__taxes_set', 'allow', 130);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (194, 'lsmb_newco__account_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (195, 'lsmb_newco__account_create', 'allow', 136);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (196, 'lsmb_newco__account_create', 'allow', 137);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (197, 'lsmb_newco__account_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (198, 'lsmb_newco__account_edit', 'allow', 136);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (199, 'lsmb_newco__account_edit', 'allow', 138);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (200, 'lsmb_newco__gifi_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (201, 'lsmb_newco__gifi_create', 'allow', 136);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (202, 'lsmb_newco__gifi_create', 'allow', 139);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (203, 'lsmb_newco__gifi_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (204, 'lsmb_newco__gifi_edit', 'allow', 136);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (205, 'lsmb_newco__gifi_edit', 'allow', 140);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (206, 'lsmb_newco__department_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (207, 'lsmb_newco__department_create', 'allow', 144);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (208, 'lsmb_newco__department_create', 'allow', 145);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (209, 'lsmb_newco__department_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (210, 'lsmb_newco__department_edit', 'allow', 144);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (211, 'lsmb_newco__department_edit', 'allow', 146);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (212, 'lsmb_newco__business_type_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (213, 'lsmb_newco__business_type_create', 'allow', 147);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (214, 'lsmb_newco__business_type_create', 'allow', 148);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (215, 'lsmb_newco__business_type_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (216, 'lsmb_newco__business_type_edit', 'allow', 147);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (217, 'lsmb_newco__business_type_edit', 'allow', 149);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (218, 'lsmb_newco__sic_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (219, 'lsmb_newco__sic_create', 'allow', 153);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (220, 'lsmb_newco__sic_create', 'allow', 154);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (221, 'lsmb_newco__sic_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (222, 'lsmb_newco__sic_edit', 'allow', 153);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (223, 'lsmb_newco__sic_edit', 'allow', 155);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (224, 'lsmb_newco__template_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (225, 'lsmb_newco__template_edit', 'allow', 156);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (226, 'lsmb_newco__template_edit', 'allow', 157);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (227, 'lsmb_newco__template_edit', 'allow', 158);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (228, 'lsmb_newco__template_edit', 'allow', 159);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (229, 'lsmb_newco__template_edit', 'allow', 160);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (230, 'lsmb_newco__template_edit', 'allow', 161);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (231, 'lsmb_newco__template_edit', 'allow', 162);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (232, 'lsmb_newco__template_edit', 'allow', 163);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (233, 'lsmb_newco__template_edit', 'allow', 164);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (234, 'lsmb_newco__template_edit', 'allow', 165);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (235, 'lsmb_newco__template_edit', 'allow', 166);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (236, 'lsmb_newco__template_edit', 'allow', 167);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (237, 'lsmb_newco__template_edit', 'allow', 168);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (238, 'lsmb_newco__template_edit', 'allow', 169);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (239, 'lsmb_newco__template_edit', 'allow', 170);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (240, 'lsmb_newco__template_edit', 'allow', 171);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (241, 'lsmb_newco__template_edit', 'allow', 172);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (242, 'lsmb_newco__template_edit', 'allow', 173);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (243, 'lsmb_newco__template_edit', 'allow', 174);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (244, 'lsmb_newco__template_edit', 'allow', 175);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (245, 'lsmb_newco__template_edit', 'allow', 176);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (246, 'lsmb_newco__template_edit', 'allow', 177);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (247, 'lsmb_newco__template_edit', 'allow', 178);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (248, 'lsmb_newco__template_edit', 'allow', 179);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (249, 'lsmb_newco__template_edit', 'allow', 180);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (250, 'lsmb_newco__template_edit', 'allow', 181);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (251, 'lsmb_newco__template_edit', 'allow', 182);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (252, 'lsmb_newco__template_edit', 'allow', 183);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (253, 'lsmb_newco__template_edit', 'allow', 184);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (254, 'lsmb_newco__template_edit', 'allow', 185);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (255, 'lsmb_newco__template_edit', 'allow', 186);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (256, 'lsmb_newco__template_edit', 'allow', 187);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (257, 'lsmb_newco__template_edit', 'allow', 188);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (258, 'lsmb_newco__template_edit', 'allow', 189);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (259, 'lsmb_newco__template_edit', 'allow', 190);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (260, 'lsmb_newco__template_edit', 'allow', 241);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (261, 'lsmb_newco__template_edit', 'allow', 242);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (262, 'lsmb_newco__users_manage', 'allow', 220);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (263, 'lsmb_newco__users_manage', 'allow', 221);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (264, 'lsmb_newco__users_manage', 'allow', 222);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (265, 'lsmb_newco__language_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (266, 'lsmb_newco__language_create', 'allow', 150);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (267, 'lsmb_newco__language_create', 'allow', 151);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (268, 'lsmb_newco__language_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (269, 'lsmb_newco__language_edit', 'allow', 150);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (270, 'lsmb_newco__language_edit', 'allow', 152);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (271, 'lsmb_newco__part_translation_create', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (272, 'lsmb_newco__part_translation_create', 'allow', 95);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (273, 'lsmb_newco__part_translation_create', 'allow', 96);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (274, 'lsmb_newco__part_translation_create', 'allow', 97);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (275, 'lsmb_newco__project_translation_create', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (276, 'lsmb_newco__project_translation_create', 'allow', 107);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (277, 'lsmb_newco__project_translation_create', 'allow', 108);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (278, 'lsmb_newco__partsgroup_translation_create', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (279, 'lsmb_newco__partsgroup_translation_create', 'allow', 107);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (280, 'lsmb_newco__partsgroup_translation_create', 'allow', 108);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (281, 'lsmb_newco__assets_enter', 'allow', 237);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (282, 'lsmb_newco__assets_enter', 'allow', 230);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (283, 'lsmb_newco__assets_enter', 'allow', 231);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (284, 'lsmb_newco__assets_enter', 'allow', 232);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (285, 'lsmb_newco__assets_enter', 'allow', 233);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (286, 'lsmb_newco__assets_enter', 'allow', 235);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (287, 'lsmb_newco__assets_depreciate', 'allow', 238);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (288, 'lsmb_newco__assets_depreciate', 'allow', 234);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (289, 'lsmb_newco__assets_approve', 'allow', 239);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (290, 'lsmb_newco__assets_approve', 'allow', 240);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (291, 'public', 'allow', 191);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (292, 'public', 'allow', 192);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (293, 'public', 'allow', 193);


--
-- Data for Name: menu_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (26, 'outstanding', '1', 584);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (205, 'menu', '1', 574);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (206, 'module', 'vouchers.pl', 575);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (206, 'action', 'search_batch', 576);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (1, 'menu', '1', 1);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (2, 'module', 'ar.pl', 2);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (2, 'action', 'add', 3);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (3, 'action', 'add', 4);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (3, 'module', 'is.pl', 5);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (3, 'type', 'invoice', 6);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (4, 'menu', '1', 7);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (5, 'module', 'ar.pl', 8);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (5, 'action', 'search', 9);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (5, 'nextsub', 'transactions', 10);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (6, 'module', 'ar.pl', 12);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (6, 'action', 'search', 13);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (6, 'nextsub', 'transactions', 14);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (7, 'module', 'rp.pl', 15);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (7, 'action', 'report', 16);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (7, 'report', 'ar_aging', 17);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (6, 'outstanding', '1', 18);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (9, 'module', 'rp.pl', 21);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (9, 'action', 'report', 22);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (9, 'report', 'tax_collected', 23);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (10, 'module', 'rp.pl', 24);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (10, 'action', 'report', 25);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (10, 'report', 'nontaxable_sales', 26);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (11, 'menu', '1', 27);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (12, 'module', 'customer.pl', 28);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (12, 'action', 'add', 29);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (13, 'menu', '1', 31);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (14, 'module', 'customer.pl', 32);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (14, 'action', 'search', 36);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (15, 'db', 'customer', 37);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (15, 'action', 'history', 33);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (16, 'menu', '1', 38);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (17, 'module', 'ps.pl', 39);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (17, 'action', 'add', 40);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (17, 'nextsub', 'openinvoices', 41);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (18, 'action', 'openinvoices', 42);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (18, 'module', 'ps.pl', 43);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (19, 'module', 'ps.pl', 44);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (19, 'action', 'receipts', 46);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (20, 'module', 'ps.pl', 47);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (20, 'action', 'till_closing', 48);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (20, 'pos', 'true', 49);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (21, 'menu', '1', 50);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (22, 'action', 'add', 52);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (22, 'module', 'ap.pl', 51);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (23, 'action', 'add', 53);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (23, 'type', 'invoice', 55);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (23, 'module', 'ir.pl', 54);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (24, 'menu', '1', 56);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (25, 'action', 'search', 58);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (25, 'nextsub', 'transactions', 59);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (25, 'module', 'ap.pl', 57);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (26, 'action', 'search', 61);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (26, 'nextsub', 'transactions', 62);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (26, 'module', 'ap.pl', 60);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (27, 'module', 'rp.pl', 63);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (27, 'action', 'report', 64);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (28, 'module', 'rp.pl', 66);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (28, 'action', 'report', 67);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (28, 'report', 'tax_collected', 68);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (27, 'report', 'tax_paid', 65);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (29, 'module', 'rp.pl', 69);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (29, 'action', 'report', 70);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (29, 'report', 'nontaxable_purchases', 71);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (30, 'menu', '1', 72);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (31, 'module', 'vendor.pl', 73);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (31, 'action', 'add', 74);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (31, 'db', 'vendor', 75);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (32, 'menu', '1', 76);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (33, 'module', 'vendor.pl', 77);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (33, 'action', 'search', 79);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (33, 'db', 'vendor', 78);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (34, 'module', 'vendor.pl', 80);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (34, 'action', 'history', 81);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (34, 'db', 'vendor', 82);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (35, 'menu', '1', 83);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (36, 'module', 'payment.pl', 84);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (36, 'action', 'payment', 85);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (36, 'type', 'receipt', 86);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (36, 'account_class', '2', 551);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (37, 'module', 'payment.pl', 87);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (37, 'account_class', '2', 89);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (37, 'action', 'use_overpayment', 88);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (223, 'module', 'payment.pl', 607);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (223, 'account_class', '1', 608);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (223, 'action', 'use_overpayment', 609);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (38, 'module', 'payment.pl', 90);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (38, 'action', 'payment', 91);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (38, 'type', 'check', 92);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (38, 'account_class', '1', 554);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (194, 'module', 'ar.pl', 538);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (194, 'action', 'add', 539);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (40, 'module', 'gl.pl', 96);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (40, 'action', 'add', 97);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (40, 'transfer', '1', 98);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (41, 'menu', '1', 99);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (42, 'module', 'rp.pl', 100);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (42, 'action', 'report', 101);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (42, 'report', 'receipts', 102);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (43, 'module', 'rp.pl', 103);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (43, 'action', 'report', 104);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (43, 'report', 'payments', 105);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (44, 'report', '1', 110);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (46, 'menu', '1', 111);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (47, 'menu', '1', 112);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (48, 'module', 'employee.pl', 113);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (48, 'action', 'add', 114);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'action', 'search', 117);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (50, 'menu', '1', 119);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (51, 'module', 'oe.pl', 120);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (51, 'action', 'add', 121);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (51, 'type', 'sales_order', 122);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (52, 'module', 'oe.pl', 123);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (52, 'action', 'add', 124);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (52, 'type', 'purchase_order', 125);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (53, 'menu', '1', 126);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (54, 'module', 'oe.pl', 127);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (54, 'type', 'sales_order', 129);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (54, 'action', 'search', 128);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (55, 'module', 'oe.pl', 130);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (55, 'type', 'purchase_order', 132);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (55, 'action', 'search', 131);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (56, 'menu', '1', 133);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (57, 'module', 'oe.pl', 134);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (57, 'action', 'search', 136);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (58, 'module', 'oe.pl', 137);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (58, 'action', 'search', 139);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (57, 'type', 'generate_sales_order', 135);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (58, 'type', 'generate_purchase_order', 138);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (60, 'menu', '1', 550);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (61, 'module', 'oe.pl', 140);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (61, 'action', 'search', 141);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (62, 'module', 'oe.pl', 143);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (62, 'action', 'search', 144);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (62, 'type', 'consolidate_purchase_order', 145);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (61, 'type', 'consolidate_sales_order', 142);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (63, 'menu', '1', 146);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (64, 'module', 'oe.pl', 147);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (64, 'action', 'search', 148);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (65, 'module', 'oe.pl', 150);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (65, 'action', 'search', 151);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (66, 'module', 'oe.pl', 153);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (66, 'action', 'search_transfer', 154);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (67, 'menu', '1', 155);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (68, 'module', 'oe.pl', 156);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (68, 'action', 'add', 157);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (69, 'module', 'oe.pl', 159);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (69, 'action', 'add', 160);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'module', 'employee.pl', 118);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (68, 'type', 'sales_quotation', 158);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (65, 'type', 'receive_order', 149);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (64, 'type', 'ship_order', 149);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (69, 'type', 'request_quotation', 161);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (70, 'menu', '1', 162);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (71, 'module', 'oe.pl', 163);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (71, 'type', 'sales_quotation', 165);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (71, 'action', 'search', 164);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (72, 'module', 'oe.pl', 166);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (72, 'action', 'search', 168);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (72, 'type', 'request_quotation', 167);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (73, 'menu', '1', 169);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (74, 'module', 'gl.pl', 170);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (74, 'action', 'add', 171);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (75, 'module', 'gl.pl', 172);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (75, 'action', 'add_pos_adjust', 174);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (75, 'rowcount', '3', 175);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (75, 'pos_adjust', '1', 176);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (75, 'reference', 'Adjusting Till: (Till)  Source: (Source)', 177);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (75, 'descripton', 'Adjusting till due to data entry error', 178);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (76, 'module', 'gl.pl', 180);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (76, 'action', 'search', 181);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (77, 'menu', '1', 182);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (78, 'module', 'ic.pl', 183);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (78, 'action', 'add', 184);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (78, 'item', 'part', 185);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (79, 'module', 'ic.pl', 186);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (79, 'action', 'add', 187);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (79, 'item', 'service', 188);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (80, 'module', 'ic.pl', 189);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (80, 'action', 'add', 190);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (81, 'module', 'ic.pl', 192);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (81, 'action', 'add', 193);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (81, 'item', 'labor', 194);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (80, 'item', 'assembly', 191);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (82, 'action', 'add', 195);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (82, 'module', 'pe.pl', 196);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (83, 'action', 'add', 198);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (83, 'module', 'pe.pl', 199);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (84, 'module', 'ic.pl', 202);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (84, 'action', 'stock_assembly', 203);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (85, 'menu', '1', 204);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (86, 'module', 'ic.pl', 205);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (86, 'action', 'search', 610);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (86, 'searchitems', 'all', 611);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (87, 'module', 'ic.pl', 612);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (87, 'action', 'search', 206);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (87, 'searchitems', 'part', 210);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (88, 'module', 'ic.pl', 211);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (88, 'action', 'requirements', 212);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (89, 'action', 'search', 213);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (89, 'module', 'ic.pl', 214);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (89, 'searchitems', 'service', 215);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (90, 'action', 'search', 216);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (90, 'module', 'ic.pl', 217);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (90, 'searchitems', 'labor', 218);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (91, 'module', 'pe.pl', 221);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (91, 'action', 'search', 220);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (92, 'module', 'pe.pl', 224);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (92, 'action', 'search', 223);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (93, 'action', 'search', 226);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (93, 'module', 'ic.pl', 227);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (93, 'searchitems', 'assembly', 228);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (94, 'action', 'search', 229);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (94, 'module', 'ic.pl', 230);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (94, 'searchitems', 'component', 231);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (95, 'menu', '1', 232);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (96, 'module', 'pe.pl', 233);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (96, 'action', 'translation', 234);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (96, 'translation', 'description', 235);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (97, 'module', 'pe.pl', 236);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (97, 'action', 'translation', 237);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (97, 'translation', 'partsgroup', 238);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (98, 'menu', '1', 239);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (99, 'module', 'pe.pl', 240);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (99, 'action', 'add', 241);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (99, 'type', 'project', 242);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (100, 'module', 'jc.pl', 243);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (100, 'action', 'add', 244);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (99, 'project', 'project', 245);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (100, 'project', 'project', 246);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (100, 'type', 'timecard', 247);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (101, 'menu', '1', 248);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (102, 'module', 'pe.pl', 249);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (102, 'action', 'project_sales_order', 250);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (103, 'menu', '1', 255);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (104, 'module', 'pe.pl', 256);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (104, 'type', 'project', 258);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (104, 'action', 'search', 257);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (105, 'action', 'report', 260);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (105, 'report', 'projects', 261);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (105, 'module', 'rp.pl', 262);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (106, 'module', 'jc.pl', 263);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (106, 'action', 'search', 264);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (106, 'type', 'timecard', 265);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (106, 'project', 'project', 266);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (107, 'menu', '1', 268);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (108, 'module', 'pe.pl', 269);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (108, 'action', 'translation', 270);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (108, 'translation', 'project', 271);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (109, 'menu', '1', 272);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (110, 'module', 'ca.pl', 273);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (110, 'action', 'chart_of_accounts', 274);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (111, 'action', 'report', 275);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (111, 'module', 'rp.pl', 276);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (111, 'report', 'trial_balance', 277);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (112, 'action', 'report', 278);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (112, 'module', 'rp.pl', 279);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (112, 'report', 'income_statement', 280);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (113, 'action', 'report', 281);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (113, 'module', 'rp.pl', 282);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (113, 'report', 'balance_sheet', 283);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (114, 'action', 'report', 284);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (114, 'module', 'rp.pl', 285);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (114, 'report', 'inv_activity', 286);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (115, 'action', 'recurring_transactions', 287);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (115, 'module', 'am.pl', 288);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (116, 'menu', '1', 289);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (119, 'module', 'bp.pl', 290);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (119, 'action', 'search', 291);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (119, 'type', 'check', 292);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (119, 'vc', 'vendor', 293);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (117, 'module', 'bp.pl', 294);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (117, 'action', 'search', 295);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (117, 'vc', 'customer', 297);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (118, 'module', 'bp.pl', 298);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (118, 'action', 'search', 299);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (118, 'vc', 'customer', 300);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (120, 'module', 'bp.pl', 302);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (120, 'action', 'search', 303);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (120, 'vc', 'customer', 304);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (121, 'module', 'bp.pl', 306);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (121, 'action', 'search', 307);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (121, 'vc', 'customer', 308);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (122, 'module', 'bp.pl', 310);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (122, 'action', 'search', 311);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (122, 'vc', 'customer', 312);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (120, 'type', 'work_order', 305);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (121, 'type', 'sales_quotation', 309);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (122, 'type', 'packing_list', 313);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (123, 'module', 'bp.pl', 314);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (123, 'action', 'search', 315);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (123, 'vc', 'customer', 316);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (123, 'type', 'pick_list', 317);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (124, 'module', 'bp.pl', 318);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (124, 'action', 'search', 319);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (124, 'vc', 'vendor', 321);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (124, 'type', 'purchase_order', 320);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (125, 'module', 'bp.pl', 322);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (125, 'action', 'search', 323);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (125, 'vc', 'vendor', 325);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (126, 'module', 'bp.pl', 326);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (117, 'type', 'invoice', 296);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (118, 'type', 'sales_order', 301);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (126, 'action', 'search', 327);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (126, 'vc', 'vendor', 329);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (127, 'module', 'bp.pl', 330);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (127, 'action', 'search', 331);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (127, 'type', 'timecard', 332);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (125, 'type', 'bin_list', 324);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (126, 'type', 'request_quotation', 328);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (127, 'vc', 'employee', 333);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (128, 'menu', '1', 334);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (129, 'module', 'am.pl', 337);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (130, 'module', 'am.pl', 338);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (131, 'module', 'am.pl', 339);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (129, 'action', 'audit_control', 340);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (130, 'taxes', 'audit_control', 341);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (131, 'action', 'defaults', 342);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (130, 'action', 'taxes', 343);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (132, 'module', 'account.pl', 346);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (132, 'action', 'yearend_info', 347);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (138, 'module', 'am.pl', 356);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (139, 'module', 'am.pl', 357);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (140, 'module', 'am.pl', 358);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (138, 'action', 'list_account', 360);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (139, 'action', 'add_gifi', 361);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (140, 'action', 'list_gifi', 362);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (141, 'menu', '1', 363);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (142, 'module', 'am.pl', 364);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (143, 'module', 'am.pl', 365);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (142, 'action', 'add_warehouse', 366);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (143, 'action', 'list_warehouse', 367);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (145, 'module', 'am.pl', 368);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (146, 'module', 'am.pl', 369);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (145, 'action', 'add_department', 370);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (146, 'action', 'list_department', 371);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (147, 'menu', '1', 372);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (148, 'module', 'am.pl', 373);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (149, 'module', 'am.pl', 374);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (148, 'action', 'add_business', 375);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (149, 'action', 'list_business', 376);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (150, 'menu', '1', 377);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (151, 'module', 'am.pl', 378);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (152, 'module', 'am.pl', 379);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (151, 'action', 'add_language', 380);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (152, 'action', 'list_language', 381);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (153, 'menu', '1', 382);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (154, 'module', 'am.pl', 383);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (155, 'module', 'am.pl', 384);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (154, 'action', 'add_sic', 385);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (155, 'action', 'list_sic', 386);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (156, 'menu', '1', 387);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (157, 'module', 'am.pl', 388);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (158, 'module', 'am.pl', 389);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (159, 'module', 'am.pl', 390);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (160, 'module', 'am.pl', 391);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (161, 'module', 'am.pl', 392);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (162, 'module', 'am.pl', 393);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (163, 'module', 'am.pl', 394);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (164, 'module', 'am.pl', 395);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (165, 'module', 'am.pl', 396);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (166, 'module', 'am.pl', 397);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (167, 'module', 'am.pl', 398);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (168, 'module', 'am.pl', 399);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (169, 'module', 'am.pl', 400);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (170, 'module', 'am.pl', 401);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (171, 'module', 'am.pl', 402);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (241, 'module', 'am.pl', 642);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (157, 'action', 'list_templates', 403);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (158, 'action', 'list_templates', 404);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (159, 'action', 'list_templates', 405);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (160, 'action', 'list_templates', 406);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (161, 'action', 'list_templates', 407);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (162, 'action', 'list_templates', 408);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (163, 'action', 'list_templates', 409);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (164, 'action', 'list_templates', 410);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (165, 'action', 'list_templates', 411);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (166, 'action', 'list_templates', 412);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (167, 'action', 'list_templates', 413);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (168, 'action', 'list_templates', 414);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (169, 'action', 'list_templates', 415);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (170, 'action', 'list_templates', 416);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (171, 'action', 'list_templates', 417);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (241, 'action', 'list_templates', 643);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (157, 'template', 'income_statement', 418);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (158, 'template', 'balance_sheet', 419);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (159, 'template', 'invoice', 420);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (160, 'template', 'ar_transaction', 421);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (161, 'template', 'ap_transaction', 422);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (162, 'template', 'packing_list', 423);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (163, 'template', 'pick_list', 424);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (164, 'template', 'sales_order', 425);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (165, 'template', 'work_order', 426);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (166, 'template', 'purchase_order', 427);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (167, 'template', 'bin_list', 428);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (168, 'template', 'statement', 429);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (169, 'template', 'quotation', 430);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (170, 'template', 'rfq', 431);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (171, 'template', 'timecard', 432);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (241, 'template', 'letterhead', 644);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (157, 'format', 'HTML', 433);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (158, 'format', 'HTML', 434);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (159, 'format', 'HTML', 435);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (160, 'format', 'HTML', 436);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (161, 'format', 'HTML', 437);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (162, 'format', 'HTML', 438);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (163, 'format', 'HTML', 439);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (164, 'format', 'HTML', 440);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (165, 'format', 'HTML', 441);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (166, 'format', 'HTML', 442);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (167, 'format', 'HTML', 443);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (168, 'format', 'HTML', 444);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (169, 'format', 'HTML', 445);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (170, 'format', 'HTML', 446);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (171, 'format', 'HTML', 447);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (241, 'format', 'HTML', 645);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (172, 'menu', '1', 448);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (173, 'action', 'list_templates', 449);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (174, 'action', 'list_templates', 450);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (175, 'action', 'list_templates', 451);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (176, 'action', 'list_templates', 452);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (177, 'action', 'list_templates', 453);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (178, 'action', 'list_templates', 454);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (179, 'action', 'list_templates', 455);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (180, 'action', 'list_templates', 456);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (181, 'action', 'list_templates', 457);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (182, 'action', 'list_templates', 458);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (183, 'action', 'list_templates', 459);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (184, 'action', 'list_templates', 460);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (185, 'action', 'list_templates', 461);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (186, 'action', 'list_templates', 462);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (187, 'action', 'list_templates', 463);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (242, 'action', 'list_templates', 646);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (173, 'module', 'am.pl', 464);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (174, 'module', 'am.pl', 465);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (175, 'module', 'am.pl', 466);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (176, 'module', 'am.pl', 467);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (177, 'module', 'am.pl', 468);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (178, 'module', 'am.pl', 469);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (179, 'module', 'am.pl', 470);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (180, 'module', 'am.pl', 471);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (181, 'module', 'am.pl', 472);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (182, 'module', 'am.pl', 473);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (183, 'module', 'am.pl', 474);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (184, 'module', 'am.pl', 475);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (185, 'module', 'am.pl', 476);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (186, 'module', 'am.pl', 477);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (187, 'module', 'am.pl', 478);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (242, 'module', 'am.pl', 647);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (173, 'format', 'LATEX', 479);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (174, 'format', 'LATEX', 480);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (175, 'format', 'LATEX', 481);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (176, 'format', 'LATEX', 482);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (177, 'format', 'LATEX', 483);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (178, 'format', 'LATEX', 484);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (179, 'format', 'LATEX', 485);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (180, 'format', 'LATEX', 486);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (181, 'format', 'LATEX', 487);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (182, 'format', 'LATEX', 488);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (183, 'format', 'LATEX', 489);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (184, 'format', 'LATEX', 490);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (185, 'format', 'LATEX', 491);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (186, 'format', 'LATEX', 492);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (187, 'format', 'LATEX', 493);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (242, 'format', 'LATEX', 648);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (173, 'template', 'invoice', 506);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (174, 'template', 'ar_transaction', 507);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (175, 'template', 'ap_transaction', 508);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (176, 'template', 'packing_list', 509);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (177, 'template', 'pick_list', 510);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (178, 'template', 'sales_order', 511);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (179, 'template', 'work_order', 512);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (180, 'template', 'purchase_order', 513);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (181, 'template', 'bin_list', 514);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (182, 'template', 'statement', 515);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (185, 'template', 'quotation', 518);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (186, 'template', 'rfq', 519);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (187, 'template', 'timecard', 520);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (183, 'template', 'check', 516);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (184, 'template', 'receipt', 517);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (242, 'template', 'letterhead', 649);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (188, 'menu', '1', 521);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (189, 'module', 'am.pl', 522);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (189, 'action', 'list_templates', 523);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (189, 'template', 'pos_invoice', 524);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (189, 'format', 'TEXT', 525);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (190, 'action', 'display_stylesheet', 526);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (190, 'module', 'am.pl', 527);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (193, 'module', 'login.pl', 532);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (193, 'action', 'logout', 533);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (193, 'target', '_top', 534);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (192, 'menu', '1', 530);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (192, 'new', '1', 531);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (0, 'menu', '1', 535);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (136, 'menu', '1', 536);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (144, 'menu', '1', 537);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (195, 'action', 'add', 540);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (195, 'module', 'is.pl', 541);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (196, 'action', 'add', 543);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (196, 'module', 'ap.pl', 544);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (197, 'action', 'add', 545);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (197, 'module', 'ir.pl', 547);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (196, 'type', 'debit_note', 549);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (194, 'type', 'credit_note', 548);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (195, 'type', 'credit_invoice', 542);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (197, 'type', 'debit_invoice', 546);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (202, 'batch_type', 'payment_reversal', 570);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (204, 'batch_type', 'receipt_reversal', 573);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (200, 'menu', '1', 552);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (198, 'action', 'create_batch', 554);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (198, 'module', 'vouchers.pl', 553);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (199, 'module', 'vouchers.pl', 559);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (199, 'action', 'create_batch', 560);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (201, 'module', 'vouchers.pl', 562);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (201, 'action', 'create_batch', 563);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (203, 'module', 'vouchers.pl', 565);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (203, 'action', 'create_batch', 566);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (202, 'module', 'vouchers.pl', 568);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (202, 'action', 'create_batch', 569);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (204, 'module', 'vouchers.pl', 571);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (204, 'action', 'create_batch', 572);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (201, 'batch_type', 'payment', 564);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (210, 'action', 'search', 585);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (210, 'module', 'drafts.pl', 586);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (199, 'batch_type', 'ap', 561);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (15, 'module', 'customer.pl', 35);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (45, 'module', 'recon.pl', 106);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (45, 'action', 'new_report', 107);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (44, 'module', 'recon.pl', 108);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (44, 'action', 'search', 109);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (211, 'module', 'recon.pl', 587);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (211, 'action', 'search', 588);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (211, 'hide_status', '1', 589);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (211, 'approved', '0', 590);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (211, 'submitted', '1', 591);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (198, 'batch_type', 'ar', 555);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (191, 'module', 'user.pl', 528);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (191, 'action', 'preference_screen', 529);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (217, 'menu', '1', 597);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (218, 'action', 'add_taxform', 598);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (218, 'module', 'taxform.pl', 599);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (137, 'module', 'account.pl', 355);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (137, 'action', 'new', 359);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (219, 'menu', '1', 600);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (220, 'module', 'admin.pl', 601);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (220, 'action', 'new_user', 602);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (221, 'module', 'admin.pl', 603);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (221, 'action', 'search_users', 604);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (222, 'module', 'admin.pl', 605);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (222, 'action', 'list_sessions', 606);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'l_last_name', '1', 115);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'l_employeenumber', '1', 116);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'l_first_name', '1', 613);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'l_id', '1', 614);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'l_startdate', '1', 615);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'l_enddate', '1', 616);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (225, 'module', 'taxform.pl', 613);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (225, 'action', 'list_all', 614);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (226, 'module', 'taxform.pl', 615);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (227, 'menu', '1', 616);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (228, 'menu', '1', 617);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (229, 'menu', '1', 618);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (230, 'action', 'asset_category_screen', 620);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (231, 'action', 'asset_category_search', 622);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (232, 'action', 'asset_screen', 624);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (233, 'action', 'asset_search', 626);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (234, 'module', 'asset.pl', 627);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (234, 'action', 'new_report', 628);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (235, 'module', 'asset.pl', 630);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (236, 'menu', '1', 632);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (237, 'module', 'asset.pl', 633);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (237, 'action', 'display_nbv', 634);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (232, 'module', 'asset.pl', 623);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (230, 'module', 'asset.pl', 619);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (231, 'module', 'asset.pl', 621);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (233, 'module', 'asset.pl', 625);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (234, 'depreciation', '1', 629);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (238, 'action', 'new_report', 636);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (238, 'module', 'asset.pl', 635);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (239, 'module', 'asset.pl', 637);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (239, 'action', 'search_reports', 638);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (239, 'depreciation', '1', 639);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (240, 'module', 'asset.pl', 640);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (240, 'action', 'search_reports', 641);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (83, 'type', 'pricegroup', 200);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (82, 'type', 'partsgroup', 197);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (91, 'type', 'partsgroup', 222);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (92, 'type', 'pricegroup', 225);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (235, 'action', 'begin_import', 631);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (203, 'batch_type', 'receipt', 567);


--
-- Data for Name: new_shipto; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: note_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO note_class (id, class) VALUES (1, 'Entity');
INSERT INTO note_class (id, class) VALUES (2, 'Invoice');
INSERT INTO note_class (id, class) VALUES (3, 'Entity Credit Account');
INSERT INTO note_class (id, class) VALUES (4, 'Asset');


--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: open_forms; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO open_forms (id, session_id) VALUES (1, 1);
INSERT INTO open_forms (id, session_id) VALUES (2, 1);
INSERT INTO open_forms (id, session_id) VALUES (5, 1);
INSERT INTO open_forms (id, session_id) VALUES (8, 1);
INSERT INTO open_forms (id, session_id) VALUES (9, 1);
INSERT INTO open_forms (id, session_id) VALUES (10, 1);
INSERT INTO open_forms (id, session_id) VALUES (11, 1);
INSERT INTO open_forms (id, session_id) VALUES (13, 1);
INSERT INTO open_forms (id, session_id) VALUES (15, 1);
INSERT INTO open_forms (id, session_id) VALUES (22, 1);


--
-- Data for Name: orderitems; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: parts_translation; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partscustomer; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partsgroup; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partsgroup_translation; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: taxmodule; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO taxmodule (taxmodule_id, taxmodulename) VALUES (1, 'Simple');


--
-- Data for Name: taxcategory; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partstax; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO partstax (parts_id, chart_id, taxcategory_id) VALUES (1, 15, NULL);
INSERT INTO partstax (parts_id, chart_id, taxcategory_id) VALUES (1, 16, NULL);


--
-- Data for Name: partsvendor; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO payment (id, reference, gl_id, payment_class, payment_date, closed, entity_credit_id, employee_id, currency, notes, department_id) VALUES (1, '2', NULL, 2, '2012-03-10', false, 3, 1, 'CAD', NULL, NULL);
INSERT INTO payment (id, reference, gl_id, payment_class, payment_date, closed, entity_credit_id, employee_id, currency, notes, department_id) VALUES (2, '3', NULL, 2, '2012-03-11', false, 4, 1, 'USD', NULL, NULL);


--
-- Data for Name: payment_links; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO payment_links (payment_id, entry_id, type) VALUES (1, 5, 1);
INSERT INTO payment_links (payment_id, entry_id, type) VALUES (1, 6, 1);
INSERT INTO payment_links (payment_id, entry_id, type) VALUES (2, 7, 1);
INSERT INTO payment_links (payment_id, entry_id, type) VALUES (2, 9, 1);


--
-- Data for Name: payment_type; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pending_job; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: payments_queue; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: person_to_company; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: person_to_contact; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: person_to_entity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: person_to_location; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_translation; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recurring; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recurringemail; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recurringprint; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: sic; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tax; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO tax (chart_id, rate, taxnumber, validto, pass, taxmodule_id) VALUES (15, 0.05, NULL, 'infinity', 0, 1);
INSERT INTO tax (chart_id, rate, taxnumber, validto, pass, taxmodule_id) VALUES (16, 0.08, NULL, 'infinity', 0, 1);


--
-- Data for Name: tax_extended; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: translation; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_preference; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO user_preference (id, language, stylesheet, printer, dateformat, numberformat) VALUES (1, NULL, 'ledgersmb.css', 'Laser', 'yyyy-mm-dd', '1000.00');


--
-- Data for Name: vendortax; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: yearend; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- PostgreSQL database dump complete
--

