--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: newco; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE newco WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C';


\connect newco

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: tablefunc; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS tablefunc WITH SCHEMA public;


--
-- Name: EXTENSION tablefunc; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION tablefunc IS 'functions that manipulate whole tables, including crosstab';


SET search_path = public, pg_catalog;

--
-- Name: asset_class_result; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE asset_class_result AS (
	id integer,
	asset_account_id integer,
	asset_accno text,
	asset_description text,
	dep_account_id integer,
	dep_accno text,
	dep_description text,
	method text,
	method_id integer,
	label text
);


--
-- Name: asset_disposal_report_line; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE asset_disposal_report_line AS (
	id integer,
	tag text,
	description text,
	start_dep date,
	disposed_on date,
	dm character(1),
	purchase_value numeric,
	accum_depreciation numeric,
	disposal_amt numeric,
	adj_basis numeric,
	gain_loss numeric
);


--
-- Name: asset_nbv_line; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE asset_nbv_line AS (
	id integer,
	tag text,
	description text,
	begin_depreciation date,
	method text,
	remaining_life numeric,
	basis numeric,
	salvage_value numeric,
	through_date date,
	accum_depreciation numeric,
	net_book_value numeric
);


--
-- Name: asset_report_line_result; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE asset_report_line_result AS (
	tag text,
	start_depreciation date,
	purchase_value numeric,
	method_short_name text,
	usable_life numeric,
	basis numeric,
	prior_through date,
	prior_dep numeric,
	dep_this_time numeric,
	dep_ytd numeric,
	dep_total numeric,
	description text,
	purchase_date date
);


--
-- Name: asset_report_result; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE asset_report_result AS (
	id integer,
	report_date date,
	gl_id bigint,
	asset_class bigint,
	report_class integer,
	entered_by bigint,
	approved_by bigint,
	entered_at timestamp without time zone,
	approved_at timestamp without time zone,
	depreciated_qty numeric,
	dont_approve boolean,
	submitted boolean,
	total numeric
);


--
-- Name: batch_list_item; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE batch_list_item AS (
	id integer,
	batch_class text,
	control_code text,
	description text,
	created_by text,
	created_on date,
	default_date date,
	transaction_total numeric,
	payment_total numeric
);


--
-- Name: company_billing_info; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE company_billing_info AS (
	legal_name text,
	meta_number text,
	control_code text,
	tax_id text,
	street1 text,
	street2 text,
	street3 text,
	city text,
	state text,
	mail_code text,
	country text
);


--
-- Name: company_search_result; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE company_search_result AS (
	entity_id integer,
	entity_control_code text,
	company_id integer,
	entity_credit_id integer,
	meta_number text,
	credit_description text,
	entity_class integer,
	legal_name text,
	sic_code text,
	business_type text,
	curr text
);


--
-- Name: contact_list; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE contact_list AS (
	class text,
	class_id integer,
	description text,
	contact text
);


--
-- Name: draft_search_result; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE draft_search_result AS (
	id integer,
	transdate date,
	reference text,
	description text,
	amount numeric
);


--
-- Name: eca__pricematrix; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE eca__pricematrix AS (
	parts_id integer,
	int_partnumber text,
	description text,
	credit_id integer,
	pricebreak numeric,
	sellprice numeric,
	lastcost numeric,
	leadtime integer,
	partnumber text,
	validfrom date,
	validto date,
	curr character(3),
	entry_id integer
);


--
-- Name: eca_history_result; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE eca_history_result AS (
	id integer,
	name text,
	meta_number text,
	inv_id integer,
	invnumber text,
	curr text,
	parts_id integer,
	partnumber text,
	description text,
	qty numeric,
	unit text,
	sellprice numeric,
	discount numeric,
	delivery_date date,
	project_id integer,
	projectnumber text,
	serialnumber text,
	exchngerate numeric,
	salesperson_id integer,
	salesperson_name text
);


--
-- Name: employee_result; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE employee_result AS (
	entity_id integer,
	person_id integer,
	salutation text,
	first_name text,
	middle_name text,
	last_name text,
	startdate date,
	enddate date,
	role character varying(20),
	ssn text,
	sales boolean,
	manager_id integer,
	manager_first_name text,
	manager_last_name text,
	employeenumber character varying(32),
	dob date,
	country_id integer
);


--
-- Name: entity_credit_retrieve; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE entity_credit_retrieve AS (
	id integer,
	entity_id integer,
	entity_class integer,
	discount numeric,
	discount_terms integer,
	taxincluded boolean,
	creditlimit numeric,
	terms smallint,
	meta_number text,
	description text,
	business_id integer,
	language_code text,
	pricegroup_id integer,
	curr text,
	startdate date,
	enddate date,
	ar_ap_account_id integer,
	cash_account_id integer,
	threshold numeric,
	control_code text,
	credit_id integer,
	pay_to_name text,
	taxform_id integer
);


--
-- Name: entity_credit_search_return; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE entity_credit_search_return AS (
	legal_name text,
	id integer,
	entity_id integer,
	entity_control_code text,
	entity_class integer,
	discount numeric,
	taxincluded boolean,
	creditlimit numeric,
	terms smallint,
	meta_number text,
	credit_description text,
	business_id integer,
	language_code text,
	pricegroup_id integer,
	curr character(3),
	startdate date,
	enddate date,
	ar_ap_account_id integer,
	cash_account_id integer,
	tax_id text,
	threshold numeric
);


--
-- Name: TYPE entity_credit_search_return; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TYPE entity_credit_search_return IS ' This may change in 1.4 and should not be relied upon too much ';


--
-- Name: entity_note_list; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE entity_note_list AS (
	id integer,
	note_class integer,
	note text
);


--
-- Name: file_list_item; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE file_list_item AS (
	mime_type text,
	file_name text,
	description text,
	uploaded_by_id integer,
	uploaded_by_name text,
	uploaded_at timestamp without time zone,
	id integer,
	ref_key integer,
	file_class integer,
	content bytea
);


--
-- Name: location_result; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE location_result AS (
	id integer,
	line_one text,
	line_two text,
	line_three text,
	city text,
	state text,
	mail_code text,
	country_id integer,
	country text,
	class_id integer,
	class text
);


--
-- Name: menu_item; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE menu_item AS (
	"position" integer,
	id integer,
	level integer,
	label character varying,
	path character varying,
	args character varying[]
);


--
-- Name: partial_disposal_line; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE partial_disposal_line AS (
	id integer,
	tag text,
	begin_depreciation date,
	purchase_value numeric,
	description text,
	disposal_date date,
	percent_disposed numeric,
	disposed_acquired_value numeric,
	percent_remaining numeric,
	remaining_aquired_value numeric
);


--
-- Name: payment_contact_invoice; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE payment_contact_invoice AS (
	contact_id integer,
	econtrol_code text,
	eca_description text,
	contact_name text,
	account_number text,
	total_due numeric,
	invoices text[],
	has_vouchers integer
);


--
-- Name: payment_header_item; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE payment_header_item AS (
	payment_id integer,
	payment_reference integer,
	payment_date date,
	legal_name text,
	amount numeric,
	employee_first_name text,
	employee_last_name text,
	currency character(3),
	notes text
);


--
-- Name: payment_invoice; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE payment_invoice AS (
	invoice_id integer,
	invnumber text,
	invoice boolean,
	invoice_date date,
	amount numeric,
	amount_fx numeric,
	discount numeric,
	discount_fx numeric,
	due numeric,
	due_fx numeric,
	exchangerate numeric
);


--
-- Name: payment_line_item; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE payment_line_item AS (
	payment_id integer,
	entry_id integer,
	link_type integer,
	trans_id integer,
	invoice_number text,
	chart_id integer,
	chart_accno text,
	chart_description text,
	chart_link text,
	amount numeric,
	trans_date date,
	source text,
	cleared boolean,
	fx_transaction boolean,
	project_id integer,
	memo text,
	invoice_id integer,
	approved boolean,
	cleared_on date,
	reconciled_on date
);


--
-- Name: payment_location_result; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE payment_location_result AS (
	id integer,
	line_one text,
	line_two text,
	line_three text,
	city text,
	state text,
	mail_code text,
	country text,
	class text
);


--
-- Name: payment_overpayments_available_amount; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE payment_overpayments_available_amount AS (
	chart_id integer,
	accno text,
	description text,
	available numeric
);


--
-- Name: payment_record; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE payment_record AS (
	amount numeric,
	meta_number text,
	credit_id integer,
	company_paid text,
	accounts text[],
	source text,
	batch_control text,
	batch_description text,
	voucher_id integer,
	date_paid date
);


--
-- Name: payment_vc_info; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE payment_vc_info AS (
	id integer,
	name text,
	entity_class integer,
	discount integer,
	meta_number character varying(32)
);


--
-- Name: recon_accounts; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE recon_accounts AS (
	name text,
	accno text,
	id integer
);


--
-- Name: report_aging_item; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE report_aging_item AS (
	entity_id integer,
	account_number character varying(24),
	name text,
	address1 text,
	address2 text,
	address3 text,
	city_province text,
	mail_code text,
	country text,
	contact_name text,
	email text,
	phone text,
	fax text,
	invnumber text,
	transdate date,
	till character varying(20),
	ordnumber text,
	ponumber text,
	notes text,
	c0 numeric,
	c30 numeric,
	c60 numeric,
	c90 numeric,
	duedate date,
	id integer,
	curr character varying(3),
	exchangerate numeric,
	line_items text[]
);


--
-- Name: session_result; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE session_result AS (
	id integer,
	username text,
	last_used timestamp without time zone,
	locks_active bigint
);


--
-- Name: tax_form_report_detail_item; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE tax_form_report_detail_item AS (
	credit_id integer,
	legal_name text,
	entity_id integer,
	entity_class integer,
	control_code text,
	meta_number character varying(32),
	acc_sum numeric,
	invoice_sum numeric,
	total_sum numeric,
	invnumber text,
	duedate text,
	invoice_id integer
);


--
-- Name: tax_form_report_item; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE tax_form_report_item AS (
	credit_id integer,
	legal_name text,
	entity_id integer,
	entity_class integer,
	control_code text,
	meta_number character varying(32),
	acc_sum numeric,
	invoice_sum numeric,
	total_sum numeric
);


--
-- Name: taxform_list; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE taxform_list AS (
	id integer,
	form_name text,
	country_id integer,
	country_name text,
	default_reportable boolean
);


--
-- Name: trial_balance_line; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE trial_balance_line AS (
	chart_id integer,
	accno text,
	description text,
	beginning_balance numeric,
	credits numeric,
	debits numeric,
	ending_balance numeric
);


--
-- Name: user_result; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE user_result AS (
	id integer,
	username text,
	first_name text,
	last_name text,
	ssn text,
	dob text
);


--
-- Name: voucher_list; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE voucher_list AS (
	id integer,
	reference text,
	description text,
	batch_id integer,
	transaction_id integer,
	amount numeric,
	transaction_date date,
	batch_class text
);


--
-- Name: _entity_location_save(integer, integer, integer, text, text, text, text, text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION _entity_location_save(in_entity_id integer, in_location_id integer, in_location_class integer, in_line_one text, in_line_two text, in_line_three text, in_city text, in_state text, in_mail_code text, in_country_code integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$

    DECLARE
        l_row location;
        l_id INT;
	t_company_id int;
    BEGIN
	SELECT id INTO t_company_id
	FROM company WHERE entity_id = in_entity_id;

	DELETE FROM company_to_location
	WHERE company_id = t_company_id
		AND location_class = in_location_class
		AND location_id = in_location_id;

	SELECT location_save(NULL, in_line_one, in_line_two, in_line_three, in_city,
		in_state, in_mail_code, in_country_code) 
	INTO l_id;

	INSERT INTO company_to_location 
		(company_id, location_class, location_id)
	VALUES  (t_company_id, in_location_class, l_id);

	RETURN l_id;    
    END;

$$;


--
-- Name: FUNCTION _entity_location_save(in_entity_id integer, in_location_id integer, in_location_class integer, in_line_one text, in_line_two text, in_line_three text, in_city text, in_state text, in_mail_code text, in_country_code integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION _entity_location_save(in_entity_id integer, in_location_id integer, in_location_class integer, in_line_one text, in_line_two text, in_line_three text, in_city text, in_state text, in_mail_code text, in_country_code integer) IS ' Private method for storing locations to an entity.  Do not call directly.
Returns the location id that was inserted or updated.';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE account (
    id integer NOT NULL,
    accno text NOT NULL,
    description text,
    category character(1) NOT NULL,
    gifi_accno text,
    heading integer NOT NULL,
    contra boolean DEFAULT false NOT NULL,
    tax boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE account; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE account IS ' This table stores the main account info.';


--
-- Name: account__get_by_link_desc(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION account__get_by_link_desc(in_description text) RETURNS SETOF account
    LANGUAGE sql
    AS $_$
SELECT * FROM account
WHERE id IN (SELECT account_id FROM account_link WHERE description = $1);
$_$;


--
-- Name: FUNCTION account__get_by_link_desc(in_description text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION account__get_by_link_desc(in_description text) IS ' Gets a list of accounts with a specific link description set.  For example,
for a dropdown list.';


--
-- Name: account__get_from_accno(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION account__get_from_accno(in_accno text) RETURNS account
    LANGUAGE sql
    AS $_$
     select * from account where accno = $1;
$_$;


--
-- Name: FUNCTION account__get_from_accno(in_accno text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION account__get_from_accno(in_accno text) IS ' Returns the account where the accno field matches (excatly) the 
in_accno provided.';


--
-- Name: account__get_taxes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION account__get_taxes() RETURNS SETOF account
    LANGUAGE sql
    AS $$
SELECT * FROM account 
 WHERE tax is true
ORDER BY accno;
$$;


--
-- Name: FUNCTION account__get_taxes(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION account__get_taxes() IS ' Returns set of accounts where the tax attribute is true.';


--
-- Name: account__is_recon(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION account__is_recon(in_accno text) RETURNS boolean
    LANGUAGE sql
    AS $_$ SELECT count(*) > 0 
     FROM cr_coa_to_account c2a
     JOIN account ON account.id = c2a.chart_id 
    WHERE accno = $1; $_$;


--
-- Name: FUNCTION account__is_recon(in_accno text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION account__is_recon(in_accno text) IS ' Returns true if account is set up for reconciliation, false otherwise.
Note that returns false on invalid account number too';


--
-- Name: account__obtain_balance(date, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION account__obtain_balance(in_transdate date, in_account_id integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE balance numeric;
BEGIN
	SELECT coalesce(sum(ac.amount) + cp.amount, sum(ac.amount))
	INTO balance
	FROM acc_trans ac
	JOIN (select id, approved from ar union
		select id, approved from ap union
		select id, approved from gl) a ON (a.id = ac.trans_id)
	LEFT JOIN (select account_id, end_date, amount from account_checkpoint
		WHERE account_id = in_account_id AND end_date < in_transdate
		ORDER BY end_date desc limit 1
	) cp ON (cp.account_id = ac.chart_id)
	WHERE ac.chart_id = in_account_id 
		AND ac.transdate > coalesce(cp.end_date, ac.transdate - '1 day'::interval)
		and ac.approved and a.approved
		and ac.transdate <= in_transdate
	GROUP BY cp.amount, ac.chart_id;

	RETURN balance;
END;
$$;


--
-- Name: FUNCTION account__obtain_balance(in_transdate date, in_account_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION account__obtain_balance(in_transdate date, in_account_id integer) IS 'Returns the account balance at a given point in time, calculating forward 
from most recent check point.';


--
-- Name: account__save_tax(integer, date, numeric, text, integer, integer, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION account__save_tax(in_chart_id integer, in_validto date, in_rate numeric, in_taxnumber text, in_pass integer, in_taxmodule_id integer, in_old_validto date) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE tax SET validto = in_validto,
               rate = in_rate,
               taxnumber = in_taxnumber,
               pass = in_pass,
               taxmodule_id = in_taxmodule_id
         WHERE chart_id = in_chart_id and validto = in_old_validto;

         IF FOUND THEN
             return true;
         END IF;

         INSERT INTO tax(chart_id, validto, rate, taxnumber, pass, taxmodule_id)
         VALUES (in_chart_id, in_validto, in_rate, in_taxnumber, in_pass,
                 in_taxmodule_id);

         RETURN TRUE;

END;
$$;


--
-- Name: FUNCTION account__save_tax(in_chart_id integer, in_validto date, in_rate numeric, in_taxnumber text, in_pass integer, in_taxmodule_id integer, in_old_validto date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION account__save_tax(in_chart_id integer, in_validto date, in_rate numeric, in_taxnumber text, in_pass integer, in_taxmodule_id integer, in_old_validto date) IS ' This saves tax rates.';


--
-- Name: concat_colon(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION concat_colon(text, text) RETURNS text
    LANGUAGE sql
    AS $_$
select CASE WHEN $1 IS NULL THEN $2 ELSE $1 || ':' || $2 END;
$_$;


--
-- Name: FUNCTION concat_colon(text, text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION concat_colon(text, text) IS '
This function takes two arguments and creates a list out  of them.  It''s useful 
as an aggregate base (see aggregate concat_colon).  However this is a temporary
function only and should not be relied upon.';


--
-- Name: concat_colon(text); Type: AGGREGATE; Schema: public; Owner: -
--

CREATE AGGREGATE concat_colon(text) (
    SFUNC = public.concat_colon,
    STYPE = text
);


--
-- Name: AGGREGATE concat_colon(text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON AGGREGATE concat_colon(text) IS ' This is a sumple aggregate to return values from the database in a 
colon-separated list.  Other programs probably should not rely on this since 
it is primarily included for the chart view.';


--
-- Name: account_heading; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE account_heading (
    id integer NOT NULL,
    accno text NOT NULL,
    parent_id integer,
    description text
);


--
-- Name: TABLE account_heading; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE account_heading IS '
This table holds the account headings in the system.  Each account must belong 
to a heading, and a heading can belong to another heading.  In this way it is 
possible to nest accounts for reporting purposes.';


--
-- Name: account_link; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE account_link (
    account_id integer NOT NULL,
    description text NOT NULL
);


--
-- Name: chart; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW chart AS
    SELECT account_heading.id, account_heading.accno, account_heading.description, 'H'::text AS charttype, NULL::bpchar AS category, NULL::text AS link, NULL::integer AS account_heading, NULL::text AS gifi_accno, false AS contra, false AS tax FROM account_heading UNION SELECT c.id, c.accno, c.description, 'A'::text AS charttype, c.category, concat_colon(l.description) AS link, c.heading AS account_heading, c.gifi_accno, c.contra, c.tax FROM (account c LEFT JOIN account_link l ON ((c.id = l.account_id))) GROUP BY c.id, c.accno, c.description, c.category, c.heading, c.gifi_accno, c.contra, c.tax;


--
-- Name: VIEW chart; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW chart IS 'Compatibility chart for 1.2 and earlier.';


--
-- Name: account_get(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION account_get(in_id integer) RETURNS SETOF chart
    LANGUAGE sql
    AS $_$
SELECT * from chart where id = $1 and charttype = 'A';
$_$;


--
-- Name: FUNCTION account_get(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION account_get(in_id integer) IS 'Returns an entry from the chart view which matches the id requested, and which
is an account, not a heading.';


--
-- Name: account_has_transactions(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION account_has_transactions(in_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
	PERFORM trans_id FROM acc_trans WHERE chart_id = in_id LIMIT 1;
	IF FOUND THEN
		RETURN true;
	ELSE
		RETURN false;
	END IF;
END;
$$;


--
-- Name: FUNCTION account_has_transactions(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION account_has_transactions(in_id integer) IS ' Checks to see if any transactions use this account.  If so, returns true.
If not, returns false.';


--
-- Name: account_heading__list(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION account_heading__list() RETURNS SETOF account_heading
    LANGUAGE sql
    AS $$ SELECT * FROM account_heading order by accno; $$;


--
-- Name: FUNCTION account_heading__list(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION account_heading__list() IS ' Returns a list of all account headings, currently ordered by account number.
';


--
-- Name: account_heading_get(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION account_heading_get(in_id integer) RETURNS chart
    LANGUAGE plpgsql
    AS $$
DECLARE
	account chart%ROWTYPE;
BEGIN
	SELECT * INTO account FROM chart WHERE id = in_id AND charttype = 'H';
	RETURN account;
END;
$$;


--
-- Name: FUNCTION account_heading_get(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION account_heading_get(in_id integer) IS 'Returns an entry from the chart view which matches the id requested, and which
is a heading, not an account.';


--
-- Name: account_heading_list(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION account_heading_list() RETURNS SETOF account_heading
    LANGUAGE sql
    AS $$
SELECT * FROM account_heading order by accno;
$$;


--
-- Name: FUNCTION account_heading_list(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION account_heading_list() IS ' Lists all existing account headings.';


--
-- Name: account_heading_save(integer, text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION account_heading_save(in_id integer, in_accno text, in_description text, in_parent integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE account_heading
	SET accno = in_accno,
		description = in_description,
		parent_id = in_parent
	WHERE id = in_id;

	IF FOUND THEN
		RETURN in_id;
	END IF;
	INSERT INTO account_heading (accno, description, parent_id)
	VALUES (in_accno, in_description, in_parent);

	RETURN currval('account_heading_id_seq');
END;
$$;


--
-- Name: FUNCTION account_heading_save(in_id integer, in_accno text, in_description text, in_parent integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION account_heading_save(in_id integer, in_accno text, in_description text, in_parent integer) IS ' Saves an account heading. ';


--
-- Name: account_save(integer, text, text, character, text, integer, boolean, boolean, text[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION account_save(in_id integer, in_accno text, in_description text, in_category character, in_gifi_accno text, in_heading integer, in_contra boolean, in_tax boolean, in_link text[]) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE 
	t_heading_id int;
	t_link record;
	t_id int;
        t_tax bool;
BEGIN

    SELECT count(*) > 0 INTO t_tax FROM tax WHERE in_id = chart_id;
    t_tax := t_tax OR in_tax;
	-- check to ensure summary accounts are exclusive
        -- necessary for proper handling by legacy code
    FOR t_link IN SELECT description FROM account_link_description 
    WHERE summary='t'
	LOOP
		IF t_link.description = ANY (in_link) and array_upper(in_link, 1) > 1 THEN
			RAISE EXCEPTION 'Invalid link settings:  Summary';
		END IF;
	END LOOP;
	-- heading settings
	IF in_heading IS NULL THEN
		SELECT id INTO t_heading_id FROM account_heading 
		WHERE accno < in_accno order by accno desc limit 1;
	ELSE
		t_heading_id := in_heading;
	END IF;

    -- don't remove custom links.
	DELETE FROM account_link 
	WHERE account_id = in_id 
              and description in ( select description 
                                    from  account_link_description
                                    where custom = 'f');

	UPDATE account 
	SET accno = in_accno,
		description = in_description,
		category = in_category,
		gifi_accno = in_gifi_accno,
		heading = t_heading_id,
		contra = in_contra,
                tax = t_tax
	WHERE id = in_id;

	IF FOUND THEN
		t_id := in_id;
	ELSE
		INSERT INTO account (accno, description, category, gifi_accno,
			heading, contra, tax)
		VALUES (in_accno, in_description, in_category, in_gifi_accno,
			t_heading_id, in_contra, in_tax);

		t_id := currval('account_id_seq');
	END IF;

	FOR t_link IN 
		select in_link[generate_series] AS val
		FROM generate_series(array_lower(in_link, 1), 
			array_upper(in_link, 1))
	LOOP
		INSERT INTO account_link (account_id, description)
		VALUES (t_id, t_link.val);
	END LOOP;

	
	RETURN t_id;
END;
$$;


--
-- Name: FUNCTION account_save(in_id integer, in_accno text, in_description text, in_category character, in_gifi_accno text, in_heading integer, in_contra boolean, in_tax boolean, in_link text[]); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION account_save(in_id integer, in_accno text, in_description text, in_category character, in_gifi_accno text, in_heading integer, in_contra boolean, in_tax boolean, in_link text[]) IS ' This deletes existing account_link entries, where the 
account_link.description is not designated as a custom one in the 
account_link_description table.

If no account heading is provided, the account heading which has an accno field
closest to but prior (by collation order) is used.

Then it saves the account information, and rebuilds the account_link records 
based on the in_link array.
';


--
-- Name: add_custom_field(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION add_custom_field(table_name character varying, new_field_name character varying, field_datatype character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
	perform TABLE_ID FROM custom_table_catalog 
		WHERE extends = table_name;
	IF NOT FOUND THEN
		BEGIN
			INSERT INTO custom_table_catalog (extends) 
				VALUES (table_name);
			EXECUTE 'CREATE TABLE ' || 
                               quote_ident('custom_' ||table_name) ||
				' (row_id INT PRIMARY KEY)';
		EXCEPTION WHEN duplicate_table THEN
			-- do nothing
		END;
	END IF;
	INSERT INTO custom_field_catalog (field_name, table_id)
	values (new_field_name, (SELECT table_id 
                                        FROM custom_table_catalog
		WHERE extends = table_name));
	EXECUTE 'ALTER TABLE '|| quote_ident('custom_'||table_name) || 
                ' ADD COLUMN ' || quote_ident(new_field_name) || ' ' || 
                  quote_ident(field_datatype);
	RETURN TRUE;
END;
$$;


--
-- Name: admin__add_function_to_group(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__add_function_to_group(in_func text, in_role text) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
    
    declare
        stmt TEXT;
        a_role name;
        a_user name;
    BEGIN
    
        -- Issue the grant
        select rolname into a_role from pg_roles where rolname = in_role;
        
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Cannot grant permissions of a non-existant role.';
        END IF;
        
        select rolname into a_user from pg_roles where rolname = in_username;
        
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Cannot grant permissions to a non-existant user.';
        END IF;
        
        stmt := 'GRANT EXECUTE ON FUNCTION '|| quote_ident(in_func) ||' to '|| quote_ident(in_role);
        
        EXECUTE stmt;
        
        return 1;
    END;
    
$$;


--
-- Name: admin__add_user_to_role(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__add_user_to_role(in_username text, in_role text) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
    
    declare
        stmt TEXT;
        a_role name;
        a_user name;
    BEGIN
    
        -- Issue the grant
        select rolname into a_role from pg_roles where rolname = in_role;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Cannot grant permissions of a non-existant role.';
        END IF;
        
        select rolname into a_user from pg_roles where rolname = in_username;
        
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Cannot grant permissions to a non-existant user.';
        END IF;
        
        stmt := 'GRANT '|| quote_ident(in_role) ||' to '|| quote_ident(in_username);
        
        EXECUTE stmt;
        insert into lsmb_roles (user_id, role) 
        SELECT id, in_role from users where username = in_username;
        return 1;
    END;
    
$$;


--
-- Name: admin__create_group(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__create_group(in_group_name text) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
    
    DECLARE
        
        stmt text;
        t_dbname text;
    BEGIN
	t_dbname := current_database();
        stmt := 'create role lsmb_'|| quote_ident(t_dbname || '__' || in_group_name);
        execute stmt;
        return 1;
    END;
    
$$;


--
-- Name: admin__delete_group(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__delete_group(in_group_name text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
    
    DECLARE
        stmt text;
        a_role role_view;
        t_dbname text;
    BEGIN
        t_dbname := current_database();
        

        select * into a_role from role_view where rolname = in_group_name;
        
        if not found then
            return 'f'::bool;
        else
            stmt := 'drop role lsmb_' || quote_ident(t_dbname || '__' || in_group_name);
            execute stmt;
            return 't'::bool;
        end if;
    END;
$$;


--
-- Name: FUNCTION admin__delete_group(in_group_name text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION admin__delete_group(in_group_name text) IS ' 
    Deletes the input group from the database. Not designed to be used to 
    remove a login-capable user.
';


--
-- Name: admin__delete_user(text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__delete_user(in_username text, in_drop_role boolean) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
    
    DECLARE
        stmt text;
        a_user users;
    BEGIN
    
        select * into a_user from users where username = in_username;
        
        IF NOT FOUND THEN
        
            raise exception 'User not found.';
        ELSIF FOUND THEN
            IF in_drop_role IS TRUE then 
                stmt := ' drop user ' || quote_ident(a_user.username);
                execute stmt;
            END IF;    
            -- also gets user_connection
            delete from user_preference where id = (
                   select id from users where entity_id = a_user.entity_id);
            delete from users where entity_id = a_user.entity_id;
            return 1;
        END IF;   
    END;
    
$$;


--
-- Name: FUNCTION admin__delete_user(in_username text, in_drop_role boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION admin__delete_user(in_username text, in_drop_role boolean) IS ' 
    Drops the provided user, as well as deletes the user configuration data.
It leaves the entity and person references.

If in_drop_role is set, it drops the role too.
';


--
-- Name: admin__drop_session(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__drop_session(in_session_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
	DELETE FROM "session" WHERE session_id = in_session_id;
	RETURN FOUND;
END;
$$;


--
-- Name: FUNCTION admin__drop_session(in_session_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION admin__drop_session(in_session_id integer) IS ' Drops the session identified, releasing all locks held.';


--
-- Name: admin__get_roles(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__get_roles() RETURNS SETOF pg_roles
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_rol record;
    t_dbname text;
BEGIN
    t_dbname := current_database();
    FOR v_rol in 
        SELECT *
        from 
            pg_roles
        where 
            rolname ~ ('^lsmb_' || t_dbname || '__') 
            and rolcanlogin is false
        order by rolname ASC
    LOOP
        RETURN NEXT v_rol;
    END LOOP;
END;
$$;


--
-- Name: admin__get_roles_for_user(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__get_roles_for_user(in_user_id integer) RETURNS SETOF text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
    
    declare
        u_role record;
        a_user users;
    begin
        select * into a_user from admin__get_user(in_user_id);
        
        FOR u_role IN 
        select r.rolname 
        from 
            pg_roles r,
            (select 
                m.roleid 
             from 
                pg_auth_members m, pg_roles b 
             where 
                m.member = b.oid 
             and 
                b.rolname = a_user.username
            ) as ar
         where 
            r.oid = ar.roleid
         LOOP
        
            RETURN NEXT u_role.rolname::text;
        
        END LOOP;
        RETURN;
    end;
    
$$;


--
-- Name: FUNCTION admin__get_roles_for_user(in_user_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION admin__get_roles_for_user(in_user_id integer) IS ' Returns a set of roles that  a user is a part of.';


--
-- Name: users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    username character varying(30) NOT NULL,
    notify_password interval DEFAULT '7 days'::interval NOT NULL,
    entity_id integer NOT NULL
);


--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE users IS 'username is the actual primary key here because we 
do not want duplicate users';


--
-- Name: admin__get_user(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__get_user(in_user_id integer) RETURNS SETOF users
    LANGUAGE plpgsql
    AS $$
    
    DECLARE
        a_user users;
    BEGIN
        
        select * into a_user from users where id = in_user_id;
        return next a_user;
        return;
    
    END;    
$$;


--
-- Name: FUNCTION admin__get_user(in_user_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION admin__get_user(in_user_id integer) IS ' Returns a set of (only one) user specified by the id.';


--
-- Name: admin__is_group(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__is_group(in_group_name text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
    -- This needs some work.  CT 
    DECLARE
        
        existant_role pg_roles;
        stmt text;
        
    BEGIN
        select * into existant_role from pg_roles 
        where rolname = in_group_name AND rolcanlogin is false;
        
        if not found then
            return 'f'::bool;
            
        else
            return 't'::bool;
        end if;            
    END;
    
$$;


--
-- Name: admin__is_user(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__is_user(in_user text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
    BEGIN
    
        PERFORM * from users where username = in_user;
        RETURN found;     
    
    END;
    
$$;


--
-- Name: FUNCTION admin__is_user(in_user text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION admin__is_user(in_user text) IS ' Returns true if user is set up in LedgerSMB.  False otherwise.';


--
-- Name: admin__list_roles(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__list_roles(in_username text) RETURNS SETOF text
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE out_rolename RECORD;
BEGIN
	FOR out_rolename IN 
		SELECT rolname FROM pg_roles 
		WHERE oid IN (SELECT id FROM connectby (
			'(SELECT m.member, m.roleid, r.oid FROM pg_roles r 
			LEFT JOIN pg_auth_members m ON (r.oid = m.roleid)) a',
			'oid', 'member', 'oid', '320461', '0', ','
			) c(id integer, parent integer, "level" integer, 
				path text, list_order integer)
			)
	LOOP
		RETURN NEXT out_rolename.rolname;
	END LOOP;
END;
$$;


--
-- Name: admin__list_sessions(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__list_sessions() RETURNS SETOF session_result
    LANGUAGE sql
    AS $$
SELECT s.session_id, u.username, s.last_used, count(t.id)
FROM "session" s
JOIN users u ON (s.users_id = u.id)
LEFT JOIN transactions t ON (t.locked_by = s.session_id)
GROUP BY s.session_id, u.username, s.last_used
ORDER BY u.username;
$$;


--
-- Name: FUNCTION admin__list_sessions(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION admin__list_sessions() IS ' Lists all active sessions.';


--
-- Name: admin__remove_function_from_group(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__remove_function_from_group(in_func text, in_role text) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $_$
    
    declare
        stmt TEXT;
        a_role name;
        a_user name;
    BEGIN
    
        -- Issue the grant
        select rolname into a_role from pg_roles where rolname = in_role;
        
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Cannot revoke permissions of non-existant role $.';
        END IF;
        
        select rolname into a_user from pg_roles where rolname = in_username;
        
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Cannot revoke permissions from a non-existant function.';
        END IF;
        
        stmt := 'REVOKE EXECUTE ON FUNCTION '|| quote_ident(in_func) ||' FROM '|| quote_ident(in_role);
        
        EXECUTE stmt;
        
        return 1;    
    END;
    
    
$_$;


--
-- Name: admin__remove_user_from_role(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__remove_user_from_role(in_username text, in_role text) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
    
    declare
        stmt TEXT;
        a_role name;
        a_user name;
    BEGIN
    
        -- Issue the grant
        select rolname into a_role from pg_roles where rolname = in_role;
        
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Cannot revoke permissions of a non-existant role.';
        END IF;
        
        select rolname into a_user from pg_roles where rolname = in_username;
        
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Cannot revoke permissions from a non-existant user.';
        END IF;
        
        stmt := 'REVOKE '|| quote_ident(in_role) ||' FROM '|| quote_ident(in_username);
        
        EXECUTE stmt;
        
        return 1;    
    END;
    
$$;


--
-- Name: admin__save_user(integer, integer, text, text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__save_user(in_id integer, in_entity_id integer, in_username text, in_password text, in_import boolean) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $_$
    DECLARE
    
        a_user users;
        v_user_id int;
        p_id int;
        l_id int;
        stmt text;
        t_is_role bool;
        t_is_user bool;
    BEGIN
        -- WARNING TO PROGRAMMERS:  This function runs as the definer and runs
        -- utility statements via EXECUTE.
        -- PLEASE BE VERY CAREFUL ABOUT SQL-INJECTION INSIDE THIS FUNCTION.

       PERFORM rolname FROM pg_roles WHERE rolname = in_username;
       t_is_role := found;
       t_is_user := admin__is_user(in_username);

       IF t_is_role is true and t_is_user is false and in_import is false THEN
          RAISE EXCEPTION 'Duplicate user';
        END IF;

        if t_is_role and in_password is not null then
                execute 'ALTER USER ' || quote_ident( in_username ) || 
                     ' WITH ENCRYPTED PASSWORD ' || quote_literal (in_password)
                     || $e$ valid until $e$ || 
                      quote_literal(now() + '1 day'::interval);
        elsif in_import is false AND t_is_user is false 
              AND in_password IS NULL THEN
                RAISE EXCEPTION 'No password';
        elsif  t_is_role is false THEN
            -- create an actual user
                execute 'CREATE USER ' || quote_ident( in_username ) || 
                     ' WITH ENCRYPTED PASSWORD ' || quote_literal (in_password)
                     || $e$ valid until $e$ || quote_literal(now() + '1 day'::interval);
       END IF;         
        
        select * into a_user from users lu where lu.id = in_id;
        IF FOUND THEN 
            return a_user.id;
        ELSE
            -- Insert cycle
            
            --- The entity is expected to already BE created. See admin.pm.
            
            
            v_user_id := nextval('users_id_seq');
            insert into users (id, username, entity_id) VALUES (
                v_user_id,
                in_username,
                in_entity_id
            );
            
            insert into user_preference (id) values (v_user_id);

            IF NOT exists(SELECT * FROM entity_employee WHERE entity_id = in_entity_id) THEN
                INSERT into entity_employee (entity_id) values (in_entity_id);
            END IF;
            -- Finally, issue the create user statement
            
            return v_user_id ;

            
        
        END IF;
    
    END;
$_$;


--
-- Name: FUNCTION admin__save_user(in_id integer, in_entity_id integer, in_username text, in_password text, in_import boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION admin__save_user(in_id integer, in_entity_id integer, in_username text, in_password text, in_import boolean) IS ' Creates a user and relevant records in LedgerSMB and PostgreSQL.';


--
-- Name: admin__search_users(text, text, text, text, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION admin__search_users(in_username text, in_first_name text, in_last_name text, in_ssn text, in_dob date) RETURNS SETOF user_result
    LANGUAGE plpgsql
    AS $$
DECLARE t_return_row user_result;
BEGIN
	FOR t_return_row IN
		SELECT u.id, u.username, p.first_name, p.last_name, e.ssn, e.dob
		FROM users u
		JOIN person p ON (u.entity_id = p.entity_id)
		JOIN entity_employee e ON (e.entity_id = p.entity_id)
		WHERE u.username LIKE '%' || coalesce(in_username,'') || '%' AND
			(p.first_name = in_first_name or in_first_name is null)
			AND (p.last_name = in_last_name or in_last_name is null)
			AND (in_ssn is NULL or in_ssn = e.ssn) 
			AND (e.dob = in_dob::date or in_dob is NULL)
	LOOP
		RETURN NEXT t_return_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION admin__search_users(in_username text, in_first_name text, in_last_name text, in_ssn text, in_dob date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION admin__search_users(in_username text, in_first_name text, in_last_name text, in_ssn text, in_dob date) IS ' Returns a list of users matching search criteria.  Nulls match all values.
only username is not an exact match.';


--
-- Name: asset_item; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_item (
    id integer NOT NULL,
    description text,
    tag text NOT NULL,
    purchase_value numeric,
    salvage_value numeric,
    usable_life numeric,
    purchase_date date NOT NULL,
    start_depreciation date NOT NULL,
    location_id integer,
    department_id integer,
    invoice_id integer,
    asset_account_id integer,
    dep_account_id integer,
    exp_account_id integer,
    obsolete_by integer,
    asset_class_id integer
);


--
-- Name: TABLE asset_item; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE asset_item IS ' Stores details of asset items.  The account fields here are authoritative,
while the ones in the asset_class table are defaults.';


--
-- Name: COLUMN asset_item.tag; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN asset_item.tag IS ' This can be plugged into other routines to generate it automatically via ALTER TABLE .... SET DEFAULT.....';


--
-- Name: asset__get(integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset__get(in_id integer, in_tag text) RETURNS asset_item
    LANGUAGE plpgsql
    AS $$
DECLARE ret_val asset_item;
BEGIN
	SELECT * into ret_val from asset_item WHERE id = in_id OR in_tag = tag
        ORDER BY id desc limit 1;
	return ret_val;
END;
$$;


--
-- Name: FUNCTION asset__get(in_id integer, in_tag text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset__get(in_id integer, in_tag text) IS ' Retrieves a given asset either by id or tag.  Both are complete matches.

Note that the behavior is undefined if both id and tag are provided.';


--
-- Name: asset__import_from_disposal(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset__import_from_disposal(in_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE t_report asset_report;
        t_import asset_report;
BEGIN

    SELECT * INTO t_report from asset_report where id = in_id;

    if t_report.report_class <> 4 THEN RETURN FALSE;
    END IF;

    SELECT * 
      INTO t_import 
      FROM  asset_report__begin_import 
            (t_report.asset_class::int, t_report.report_date);

    PERFORM asset_report__import(
	ai.description,
	ai.tag,
	ai.purchase_value * rld.percent_disposed / 100,
	ai.salvage_value * rld.percent_disposed / 100,
	ai.usable_life,
	ai.purchase_date,
        ai.start_depreciation,
	ai.location_id,
	ai.department_id,
	ai.asset_account_id,
	ai.dep_account_id,
	ai.exp_account_id,
	ai.asset_class_id,
        ai.invoice_id,
        t_import.id,
        r.accum_depreciation * rld.percent_disposed / 100,
        TRUE)
    FROM asset_item ai
    JOIN asset_report__get_disposal(t_report.id) r  ON (ai.id = r.id)
    JOIN asset_report_line rl ON (rl.asset_id = ai.id AND rl.report_id = in_id)
    join asset_rl_to_disposal_method rld 
         ON (rl.report_id = rld.report_id and ai.id = rld.asset_id)
   where rld.percent_disposed is null or percent_disposed < 100;
   RETURN TRUE;
END;
$$;


--
-- Name: FUNCTION asset__import_from_disposal(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset__import_from_disposal(in_id integer) IS ' Imports items from partial disposal reports. This function should not be
called dirctly by programmers but rather through the other disposal approval
api''s.';


--
-- Name: asset__save(integer, integer, text, text, date, numeric, numeric, numeric, date, integer, integer, integer, integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset__save(in_id integer, in_asset_class integer, in_description text, in_tag text, in_purchase_date date, in_purchase_value numeric, in_usable_life numeric, in_salvage_value numeric, in_start_depreciation date, in_warehouse_id integer, in_department_id integer, in_invoice_id integer, in_asset_account_id integer, in_dep_account_id integer, in_exp_account_id integer) RETURNS asset_item
    LANGUAGE plpgsql
    AS $$
DECLARE ret_val asset_item;
BEGIN
	UPDATE asset_item
	SET asset_class_id = in_asset_class,
		description = in_description,
		tag = in_tag,
		purchase_date = in_purchase_date,
		purchase_value = in_purchase_value,
		usable_life = in_usable_life,
		location_id = in_warehouse_id,
		department_id = in_department_id,
		invoice_id = in_invoice_id,
		salvage_value = in_salvage_value,
                asset_account_id = in_asset_account_id,
                exp_account_id = in_exp_account_id,
                start_depreciation = 
                         coalesce(in_start_depreciation, in_purchase_date),
                dep_account_id = in_dep_account_id
	WHERE id = in_id;
	IF FOUND THEN
		SELECT * INTO ret_val FROM asset_item WHERE id = in_id;
		return ret_val;
	END IF;

	INSERT INTO asset_item (asset_class_id, description, tag, purchase_date,
		purchase_value, usable_life, salvage_value, department_id,
		location_id, invoice_id, asset_account_id, dep_account_id,
                start_depreciation, exp_account_id)
	VALUES (in_asset_class, in_description, in_tag, in_purchase_date,
		in_purchase_value, in_usable_life, in_salvage_value,
		in_department_id, in_warehouse_id, in_invoice_id,
                in_asset_account_id, in_dep_account_id,
                coalesce(in_start_depreciation, in_purchase_date),
                in_exp_account_id);

	SELECT * INTO ret_val FROM asset_item 
	WHERE id = currval('asset_item_id_seq');
	RETURN ret_val;
END;
$$;


--
-- Name: FUNCTION asset__save(in_id integer, in_asset_class integer, in_description text, in_tag text, in_purchase_date date, in_purchase_value numeric, in_usable_life numeric, in_salvage_value numeric, in_start_depreciation date, in_warehouse_id integer, in_department_id integer, in_invoice_id integer, in_asset_account_id integer, in_dep_account_id integer, in_exp_account_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset__save(in_id integer, in_asset_class integer, in_description text, in_tag text, in_purchase_date date, in_purchase_value numeric, in_usable_life numeric, in_salvage_value numeric, in_start_depreciation date, in_warehouse_id integer, in_department_id integer, in_invoice_id integer, in_asset_account_id integer, in_dep_account_id integer, in_exp_account_id integer) IS ' Saves the asset with the information provided.  If the id is provided, 
overwrites the record with the id.  Otherwise, or if that record is not found,
inserts.  Returns the row inserted or updated.
';


--
-- Name: asset__search(integer, text, text, date, numeric, numeric, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset__search(in_asset_class integer, in_description text, in_tag text, in_purchase_date date, in_purchase_value numeric, in_usable_life numeric, in_salvage_value numeric) RETURNS SETOF asset_item
    LANGUAGE plpgsql
    AS $$
DECLARE out_val asset_item;
BEGIN
	FOR out_val IN
		SELECT * FROM asset_item
		WHERE (in_asset_class is null 
			or asset_class_id = in_asset_class)
			AND (in_description is null or description 
				LIKE '%' || in_description || '%')
			and (in_tag is not null or tag like '%'||in_tag||'%')
			AND (in_purchase_date is null 
				or purchase_date = in_purchase_date)
			AND (in_purchase_value is null
				or in_purchase_value = purchase_value)
			AND (in_usable_life is null
				or in_usable_life = usable_life)
			AND (in_salvage_value is null
				OR in_salvage_value = salvage_value)
	LOOP
		RETURN NEXT out_val;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION asset__search(in_asset_class integer, in_description text, in_tag text, in_purchase_date date, in_purchase_value numeric, in_usable_life numeric, in_salvage_value numeric); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset__search(in_asset_class integer, in_description text, in_tag text, in_purchase_date date, in_purchase_value numeric, in_usable_life numeric, in_salvage_value numeric) IS 'Searches for assets.  Nulls match all records.  Asset class is exact,
as is purchase date, purchase value, and salvage value. Tag and description
are partial matches.';


--
-- Name: asset_class; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_class (
    id integer NOT NULL,
    label text NOT NULL,
    asset_account_id integer,
    dep_account_id integer,
    method integer
);


--
-- Name: TABLE asset_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE asset_class IS '
The account fields here set the defaults for the individual asset items.  They
are non-authoritative.
';


--
-- Name: asset_class__get(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_class__get(in_id integer) RETURNS asset_class
    LANGUAGE plpgsql
    AS $$
DECLARE ret_val asset_class;
BEGIN 
	SELECT * INTO ret_val FROM asset_class WHERE id = in_id;
	RETURN ret_val;
END;
$$;


--
-- Name: FUNCTION asset_class__get(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_class__get(in_id integer) IS ' returns the row from asset_class identified by in_id.';


--
-- Name: asset_class__get_asset_accounts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_class__get_asset_accounts() RETURNS SETOF account
    LANGUAGE sql
    AS $$
SELECT * FROM account 
WHERE id IN 
	(select account_id from account_link where description = 'Fixed_Asset')
ORDER BY accno;
$$;


--
-- Name: FUNCTION asset_class__get_asset_accounts(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_class__get_asset_accounts() IS ' Returns a list of fixed asset accounts, ordered by account number';


--
-- Name: asset_class__get_dep_accounts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_class__get_dep_accounts() RETURNS SETOF account
    LANGUAGE sql
    AS $$
SELECT * FROM account 
WHERE id IN 
	(select account_id from account_link where description = 'Asset_Dep')
ORDER BY accno;
$$;


--
-- Name: FUNCTION asset_class__get_dep_accounts(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_class__get_dep_accounts() IS ' Returns a list of asset depreciation accounts, ordered by account number';


--
-- Name: asset_dep_method; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_dep_method (
    id integer NOT NULL,
    method text NOT NULL,
    sproc text NOT NULL,
    unit_label text NOT NULL,
    short_name text NOT NULL,
    unit_class integer NOT NULL
);


--
-- Name: TABLE asset_dep_method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE asset_dep_method IS ' Stores asset depreciation methods, and their relevant stored procedures.

The fixed asset system is such depreciation methods can be plugged in via this
table.';


--
-- Name: COLUMN asset_dep_method.method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN asset_dep_method.method IS ' These are keyed to specific stored procedures.  Currently only "straight_line" is supported';


--
-- Name: COLUMN asset_dep_method.sproc; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN asset_dep_method.sproc IS 'The sproc mentioned here is a stored procedure which must have the following
arguments: (in_asset_ids int[],  in_report_date date, in_report_id int).

Here in_asset_ids are the assets to be depreciated, in_report_date is the date
of the report, and in_report_id is the id of the report.  The sproc MUST
insert the relevant lines into asset_report_line. ';


--
-- Name: asset_class__get_dep_method(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_class__get_dep_method(in_asset_class integer) RETURNS asset_dep_method
    LANGUAGE sql
    AS $_$
SELECT * from asset_dep_method 
WHERE id = (select method from asset_class where id = $1);
$_$;


--
-- Name: FUNCTION asset_class__get_dep_method(in_asset_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_class__get_dep_method(in_asset_class integer) IS 'Returns the depreciation method associated with the asset class.';


--
-- Name: asset_class__get_dep_methods(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_class__get_dep_methods() RETURNS SETOF asset_dep_method
    LANGUAGE sql
    AS $$
SELECT * FROM asset_dep_method ORDER BY method;
$$;


--
-- Name: FUNCTION asset_class__get_dep_methods(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_class__get_dep_methods() IS ' Returns a set of asset_dep_methods ordered by the method label.';


--
-- Name: asset_class__list(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_class__list() RETURNS SETOF asset_class
    LANGUAGE sql
    AS $$
SELECT * FROM asset_class ORDER BY label;
$$;


--
-- Name: FUNCTION asset_class__list(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_class__list() IS ' Returns an alphabetical list of asset classes.';


--
-- Name: asset_class__save(integer, integer, integer, integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_class__save(in_id integer, in_asset_account_id integer, in_dep_account_id integer, in_method integer, in_label text, in_unit_label text) RETURNS asset_class
    LANGUAGE plpgsql
    AS $$
DECLARE ret_val asset_class;
BEGIN
	UPDATE asset_class 
	SET asset_account_id = in_asset_account_id,
		dep_account_id = in_dep_account_id,
		method = in_method,
		label = in_label
	WHERE id = in_id;

	IF FOUND THEN
		SELECT * INTO ret_val FROM asset_class where id = in_id;
		RETURN ret_val;
	END IF;

	INSERT INTO asset_class (asset_account_id, dep_account_id, method,
		label)
	VALUES (in_asset_account_id, in_dep_account_id, in_method, 
		in_label);

	SELECT * INTO ret_val FROM asset_class 
	WHERE id = currval('asset_class_id_seq');

	RETURN ret_val;
END;
$$;


--
-- Name: FUNCTION asset_class__save(in_id integer, in_asset_account_id integer, in_dep_account_id integer, in_method integer, in_label text, in_unit_label text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_class__save(in_id integer, in_asset_account_id integer, in_dep_account_id integer, in_method integer, in_label text, in_unit_label text) IS ' Saves this data as an asset_class record.  If in_id is NULL or is not found
in the table, inserts a new row.  Returns the row saved.';


--
-- Name: asset_class__search(integer, integer, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_class__search(in_asset_account_id integer, in_dep_account_id integer, in_method integer, in_label text) RETURNS SETOF asset_class_result
    LANGUAGE plpgsql
    AS $$
DECLARE out_var asset_class_result;
BEGIN
	FOR out_var IN
		SELECT ac.id, ac.asset_account_id, aa.accno, aa.description, 
			ad.accno, ad.description, m.method, ac.method,
			ac.label
		FROM asset_class ac
		JOIN account aa ON (aa.id = ac.asset_account_id)
		JOIN account ad ON (ad.id = ac.dep_account_id)
		JOIN asset_dep_method m ON (ac.method = m.id)
		WHERE 
			(in_asset_account_id is null 
				or in_asset_account_id = ac.asset_account_id)
			AND (in_dep_account_id is null OR
				in_dep_account_id = ac.dep_account_id)
			AND (in_method is null OR in_method = ac.method)
			AND (in_label IS NULL OR ac.label LIKE 
				'%' || in_label || '%')
               ORDER BY label
	LOOP
		RETURN NEXT out_var;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION asset_class__search(in_asset_account_id integer, in_dep_account_id integer, in_method integer, in_label text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_class__search(in_asset_account_id integer, in_dep_account_id integer, in_method integer, in_label text) IS ' Returns a list of matching asset classes.  The account id''s are exact matches
as is the method, but the label is a partial match.  NULL''s match all.';


--
-- Name: asset_dep__straight_line_base(numeric, numeric, numeric, numeric, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_dep__straight_line_base(in_base_life numeric, in_life numeric, in_used numeric, in_basis numeric, in_dep_to_date numeric) RETURNS numeric
    LANGUAGE sql
    AS $_$
SELECT CASE WHEN $3/$1 * $4 < $4 - $5 THEN $3/$1 * $4 
            ELSE $4 - $5
            END;
$_$;


--
-- Name: FUNCTION asset_dep__straight_line_base(in_base_life numeric, in_life numeric, in_used numeric, in_basis numeric, in_dep_to_date numeric); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_dep__straight_line_base(in_base_life numeric, in_life numeric, in_used numeric, in_basis numeric, in_dep_to_date numeric) IS ' This function is a basic function which does the actual calculation for 
straight line depreciation.';


--
-- Name: asset_dep__used_months(date, date, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_dep__used_months(in_last_dep date, in_dep_date date, in_usable_life numeric) RETURNS numeric
    LANGUAGE sql
    AS $_$
select CASE WHEN extract('MONTHS' FROM (date_trunc('day', $2) - date_trunc('day', $1))) 
                 > $3
            THEN $3
            ELSE extract('MONTHS' FROM (date_trunc('day', $2) - date_trunc('day', $1)))::numeric
            END;
$_$;


--
-- Name: FUNCTION asset_dep__used_months(in_last_dep date, in_dep_date date, in_usable_life numeric); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_dep__used_months(in_last_dep date, in_dep_date date, in_usable_life numeric) IS ' This checks the interval between the two dates, and if longer than the 
usable life, returns the months in that interval.  Otherwise returns the 
usable life.';


--
-- Name: asset_dep_get_usable_life_yr(numeric, date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_dep_get_usable_life_yr(in_usable_life numeric, in_start_date date, in_dep_date date) RETURNS numeric
    LANGUAGE sql
    AS $_$
   SELECT CASE WHEN $3 IS NULL or get_fractional_year($2, $3) > $1 
               then $1
               WHEN get_fractional_year($2, $3) < 0
               THEN 0
               ELSE get_fractional_year($2, $3)
          END;
$_$;


--
-- Name: FUNCTION asset_dep_get_usable_life_yr(in_usable_life numeric, in_start_date date, in_dep_date date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_dep_get_usable_life_yr(in_usable_life numeric, in_start_date date, in_dep_date date) IS 'If the interval is less than 0 then 0.  If the interval is greater than the 
usable life, then the usable life.  Otherwise, return the interval as a 
fractional year.';


--
-- Name: asset_dep_straight_line_month(integer[], date, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_dep_straight_line_month(in_asset_ids integer[], in_report_date date, in_report_id integer) RETURNS boolean
    LANGUAGE sql
    AS $_$
     INSERT INTO asset_report_line (asset_id, report_id, amount, department_id, 
                                   warehouse_id)
     SELECT ai.id, $3, 
            asset_dep__straight_line_base(
                  ai.usable_life,
                  ai.usable_life --months
                  - months_passed(coalesce(start_depreciation, purchase_date),
                                  coalesce(max(report_date),
                                           start_depreciation,
                                           purchase_date)),
                  months_passed(coalesce(max(report_date),
                                         start_depreciation,
                                         purchase_date),
                                $2),
                  purchase_value - salvage_value,
                  coalesce(sum(l.amount), 0)), 
            ai.department_id, ai.location_id
       FROM asset_item ai
  LEFT JOIN asset_report_line l ON (l.asset_id = ai.id)
  LEFT JOIN asset_report r ON (l.report_id = r.id)
      WHERE ai.id = ANY($1) 
   GROUP BY ai.id, ai.start_depreciation, ai.purchase_date, ai.purchase_value,
            ai.salvage_value, ai.department_id, ai.location_id, ai.usable_life;
                                                      
    UPDATE asset_report SET report_class = 1 WHERE id = $3;

    select true;
$_$;


--
-- Name: FUNCTION asset_dep_straight_line_month(in_asset_ids integer[], in_report_date date, in_report_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_dep_straight_line_month(in_asset_ids integer[], in_report_date date, in_report_id integer) IS ' Performs straight line depreciation, selecting depreciation amounts, etc. 
into a report for further review and approval.  Usable life is in months, and
depreciation is an equal amount every month.';


--
-- Name: asset_dep_straight_line_yr_m(integer[], date, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_dep_straight_line_yr_m(in_asset_ids integer[], in_report_date date, in_report_id integer) RETURNS boolean
    LANGUAGE sql
    AS $_$
     INSERT INTO asset_report_line (asset_id, report_id, amount, department_id, 
                                   warehouse_id)
     SELECT ai.id, $3, 
            asset_dep__straight_line_base(
                  ai.usable_life * 12,
                  ai.usable_life * 12 --months
                  - months_passed(coalesce(start_depreciation, purchase_date),
                                  coalesce(max(report_date),
                                           start_depreciation,
                                           purchase_date)),
                  months_passed(coalesce(max(report_date),
                                         start_depreciation,
                                         purchase_date),
                                $2),
                  purchase_value - salvage_value,
                  coalesce(sum(l.amount), 0)), 
            ai.department_id, ai.location_id
       FROM asset_item ai
  LEFT JOIN asset_report_line l ON (l.asset_id = ai.id)
  LEFT JOIN asset_report r ON (l.report_id = r.id)
      WHERE ai.id = ANY($1) 
   GROUP BY ai.id, ai.start_depreciation, ai.purchase_date, ai.purchase_value,
            ai.salvage_value, ai.department_id, ai.location_id, ai.usable_life;
                                                      
    UPDATE asset_report SET report_class = 1 WHERE id = $3;

    select true;
$_$;


--
-- Name: FUNCTION asset_dep_straight_line_yr_m(in_asset_ids integer[], in_report_date date, in_report_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_dep_straight_line_yr_m(in_asset_ids integer[], in_report_date date, in_report_id integer) IS ' Performs straight line depreciation on a set of selected assets, selecting
the depreciation values into a report.

Assumes the usable life is measured in years, and is depreciated eavenly every
month.';


--
-- Name: person__get_my_entity_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION person__get_my_entity_id() RETURNS integer
    LANGUAGE sql
    AS $$
	SELECT entity_id from users where username = SESSION_USER;
$$;


--
-- Name: FUNCTION person__get_my_entity_id(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION person__get_my_entity_id() IS ' Returns the entity_id of the current, logged in user.';


--
-- Name: asset_report; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_report (
    id integer NOT NULL,
    report_date date,
    gl_id bigint,
    asset_class bigint,
    report_class integer,
    entered_by bigint DEFAULT person__get_my_entity_id() NOT NULL,
    approved_by bigint,
    entered_at timestamp without time zone DEFAULT now(),
    approved_at timestamp without time zone,
    depreciated_qty numeric,
    dont_approve boolean DEFAULT false,
    submitted boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE asset_report; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE asset_report IS ' Asset reports are discrete sets of depreciation or disposal transctions,
and each one may be turned into no more than one GL transaction.';


--
-- Name: asset_depreciation__approve(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_depreciation__approve(in_report_id integer, in_expense_acct integer) RETURNS asset_report
    LANGUAGE plpgsql
    AS $$
declare retval asset_report;
begin

retval := asset_report__record_approve(in_report_id);

INSERT INTO gl (reference, description, approved)
select 'Asset Report ' || in_id, 'Asset Depreciation Report for ' || report_date,
       false
 FROM asset_report where id = in_id;

INSERT INTO acc_trans (amount, chart_id, transdate, approved, trans_id)
SELECT l.amount, a.dep_account_id, r.report_date, true, currval('id')
  FROM asset_report r
  JOIN asset_report_line l ON (r.id = l.report_id)
  JOIN asset_item a ON (a.id = l.asset_id)
 WHERE r.id = in_id;

INSERT INTO acc_trans (amount, chart_id, transdate, approved, trans_id)
SELECT sum(l.amount) * -1, in_expense_acct, r.report_date, approved, 
       currval('id')
  FROM asset_report r
  JOIN asset_report_line l ON (r.id = l.report_id)
  JOIN asset_item a ON (a.id = l.asset_id)
 WHERE r.id = in_id
 GROUP BY r.report_date;


return retval;

end;
$$;


--
-- Name: FUNCTION asset_depreciation__approve(in_report_id integer, in_expense_acct integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_depreciation__approve(in_report_id integer, in_expense_acct integer) IS 'Approves an asset depreciation report and creats the GL draft.';


--
-- Name: asset_disposal__approve(integer, integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_disposal__approve(in_id integer, in_gain_acct integer, in_loss_acct integer, in_asset_acct integer) RETURNS asset_report
    LANGUAGE plpgsql
    AS $$
DECLARE 
   retval asset_report;
   iter record;
   t_disposed_percent numeric;
begin
-- this code is fairly opaque and needs more documentation that would be 
-- otherwise optimal. This is mostly due to the fact that we have fairly
-- repetitive insert/select routines and the fact that the accounting 
-- requirements are not immediately intuitive.  Inserts marked functionally along
-- with typical debit/credit designations.  Note debits are always negative.


retval := asset_report__record_approve(in_id);
if retval.report_class = 2 then
     t_disposed_percent := 100;
end if;

INSERT INTO gl (reference, description, approved, transdate)
select 'Asset Report ' || in_id, 'Asset Disposal Report for ' || report_date,
       false, report_date
 FROM asset_report where id = in_id;

-- REMOVING ASSETS FROM ACCOUNT (Credit)
insert into acc_trans (trans_id, chart_id, amount, approved, transdate)
SELECT currval('id'), a.asset_account_id, 
       a.purchase_value 
       * (coalesce(t_disposed_percent, m.percent_disposed)/100), 
       true, r.report_date
 FROM  asset_item a
 JOIN  asset_report_line l ON (l.asset_id = a.id)
 JOIN  asset_report r ON (r.id = l.report_id)
 JOIN  asset_rl_to_disposal_method m 
        ON (l.report_id = m.report_id and l.asset_id = m.asset_id)
 WHERE r.id = in_id;

-- REMOVING ACCUM DEP. (Debit)
INSERT into acc_trans (trans_id, chart_id, amount, approved, transdate)
SELECT currval('id'), a.dep_account_id, 
       sum(dl.amount) * -1 
       * (coalesce(t_disposed_percent, m.percent_disposed)/100), 
       true, r.report_date
 FROM  asset_item a
 JOIN  asset_report_line l ON (l.asset_id = a.id)
 JOIN  asset_report r ON (r.id = l.report_id)
 JOIN  asset_report_line dl ON (l.asset_id = dl.asset_id)
 JOIN  asset_rl_to_disposal_method m 
        ON (l.report_id = m.report_id and l.asset_id = m.asset_id)
 JOIN  asset_report dr ON (dl.report_id = dr.id 
                           and dr.report_class = 1
                           and dr.approved_at is not null)
 WHERE r.id = in_id
group by a.dep_account_id, m.percent_disposed, r.report_date;

-- INSERT asset/proceeds (Debit, credit for negative values)
INSERT INTO acc_trans (trans_id, chart_id, amount, approved, transdate)
SELECT currval('id'), in_asset_acct, coalesce(l.amount, 0) * -1, true, r.report_date
 FROM  asset_item a
 JOIN  asset_report_line l ON (l.asset_id = a.id)
 JOIN  asset_report r ON (r.id = l.report_id)
 JOIN  asset_rl_to_disposal_method m 
        ON (l.report_id = m.report_id and l.asset_id = m.asset_id)
 WHERE r.id = in_id;

-- INSERT GAIN/LOSS (Credit for gain, debit for loss)
INSERT INTO acc_trans(trans_id, chart_id, amount, approved, transdate)
select currval('id'), 
            CASE WHEN sum(amount) > 0 THEN in_loss_acct
            else in_gain_acct
        END,
        sum(amount) * -1 , true, 
        retval.report_date
  FROM acc_trans
  WHERE trans_id = currval('id');

IF retval.report_class = 4 then
   PERFORM asset__import_from_disposal(retval.id);
end if;

return retval;
end;
$$;


--
-- Name: FUNCTION asset_disposal__approve(in_id integer, in_gain_acct integer, in_loss_acct integer, in_asset_acct integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_disposal__approve(in_id integer, in_gain_acct integer, in_loss_acct integer, in_asset_acct integer) IS ' This approves the asset_report for disposals, creating relevant GL drafts.

If the report is a partial disposal report, imports remaining percentages as new
asset items.';


--
-- Name: note; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE note (
    id integer NOT NULL,
    note_class integer NOT NULL,
    note text NOT NULL,
    vector tsvector DEFAULT ''::tsvector NOT NULL,
    created timestamp without time zone DEFAULT now() NOT NULL,
    created_by text DEFAULT "session_user"(),
    ref_key integer NOT NULL,
    subject text
);


--
-- Name: TABLE note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE note IS ' This is an abstract table which should have zero rows.  It is inherited by
other tables for specific notes.';


--
-- Name: COLUMN note.note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN note.note IS 'Body of note.';


--
-- Name: COLUMN note.vector; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN note.vector IS 'tsvector for full text indexing, requires 
both setting up tsearch dictionaries and adding triggers to use at present.';


--
-- Name: COLUMN note.ref_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN note.ref_key IS ' Subclassed tables use this column as a foreign key against the table storing
the record a note is attached to.';


--
-- Name: note_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE note_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: note_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE note_id_seq OWNED BY note.id;


--
-- Name: note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('note_id_seq', 1, false);


--
-- Name: asset_note; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_note (
    note_class integer DEFAULT 4,
    CONSTRAINT asset_note_note_class_check CHECK ((note_class = 4))
)
INHERITS (note);


--
-- Name: asset_item__add_note(integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_item__add_note(in_id integer, in_subject text, in_note text) RETURNS asset_note
    LANGUAGE sql
    AS $_$
INSERT INTO asset_note (ref_key, subject, note) values ($1, $2, $3);
SELECT * FROM asset_note WHERE id = currval('note_id_seq');
$_$;


--
-- Name: FUNCTION asset_item__add_note(in_id integer, in_subject text, in_note text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_item__add_note(in_id integer, in_subject text, in_note text) IS ' Adds a note to an asset item';


--
-- Name: asset_item__search(integer, integer, text, text, date, numeric, numeric, numeric, date, integer, integer, integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_item__search(in_id integer, in_asset_class integer, in_description text, in_tag text, in_purchase_date date, in_purchase_value numeric, in_usable_life numeric, in_salvage_value numeric, in_start_depreciation date, in_warehouse_id integer, in_department_id integer, in_invoice_id integer, in_asset_account_id integer, in_dep_account_id integer) RETURNS SETOF asset_item
    LANGUAGE plpgsql
    AS $$
DECLARE retval asset_item;
BEGIN
    FOR retval IN
         SELECT * FROM asset_item
          WHERE (id = in_id or in_id is null)
                and (asset_class_id = in_asset_class or in_asset_class is null)
                and (description like '%'||in_description||'%'
                     or in_description is null)
                and (tag like '%' || in_tag || '%' or in_tag is null)
                and (purchase_value = in_purchase_value 
                    or in_purchase_value is null)
                and (in_purchase_date = purchase_date 
                    or in_purchase_date is null)
                and (start_depreciation = in_start_depreciation
                    or in_start_depreciation is null)
                and (in_warehouse_id = location_id OR in_warehouse_id is null)
                and (department_id = in_department_id 
                    or in_department_id is null)
                and (in_invoice_id = invoice_id OR in_invoice_id IS NULL)
                and (asset_account_id = in_asset_account_id
                    or in_asset_account_id is null)
                and (dep_account_id = in_dep_account_id
                    or in_dep_account_id is null)
   LOOP
       return next retval;
   end loop;
END;
$$;


--
-- Name: FUNCTION asset_item__search(in_id integer, in_asset_class integer, in_description text, in_tag text, in_purchase_date date, in_purchase_value numeric, in_usable_life numeric, in_salvage_value numeric, in_start_depreciation date, in_warehouse_id integer, in_department_id integer, in_invoice_id integer, in_asset_account_id integer, in_dep_account_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_item__search(in_id integer, in_asset_class integer, in_description text, in_tag text, in_purchase_date date, in_purchase_value numeric, in_usable_life numeric, in_salvage_value numeric, in_start_depreciation date, in_warehouse_id integer, in_department_id integer, in_invoice_id integer, in_asset_account_id integer, in_dep_account_id integer) IS ' Returns a list of matching asset items.  Nulls match all records.
Tag and description allow for partial match.  All other matches are exact.';


--
-- Name: asset_nbv_report(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_nbv_report() RETURNS SETOF asset_nbv_line
    LANGUAGE sql
    AS $$
   SELECT ai.id, ai.tag, ai.description, coalesce(ai.start_depreciation, ai.purchase_date),
          adm.short_name, ai.usable_life 
           - months_passed(coalesce(ai.start_depreciation, ai.purchase_date),
                                  coalesce(max(r.report_date),
                                           ai.start_depreciation,
                                           ai.purchase_date))/ 12,
          ai.purchase_value - ai.salvage_value, ai.salvage_value, max(r.report_date),
          sum(rl.amount), ai.purchase_value - sum(rl.amount) 
     FROM asset_item ai
     JOIN asset_class ac ON (ai.asset_class_id = ac.id)
     JOIN asset_dep_method adm ON (adm.id = ac.method)
LEFT JOIN asset_report_line rl ON (ai.id = rl.asset_id)
LEFT JOIN asset_report r on (rl.report_id = r.id)
    WHERE r.id IS NULL OR r.approved_at IS NOT NULL
 GROUP BY ai.id, ai.tag, ai.description, ai.start_depreciation, ai.purchase_date,
          adm.short_name, ai.usable_life, ai.purchase_value, salvage_value
   HAVING (NOT 2 = ANY(as_array(r.report_class))) 
          AND (NOT 4 = ANY(as_array(r.report_class)))
          OR max(r.report_class) IS NULL
 ORDER BY ai.id, ai.tag, ai.description;
$$;


--
-- Name: FUNCTION asset_nbv_report(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_nbv_report() IS ' Returns the current net book value report.';


--
-- Name: asset_report__approve(integer, integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__approve(in_id integer, in_expense_acct integer, in_gain_acct integer, in_loss_acct integer) RETURNS asset_report
    LANGUAGE plpgsql
    AS $$
DECLARE ret_val asset_report;
BEGIN
        UPDATE asset_report 
           SET approved_at = now(),
               approved_by = person__get_my_entity_id()
         where id = in_id;
	SELECT * INTO ret_val FROM asset_report WHERE id = in_id;
        if ret_val.dont_approve is not true then 
                if ret_val.report_class = 1 THEN
                    PERFORM asset_report__generate_gl(in_id, in_expense_acct);
                ELSIF ret_val.report_class = 2 THEN
                    PERFORM asset_report__disposal_gl(
                                 in_id, in_gain_acct, in_loss_acct);
                ELSIF ret_val.report_class = 4 THEN
                    PERFORM asset_disposal__approve(in_id, in_gain_acct, in_loss_acct, (select asset_account_id from asset_class 
                                                                                         where id = ret_val.asset_class)
                                                   );
                ELSE RAISE EXCEPTION 'Invalid report class';
                END IF;
        end if;
	SELECT * INTO ret_val FROM asset_report WHERE id = in_id;
	RETURN ret_val;
end;
$$;


--
-- Name: FUNCTION asset_report__approve(in_id integer, in_expense_acct integer, in_gain_acct integer, in_loss_acct integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__approve(in_id integer, in_expense_acct integer, in_gain_acct integer, in_loss_acct integer) IS ' This function approves an asset report (whether depreciation or disposal).
Also generates relevant GL drafts for review and posting.';


--
-- Name: asset_report__begin_disposal(integer, date, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__begin_disposal(in_asset_class integer, in_report_date date, in_report_class integer) RETURNS asset_report
    LANGUAGE plpgsql
    AS $$
DECLARE retval asset_report;

begin

INSERT INTO asset_report (asset_class, report_date, entered_at, entered_by, 
            report_class)
     VALUES (in_asset_class, in_report_date, now(), person__get_my_entity_id(), 
            in_report_class);

SELECT * INTO retval FROM asset_report where id = currval('asset_report_id_seq');

return retval;

end;

$$;


--
-- Name: FUNCTION asset_report__begin_disposal(in_asset_class integer, in_report_date date, in_report_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__begin_disposal(in_asset_class integer, in_report_date date, in_report_class integer) IS ' Creates the asset report recofd for the asset disposal report.';


--
-- Name: asset_report__begin_import(integer, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__begin_import(in_asset_class integer, in_report_date date) RETURNS asset_report
    LANGUAGE sql
    AS $_$
INSERT INTO asset_report (asset_class, report_date, entered_at, entered_by, 
            report_class, dont_approve)
     VALUES ($1, $2, now(), person__get_my_entity_id(), 
            3, true);

SELECT * FROM asset_report where id = currval('asset_report_id_seq');

$_$;


--
-- Name: FUNCTION asset_report__begin_import(in_asset_class integer, in_report_date date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__begin_import(in_asset_class integer, in_report_date date) IS 'Creates the outline of an asset import report';


--
-- Name: asset_report__disposal_gl(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__disposal_gl(in_id integer, in_gain_acct integer, in_loss_acct integer) RETURNS boolean
    LANGUAGE sql
    AS $_$
  INSERT 
    INTO gl (reference, description, transdate, approved)
  SELECT setting_increment('glnumber'), 'Asset Report ' || asset_report.id,
		report_date, false
    FROM asset_report 
    JOIN asset_report_line ON (asset_report.id = asset_report_line.report_id)
    JOIN asset_item        ON (asset_report_line.asset_id = asset_item.id)
   WHERE asset_report.id = $1
GROUP BY asset_report.id, asset_report.report_date;

  INSERT
    INTO acc_trans (chart_id, trans_id, amount, approved, transdate)
  SELECT a.dep_account_id, currval('id')::int, sum(r.accum_depreciation) * -1,
         TRUE, r.disposed_on
    FROM asset_report__get_disposal($1) r
    JOIN asset_item a ON (r.id = a.id)
GROUP BY a.dep_account_id, r.disposed_on;

  -- GAIN is negative since it is a debit
  INSERT
    INTO acc_trans (chart_id, trans_id, amount, approved, transdate)
  SELECT case when sum(r.gain_loss) > 0 THEN $3 else $2 end,
         currval('id')::int, sum(r.gain_loss),
         TRUE, r.disposed_on
    FROM asset_report__get_disposal($1) r
    JOIN asset_item ai ON (r.id = ai.id)
GROUP BY r.disposed_on;

  INSERT
    INTO acc_trans (chart_id, trans_id, amount, approved, transdate)
  SELECT a.asset_account_id, currval('id')::int, sum(r.purchase_value),
         TRUE, r.disposed_on
    FROM asset_report__get_disposal($1) r
    JOIN asset_item a ON (r.id = a.id)
GROUP BY a.asset_account_id, r.disposed_on;


  SELECT TRUE;
$_$;


--
-- Name: FUNCTION asset_report__disposal_gl(in_id integer, in_gain_acct integer, in_loss_acct integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__disposal_gl(in_id integer, in_gain_acct integer, in_loss_acct integer) IS ' Generates GL transactions for ful disposal reports.';


--
-- Name: asset_report__dispose(integer, integer, numeric, integer, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__dispose(in_id integer, in_asset_id integer, in_amount numeric, in_dm integer, in_percent_disposed numeric) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT 
      INTO asset_report_line (report_id, asset_id, amount)
    values (in_id, in_asset_id, in_amount);

    INSERT 
      INTO asset_rl_to_disposal_method 
           (report_id, asset_id, disposal_method_id, percent_disposed)
    VALUES (in_id, in_asset_id, in_dm, in_percent_disposed);

    RETURN TRUE;
    END;
$$;


--
-- Name: FUNCTION asset_report__dispose(in_id integer, in_asset_id integer, in_amount numeric, in_dm integer, in_percent_disposed numeric); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__dispose(in_id integer, in_asset_id integer, in_amount numeric, in_dm integer, in_percent_disposed numeric) IS ' Disposes of an asset.  in_dm is the disposal method id.';


--
-- Name: asset_report__generate(boolean, integer, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__generate(in_depreciation boolean, in_asset_class integer, in_report_date date) RETURNS SETOF asset_item
    LANGUAGE sql
    AS $_$
   SELECT ai.*
     FROM asset_item ai
     JOIN asset_class ac ON (ai.asset_class_id = ac.id)
LEFT JOIN asset_report_line arl ON (arl.asset_id = ai.id)
LEFT JOIN asset_report ar ON (arl.report_id = ar.id)
    WHERE COALESCE(ai.start_depreciation, ai.purchase_date) <= $3 AND ac.id = $2
          AND obsolete_by IS NULL
 GROUP BY ai.id, ai.tag, ai.description, ai.purchase_value, ai.usable_life,
          ai.purchase_date, ai.location_id, ai.invoice_id, ai.asset_account_id,
          ai.dep_account_id, ai.asset_class_id, ai.start_depreciation,
          ai.salvage_value, ai.department_id, ai.exp_account_id, ai.obsolete_by
   HAVING (count(ar.report_class) = 0 OR    
          (2 <> ALL(as_array(ar.report_class)) 
          and 4 <> ALL(as_array(ar.report_class))))
          AND ((ai.purchase_value - coalesce(sum(arl.amount), 0) 
               > ai.salvage_value) and ai.obsolete_by is null)
               OR $1 is not true;
$_$;


--
-- Name: FUNCTION asset_report__generate(in_depreciation boolean, in_asset_class integer, in_report_date date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__generate(in_depreciation boolean, in_asset_class integer, in_report_date date) IS ' Generates lines to select/deselect for the asset report (depreciation or
disposal).';


--
-- Name: asset_report__generate_gl(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__generate_gl(in_report_id integer, in_accum_account_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE 
	t_report_dept record;
	t_dep_amount numeric;

Begin
	INSERT INTO gl (reference, description, transdate, approved)
	SELECT setting_increment('glnumber'), 'Asset Report ' || asset_report.id,
		report_date, false
	FROM asset_report 
	JOIN asset_report_line 
		ON (asset_report.id = asset_report_line.report_id)
	JOIN asset_item 
		ON (asset_report_line.asset_id = asset_item.id)
	WHERE asset_report.id = in_report_id
	GROUP BY asset_report.id, asset_report.report_date;

	INSERT INTO acc_trans (trans_id, chart_id, transdate, approved, amount)
	SELECT gl.id, a.exp_account_id, r.report_date, true, sum(amount) * -1
	FROM asset_report r
	JOIN asset_report_line l ON (r.id = l.report_id)
	JOIN asset_item a ON (l.asset_id = a.id)
	JOIN gl ON (gl.description = 'Asset Report ' || l.report_id)
	WHERE r.id = in_report_id
	GROUP BY gl.id, r.report_date, a.exp_account_id;

	INSERT INTO acc_trans (trans_id, chart_id, transdate, approved, amount)
	SELECT gl.id, a.dep_account_id, r.report_date, true, sum(amount)
	FROM asset_report r
	JOIN asset_report_line l ON (r.id = l.report_id)
	JOIN asset_item a ON (l.asset_id = a.id)
	JOIN gl ON (gl.description = 'Asset Report ' || l.report_id) 
	WHERE r.id = in_report_id
	GROUP BY gl.id, a.dep_account_id, r.report_date, a.tag, a.description;

	RETURN in_report_id;
END;
$$;


--
-- Name: FUNCTION asset_report__generate_gl(in_report_id integer, in_accum_account_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__generate_gl(in_report_id integer, in_accum_account_id integer) IS ' Generates a GL transaction when the Asset report is approved.

Currently this creates GL drafts, not approved transctions
';


--
-- Name: asset_report__get(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__get(in_id integer) RETURNS asset_report
    LANGUAGE sql
    AS $_$
select * from asset_report where id = $1;
$_$;


--
-- Name: FUNCTION asset_report__get(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__get(in_id integer) IS ' Returns the asset_report line identified by id.';


--
-- Name: asset_report__get_disposal(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__get_disposal(in_id integer) RETURNS SETOF asset_disposal_report_line
    LANGUAGE sql
    AS $_$
   SELECT ai.id, ai.tag, ai.description, ai.start_depreciation, r.report_date,
          dm.short_label, ai.purchase_value, 
          sum (CASE WHEN pr.report_class in (1,3) THEN prl.amount ELSE 0 END) 
          as accum_dep,
          l.amount, 
          ai.purchase_value - sum(CASE WHEN pr.report_class in (1,3) 
                                       THEN prl.amount 
                                       ELSE 0 
                                   END) as adjusted_basis,
          l.amount - ai.purchase_value + sum(CASE WHEN pr.report_class in (1,3)
                                                  THEN prl.amount 
                                                  ELSE 0 
                                              END) as gain_loss
     FROM asset_item ai
     JOIN asset_report_line l   ON (l.report_id = $1 AND ai.id = l.asset_id)
     JOIN asset_report r        ON (l.report_id = r.id)
LEFT JOIN asset_rl_to_disposal_method adm 
                             USING (report_id, asset_id)
     JOIN asset_disposal_method dm
                                ON (adm.disposal_method_id = dm.id)
LEFT JOIN asset_report_line prl ON (prl.report_id <> $1 
                                   AND ai.id = prl.asset_id)
LEFT JOIN asset_report pr       ON (prl.report_id = pr.id)
 GROUP BY ai.id, ai.tag, ai.description, ai.start_depreciation, r.report_date,
          ai.purchase_value, l.amount, dm.short_label
 ORDER BY ai.id, ai.tag;
$_$;


--
-- Name: FUNCTION asset_report__get_disposal(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__get_disposal(in_id integer) IS ' Returns a set of lines of disposed assets in a disposal report, specified
by the report id.';


--
-- Name: asset_disposal_method; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_disposal_method (
    label text NOT NULL,
    id integer NOT NULL,
    multiple integer,
    short_label character(1),
    CONSTRAINT asset_disposal_method_multiple_check CHECK ((multiple = ANY (ARRAY[1, 0, (-1)])))
);


--
-- Name: asset_report__get_disposal_methods(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__get_disposal_methods() RETURNS SETOF asset_disposal_method
    LANGUAGE sql
    AS $$
SELECT * FROM asset_disposal_method order by label;
$$;


--
-- Name: FUNCTION asset_report__get_disposal_methods(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__get_disposal_methods() IS ' Returns a list of asset_disposal_method items ordered by label.';


--
-- Name: asset_report__get_expense_accts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__get_expense_accts() RETURNS SETOF account
    LANGUAGE sql
    AS $$
    SELECT * FROM account__get_by_link_desc('asset_expense');
$$;


--
-- Name: FUNCTION asset_report__get_expense_accts(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__get_expense_accts() IS ' Lists all asset expense reports.';


--
-- Name: asset_report__get_gain_accts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__get_gain_accts() RETURNS SETOF account
    LANGUAGE sql
    AS $$
    SELECT * FROM account__get_by_link_desc('asset_gain');
$$;


--
-- Name: FUNCTION asset_report__get_gain_accts(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__get_gain_accts() IS ' Returns a list of gain accounts for asset depreciation and disposal reports.
';


--
-- Name: asset_report__get_lines(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__get_lines(in_id integer) RETURNS SETOF asset_report_line_result
    LANGUAGE sql
    AS $_$
   select ai.tag, coalesce(ai.start_depreciation, ai.purchase_date), ai.purchase_value, m.short_name, 
          ai.usable_life, 
          ai.purchase_value - ai.salvage_value, max(pr.report_date),
          sum(case when pr.report_date < r.report_date then prl.amount
                   else 0
                end), 
          rl.amount, 
          sum (case when extract(year from pr.report_date)
                         = extract(year from r.report_date)
                         AND pr.report_date < r.report_date
                    then prl.amount
                    else 0
                end), 
          sum(prl.amount), 
          ai.description, ai.purchase_date
     FROM asset_item ai
     JOIN asset_class c ON (ai.asset_class_id = c.id)
     JOIN asset_dep_method m ON (c.method = m.id)
     JOIN asset_report_line rl ON (rl.asset_id = ai.id)
     JOIN asset_report r ON (rl.report_id = r.id)
LEFT JOIN asset_report_line prl ON (prl.asset_id = ai.id)
LEFT JOIN asset_report pr ON (prl.report_id = pr.id)
    WHERE rl.report_id = $1
 GROUP BY ai.tag, ai.start_depreciation, ai.purchase_value, m.short_name,
          ai.usable_life, ai.salvage_value, r.report_date, rl.amount,
          ai.description, ai.purchase_date;
$_$;


--
-- Name: FUNCTION asset_report__get_lines(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__get_lines(in_id integer) IS ' Returns the lines of an asset depreciation report.';


--
-- Name: asset_report__get_loss_accts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__get_loss_accts() RETURNS SETOF account
    LANGUAGE sql
    AS $$
    SELECT * FROM account__get_by_link_desc('asset_loss');
$$;


--
-- Name: FUNCTION asset_report__get_loss_accts(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__get_loss_accts() IS ' Returns a list of loss accounts for asset depreciation and disposal reports.
';


--
-- Name: asset_report__import(text, text, numeric, numeric, numeric, date, date, integer, integer, integer, integer, integer, integer, integer, integer, numeric, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__import(in_description text, in_tag text, in_purchase_value numeric, in_salvage_value numeric, in_usable_life numeric, in_purchase_date date, in_start_depreciation date, in_location_id integer, in_department_id integer, in_asset_account_id integer, in_dep_account_id integer, in_exp_account_id integer, in_asset_class_id integer, in_invoice_id integer, in_dep_report_id integer, in_accum_dep numeric, in_obsolete_other boolean) RETURNS boolean
    LANGUAGE sql
    AS $_$

SET CONSTRAINTS asset_item_obsolete_by_fkey DEFERRED;
-- This fails a deferrable fkey constraint but avoids a partial unique index
-- so in this case, the foreign key is deferred for the duration of this 
-- specific stored proc call.

UPDATE asset_item
   SET obsolete_by = -1 
 WHERE tag = $2 and $17 is true;

INSERT 
  INTO asset_report_line 
       (report_id, asset_id, amount, department_id, warehouse_id)
select $15, id, $16, department_id, location_id
  from asset__save
       (NULL, $13, $1, $2, $6, $3, $5, coalesce($4, 0), $7, $8, $9, $14, $10, $11, $12);

UPDATE asset_item 
   SET obsolete_by = currval('asset_item_id_seq')
 WHERE obsolete_by = -1;

-- enforce fkeys now and raise exception if fail
SET CONSTRAINTS asset_item_obsolete_by_fkey IMMEDIATE;
SELECT true;
$_$;


--
-- Name: FUNCTION asset_report__import(in_description text, in_tag text, in_purchase_value numeric, in_salvage_value numeric, in_usable_life numeric, in_purchase_date date, in_start_depreciation date, in_location_id integer, in_department_id integer, in_asset_account_id integer, in_dep_account_id integer, in_exp_account_id integer, in_asset_class_id integer, in_invoice_id integer, in_dep_report_id integer, in_accum_dep numeric, in_obsolete_other boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__import(in_description text, in_tag text, in_purchase_value numeric, in_salvage_value numeric, in_usable_life numeric, in_purchase_date date, in_start_depreciation date, in_location_id integer, in_department_id integer, in_asset_account_id integer, in_dep_account_id integer, in_exp_account_id integer, in_asset_class_id integer, in_invoice_id integer, in_dep_report_id integer, in_accum_dep numeric, in_obsolete_other boolean) IS ' Imports an asset with the supplied information.  If in_obsolete_other is
false, this creates a new depreciable asset.  If it is true, it sets up the 
other asset as obsolete.  This is the way partial disposal reports are handled.
';


--
-- Name: asset_report__record_approve(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__record_approve(in_id integer) RETURNS asset_report
    LANGUAGE sql
    AS $_$
UPDATE asset_report 
   set approved_by = person__get_my_entity_id(),
       approved_at = now()
 where id = $1;

select * from asset_report where id = $1;

$_$;


--
-- Name: FUNCTION asset_report__record_approve(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__record_approve(in_id integer) IS 'Marks the asset_report record approved.  Not generally recommended to call
directly.';


--
-- Name: asset_report__save(integer, date, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__save(in_id integer, in_report_date date, in_report_class integer, in_asset_class integer, in_submit boolean) RETURNS asset_report
    LANGUAGE plpgsql
    AS $$
DECLARE 
	ret_val asset_report;
	item record;
	method_text text;
BEGIN
	UPDATE asset_report 
	set asset_class = in_asset_class,
		report_class = in_report_class,
		report_date = in_report_date,
		submitted = (in_submit or submitted)
	WHERE id = in_id;

	IF FOUND THEN
		SELECT * INTO ret_val FROM asset_report WHERE id = in_id;
	ELSE 
		INSERT INTO asset_report(report_class, asset_class, report_date,
			submitted)
		values (in_report_class, in_asset_class, in_report_date, 
			coalesce(in_submit, true));

		SELECT * INTO ret_val FROM asset_report 
		WHERE id = currval('asset_report_id_seq');
                
	END IF;
        RETURN ret_val;

END;
$$;


--
-- Name: FUNCTION asset_report__save(in_id integer, in_report_date date, in_report_class integer, in_asset_class integer, in_submit boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__save(in_id integer, in_report_date date, in_report_class integer, in_asset_class integer, in_submit boolean) IS ' Creates or updates an asset report with the information presented.  Note that
approval values are not set here, and that one cannot unsubmit a report though
this function.';


--
-- Name: asset_report__search(date, date, integer, boolean, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report__search(in_start_date date, in_end_date date, in_asset_class integer, in_approved boolean, in_entered_by integer) RETURNS SETOF asset_report_result
    LANGUAGE sql
    AS $_$

  SELECT r.id, r.report_date, r.gl_id, r.asset_class, r.report_class, 
         r.entered_by, r.approved_by, r.entered_at, r.approved_at, 
         r.depreciated_qty, r.dont_approve, r.submitted, sum(l.amount)
    FROM asset_report r
    JOIN asset_report_line l ON (l.report_id = r.id)
   where ($1 is null or $1 <= report_date)
         and ($2 is null or $2 >= report_date)
         and ($3 is null or $3 = asset_class)
         and ($4 is null 
              or ($4 is true and approved_by is not null)
              or ($4 is false and approved_by is null))
         and ($5 is null or $5 = entered_by)
GROUP BY r.id, r.report_date, r.gl_id, r.asset_class, r.report_class,
         r.entered_by, r.approved_by, r.entered_at, r.approved_at,
         r.depreciated_qty, r.dont_approve, r.submitted;
$_$;


--
-- Name: FUNCTION asset_report__search(in_start_date date, in_end_date date, in_asset_class integer, in_approved boolean, in_entered_by integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report__search(in_start_date date, in_end_date date, in_asset_class integer, in_approved boolean, in_entered_by integer) IS ' Searches for asset reports.  Nulls match all rows.  Approved, asset class, 
and entered_by are exact matches.  Start_date and end_date define the beginning
and end of the search date. ';


--
-- Name: asset_report_partial_disposal_details(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION asset_report_partial_disposal_details(in_id integer) RETURNS SETOF partial_disposal_line
    LANGUAGE sql
    AS $_$
SELECT ai.id, ai.tag, ai.start_depreciation, ai.purchase_value, ai.description,
       ar.report_date, arld.percent_disposed, 
       (arld.percent_disposed / 100) * ai.purchase_value, 
       100 - arld.percent_disposed,
       ((100 - arld.percent_disposed)/100) * ai.purchase_value
  FROM asset_item ai
  JOIN asset_report_line l ON (ai.id = l.asset_id)
  JOIN asset_report ar ON (ar.id = l.report_id)
  JOIN asset_rl_to_disposal_method arld
       ON  ((arld.report_id, arld.asset_id) = (l.report_id, l.asset_id))
 WHERE ar.id = $1;
$_$;


--
-- Name: FUNCTION asset_report_partial_disposal_details(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION asset_report_partial_disposal_details(in_id integer) IS ' Returns the partial disposal details for a partial disposal report.';


--
-- Name: avgcost(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION avgcost(integer) RETURNS double precision
    LANGUAGE plpgsql
    AS $_$

DECLARE

v_cost float;
v_qty float;
v_parts_id alias for $1;

BEGIN

  SELECT INTO v_cost, v_qty SUM(i.sellprice * i.qty), SUM(i.qty)
  FROM invoice i
  JOIN ap a ON (a.id = i.trans_id)
  WHERE i.parts_id = v_parts_id;
  
  IF v_cost IS NULL THEN
    v_cost := 0;
  END IF;

  IF NOT v_qty IS NULL THEN
    IF v_qty = 0 THEN
      v_cost := 0;
    ELSE
      v_cost := v_cost/v_qty;
    END IF;
  END IF;

RETURN v_cost;
END;
$_$;


--
-- Name: batch_create(text, text, text, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION batch_create(in_batch_number text, in_description text, in_batch_class text, in_batch_date date) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
	INSERT INTO 
		batch (batch_class_id, default_date, description, control_code,
			created_by)
	VALUES ((SELECT id FROM batch_class WHERE class = in_batch_class),
		in_batch_date, in_description, in_batch_number, 
			(select entity_id FROM users WHERE username = session_user));

	return currval('batch_id_seq');
END;	
$$;


--
-- Name: FUNCTION batch_create(in_batch_number text, in_description text, in_batch_class text, in_batch_date date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION batch_create(in_batch_number text, in_description text, in_batch_class text, in_batch_date date) IS ' Inserts the batch into the table.';


--
-- Name: batch_delete(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION batch_delete(in_batch_id integer) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE 
	t_transaction_ids int[];
BEGIN
	-- Adjust AR/AP tables for payment and payment reversal vouchers
	-- voucher_id is only set in acc_trans on payment/receipt vouchers and
	-- their reversals. -CT
        perform * from batch where id = in_batch_id and approved_on IS NULL;
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Batch not found';
        END IF; 
	update ar set paid = amount + 
		(select sum(amount) from acc_trans 
		join chart ON (acc_trans.chart_id = chart.id)
		where link = 'AR' AND trans_id = ar.id
			AND (voucher_id IS NULL OR voucher_id NOT IN 
				(select id from voucher 
				WHERE batch_id = in_batch_id))) 
	where id in (select trans_id from acc_trans where voucher_id IN 
		(select id from voucher where batch_id = in_batch_id));

	update ap set paid = amount - (select sum(amount) from acc_trans 
		join chart ON (acc_trans.chart_id = chart.id)
		where link = 'AP' AND trans_id = ap.id
			AND (voucher_id IS NULL OR voucher_id NOT IN 
				(select id from voucher 
				WHERE batch_id = in_batch_id))) 
	where id in (select trans_id from acc_trans where voucher_id IN 
		(select id from voucher where batch_id = in_batch_id));

        DELETE FROM ac_tax_form WHERE entry_id IN
               (select entry_id from acc_trans where voucher_id in
                       (select id from voucher where batch_id = in_batch_id)
               );

	DELETE FROM acc_trans WHERE voucher_id IN 
		(select id FROM voucher where batch_id = in_batch_id);

	-- The rest of this function involves the deletion of actual
	-- transactions, vouchers, and batches, and jobs which are in progress.
	-- -CT
	SELECT as_array(trans_id) INTO t_transaction_ids
	FROM voucher WHERE batch_id = in_batch_id AND batch_class IN (1, 2, 5);

        DELETE FROM ac_tax_form WHERE entry_id in
               (select entry_id from acc_trans 
                 where trans_id = any(t_transaction_ids));

	DELETE FROM acc_trans WHERE trans_id = ANY(t_transaction_ids);
	DELETE FROM ap WHERE id = ANY(t_transaction_ids);
	DELETE FROM gl WHERE id = ANY(t_transaction_ids);
	DELETE FROM voucher WHERE batch_id = in_batch_id;
	DELETE FROM payments_queue WHERE batch_id = in_batch_id;
	DELETE FROM pending_job WHERE batch_id = in_batch_id;
	DELETE FROM batch WHERE id = in_batch_id;
	DELETE FROM transactions WHERE id = ANY(t_transaction_ids);

	RETURN 1;
END;
$$;


--
-- Name: FUNCTION batch_delete(in_batch_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION batch_delete(in_batch_id integer) IS ' If the batch is found and unapproved, deletes it and returns 1.
Otherwise raises an exception.';


--
-- Name: batch_get_class_id(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION batch_get_class_id(in_type text) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT id FROM batch_class WHERE class = $1;
$_$;


--
-- Name: FUNCTION batch_get_class_id(in_type text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION batch_get_class_id(in_type text) IS ' returns the batch class id associated with the in_type label provided.';


--
-- Name: batch_get_users(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION batch_get_users() RETURNS SETOF users
    LANGUAGE plpgsql
    AS $$
DECLARE out_record users%ROWTYPE;
BEGIN
	FOR out_record IN
		SELECT * from users WHERE entity_id IN (select created_by from batch)
	LOOP
		RETURN NEXT out_record;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION batch_get_users(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION batch_get_users() IS ' Returns a sim[ple set of user objects.  This should be renamed so that 
it is more obvious it is a general purpose function.';


--
-- Name: batch_class; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE batch_class (
    id integer NOT NULL,
    class character varying NOT NULL
);


--
-- Name: TABLE batch_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE batch_class IS ' These values are hard-coded.  Please coordinate before adding standard
values.';


--
-- Name: batch_list_classes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION batch_list_classes() RETURNS SETOF batch_class
    LANGUAGE plpgsql
    AS $$
DECLARE out_val record;
BEGIN
	FOR out_val IN select * from batch_class order by id
 	LOOP
		return next out_val;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION batch_list_classes(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION batch_list_classes() IS ' Returns a list of all batch classes.';


--
-- Name: batch_post(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION batch_post(in_batch_id integer) RETURNS date
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
	UPDATE ar SET approved = true 
	WHERE id IN (select trans_id FROM voucher 
		WHERE batch_id = in_batch_id
		AND batch_class = 2);
	
	UPDATE ap SET approved = true 
	WHERE id IN (select trans_id FROM voucher 
		WHERE batch_id = in_batch_id
		AND batch_class = 1);

	UPDATE gl SET approved = true 
	WHERE id IN (select trans_id FROM voucher 
		WHERE batch_id = in_batch_id
		AND batch_class = 5);

	UPDATE acc_trans SET approved = true 
	WHERE voucher_id IN (select id FROM voucher 
		WHERE batch_id = in_batch_id
		AND batch_class IN (3, 4, 6, 7));

	UPDATE batch 
	SET approved_on = now(),
		approved_by = (select entity_id FROM users 
			WHERE username = SESSION_USER)
	WHERE id = in_batch_id;

	RETURN now()::date;
END;
$$;


--
-- Name: FUNCTION batch_post(in_batch_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION batch_post(in_batch_id integer) IS ' Posts the specified batch to the books.  Only posted batches should show up
on standard financial reports.';


--
-- Name: batch_search(integer, text, integer, date, date, numeric, numeric, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION batch_search(in_class_id integer, in_description text, in_created_by_eid integer, in_date_from date, in_date_to date, in_amount_gt numeric, in_amount_lt numeric, in_approved boolean) RETURNS SETOF batch_list_item
    LANGUAGE plpgsql
    AS $$
DECLARE out_value batch_list_item;
BEGIN
	FOR out_value IN
		SELECT b.id, c.class, b.control_code, b.description, u.username,
			b.created_on, b.default_date,
			sum(
				CASE WHEN vc.id = 5 AND al.amount < 0 -- GL
				     THEN al.amount 
				     WHEN vc.id  = 1
				     THEN ap.amount 
				     WHEN vc.id = 2
                                     THEN ap.amount
				     ELSE 0
                                END) AS transaction_total,
			sum(
				CASE WHEN alc.link = 'AR' AND vc.id IN (6, 7)
				     THEN al.amount
				     WHEN alc.link = 'AP' AND vc.id IN (3, 4)
				     THEN al.amount * -1
				     ELSE 0
				END
			   ) AS payment_total
		FROM batch b
		JOIN batch_class c ON (b.batch_class_id = c.id)
		LEFT JOIN users u ON (u.entity_id = b.created_by)
		LEFT JOIN voucher v ON (v.batch_id = b.id)
		LEFT JOIN batch_class vc ON (v.batch_class = vc.id)
		LEFT JOIN ar ON (vc.id = 2 AND v.trans_id = ar.id)
		LEFT JOIN ap ON (vc.id = 1 AND v.trans_id = ap.id)
		LEFT JOIN acc_trans al ON 
			((vc.id = 5 AND v.trans_id = al.trans_id) OR
				(vc.id IN (3, 4, 6, 7) 
					AND al.voucher_id = v.id))
		LEFT JOIN chart alc ON (al.chart_id = alc.id)
		WHERE (c.id = in_class_id OR in_class_id IS NULL) AND 
			(b.description LIKE 
				'%' || in_description || '%' OR
				in_description IS NULL) AND
			(in_created_by_eid = b.created_by OR
				in_created_by_eid IS NULL) AND
			((in_approved = false OR in_approved IS NULL AND
				approved_on IS NULL) OR
				(in_approved = true AND approved_on IS NOT NULL)
			) 
			and (in_date_from IS NULL 
				or b.default_date >= in_date_from)
			and (in_date_to IS NULL
				or b.default_date <= in_date_to)
		GROUP BY b.id, c.class, b.description, u.username, b.created_on,
			b.control_code, b.default_date
		HAVING  
			(in_amount_gt IS NULL OR
			sum(coalesce(ar.amount - ar.paid, ap.amount - ap.paid, 
				al.amount)) 
			>= in_amount_gt) 
			AND 
			(in_amount_lt IS NULL OR
			sum(coalesce(ar.amount - ar.paid, ap.amount - ap.paid, 
				al.amount))
			<= in_amount_lt)
		ORDER BY b.control_code, b.description
		
	LOOP
		RETURN NEXT out_value;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION batch_search(in_class_id integer, in_description text, in_created_by_eid integer, in_date_from date, in_date_to date, in_amount_gt numeric, in_amount_lt numeric, in_approved boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION batch_search(in_class_id integer, in_description text, in_created_by_eid integer, in_date_from date, in_date_to date, in_amount_gt numeric, in_amount_lt numeric, in_approved boolean) IS 'Returns a list of batches and amounts processed on the batch.

Nulls match all values.
in_date_from and in_date_to specify date ranges.
in_description is a partial match.
All other criteria are exact matches.
';


--
-- Name: batch_search_empty(integer, text, integer, numeric, numeric, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION batch_search_empty(in_class_id integer, in_description text, in_created_by_eid integer, in_amount_gt numeric, in_amount_lt numeric, in_approved boolean) RETURNS SETOF batch_list_item
    LANGUAGE plpgsql
    AS $$
DECLARE out_value batch_list_item;
BEGIN
	FOR out_value IN
               SELECT b.id, c.class, b.control_code, b.description, u.username,
                        b.created_on, b.default_date, 0, 0
                FROM batch b
                JOIN batch_class c ON (b.batch_class_id = c.id)
                JOIN users u ON (u.entity_id = b.created_by)
                LEFT JOIN voucher v ON (v.batch_id = b.id) 
               where v.id is null
                     and(u.entity_id = in_created_by_eid 
                     or in_created_by_eid is null) and
                     (in_description is null or b.description 
                     like '%'  || in_description || '%') and
                     (in_class_id is null or c.id = in_class_id)
            GROUP BY b.id, c.class, b.description, u.username, b.created_on, 
                     b.control_code, b.default_date
            ORDER BY b.control_code, b.description

		
	LOOP
		RETURN NEXT out_value;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION batch_search_empty(in_class_id integer, in_description text, in_created_by_eid integer, in_amount_gt numeric, in_amount_lt numeric, in_approved boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION batch_search_empty(in_class_id integer, in_description text, in_created_by_eid integer, in_amount_gt numeric, in_amount_lt numeric, in_approved boolean) IS ' This is a full search for the batches, listing them by amount processed.
in_amount_gt and in_amount_lt provide a range to search for.
in_description is a partial match field.
Other fields are exact matches.

NULLs match all values.
';


--
-- Name: batch_search_mini(integer, text, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION batch_search_mini(in_class_id integer, in_description text, in_created_by_eid integer, in_approved boolean) RETURNS SETOF batch_list_item
    LANGUAGE plpgsql
    AS $$
DECLARE out_value batch_list_item;
BEGIN
	FOR out_value IN
		SELECT b.id, c.class, b.control_code, b.description, u.username,
			b.created_on, b.default_date, NULL
		FROM batch b
		JOIN batch_class c ON (b.batch_class_id = c.id)
		LEFT JOIN users u ON (u.entity_id = b.created_by)
		WHERE (c.id = in_class_id OR in_class_id IS NULL) AND 
			(b.description LIKE 
				'%' || in_description || '%' OR
				in_description IS NULL) AND
			(in_created_by_eid = b.created_by OR
				in_created_by_eid IS NULL) AND
			((in_approved = false OR in_approved IS NULL AND
				approved_on IS NULL) OR
				(in_approved = true AND approved_on IS NOT NULL)
			)
		GROUP BY b.id, c.class, b.description, u.username, b.created_on,
			b.control_code, b.default_date
	LOOP
		RETURN NEXT out_value;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION batch_search_mini(in_class_id integer, in_description text, in_created_by_eid integer, in_approved boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION batch_search_mini(in_class_id integer, in_description text, in_created_by_eid integer, in_approved boolean) IS ' This performs a simple search of open batches created by the entity_id
in question.  This is used to pull up batches that were currently used so that
they can be picked up and more vouchers added.

NULLs match all values.
in_description is a partial match
All other inouts are exact matches.
';


--
-- Name: business; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE business (
    id integer NOT NULL,
    description text,
    discount numeric
);


--
-- Name: TABLE business; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE business IS 'Groups of Customers assigned joint discounts.';


--
-- Name: business_type__list(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION business_type__list() RETURNS SETOF business
    LANGUAGE plpgsql
    AS $$
DECLARE out_row business%ROWTYPE;
BEGIN
	FOR out_row IN SELECT * FROM business ORDER BY description LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION business_type__list(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION business_type__list() IS 'Returns a list of all business types. Ordered by description by default.';


--
-- Name: chart_get_ar_ap(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION chart_get_ar_ap(in_account_class integer) RETURNS SETOF chart
    LANGUAGE plpgsql
    AS $$
DECLARE out_row chart%ROWTYPE;
BEGIN
	IF in_account_class NOT IN (1, 2) THEN
		RAISE EXCEPTION 'Bad Account Type';
	END IF;
       FOR out_row IN
               SELECT * FROM chart 
               WHERE link = CASE WHEN in_account_class = 1 THEN 'AP'
                               WHEN in_account_class = 2 THEN 'AR'
                               END
               ORDER BY accno
       LOOP
               RETURN NEXT out_row;
       END LOOP;
END;
$$;


--
-- Name: FUNCTION chart_get_ar_ap(in_account_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION chart_get_ar_ap(in_account_class integer) IS ' This function returns the cash account acording with in_account_class which 
must be 1 or 2.

If in_account_class is 1 then it returns a list of AP accounts, and if 
in_account_class is 2, then a list of AR accounts.';


--
-- Name: chart_list_all(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION chart_list_all() RETURNS SETOF chart
    LANGUAGE plpgsql
    AS $$
DECLARE out_row chart%ROWTYPE;
BEGIN
	FOR out_row IN 
		SELECT * FROM chart ORDER BY accno
	LOOP
		RETURN next out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION chart_list_all(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION chart_list_all() IS ' Generates a list of chart view entries.';


--
-- Name: chart_list_cash(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION chart_list_cash(in_account_class integer) RETURNS SETOF chart
    LANGUAGE plpgsql
    AS $$
 DECLARE resultrow record;
         link_string text;
 BEGIN
         IF in_account_class = 1 THEN
            link_string := '%AP_paid%';
         ELSE 
            link_string := '%AR_paid%';
         END IF;
 
         FOR resultrow IN
           SELECT *  FROM chart
           WHERE link LIKE link_string
           ORDER BY accno
           LOOP
           return next resultrow;
         END LOOP;
 END;
$$;


--
-- Name: FUNCTION chart_list_cash(in_account_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION chart_list_cash(in_account_class integer) IS ' This function returns the overpayment accounts acording with 
in_account_class which must be 1 or 2.

If in_account_class is 1 it returns a list of AP cash accounts and 
if 2, AR cash accounts.';


--
-- Name: chart_list_discount(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION chart_list_discount(in_account_class integer) RETURNS SETOF chart
    LANGUAGE plpgsql
    AS $$
DECLARE resultrow record;
        link_string text;
BEGIN
        IF in_account_class = 1 THEN
           link_string := '%AP_discount%';
        ELSE
           link_string := '%AR_discount%';
        END IF;

        FOR resultrow IN
          SELECT *  FROM chart
          WHERE link LIKE link_string
          ORDER BY accno
          LOOP
          return next resultrow;
        END LOOP;
END;
$$;


--
-- Name: FUNCTION chart_list_discount(in_account_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION chart_list_discount(in_account_class integer) IS ' This function returns the discount accounts acording with in_account_class 
which must be 1 or 2.

If in_account_class is 1, returns AP discount accounts, if 2, AR discount 
accounts.';


--
-- Name: chart_list_overpayment(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION chart_list_overpayment(in_account_class integer) RETURNS SETOF chart
    LANGUAGE plpgsql
    AS $$
DECLARE resultrow record;
        link_string text;
BEGIN
        IF in_account_class = 1 THEN
           link_string := '%AP_overpayment%';
        ELSE 
           link_string := '%AR_overpayment%';
        END IF;

        FOR resultrow IN
          SELECT *  FROM chart
          WHERE link LIKE link_string
          ORDER BY accno
          LOOP
          return next resultrow;
        END LOOP;
END;
$$;


--
-- Name: FUNCTION chart_list_overpayment(in_account_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION chart_list_overpayment(in_account_class integer) IS ' Returns a list of AP_overpayment accounts if in_account_class is 1
Otherwise it returns a list of AR_overpayment accounts.';


--
-- Name: chart_list_search(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION chart_list_search(in_search text, in_link_desc text) RETURNS SETOF account
    LANGUAGE plpgsql
    AS $$
DECLARE out_row account%ROWTYPE;
BEGIN
	FOR out_row IN 
		SELECT * FROM account 
                 WHERE (accno ~* ('^'||in_search) 
                       OR description ~* ('^'||in_search))
                       AND (in_link_desc IS NULL 
                           or id in 
                          (select account_id from account_link 
                            where description = in_link_desc))
              ORDER BY accno
	LOOP
		RETURN next out_row;
	END LOOP;
END;$$;


--
-- Name: FUNCTION chart_list_search(in_search text, in_link_desc text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION chart_list_search(in_search text, in_link_desc text) IS ' This returns a list of account entries where the description or account 
number begins with in_search.

If in_link_desc is provided, the list is further filtered by which accounts are 
set to an account_link.description equal to that provided.';


--
-- Name: check_department(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION check_department() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

declare
  dpt_id int;

begin
 
  if new.department_id = 0 then
    delete from dpt_trans where trans_id = new.id;
    return NULL;
  end if;

  select into dpt_id trans_id from dpt_trans where trans_id = new.id;
  
  if dpt_id > 0 then
    update dpt_trans set department_id = new.department_id where trans_id = dpt_id;
  else
    insert into dpt_trans (trans_id, department_id) values (new.id, new.department_id);
  end if;
return NULL;

end;
$$;


--
-- Name: check_expiration(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION check_expiration() RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE test_result BOOL;
	expires_in interval;
	notify_again interval;
BEGIN
	expires_in := user__check_my_expiration();

	SELECT expires_in < notify_password INTO test_result
	FROM users WHERE username = SESSION_USER;

	IF test_result THEN 
		IF expires_in < '1 week' THEN
			notify_again := '1 hour';
		ELSE
			notify_again := '1 day';
		END IF;

		UPDATE users 
		SET notify_password = expires_in - notify_again
		WHERE username = SESSION_USER;
	END IF;
	RETURN test_result;
END;
$$;


--
-- Name: FUNCTION check_expiration(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION check_expiration() IS ' This checks whether the user needs to be notified of a pending expiration of 
his/her password.  Returns true if needed, false if not.

The function also records the next time when the notification will again need to
be displayed. ';


--
-- Name: company__delete_contact(integer, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company__delete_contact(in_company_id integer, in_contact_class_id integer, in_contact text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN

DELETE FROM company_to_contact
 WHERE company_id = in_company_id and contact_class_id = in_contact_class_id
       and contact= in_contact;
RETURN FOUND;

END;

$$;


--
-- Name: FUNCTION company__delete_contact(in_company_id integer, in_contact_class_id integer, in_contact text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION company__delete_contact(in_company_id integer, in_contact_class_id integer, in_contact text) IS ' Returns true if at least one record was deleted.  False if no records were 
affected.';


--
-- Name: company__delete_location(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company__delete_location(in_company_id integer, in_location_id integer, in_location_class integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN

DELETE FROM eca_to_location
 WHERE company_id = in_company_id AND location_id = in_location_id 
       AND location_class = in_location_class;

RETURN FOUND;

END;
$$;


--
-- Name: FUNCTION company__delete_location(in_company_id integer, in_location_id integer, in_location_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION company__delete_location(in_company_id integer, in_location_id integer, in_location_class integer) IS ' Deletes the record identified.  Returns true if successful, false if no record
found.';


--
-- Name: entity_credit_account; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE entity_credit_account (
    id integer NOT NULL,
    entity_id integer NOT NULL,
    entity_class integer NOT NULL,
    pay_to_name text,
    discount numeric,
    description text,
    discount_terms integer DEFAULT 0,
    discount_account_id integer,
    taxincluded boolean DEFAULT false,
    creditlimit numeric DEFAULT 0,
    terms smallint DEFAULT 0,
    meta_number character varying(32) NOT NULL,
    business_id integer,
    language_code character varying(6) DEFAULT 'en'::character varying,
    pricegroup_id integer,
    curr character(3),
    startdate date DEFAULT ('now'::text)::date,
    enddate date,
    threshold numeric DEFAULT 0,
    employee_id integer,
    primary_contact integer,
    ar_ap_account_id integer,
    cash_account_id integer,
    bank_account integer,
    taxform_id integer,
    CONSTRAINT entity_credit_account_check CHECK (((ar_ap_account_id IS NOT NULL) OR (entity_id = 0))),
    CONSTRAINT entity_credit_account_entity_class_check CHECK ((entity_class = ANY (ARRAY[1, 2])))
);


--
-- Name: TABLE entity_credit_account; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE entity_credit_account IS 'This table stores information relating to general relationships regarding 
moneys owed on invoice.  Invoices, whether AR or AP, must be attached to 
a record in this table.';


--
-- Name: COLUMN entity_credit_account.meta_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN entity_credit_account.meta_number IS ' This stores the human readable control code for the customer/vendor record.
This is typically called the customer/vendor "account" in the application.';


--
-- Name: company__get_all_accounts(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company__get_all_accounts(in_entity_id integer, in_entity_class integer) RETURNS SETOF entity_credit_account
    LANGUAGE sql
    AS $_$
    
    SELECT * 
      FROM entity_credit_account 
     WHERE entity_id = $1
       AND entity_class = $2;
    
$_$;


--
-- Name: FUNCTION company__get_all_accounts(in_entity_id integer, in_entity_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION company__get_all_accounts(in_entity_id integer, in_entity_class integer) IS ' Returns a list of all entity credit accounts attached to that entity.';


--
-- Name: entity_bank_account; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE entity_bank_account (
    id integer NOT NULL,
    entity_id integer NOT NULL,
    bic character varying,
    iban character varying NOT NULL
);


--
-- Name: TABLE entity_bank_account; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE entity_bank_account IS 'This stores bank account information for both companies and persons.';


--
-- Name: COLUMN entity_bank_account.bic; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN entity_bank_account.bic IS ' Banking Institution Code, such as routing number of SWIFT code.';


--
-- Name: COLUMN entity_bank_account.iban; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN entity_bank_account.iban IS ' International Bank Account Number.  used to store the actual account number
for the banking institution.';


--
-- Name: company__list_bank_account(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company__list_bank_account(in_entity_id integer) RETURNS SETOF entity_bank_account
    LANGUAGE plpgsql
    AS $$
DECLARE out_row entity_bank_account%ROWTYPE;
BEGIN
	FOR out_row IN
		SELECT * from entity_bank_account where entity_id = in_entity_id
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION company__list_bank_account(in_entity_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION company__list_bank_account(in_entity_id integer) IS ' Lists all bank accounts for the entity.';


--
-- Name: company__list_contacts(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company__list_contacts(in_entity_id integer) RETURNS SETOF contact_list
    LANGUAGE plpgsql
    AS $$
DECLARE out_row contact_list;
BEGIN
	FOR out_row IN
		SELECT cl.class, cl.id, c.description, c.contact
		FROM company_to_contact c
		JOIN contact_class cl ON (c.contact_class_id = cl.id)
		WHERE company_id = 
			(select id FROM company 
			WHERE entity_id = in_entity_id)
	LOOP
		return next out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION company__list_contacts(in_entity_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION company__list_contacts(in_entity_id integer) IS ' Lists all contact info for the entity.';


--
-- Name: company__list_locations(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company__list_locations(in_entity_id integer) RETURNS SETOF location_result
    LANGUAGE plpgsql
    AS $$
DECLARE out_row RECORD;
BEGIN
	FOR out_row IN
		SELECT l.id, l.line_one, l.line_two, l.line_three, l.city, 
			l.state, l.mail_code, c.id, c.name, lc.id, lc.class
		FROM location l
		JOIN company_to_location ctl ON (ctl.location_id = l.id)
		JOIN location_class lc ON (ctl.location_class = lc.id)
		JOIN country c ON (c.id = l.country_id)
		WHERE ctl.company_id = (select id from company where entity_id = in_entity_id)
		ORDER BY lc.id, l.id, c.name
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION company__list_locations(in_entity_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION company__list_locations(in_entity_id integer) IS ' Lists all locations for an entity.';


--
-- Name: entity_note; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE entity_note (
    entity_id integer,
    CONSTRAINT entity_note_note_class_check CHECK ((note_class = 1))
)
INHERITS (note);


--
-- Name: company__list_notes(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company__list_notes(in_entity_id integer) RETURNS SETOF entity_note
    LANGUAGE plpgsql
    AS $$
DECLARE out_row record;
BEGIN
	FOR out_row IN
		SELECT *
		FROM entity_note
		WHERE ref_key = in_entity_id
		ORDER BY created
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION company__list_notes(in_entity_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION company__list_notes(in_entity_id integer) IS ' Returns a set of notes (including content) attached to the entity.';


--
-- Name: company__location_save(integer, integer, integer, text, text, text, text, text, integer, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company__location_save(in_entity_id integer, in_location_id integer, in_location_class integer, in_line_one text, in_line_two text, in_city text, in_state text, in_mail_code text, in_country_code integer, in_created date) RETURNS integer
    LANGUAGE plpgsql
    AS $$
    BEGIN
    return _entity_location_save(
        in_entity_id, in_location_id,
        in_location_class, in_line_one, in_line_two, 
        '', in_city , in_state, in_mail_code, in_country_code);
    END;

$$;


--
-- Name: FUNCTION company__location_save(in_entity_id integer, in_location_id integer, in_location_class integer, in_line_one text, in_line_two text, in_city text, in_state text, in_mail_code text, in_country_code integer, in_created date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION company__location_save(in_entity_id integer, in_location_id integer, in_location_class integer, in_line_one text, in_line_two text, in_city text, in_state text, in_mail_code text, in_country_code integer, in_created date) IS ' Saves a location to a company.  Returns the location id.';


--
-- Name: company__next_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company__next_id() RETURNS bigint
    LANGUAGE sql
    AS $$
    
    select nextval('company_id_seq');
    
$$;


--
-- Name: company__save_contact(integer, integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company__save_contact(in_entity_id integer, in_contact_class integer, in_description text, in_contact text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE out_id int;
BEGIN
	INSERT INTO company_to_contact(company_id, contact_class_id, 
		description, contact)
	SELECT id, in_contact_class, in_description, in_contact FROM company
	WHERE entity_id = in_entity_id;

	RETURN 1;
END;
$$;


--
-- Name: FUNCTION company__save_contact(in_entity_id integer, in_contact_class integer, in_description text, in_contact text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION company__save_contact(in_entity_id integer, in_contact_class integer, in_description text, in_contact text) IS ' Saves company contact information.  The return value is meaningless. ';


--
-- Name: company__search(integer, text, text[], text, text, text, text, text, text, date, date, integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company__search(in_account_class integer, in_contact text, in_contact_info text[], in_meta_number text, in_address text, in_city text, in_state text, in_mail_code text, in_country text, in_date_from date, in_date_to date, in_business_id integer, in_legal_name text, in_control_code text) RETURNS SETOF company_search_result
    LANGUAGE plpgsql
    AS $$
DECLARE
	out_row company_search_result;
	loop_count int;
	t_contact_info text[];
BEGIN
	t_contact_info = in_contact_info;


	FOR out_row IN
		SELECT e.id, e.control_code, c.id, ec.id, ec.meta_number, 
			ec.description, ec.entity_class, 
			c.legal_name, c.sic_code, b.description , ec.curr::text
		FROM (select * from entity where in_control_code = control_code
                      union
                      select * from entity where in_control_code is null) e
		JOIN (SELECT * FROM company 
                       WHERE legal_name ilike  '%' || in_legal_name || '%'
                      UNION ALL
                      SELECT * FROM company
                       WHERE in_legal_name IS NULL) c ON (e.id = c.entity_id)
		LEFT JOIN (SELECT * FROM entity_credit_account 
                       WHERE meta_number = in_meta_number
                      UNION ALL
                      SELECT * from entity_credit_account
                       WHERE in_meta_number IS NULL) ec ON (ec.entity_id = e.id)
		LEFT JOIN business b ON (ec.business_id = b.id)
		WHERE coalesce(ec.entity_class,e.entity_class) = in_account_class
			AND (c.id IN (select company_id FROM company_to_contact
				WHERE contact ILIKE ALL(t_contact_info))
				OR '' ILIKE ALL(t_contact_info))
			
			AND (c.legal_name ilike '%' || in_legal_name || '%'
				OR in_legal_name IS NULL)
			AND ((in_address IS NULL AND in_city IS NULL 
					AND in_state IS NULL 
					AND in_country IS NULL)
				OR (c.id IN 
				(select company_id FROM company_to_location
				WHERE location_id IN 
					(SELECT id FROM location
					WHERE line_one 
						ilike '%' || 
							coalesce(in_address, '')
							|| '%'
						AND city ILIKE 
							'%' || 
							coalesce(in_city, '') 
							|| '%'
						AND state ILIKE
							'%' || 
							coalesce(in_state, '') 
							|| '%'
						AND mail_code ILIKE
							'%' || 
							coalesce(in_mail_code,
								'')
							|| '%'
						AND country_id IN 
							(SELECT id FROM country
							WHERE name ILIKE '%' ||
								in_country ||'%'
								OR short_name
								ilike 
								in_country)))))
			AND (ec.business_id = 
				coalesce(in_business_id, ec.business_id)
				OR (ec.business_id IS NULL 
					AND in_business_id IS NULL))
			AND (ec.startdate <= coalesce(in_date_to, 
						ec.startdate)
				OR (ec.startdate IS NULL))
			AND (ec.enddate >= coalesce(in_date_from, ec.enddate)
				OR (ec.enddate IS NULL))
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: company_get_billing_info(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company_get_billing_info(in_id integer) RETURNS company_billing_info
    LANGUAGE plpgsql
    AS $$
DECLARE out_var company_billing_info;
	t_id INT;
BEGIN
	select coalesce(eca.pay_to_name, c.legal_name), eca.meta_number, 
		e.control_code, c.tax_id, a.line_one, a.line_two, a.line_three, 
		a.city, a.state, a.mail_code, cc.name
	into out_var
	FROM company c
	JOIN entity e ON (c.entity_id = e.id)
	JOIN entity_credit_account eca ON (eca.entity_id = e.id)
	LEFT JOIN eca_to_location cl ON (eca.id = cl.credit_id)
	LEFT JOIN location a ON (a.id = cl.location_id)
	LEFT JOIN country cc ON (cc.id = a.country_id)
	WHERE eca.id = in_id AND (location_class = 1 or location_class is null);

	RETURN out_var;
END;
$$;


--
-- Name: FUNCTION company_get_billing_info(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION company_get_billing_info(in_id integer) IS ' Returns billing information (billing name and address) for a given credit 
account.';


--
-- Name: company; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE company (
    id integer NOT NULL,
    entity_id integer NOT NULL,
    legal_name text NOT NULL,
    tax_id text,
    sic_code character varying,
    created date DEFAULT ('now'::text)::date NOT NULL,
    CONSTRAINT company_legal_name_check CHECK ((legal_name ~ '[[:alnum:]_]'::text))
);


--
-- Name: COLUMN company.tax_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN company.tax_id IS ' In the US this would be a EIN. ';


--
-- Name: company_retrieve(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company_retrieve(in_entity_id integer) RETURNS company
    LANGUAGE plpgsql
    AS $$
DECLARE t_company company;
BEGIN
	SELECT * INTO t_company FROM company WHERE entity_id = in_entity_id;
	RETURN t_company;
END;
$$;


--
-- Name: FUNCTION company_retrieve(in_entity_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION company_retrieve(in_entity_id integer) IS ' Returns all attributes for the company attached to the entity.';


--
-- Name: company_save(integer, text, integer, text, text, integer, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION company_save(in_id integer, in_control_code text, in_entity_class integer, in_name text, in_tax_id text, in_entity_id integer, in_sic_code text, in_country_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE t_entity_id INT;
	t_company_id INT;
	t_control_code TEXT;
BEGIN
	t_company_id := in_id;

	IF in_control_code IS NULL THEN
		t_control_code := setting_increment('company_control');
	ELSE
		t_control_code := in_control_code;
	END IF;

	UPDATE entity 
	SET name = in_name, 
		entity_class = in_entity_class,
		control_code = in_control_code
	WHERE id = in_entity_id;

	IF FOUND THEN
		t_entity_id = in_entity_id;
	ELSE
		INSERT INTO entity (name, entity_class, control_code,country_id)
		VALUES (in_name, in_entity_class, t_control_code,in_country_id);
		t_entity_id := currval('entity_id_seq');
	END IF;

	UPDATE company
	SET legal_name = in_name,
		tax_id = in_tax_id,
		sic_code = in_sic_code
	WHERE id = t_company_id;


	IF NOT FOUND THEN
		INSERT INTO company(entity_id, legal_name, tax_id, sic_code)
		VALUES (t_entity_id, in_name, in_tax_id, in_sic_code);

	END IF;
	RETURN t_entity_id;
END;
$$;


--
-- Name: FUNCTION company_save(in_id integer, in_control_code text, in_entity_class integer, in_name text, in_tax_id text, in_entity_id integer, in_sic_code text, in_country_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION company_save(in_id integer, in_control_code text, in_entity_class integer, in_name text, in_tax_id text, in_entity_id integer, in_sic_code text, in_country_id integer) IS ' Saves a company.  Returns the id number of the record stored.';


--
-- Name: cr_coa_to_account_save(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION cr_coa_to_account_save(in_accno text, in_description text) RETURNS void
    LANGUAGE plpgsql
    AS $$
    DECLARE
       v_chart_id int;
    BEGIN
        -- Check for existence of the account already
        PERFORM * FROM cr_coa_to_account WHERE account = in_accno;

        IF NOT FOUND THEN
           -- This is a new account. Insert the relevant data.
           SELECT id INTO v_chart_id FROM chart WHERE accno = in_accno;
           INSERT INTO cr_coa_to_account (chart_id, account) VALUES (v_chart_id, in_accno||'--'||in_description);
        END IF;
        -- Already found, no need to do anything. =) 
    END;
$$;


--
-- Name: FUNCTION cr_coa_to_account_save(in_accno text, in_description text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION cr_coa_to_account_save(in_accno text, in_description text) IS ' Provides default rules for setting reconciliation labels.  Currently 
saves a label of accno ||''--'' || description.';


--
-- Name: cr_report_block_changing_approved(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION cr_report_block_changing_approved() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
   IF OLD.approved IS TRUE THEN
       RAISE EXCEPTION 'Report is approved.  Cannot change!';
   END IF;
   IF TG_OP = 'DELETE' THEN
       RETURN OLD;
   ELSE
      RETURN NEW;
   END IF;
END;
$$;


--
-- Name: FUNCTION cr_report_block_changing_approved(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION cr_report_block_changing_approved() IS ' This is a simple filter that prevents updating or deleting reconciliation
reports that have already been approved.  To purge old reconciliations you must
disable the block_change_when_approved trigger on cr_report.';


--
-- Name: currency_get_exchangerate(character, date, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION currency_get_exchangerate(in_currency character, in_date date, in_account_class integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE 
    out_exrate exchangerate.buy%TYPE;
    default_currency char(3);
    
    BEGIN 
        SELECT * INTO default_currency  FROM defaults_get_defaultcurrency();
        IF default_currency = in_currency THEN
           RETURN 1;
        END IF; 
        IF in_account_class = 2 THEN
          SELECT buy INTO out_exrate 
          FROM exchangerate
          WHERE transdate = in_date AND curr = in_currency;
        ELSE 
          SELECT sell INTO out_exrate 
          FROM exchangerate
          WHERE transdate = in_date AND curr = in_currency;   
        END IF;
        RETURN out_exrate;
    END;
$$;


--
-- Name: FUNCTION currency_get_exchangerate(in_currency character, in_date date, in_account_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION currency_get_exchangerate(in_currency character, in_date date, in_account_class integer) IS ' This function return the exchange rate of a given currency, date and exchange rate class (buy or sell). ';


--
-- Name: customer_location_save(integer, integer, text, text, text, text, text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION customer_location_save(in_entity_id integer, in_location_class integer, in_line_one text, in_line_two text, in_line_three text, in_city text, in_state text, in_mail_code text, in_country_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
    BEGIN
    return _entity_location_save(
        in_entity_id, NULL,
        in_location_class, in_line_one, in_line_two, in_line_three,
        in_city, in_state, in_mail_code, in_country_id);
    END;

$$;


--
-- Name: date_get_all_years(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION date_get_all_years() RETURNS SETOF integer
    LANGUAGE plpgsql
    AS $$
DECLARE next_record int;
BEGIN

SELECT MIN(EXTRACT ('YEAR' FROM transdate))::INT
INTO next_record
FROM acc_trans;

LOOP

  EXIT WHEN next_record IS NULL;
  RETURN NEXT next_record;
  SELECT MIN(EXTRACT ('YEAR' FROM transdate))::INT AS YEAR
  INTO next_record
  FROM acc_trans
  WHERE EXTRACT ('YEAR' FROM transdate) > next_record;


END LOOP;

END;
$$;


--
-- Name: FUNCTION date_get_all_years(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION date_get_all_years() IS ' This function return each year inside transdate in transactions. 
Currently it uses a sparse index scan because the number of rows returned is 
very small and the table can be very large.';


--
-- Name: days_in_month(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION days_in_month(in_date date) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT (extract(DOM FROM date_trunc('month', $1)
                         + '1 month - 1 second'::interval)
      )::int;

$_$;


--
-- Name: FUNCTION days_in_month(in_date date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION days_in_month(in_date date) IS ' Returns the number of days in the month that includes in_date.';


--
-- Name: defaults_get_defaultcurrency(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION defaults_get_defaultcurrency() RETURNS SETOF character
    LANGUAGE plpgsql
    AS $$
DECLARE defaultcurrency defaults.value%TYPE;
      BEGIN   
           SELECT INTO defaultcurrency substr(value,1,3)
           FROM defaults
           WHERE setting_key = 'curr';
           RETURN NEXT defaultcurrency;
      END;
$$;


--
-- Name: FUNCTION defaults_get_defaultcurrency(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION defaults_get_defaultcurrency() IS ' This function return the default currency asigned by the program. ';


--
-- Name: del_department(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION del_department() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  delete from dpt_trans where trans_id = old.id;
  return NULL;
end;
$$;


--
-- Name: del_exchangerate(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION del_exchangerate() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

declare
  t_transdate date;
  t_curr char(3);
  t_id int;
  d_curr text;

begin

  select into d_curr substr(value,1,3) from defaults where setting_key = 'curr';
  
  if TG_RELNAME = 'ar' then
    select into t_curr, t_transdate curr, transdate from ar where id = old.id;
  end if;
  if TG_RELNAME = 'ap' then
    select into t_curr, t_transdate curr, transdate from ap where id = old.id;
  end if;
  if TG_RELNAME = 'oe' then
    select into t_curr, t_transdate curr, transdate from oe where id = old.id;
  end if;

  if d_curr != t_curr then

    select into t_id a.id from acc_trans ac
    join ar a on (a.id = ac.trans_id)
    where a.curr = t_curr
    and ac.transdate = t_transdate

    except select a.id from ar a where a.id = old.id
    
    union
    
    select a.id from acc_trans ac
    join ap a on (a.id = ac.trans_id)
    where a.curr = t_curr
    and ac.transdate = t_transdate
    
    except select a.id from ap a where a.id = old.id
    
    union
    
    select o.id from oe o
    where o.curr = t_curr
    and o.transdate = t_transdate
    
    except select o.id from oe o where o.id = old.id;

    if not found then
      delete from exchangerate where curr = t_curr and transdate = t_transdate;
    end if;
  end if;
return old;

end;
$$;


--
-- Name: del_recurring(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION del_recurring() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  DELETE FROM recurring WHERE id = old.id;
  DELETE FROM recurringemail WHERE id = old.id;
  DELETE FROM recurringprint WHERE id = old.id;
  RETURN NULL;
END;
$$;


--
-- Name: del_yearend(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION del_yearend() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  delete from yearend where trans_id = old.id;
  return NULL;
end;
$$;


--
-- Name: department; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE department (
    id integer NOT NULL,
    description text,
    role character(1) DEFAULT 'P'::bpchar
);


--
-- Name: COLUMN department.role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN department.role IS 'P for Profit Center, C for Cost Center';


--
-- Name: department__list_all(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION department__list_all() RETURNS SETOF department
    LANGUAGE sql
    AS $$
SELECT * FROM department order by description;
$$;


--
-- Name: department_list(character); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION department_list(in_role character) RETURNS SETOF department
    LANGUAGE plpgsql
    AS $$
DECLARE out_department department%ROWTYPE;
BEGIN
       FOR out_department IN
               SELECT * from department
               WHERE role = coalesce(in_role, role)
       LOOP
               return next out_department;
       END LOOP;
END;
$$;


--
-- Name: FUNCTION department_list(in_role character); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION department_list(in_role character) IS ' This function returns all department that match the role provided as
the argument.';


--
-- Name: draft__search(text, text, date, date, numeric, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION draft__search(in_type text, in_with_accno text, in_from_date date, in_to_date date, in_amount_le numeric, in_amount_ge numeric) RETURNS SETOF draft_search_result
    LANGUAGE plpgsql
    AS $$
DECLARE out_row RECORD;
BEGIN
	FOR out_row IN
		SELECT trans.id, trans.transdate, trans.reference, 
			trans.description, 
			sum(case when lower(in_type) = 'ap' AND chart.link = 'AP'
				 THEN line.amount
				 WHEN lower(in_type) = 'ar' AND chart.link = 'AR'
				 THEN line.amount * -1
				 WHEN lower(in_type) = 'gl' AND line.amount > 0
				 THEN line.amount
			 	 ELSE 0
			    END) as amount
		FROM (
			SELECT id, transdate, reference, 
				description,
                                approved from gl
			WHERE lower(in_type) = 'gl'
			UNION
			SELECT id, transdate, invnumber as reference, 
				(SELECT name FROM eca__get_entity(entity_credit_account)),
				approved from ap
			WHERE lower(in_type) = 'ap'
			UNION
			SELECT id, transdate, invnumber as reference,
				description, 
				approved from ar
			WHERE lower(in_type) = 'ar'
			) trans
		JOIN acc_trans line ON (trans.id = line.trans_id)
		JOIN chart ON (line.chart_id = chart.id and charttype = 'A')
           LEFT JOIN voucher v ON (v.trans_id = trans.id)
		WHERE (in_from_date IS NULL or trans.transdate >= in_from_date)
			AND (in_to_date IS NULL 
				or trans.transdate <= in_to_date)
			AND trans.approved IS FALSE
			AND v.id IS NULL
		GROUP BY trans.id, trans.transdate, trans.description, trans.reference
		HAVING (in_with_accno IS NULL or in_with_accno = 
			ANY(as_array(chart.accno)))
		ORDER BY trans.reference
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION draft__search(in_type text, in_with_accno text, in_from_date date, in_to_date date, in_amount_le numeric, in_amount_ge numeric); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION draft__search(in_type text, in_with_accno text, in_from_date date, in_to_date date, in_amount_le numeric, in_amount_ge numeric) IS ' Searches for drafts.  in_type may be any of ''ar'', ''ap'', or ''gl''.';


--
-- Name: draft_approve(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION draft_approve(in_id integer) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
declare 
	t_table text;
begin
	SELECT table_name into t_table FROM transactions where id = in_id;

        IF (t_table = 'ar') THEN
		UPDATE ar set approved = true where id = in_id;
	ELSIF (t_table = 'ap') THEN
		UPDATE ap set approved = true where id = in_id;
	ELSIF (t_table = 'gl') THEN
		UPDATE gl set approved = true where id = in_id;
	ELSE
		raise exception 'Invalid table % in draft_approve for transaction %', t_table, in_id;
	END IF;

	IF NOT FOUND THEN
		RETURN FALSE;
	END IF;

	UPDATE transactions 
	SET approved_by = 
			(select entity_id FROM users 
			WHERE username = SESSION_USER), 
		approved_at = now() 
	WHERE id = in_id;

	RETURN TRUE;
END;
$$;


--
-- Name: FUNCTION draft_approve(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION draft_approve(in_id integer) IS ' Deletes the draft from the book.  Only will delete unapproved transactions.
Otherwise an exception is raised and the transaction terminated.';


--
-- Name: draft_delete(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION draft_delete(in_id integer) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
declare 
	t_table text;
begin
	DELETE FROM ac_tax_form 
	WHERE entry_id IN 
		(SELECT entry_id FROM acc_trans WHERE trans_id = in_id);

        DELETE FROM acc_trans WHERE trans_id = in_id;
	SELECT lower(table_name) into t_table FROM transactions where id = in_id;

        IF t_table = 'ar' THEN
		DELETE FROM ar WHERE id = in_id AND approved IS FALSE;
	ELSIF t_table = 'ap' THEN
		DELETE FROM ap WHERE id = in_id AND approved IS FALSE;
	ELSIF t_table = 'gl' THEN
		DELETE FROM gl WHERE id = in_id AND approved IS FALSE;
	ELSE
		raise exception 'Invalid table % in draft_delete for transaction %', t_table, in_id;
	END IF;
	IF NOT FOUND THEN
		RAISE EXCEPTION 'Invalid transaction id %', in_id;
	END IF;
	RETURN TRUE;
END;
$$;


--
-- Name: drop_custom_field(character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION drop_custom_field(character varying, character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
DECLARE
table_name ALIAS FOR $1;
custom_field_name ALIAS FOR $2;
BEGIN
	DELETE FROM custom_field_catalog 
	WHERE field_name = custom_field_name AND 
		table_id = (SELECT table_id FROM custom_table_catalog 
			WHERE extends = table_name);
	EXECUTE 'ALTER TABLE ' || quote_ident('custom_' || table_name) || 
		' DROP COLUMN ' || quote_ident(custom_field_name);
	RETURN TRUE;	
END;
$_$;


--
-- Name: eca__delete_contact(integer, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__delete_contact(in_credit_id integer, in_contact_class_id integer, in_contact text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN

DELETE FROM eca_to_contact
 WHERE credit_id = in_credit_id and contact_class_id = in_contact_class_id
       and contact= in_contact;
RETURN FOUND;

END;

$$;


--
-- Name: FUNCTION eca__delete_contact(in_credit_id integer, in_contact_class_id integer, in_contact text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca__delete_contact(in_credit_id integer, in_contact_class_id integer, in_contact text) IS ' Returns true if at least one record was deleted.  False if no records were
affected.';


--
-- Name: eca__delete_location(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__delete_location(in_credit_id integer, in_location_id integer, in_location_class integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN

DELETE FROM eca_to_location
 WHERE credit_id = in_credit_id AND location_id = in_location_id 
       AND location_class = in_location_class;

RETURN FOUND;

END;
$$;


--
-- Name: FUNCTION eca__delete_location(in_credit_id integer, in_location_id integer, in_location_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca__delete_location(in_credit_id integer, in_location_id integer, in_location_class integer) IS ' Deletes the record identified.  Returns true if successful, false if no record
found.';


--
-- Name: eca__delete_pricematrix(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__delete_pricematrix(in_credit_id integer, in_entry_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE retval bool;

BEGIN

retval := false;

DELETE FROM partsvendor 
 WHERE entry_id = in_entry_id 
       AND credit_id = in_credit_id;

retval := FOUND;

DELETE FROM partscustomer
 WHERE entry_id = in_entry_id
       AND credit_id = in_credit_id;

RETURN FOUND or retval;

END;
$$;


--
-- Name: setting_increment(character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION setting_increment(in_key character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$
DECLARE
	base_value VARCHAR;
	raw_value VARCHAR;
	increment INTEGER;
	inc_length INTEGER;
	new_value VARCHAR;
BEGIN
	SELECT value INTO raw_value FROM defaults 
	WHERE setting_key = in_key
	FOR UPDATE;

	SELECT substring(raw_value from  '(' || E'\\' || 'd*)(' || E'\\' || 'D*|<' || E'\\' || '?lsmb [^<>] ' || E'\\' || '?>)*$')
	INTO base_value;

	IF base_value like '0%' THEN
		increment := base_value::integer + 1;
		SELECT char_length(increment::text) INTO inc_length;

		SELECT overlay(base_value placing increment::varchar
			from (select char_length(base_value) 
				- inc_length + 1) for inc_length)
		INTO new_value;
	ELSE
		new_value := base_value::integer + 1;
	END IF;
	SELECT regexp_replace(raw_value, base_value, new_value) INTO new_value;
	UPDATE defaults SET value = new_value WHERE setting_key = in_key;

	return new_value;	
END;
$_$;


--
-- Name: FUNCTION setting_increment(in_key character varying); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION setting_increment(in_key character varying) IS 'This function takes a value for a sequence in the defaults table and increments
it.  Leading zeroes and spaces are preserved as placeholders.  Currently <?lsmb
parsing is not supported in this routine though it may be added at a later date.
';


--
-- Name: entity; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE entity (
    id integer NOT NULL,
    name text,
    entity_class integer NOT NULL,
    created date DEFAULT ('now'::text)::date NOT NULL,
    control_code text DEFAULT setting_increment('entity_control'::character varying) NOT NULL,
    country_id integer NOT NULL,
    CONSTRAINT entity_name_check CHECK ((name ~ '[[:alnum:]_]'::text))
);


--
-- Name: TABLE entity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE entity IS ' The primary entity table to map to all contacts ';


--
-- Name: COLUMN entity.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN entity.name IS ' This is the common name of an entity. If it was a person it may be Joshua Drake, a company Acme Corp. You may also choose to use a domain such as commandprompt.com ';


--
-- Name: eca__get_entity(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__get_entity(in_credit_id integer) RETURNS SETOF entity
    LANGUAGE plpgsql
    AS $$

declare
    v_row entity;
BEGIN
    SELECT entity.* INTO v_row FROM entity_credit_account JOIN entity ON entity_credit_account.entity_id = entity.id WHERE entity_credit_account.id = in_credit_id;
    IF NOT FOUND THEN
        raise exception 'Could not find entity with ID %', in_credit_id;
    ELSE
        return next v_row;
    END IF;
END;

$$;


--
-- Name: FUNCTION eca__get_entity(in_credit_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca__get_entity(in_credit_id integer) IS ' Returns a set of (only one) entity to which the entity credit account is
attached.';


--
-- Name: eca__get_pricematrix(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__get_pricematrix(in_credit_id integer) RETURNS SETOF eca__pricematrix
    LANGUAGE sql
    AS $_$

SELECT pc.parts_id, p.partnumber, p.description, pc.credit_id, pc.pricebreak,
       pc.sellprice, NULL, NULL::int, NULL, pc.validfrom, pc.validto, pc.curr,
       pc.entry_id
  FROM partscustomer pc
  JOIN parts p on pc.parts_id = p.id
  JOIN entity_credit_account eca ON pc.credit_id = eca.id
 WHERE pc.credit_id = $1 AND eca.entity_class = 2
 UNION
SELECT pv.parts_id, p.partnumber, p.description, pv.credit_id, NULL, NULL,
       pv.lastcost, pv.leadtime::int, pv.partnumber, NULL, NULL, pv.curr, 
       pv.entry_id
  FROM partsvendor pv
  JOIN parts p on pv.parts_id = p.id
  JOIN entity_credit_account eca ON pv.credit_id = eca.id
 WHERE pv.credit_id = $1 and eca.entity_class = 1
 ORDER BY partnumber, validfrom

$_$;


--
-- Name: FUNCTION eca__get_pricematrix(in_credit_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca__get_pricematrix(in_credit_id integer) IS ' This returns the pricematrix for the customer or vendor 
(entity_credit_account identified by in_id), orderd by partnumber, validfrom
';


--
-- Name: eca__get_pricematrix_by_pricegroup(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__get_pricematrix_by_pricegroup(in_credit_id integer) RETURNS SETOF eca__pricematrix
    LANGUAGE sql
    AS $_$
SELECT pc.parts_id, p.partnumber, p.description, pc.credit_id, pc.pricebreak,
       pc.sellprice, NULL::numeric, NULL::int, NULL::text, pc.validfrom, 
       pc.validto, pc.curr, pc.entry_id
  FROM partscustomer pc
  JOIN parts p on pc.parts_id = p.id
  JOIN entity_credit_account eca ON pc.pricegroup_id = eca.pricegroup_id
 WHERE eca.id = $1 AND eca.entity_class = 2
$_$;


--
-- Name: customertax; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE customertax (
    customer_id integer NOT NULL,
    chart_id integer NOT NULL
);


--
-- Name: TABLE customertax; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE customertax IS ' Mapping customer to taxes.';


--
-- Name: eca__get_taxes(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__get_taxes(in_credit_id integer) RETURNS SETOF customertax
    LANGUAGE sql
    AS $_$
select * from customertax where customer_id = $1
union
select * from vendortax where vendor_id = $1;
$_$;


--
-- Name: FUNCTION eca__get_taxes(in_credit_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca__get_taxes(in_credit_id integer) IS ' Returns a set of taxable account id''s.';


--
-- Name: eca__list_contacts(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__list_contacts(in_credit_id integer) RETURNS SETOF contact_list
    LANGUAGE plpgsql
    AS $$
DECLARE out_row contact_list;
BEGIN
	FOR out_row IN
		SELECT cl.class, cl.id, c.description, c.contact
		FROM eca_to_contact c
		JOIN contact_class cl ON (c.contact_class_id = cl.id)
		WHERE credit_id = in_credit_id
	LOOP
		return next out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION eca__list_contacts(in_credit_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca__list_contacts(in_credit_id integer) IS ' Returns a list of contact info attached to the entity credit account.';


--
-- Name: eca__list_locations(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__list_locations(in_credit_id integer) RETURNS SETOF location_result
    LANGUAGE plpgsql
    AS $$
DECLARE out_row RECORD;
BEGIN
	FOR out_row IN
		SELECT l.id, l.line_one, l.line_two, l.line_three, l.city, 
			l.state, l.mail_code, c.id, c.name, lc.id, lc.class
		FROM location l
		JOIN eca_to_location ctl ON (ctl.location_id = l.id)
		JOIN location_class lc ON (ctl.location_class = lc.id)
		JOIN country c ON (c.id = l.country_id)
		WHERE ctl.credit_id = in_credit_id
		ORDER BY lc.id, l.id, c.name
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION eca__list_locations(in_credit_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca__list_locations(in_credit_id integer) IS ' Returns a list of locations attached to the credit account.';


--
-- Name: eca__list_notes(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__list_notes(in_credit_id integer) RETURNS SETOF note
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE out_row record;
	t_entity_id int;
BEGIN
        -- ALERT: security definer function.  Be extra careful about EXECUTE
        -- in here. --CT
	SELECT entity_id INTO t_entity_id
	FROM entity_credit_account
	WHERE id = in_credit_id;

	FOR out_row IN
		SELECT *
		FROM note
		WHERE (note_class = 3 and ref_key = in_credit_id) or
			(note_class = 1 and ref_key = t_entity_id)
		ORDER BY created
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION eca__list_notes(in_credit_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca__list_notes(in_credit_id integer) IS 'Returns a list of notes attached to the entity credit account.';


--
-- Name: eca__location_save(integer, integer, integer, text, text, text, text, text, text, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__location_save(in_credit_id integer, in_location_id integer, in_location_class integer, in_line_one text, in_line_two text, in_line_three text, in_city text, in_state text, in_mail_code text, in_country_code integer, in_old_location_class integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$

    DECLARE
        l_row location;
        l_id INT;
        l_orig_id INT;
    BEGIN
       
        UPDATE eca_to_location
           SET location_class = in_location_class
         WHERE credit_id = in_credit_id
           AND location_class = in_old_location_class
           AND location_id = in_location_id;
           
         IF FOUND THEN
            SELECT location_save(
                in_location_id, 
                in_line_one, 
                in_line_two, 
                in_line_three, 
                in_city,
                in_state, 
                in_mail_code, 
                in_country_code
            )
        	INTO l_id; 
        ELSE
            SELECT location_save(
                NULL, 
                in_line_one, 
                in_line_two, 
                in_line_three, 
                in_city,
                in_state, 
                in_mail_code, 
                in_country_code
            )
        	INTO l_id; 
            INSERT INTO eca_to_location 
        		(credit_id, location_class, location_id)
        	VALUES  (in_credit_id, in_location_class, l_id);
        
        END IF;

	RETURN l_id;    
    END;

$$;


--
-- Name: FUNCTION eca__location_save(in_credit_id integer, in_location_id integer, in_location_class integer, in_line_one text, in_line_two text, in_line_three text, in_city text, in_state text, in_mail_code text, in_country_code integer, in_old_location_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca__location_save(in_credit_id integer, in_location_id integer, in_location_class integer, in_line_one text, in_line_two text, in_line_three text, in_city text, in_state text, in_mail_code text, in_country_code integer, in_old_location_class integer) IS ' Saves a location to an entity credit account. Returns id of saved record.';


--
-- Name: eca__save_bank_account(integer, integer, text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__save_bank_account(in_entity_id integer, in_credit_id integer, in_bic text, in_iban text, in_bank_account_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE out_id int;
BEGIN
        UPDATE entity_bank_account
           SET bic = in_bic,
               iban = in_iban
         WHERE id = in_bank_account_id;

        IF FOUND THEN
                out_id = in_bank_account_id;
        ELSE
	  	INSERT INTO entity_bank_account(entity_id, bic, iban)
		VALUES(in_entity_id, in_bic, in_iban);
	        SELECT CURRVAL('entity_bank_account_id_seq') INTO out_id ;
	END IF;

	IF in_credit_id IS NOT NULL THEN
		UPDATE entity_credit_account SET bank_account = out_id
		WHERE id = in_credit_id;
	END IF;

	RETURN out_id;
END;
$$;


--
-- Name: FUNCTION eca__save_bank_account(in_entity_id integer, in_credit_id integer, in_bic text, in_iban text, in_bank_account_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca__save_bank_account(in_entity_id integer, in_credit_id integer, in_bic text, in_iban text, in_bank_account_id integer) IS ' Saves bank account to the credit account.';


--
-- Name: eca__save_contact(integer, integer, text, text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__save_contact(in_credit_id integer, in_contact_class integer, in_description text, in_contact text, in_old_contact text, in_old_contact_class integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE out_id int;
BEGIN

    PERFORM *
       FROM eca_to_contact
      WHERE credit_id = in_credit_id
        AND contact_class_id = in_old_contact_class
        AND contact = in_old_contact;
        
    IF FOUND THEN
        UPDATE eca_to_contact
           SET contact = in_contact,
               description = in_description,
               contact_class_id = in_contact_class
         WHERE credit_id = in_credit_id
           AND contact_class_id = in_old_contact_class
           AND contact = in_old_contact;
    ELSE
        INSERT INTO eca_to_contact(credit_id, contact_class_id, 
                description, contact)
        VALUES (in_credit_id, in_contact_class, in_description, in_contact);
        
    END IF;

	RETURN 1;
END;
$$;


--
-- Name: FUNCTION eca__save_contact(in_credit_id integer, in_contact_class integer, in_description text, in_contact text, in_old_contact text, in_old_contact_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca__save_contact(in_credit_id integer, in_contact_class integer, in_description text, in_contact text, in_old_contact text, in_old_contact_class integer) IS ' Saves the contact record at the entity credit account level.  Returns 1.';


--
-- Name: eca__save_notes(integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__save_notes(in_credit_id integer, in_note text, in_subject text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE out_id int;
BEGIN
	-- TODO, change this to create vector too
	INSERT INTO eca_note (ref_key, note_class, note, vector, subject)
	VALUES (in_credit_id, 3, in_note, '', in_subject);

	SELECT currval('note_id_seq') INTO out_id;
	RETURN out_id;
END;
$$;


--
-- Name: FUNCTION eca__save_notes(in_credit_id integer, in_note text, in_subject text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca__save_notes(in_credit_id integer, in_note text, in_subject text) IS ' Saves an entity credit account-level note.  Such a note is valid for only one
credit account. Returns the id of the note.  ';


--
-- Name: eca__save_pricematrix(integer, integer, numeric, numeric, smallint, text, date, date, character, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__save_pricematrix(in_parts_id integer, in_credit_id integer, in_pricebreak numeric, in_price numeric, in_lead_time smallint, in_partnumber text, in_validfrom date, in_validto date, in_curr character, in_entry_id integer) RETURNS eca__pricematrix
    LANGUAGE plpgsql
    AS $$
DECLARE 
   retval eca__pricematrix;
   t_insert bool;

BEGIN

t_insert := false;

PERFORM * FROM entity_credit_account 
  WHERE id = in_credit_id AND entity_class = 1;

IF FOUND THEN -- VENDOR
    UPDATE partsvendor
       SET lastcost = in_price,
           leadtime = in_lead_time,
           partnumber = in_partnumber,
           curr = in_curr
     WHERE credit_id = in_credit_id AND entry_id = in_entry_id;

    IF NOT FOUND THEN
        INSERT INTO partsvendor
               (parts_id, credit_id, lastcost, leadtime, partnumber, curr)
        VALUES (in_parts_id, in_credit_id, in_price, in_leadtime::int2, 
               in_partnumber, in_curr);
    END IF;

    SELECT pv.parts_id, p.partnumber, p.description, pv.credit_id, NULL, NULL,
           pv.lastcost, pv.leadtime::int, pv.partnumber, NULL, NULL, pv.curr, 
           pv.entry_id
      INTO retval
      FROM partsvendor pv
      JOIN parts p ON p.id = pv.parts_id
     WHERE parts_id = in_parts_id and credit_id = in_credit_id;

    RETURN retval;
END IF;

PERFORM * FROM entity_credit_account
  WHERE id = in_credit_id AND entity_class = 2;

IF FOUND THEN -- CUSTOMER
    UPDATE partscustomer
       SET pricebreak = in_pricebreak,
           sellprice  = in_price,
           validfrom  = in_validfrom,
           validto    = in_validto,
           curr       = in_curr
     WHERE entry_id = in_entry_id and credit_id = in_credit_id;

    IF NOT FOUND THEN
        INSERT INTO partscustomer
               (parts_id, credit_id, sellprice, validfrom, validto, curr)
        VALUES (in_parts_id, in_credit_id, in_price, in_validfrom, in_validto, 
                in_curr);

        t_insert := true;
    END IF;

    SELECT pc.parts_id, p.partnumber, p.description, pc.credit_id, 
           pc.pricebreak, pc.sellprice, NULL, NULL, NULL, pc.validfrom, 
           pc.validto, pc.curr, pc.entry_id
      INTO retval
      FROM partscustomer pc
      JOIN parts p on pc.parts_id = p.id
     WHERE entry_id = CASE WHEN t_insert 
                           THEN currval('partscustomer_entry_id_seq') 
                           ELSE in_entry_id 
                      END;
                           
    RETURN retval;

END IF;

RAISE EXCEPTION 'No valid entity credit account found';
   
END;
$$;


--
-- Name: eca__set_taxes(integer, integer[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca__set_taxes(in_credit_id integer, in_tax_ids integer[]) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE 
    eca entity_credit_account;
    iter int;
BEGIN
     SELECT * FROM entity_credit_account into eca WHERE id = in_credit_id;

     IF eca.entity_class = 1 then
        DELETE FROM vendortax WHERE vendor_id = in_credit_id;
        FOR iter in array_lower(in_tax_ids, 1) .. array_upper(in_tax_ids, 1)
        LOOP
             INSERT INTO vendortax (vendor_id, chart_id)
             values (in_credit_id, in_tax_ids[iter]);
        END LOOP;
     ELSIF eca.entity_class = 2 then
        DELETE FROM customertax WHERE customer_id = in_credit_id;
        FOR iter in array_lower(in_tax_ids, 1) .. array_upper(in_tax_ids, 1)
        LOOP
             INSERT INTO customertax (customer_id, chart_id)
             values (in_credit_id, in_tax_ids[iter]);
        END LOOP;
     ELSE 
        RAISE EXCEPTION 'Wrong entity class or credit account not found!';
     END IF;
     RETURN TRUE;
end;
$$;


--
-- Name: FUNCTION eca__set_taxes(in_credit_id integer, in_tax_ids integer[]); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca__set_taxes(in_credit_id integer, in_tax_ids integer[]) IS 'Sets the tax values for the customer or vendor.

The entity credit account must exist before calling this function, and must
have a type of either 1 or 2.
';


--
-- Name: eca_history(text, text, text, text, text, text, text, text, text, integer, date, date, character, date, date, integer, boolean, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca_history(in_name text, in_meta_number text, in_contact_info text, in_address_line text, in_city text, in_state text, in_zip text, in_salesperson text, in_notes text, in_country_id integer, in_from_date date, in_to_date date, in_type character, in_start_from date, in_start_to date, in_account_class integer, in_inc_open boolean, in_inc_closed boolean) RETURNS SETOF eca_history_result
    LANGUAGE sql
    AS $_$
     SELECT eca.id, e.name, eca.meta_number, 
            a.id as invoice_id, a.invnumber, a.curr::text, 
            p.id AS parts_id, p.partnumber, 
            i.description, i.qty, i.unit::text, i.sellprice, i.discount, 
            i.deliverydate, pr.id as project_id, pr.projectnumber,
            i.serialnumber, 
            case when $16 = 1 then xr.buy else xr.sell end as exchange_rate,
            ee.id as salesperson_id, 
            ep.last_name || ', ' || ep.first_name as salesperson_name
     FROM (select * from entity_credit_account 
            where meta_number = $2
           UNION 
          select * from entity_credit_account WHERE $2 is null
          ) eca  -- broken into unions for performance
     join entity e on eca.entity_id = e.id
     JOIN (select  invnumber, curr, transdate, entity_credit_account, id,
                   person_id
             FROM ar 
            where $16 = 2 and $13 = 'i'
                  and (($17 and amount = paid) or ($18 and amount <> paid))
            UNION 
           select invnumber, curr, transdate, entity_credit_account, id,
                  person_id
             FROM ap 
            where $16 = 1 and $13 = 'i'
                  and (($17 and amount = paid) or ($18 and amount <> paid))
           union 
           select ordnumber, curr, transdate, entity_credit_account, id,
                  person_id
           from oe 
           where ($16= 1 and oe.oe_class_id = 2 and $13 = 'o' 
                  and quotation is not true)
                  and (($17 and not closed) or ($18 and closed))
           union 
           select ordnumber, curr, transdate, entity_credit_account, id,
                  person_id
           from oe 
           where ($16= 2 and oe.oe_class_id = 1 and $13 = 'o'
                  and quotation is not true)
                  and (($17 and not closed) or ($18 and closed))
           union 
           select quonumber, curr, transdate, entity_credit_account, id,
                  person_id
           from oe 
           where($16= 1 and oe.oe_class_id = 4 and $13 = 'q'
                and quotation is true)
                  and (($17 and not closed) or ($18 and closed))
           union 
           select quonumber, curr, transdate, entity_credit_account, id,
                  person_id
           from oe 
           where($16= 2 and oe.oe_class_id = 4 and $13 = 'q'
                 and quotation is true)
                  and (($17 and not closed) or ($18 and closed))
          ) a ON (a.entity_credit_account = eca.id) -- broken into unions 
                                                    -- for performance
     JOIN ( select trans_id, parts_id, qty, description, unit, discount,
                   deliverydate, serialnumber, project_id, sellprice
             FROM  invoice where $13 = 'i'
            union 
            select trans_id, parts_id, qty, description, unit, discount,
                   reqdate, serialnumber, project_id, sellprice
             FROM orderitems where $13 <> 'i'
          ) i on i.trans_id = a.id
     JOIN parts p ON (p.id = i.parts_id)
LEFT JOIN exchangerate ex ON (ex.transdate = a.transdate)
LEFT JOIN project pr ON (pr.id = i.project_id)
LEFT JOIN entity ee ON (a.person_id = ee.id)
LEFT JOIN person ep ON (ep.entity_id = ee.id)
     JOIN exchangerate xr ON a.transdate = xr.transdate
    -- these filters don't perform as well on large databases
    WHERE (e.name ilike '%' || $1 || '%' or $1 is null)
          and ($3 is null or eca.id in 
                 (select credit_id from eca_to_contact
                   where contact ilike '%' || $3 || '%'))
          and (($4 is null and $5 is null and $6 is null and $7 is null)
               or eca.id in
                  (select credit_id from eca_to_location 
                    where location_id in
                          (select id from location
                            where ($4 is null or line_one ilike '%' || $4 || '%'
                                   or line_two ilike '%' || $4 || '%') 
                                  and ($5 is null or city 
                                                     ilike '%' || $5 || '%')
                                  and ($6 is null or state 
                                                    ilike '%' || $6 || '%')
                                  and ($7 is null or mail_code 
                                                    ilike '%' || $7 || '%')
                                  and ($10 is null or country_id = $10))
                   )
              )
          and (a.transdate >= $11 or $11 is null)
          and (a.transdate <= $12 or $12 is null)
          and (eca.startdate >= $14 or $14 is null)
          and (eca.startdate <= $15 or $15 is null)
 ORDER BY eca.meta_number;
$_$;


--
-- Name: FUNCTION eca_history(in_name text, in_meta_number text, in_contact_info text, in_address_line text, in_city text, in_state text, in_zip text, in_salesperson text, in_notes text, in_country_id integer, in_from_date date, in_to_date date, in_type character, in_start_from date, in_start_to date, in_account_class integer, in_inc_open boolean, in_inc_closed boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca_history(in_name text, in_meta_number text, in_contact_info text, in_address_line text, in_city text, in_state text, in_zip text, in_salesperson text, in_notes text, in_country_id integer, in_from_date date, in_to_date date, in_type character, in_start_from date, in_start_to date, in_account_class integer, in_inc_open boolean, in_inc_closed boolean) IS 'This produces a history detail report, i.e. a list of all products purchased by
a customer over a specific date range.  

meta_number is an exact match, as are in_open and inc_closed.  All other fields
allow for partial matches.  NULL matches all values.';


--
-- Name: eca_history_summary(text, text, text, text, text, text, text, text, text, integer, date, date, character, date, date, integer, boolean, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eca_history_summary(in_name text, in_meta_number text, in_contact_info text, in_address_line text, in_city text, in_state text, in_zip text, in_salesperson text, in_notes text, in_country_id integer, in_from_date date, in_to_date date, in_type character, in_start_from date, in_start_to date, in_account_class integer, in_inc_open boolean, in_inc_closed boolean) RETURNS SETOF eca_history_result
    LANGUAGE sql
    AS $_$
SELECT id, name, meta_number, null::int, null::text, curr, parts_id, partnumber,
       description, sum(qty), unit, null::numeric, null::numeric, null::date, 
       null::int, null::text, null::text, null::numeric,
       null::int, null::text
FROM   eca_history($1, $2, $3, $4, $5, $6, $7, $8, $9,
                   $10, $11, $12, $13, $14, $15, $16, $17, $18)
 group by id, name, meta_number, curr, parts_id, partnumber, description, unit
 order by meta_number;
$_$;


--
-- Name: FUNCTION eca_history_summary(in_name text, in_meta_number text, in_contact_info text, in_address_line text, in_city text, in_state text, in_zip text, in_salesperson text, in_notes text, in_country_id integer, in_from_date date, in_to_date date, in_type character, in_start_from date, in_start_to date, in_account_class integer, in_inc_open boolean, in_inc_closed boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eca_history_summary(in_name text, in_meta_number text, in_contact_info text, in_address_line text, in_city text, in_state text, in_zip text, in_salesperson text, in_notes text, in_country_id integer, in_from_date date, in_to_date date, in_type character, in_start_from date, in_start_to date, in_account_class integer, in_inc_open boolean, in_inc_closed boolean) IS 'Creates a summary account (no quantities, just parts group by invoice).

meta_number must match exactly or be NULL.  inc_open and inc_closed are exact
matches too.  All other values specify ranges or may match partially.';


--
-- Name: employee__all_managers(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION employee__all_managers() RETURNS SETOF employee_result
    LANGUAGE sql
    AS $$
   SELECT p.entity_id, p.id, s.salutation,
          p.first_name, p.middle_name, p.last_name,
          ee.startdate, ee.enddate, ee.role, ee.ssn, ee.sales, ee.manager_id,
          mp.first_name, mp.last_name, ee.employeenumber, ee.dob, e.country_id
     FROM person p
     JOIN entity_employee ee on (ee.entity_id = p.entity_id)
     JOIN entity e ON (p.entity_id = e.id)
LEFT JOIN salutation s on (p.salutation_id = s.id)
LEFT JOIN person mp ON ee.manager_id = p.entity_id
    WHERE ee.role = 'manager'
 ORDER BY ee.employeenumber;
$$;


--
-- Name: employee__get(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION employee__get(in_entity_id integer) RETURNS employee_result
    LANGUAGE sql
    AS $_$
   SELECT p.entity_id, p.id, s.salutation, 
          p.first_name, p.middle_name, p.last_name,
          ee.startdate, ee.enddate, ee.role, ee.ssn, ee.sales, ee.manager_id,
          mp.first_name, mp.last_name, ee.employeenumber, ee.dob, e.country_id
     FROM person p
     JOIN entity_employee ee on (ee.entity_id = p.entity_id)
     JOIN entity e ON (p.entity_id = e.id)
LEFT JOIN salutation s on (p.salutation_id = s.id)
LEFT JOIN person mp ON ee.manager_id = p.entity_id
    WHERE p.entity_id = $1;
$_$;


--
-- Name: FUNCTION employee__get(in_entity_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION employee__get(in_entity_id integer) IS ' Returns an employee_result tuple with information specified by the entity_id.
';


--
-- Name: employee__get_user(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION employee__get_user(in_entity_id integer) RETURNS SETOF users
    LANGUAGE sql
    AS $_$SELECT * FROM users WHERE entity_id = $1;$_$;


--
-- Name: FUNCTION employee__get_user(in_entity_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION employee__get_user(in_entity_id integer) IS ' Returns username, user_id, etc. information if the employee is a user.';


--
-- Name: entity_employee; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE entity_employee (
    entity_id integer NOT NULL,
    startdate date DEFAULT ('now'::text)::date NOT NULL,
    enddate date,
    role character varying(20),
    ssn text,
    sales boolean DEFAULT false,
    manager_id integer,
    employeenumber character varying(32),
    dob date
);


--
-- Name: TABLE entity_employee; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE entity_employee IS ' This contains employee-specific extensions to person/entity. ';


--
-- Name: person; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE person (
    id integer NOT NULL,
    entity_id integer NOT NULL,
    salutation_id integer,
    first_name text NOT NULL,
    middle_name text,
    last_name text NOT NULL,
    created date DEFAULT ('now'::text)::date NOT NULL,
    CONSTRAINT person_first_name_check CHECK ((first_name ~ '[[:alnum:]_]'::text)),
    CONSTRAINT person_last_name_check CHECK ((last_name ~ '[[:alnum:]_]'::text))
);


--
-- Name: TABLE person; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE person IS ' Every person, must have an entity to derive a common or display name. The correct way to get class information on a person would be person.entity_id->entity_class_to_entity.entity_id. ';


--
-- Name: salutation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE salutation (
    id integer NOT NULL,
    salutation text NOT NULL
);


--
-- Name: employees; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW employees AS
    SELECT s.salutation, p.first_name, p.last_name, ee.entity_id, ee.startdate, ee.enddate, ee.role, ee.ssn, ee.sales, ee.manager_id, ee.employeenumber, ee.dob FROM ((person p JOIN entity_employee ee USING (entity_id)) LEFT JOIN salutation s ON ((p.salutation_id = s.id)));


--
-- Name: employee__list_managers(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION employee__list_managers(in_id integer) RETURNS SETOF employees
    LANGUAGE plpgsql
    AS $$
DECLARE
	emp employees%ROWTYPE;
BEGIN
	FOR emp IN 
		SELECT 
		    e.salutation,
		    e.first_name,
		    e.last_name,
		    ee.* 
		FROM entity_employee ee
		JOIN entity e on e.id = ee.entity_id
		WHERE ee.sales = 't'::bool AND ee.role='manager'
			AND ee.entity_id <> coalesce(in_id, -1)
		ORDER BY name
	LOOP
		RETURN NEXT emp;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION employee__list_managers(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION employee__list_managers(in_id integer) IS ' Returns a list of managers, that is employees with the ''manager'' role set.';


--
-- Name: employee__save(integer, date, date, date, text, text, boolean, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION employee__save(in_entity_id integer, in_start_date date, in_end_date date, in_dob date, in_role text, in_ssn text, in_sales boolean, in_manager_id integer, in_employee_number text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE out_id INT;
BEGIN
	UPDATE entity_employee 
	SET startdate = coalesce(in_start_date, now()::date),
		enddate = in_end_date,
		dob = in_dob,
		role = in_role,
		ssn = in_ssn,
		manager_id = in_manager_id,
		employeenumber = in_employee_number
	WHERE entity_id = in_entity_id;

	out_id = in_entity_id;

	IF NOT FOUND THEN
		INSERT INTO entity_employee 
			(startdate, enddate, dob, role, ssn, manager_id, 
				employeenumber, entity_id)
		VALUES
			(coalesce(in_start_date, now()::date), in_end_date, 
                                in_dob, in_role, in_ssn,
				in_manager_id, in_employee_number, 
                                in_entity_id);
		RETURN in_entity_id;
	END IF;
        RETURN out_id;
END;
$$;


--
-- Name: FUNCTION employee__save(in_entity_id integer, in_start_date date, in_end_date date, in_dob date, in_role text, in_ssn text, in_sales boolean, in_manager_id integer, in_employee_number text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION employee__save(in_entity_id integer, in_start_date date, in_end_date date, in_dob date, in_role text, in_ssn text, in_sales boolean, in_manager_id integer, in_employee_number text) IS ' Saves an employeerecord with the specified information.';


--
-- Name: employee__search(text, date, date, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION employee__search(in_employeenumber text, in_startdate_from date, in_startdate_to date, in_first_name text, in_middle_name text, in_last_name text, in_notes text) RETURNS SETOF employee_result
    LANGUAGE sql
    AS $_$
SELECT p.entity_id, p.id, s.salutation,
          p.first_name, p.middle_name, p.last_name,
          ee.startdate, ee.enddate, ee.role, ee.ssn, ee.sales, ee.manager_id,
          mp.first_name, mp.last_name, ee.employeenumber, ee.dob, e.country_id
     FROM person p
     JOIN entity e ON p.entity_id = e.id
     JOIN entity_employee ee on (ee.entity_id = p.entity_id)
LEFT JOIN salutation s on (p.salutation_id = s.id)
LEFT JOIN person mp ON ee.manager_id = p.entity_id
    WHERE ($7 is null or p.entity_id in (select ref_key from entity_note
                                          WHERE note ilike '%' || $7 || '%'))
          and ($1 is null or $1 = ee.employeenumber)
          and ($2 is null or $2 <= ee.startdate)
          and ($3 is null or $3 >= ee.startdate)
          and ($4 is null or p.first_name ilike '%' || $4 || '%')
          and ($5 is null or p.middle_name ilike '%' || $5 || '%')
          and ($6 is null or p.last_name ilike '%' || $6 || '%');
$_$;


--
-- Name: FUNCTION employee__search(in_employeenumber text, in_startdate_from date, in_startdate_to date, in_first_name text, in_middle_name text, in_last_name text, in_notes text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION employee__search(in_employeenumber text, in_startdate_from date, in_startdate_to date, in_first_name text, in_middle_name text, in_last_name text, in_notes text) IS ' Returns a list of employee_result records matching the search criteria.

employeenumber is an exact match.  
stardate_from and startdate_to specify the start dates for employee searches
All others are partial matches.

NULLs match all values.';


--
-- Name: employee_search; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW employee_search AS
    SELECT e.entity_id, e.startdate, e.enddate, e.role, e.ssn, e.sales, e.manager_id, e.employeenumber, e.dob, em.name AS manager, emn.note, en.name FROM ((((entity_employee e LEFT JOIN entity en ON ((e.entity_id = en.id))) LEFT JOIN entity_employee m ON ((e.manager_id = m.entity_id))) LEFT JOIN entity em ON ((em.id = m.entity_id))) LEFT JOIN entity_note emn ON ((emn.ref_key = em.id)));


--
-- Name: employee_search(date, date, character varying, text, date, date, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION employee_search(in_startdatefrom date, in_startdateto date, in_name character varying, in_notes text, in_enddateto date, in_enddatefrom date, in_sales boolean) RETURNS SETOF employee_search
    LANGUAGE plpgsql
    AS $$
DECLARE
	emp employee_search%ROWTYPE;
BEGIN
	FOR emp IN
		SELECT * FROM employee_search
		WHERE coalesce(startdate, 'infinity'::timestamp)
			>= coalesce(in_startdateto, '-infinity'::timestamp)
			AND coalesce(startdate, '-infinity'::timestamp) <=
				coalesce(in_startdatefrom, 
						'infinity'::timestamp)
			AND coalesce(enddate, '-infinity'::timestamp) <= 
				coalesce(in_enddateto, 'infinity'::timestamp)
			AND coalesce(enddate, 'infinity'::timestamp) >= 
				coalesce(in_enddatefrom, '-infinity'::timestamp)
			AND (name % in_name
			    OR note % in_notes)
			AND (sales = 't' OR coalesce(in_sales, 'f') = 'f')
	LOOP
		RETURN NEXT emp;
	END LOOP;
	return;
END;
$$;


--
-- Name: employee_set_location(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION employee_set_location(in_employee integer, in_location integer) RETURNS void
    LANGUAGE sql
    AS $_$

    INSERT INTO person_to_location (person_id,location_id) 
        VALUES ($1, $2);
    
$_$;


--
-- Name: entity__delete_bank_account(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION entity__delete_bank_account(in_entity_id integer, in_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN

UPDATE entity_credit_account SET bank_account = NULL
 WHERE entity_id = in_entity_id AND bank_account = in_id;

DELETE FROM entity_bank_account
 WHERE id = in_id AND entity_id = in_entity_id;

RETURN FOUND;

END;
$$;


--
-- Name: FUNCTION entity__delete_bank_account(in_entity_id integer, in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION entity__delete_bank_account(in_entity_id integer, in_id integer) IS ' Deletes the bank account identitied by in_id if it is attached to the entity
identified by entity_id.  Returns true if a record is deleted, false if not.';


--
-- Name: entity__get_by_cc(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION entity__get_by_cc(in_control_code text) RETURNS SETOF entity
    LANGUAGE sql
    AS $_$
SELECT * FROM entity WHERE control_code = $1 $_$;


--
-- Name: FUNCTION entity__get_by_cc(in_control_code text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION entity__get_by_cc(in_control_code text) IS ' Returns the entity row attached to the control code. ';


--
-- Name: entity__get_entity(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION entity__get_entity(in_entity_id integer) RETURNS SETOF entity
    LANGUAGE plpgsql
    AS $$

declare
    v_row entity;
BEGIN
    -- Removing the exception when not found handling.  Applications are
    -- perfectly capable of handling whether an entity was not found.  No need
    -- for a database-level exception here. Moreover such results may be useful
    -- --CT

    SELECT * INTO v_row FROM entity WHERE id = in_entity_id;
    return next v_row;
END;

$$;


--
-- Name: FUNCTION entity__get_entity(in_entity_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION entity__get_entity(in_entity_id integer) IS ' Returns a set of (only one) entity record with the entity id.';


--
-- Name: entity_class; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE entity_class (
    id integer NOT NULL,
    class text NOT NULL,
    country_id integer,
    active boolean DEFAULT true NOT NULL,
    CONSTRAINT entity_class_class_check CHECK ((class ~ '[[:alnum:]_]'::text))
);


--
-- Name: TABLE entity_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE entity_class IS ' Defines the class type such as vendor, customer, contact, employee ';


--
-- Name: COLUMN entity_class.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN entity_class.id IS ' The first 7 values are reserved and 
permanent.  Individuals who create new classes, however, should coordinate 
with others for ranges to use.';


--
-- Name: entity__list_classes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION entity__list_classes() RETURNS SETOF entity_class
    LANGUAGE plpgsql
    AS $$
DECLARE out_row entity_class;
BEGIN
	FOR out_row IN 
		SELECT * FROM entity_class
		WHERE active
		ORDER BY id
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION entity__list_classes(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION entity__list_classes() IS ' Returns a list of entity classes, ordered by assigned ids';


--
-- Name: entity__list_credit(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION entity__list_credit(in_entity_id integer, in_entity_class integer) RETURNS SETOF entity_credit_retrieve
    LANGUAGE plpgsql
    AS $$
DECLARE out_row entity_credit_retrieve;
BEGIN
	
	FOR out_row IN 
		SELECT  c.id, e.id, ec.entity_class, ec.discount, 
                        ec.discount_terms,
			ec.taxincluded, ec.creditlimit, ec.terms, 
			ec.meta_number, ec.description, ec.business_id, 
			ec.language_code, 
			ec.pricegroup_id, ec.curr, ec.startdate, 
			ec.enddate, ec.ar_ap_account_id, ec.cash_account_id, 
			ec.threshold, e.control_code, ec.id, ec.pay_to_name,
                        ec.taxform_id
		FROM company c
		JOIN entity e ON (c.entity_id = e.id)
		JOIN entity_credit_account ec ON (c.entity_id = ec.entity_id)
		WHERE e.id = in_entity_id
			AND ec.entity_class = 
				CASE WHEN in_entity_class = 3 THEN 2
				     WHEN in_entity_class IS NULL 
					THEN ec.entity_class
				ELSE in_entity_class END
	LOOP

		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION entity__list_credit(in_entity_id integer, in_entity_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION entity__list_credit(in_entity_id integer, in_entity_class integer) IS ' Returns a list of entity credit account entries for the entity and of the
entity class.';


--
-- Name: entity__save_bank_account(integer, text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION entity__save_bank_account(in_entity_id integer, in_bic text, in_iban text, in_bank_account_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE out_id int;
BEGIN
        UPDATE entity_bank_account
           SET bic = in_bic,
               iban = in_iban
         WHERE id = in_bank_account_id;

        IF FOUND THEN
                out_id = in_bank_account_id;
        ELSE
	  	INSERT INTO entity_bank_account(entity_id, bic, iban)
		VALUES(in_entity_id, in_bic, in_iban);
	        SELECT CURRVAL('entity_bank_account_id_seq') INTO out_id ;
	END IF;

	RETURN out_id;
END;
$$;


--
-- Name: FUNCTION entity__save_bank_account(in_entity_id integer, in_bic text, in_iban text, in_bank_account_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION entity__save_bank_account(in_entity_id integer, in_bic text, in_iban text, in_bank_account_id integer) IS 'Saves a bank account to the entity.';


--
-- Name: entity__save_notes(integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION entity__save_notes(in_entity_id integer, in_note text, in_subject text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE out_id int;
BEGIN
	-- TODO, change this to create vector too
	INSERT INTO entity_note (ref_key, note_class, entity_id, note, vector, subject)
	VALUES (in_entity_id, 1, in_entity_id, in_note, '', in_subject);

	SELECT currval('note_id_seq') INTO out_id;
	RETURN out_id;
END;
$$;


--
-- Name: FUNCTION entity__save_notes(in_entity_id integer, in_note text, in_subject text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION entity__save_notes(in_entity_id integer, in_note text, in_subject text) IS ' Saves an entity-level note.  Such a note is valid for all credit accounts 
attached to that entity.  Returns the id of the note.  ';


--
-- Name: entity_credit__get(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION entity_credit__get(in_id integer) RETURNS entity_credit_account
    LANGUAGE sql
    AS $_$
SELECT * FROM entity_credit_account WHERE id = $1;
$_$;


--
-- Name: FUNCTION entity_credit__get(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION entity_credit__get(in_id integer) IS ' Returns the entity credit account info.';


--
-- Name: entity_credit_get_id(integer, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION entity_credit_get_id(in_entity_id integer, in_entity_class integer, in_meta_number text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE out_var int;
BEGIN
	SELECT id INTO out_var FROM entity_credit_account
	WHERE entity_id = in_entity_id 
		AND in_entity_class = entity_class
		AND in_meta_number = meta_number;

	RETURN out_var;
END;
$$;


--
-- Name: FUNCTION entity_credit_get_id(in_entity_id integer, in_entity_class integer, in_meta_number text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION entity_credit_get_id(in_entity_id integer, in_entity_class integer, in_meta_number text) IS ' Returns an entity credit id, based on entity_id, entity_class, 
and meta_number.  This is the preferred way to locate an account if all three of 
these are known';


--
-- Name: entity_credit_get_id_by_meta_number(text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION entity_credit_get_id_by_meta_number(in_meta_number text, in_account_class integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE out_credit_id int;
BEGIN
	SELECT id INTO out_credit_id 
	FROM entity_credit_account 
	WHERE meta_number = in_meta_number 
		AND entity_class = in_account_class;

	RETURN out_credit_id;
END;
$$;


--
-- Name: FUNCTION entity_credit_get_id_by_meta_number(in_meta_number text, in_account_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION entity_credit_get_id_by_meta_number(in_meta_number text, in_account_class integer) IS ' Returns the credit id from the meta_number and entity_class.';


--
-- Name: entity_credit_save(integer, integer, integer, text, numeric, boolean, numeric, integer, integer, character varying, integer, character varying, integer, character, date, date, numeric, integer, integer, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION entity_credit_save(in_credit_id integer, in_entity_class integer, in_entity_id integer, in_description text, in_discount numeric, in_taxincluded boolean, in_creditlimit numeric, in_discount_terms integer, in_terms integer, in_meta_number character varying, in_business_id integer, in_language_code character varying, in_pricegroup_id integer, in_curr character, in_startdate date, in_enddate date, in_threshold numeric, in_ar_ap_account_id integer, in_cash_account_id integer, in_pay_to_name text, in_taxform_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
    
    DECLARE
        t_entity_class int;
        l_id int;
	t_meta_number text; 
	t_mn_default_key text;
    BEGIN
	-- TODO:  Move to mapping table.
            IF in_entity_class = 1 THEN
	       t_mn_default_key := 'vendornumber';
	    ELSIF in_entity_class = 2 THEN
	       t_mn_default_key := 'customernumber';
	    END IF;
	    IF in_meta_number IS NULL THEN
		t_meta_number := setting_increment(t_mn_default_key);
	    ELSE
		t_meta_number := in_meta_number;
	    END IF;
            update entity_credit_account SET
                discount = in_discount,
                taxincluded = in_taxincluded,
                creditlimit = in_creditlimit,
		description = in_description,
                terms = in_terms,
                ar_ap_account_id = in_ar_ap_account_id,
                cash_account_id = in_cash_account_id,
                meta_number = t_meta_number,
                business_id = in_business_id,
                language_code = in_language_code,
                pricegroup_id = in_pricegroup_id,
                curr = in_curr,
                startdate = in_startdate,
                enddate = in_enddate,
                threshold = in_threshold,
		discount_terms = in_discount_terms,
		pay_to_name = in_pay_to_name,
		taxform_id = in_taxform_id
            where id = in_credit_id;
        
         IF FOUND THEN
            RETURN in_credit_id;
         ELSE
            INSERT INTO entity_credit_account (
                entity_id,
                entity_class,
                discount, 
                description,
                taxincluded,
                creditlimit,
                terms,
                meta_number,
                business_id,
                language_code,
                pricegroup_id,
                curr,
                startdate,
                enddate,
                discount_terms,
                threshold,
		ar_ap_account_id,
                pay_to_name,
                taxform_id,
                cash_account_id

            )
            VALUES (
                in_entity_id,
                in_entity_class,
                in_discount, 
                in_description,
                in_taxincluded,
                in_creditlimit,
                in_terms,
                t_meta_number,
                in_business_id,
                in_language_code,
                in_pricegroup_id,
                in_curr,
                in_startdate,
                in_enddate,
                in_discount_terms,
                in_threshold,
                in_ar_ap_account_id,
                in_pay_to_name,
                in_taxform_id,
		in_cash_account_id
            );
            RETURN currval('entity_credit_account_id_seq');
       END IF;

    END;
    
$$;


--
-- Name: FUNCTION entity_credit_save(in_credit_id integer, in_entity_class integer, in_entity_id integer, in_description text, in_discount numeric, in_taxincluded boolean, in_creditlimit numeric, in_discount_terms integer, in_terms integer, in_meta_number character varying, in_business_id integer, in_language_code character varying, in_pricegroup_id integer, in_curr character, in_startdate date, in_enddate date, in_threshold numeric, in_ar_ap_account_id integer, in_cash_account_id integer, in_pay_to_name text, in_taxform_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION entity_credit_save(in_credit_id integer, in_entity_class integer, in_entity_id integer, in_description text, in_discount numeric, in_taxincluded boolean, in_creditlimit numeric, in_discount_terms integer, in_terms integer, in_meta_number character varying, in_business_id integer, in_language_code character varying, in_pricegroup_id integer, in_curr character, in_startdate date, in_enddate date, in_threshold numeric, in_ar_ap_account_id integer, in_cash_account_id integer, in_pay_to_name text, in_taxform_id integer) IS ' Saves an entity credit account.  Returns the id of the record saved.  ';


--
-- Name: contact_class; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE contact_class (
    id integer NOT NULL,
    class text NOT NULL,
    CONSTRAINT contact_class_class_check CHECK ((class ~ '[[:alnum:]_]'::text))
);


--
-- Name: TABLE contact_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE contact_class IS ' Stores type of contact information attached to companies and persons.
Please coordinate with others before adding new types.';


--
-- Name: entity_list_contact_class(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION entity_list_contact_class() RETURNS SETOF contact_class
    LANGUAGE plpgsql
    AS $$
DECLARE out_row RECORD;
BEGIN
	FOR out_row IN
		SELECT * FROM contact_class ORDER BY id
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION entity_list_contact_class(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION entity_list_contact_class() IS ' Returns a list of contact classes ordered by ID.';


--
-- Name: entity_save(integer, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION entity_save(in_entity_id integer, in_name text, in_entity_class integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$

    DECLARE
        e entity;
        e_id int;
        
    BEGIN
    
        select * into e from entity where id = in_entity_id;
        
        update 
            entity 
        SET
            name = in_name,
            entity_class = in_entity_class
        WHERE
            id = in_entity_id;
        IF NOT FOUND THEN
            -- do the insert magic.
            e_id = nextval('entity_id_seq');
            insert into entity (id, name, entity_class) values 
                (e_id,
                in_name,
                in_entity_class
                );
            return e_id;
        END IF;
        return in_entity_id;
            
    END;

$$;


--
-- Name: FUNCTION entity_save(in_entity_id integer, in_name text, in_entity_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION entity_save(in_entity_id integer, in_name text, in_entity_class integer) IS ' Currently unused.  Left in because it is believed it may be helpful.

This saves an entity, with the control code being the next available via the 
defaults table.';


--
-- Name: eoy_close_books(date, text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eoy_close_books(in_end_date date, in_reference text, in_description text, in_retention_acc_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF eoy_zero_accounts(in_end_date, in_reference, in_description, in_retention_acc_id) > 0 THEN
		PERFORM eoy_create_checkpoint(in_end_date);
		RETURN TRUE;
	ELSE
		RETURN FALSE;
	END IF;
END;
$$;


--
-- Name: FUNCTION eoy_close_books(in_end_date date, in_reference text, in_description text, in_retention_acc_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eoy_close_books(in_end_date date, in_reference text, in_description text, in_retention_acc_id integer) IS ' Zeroes accounts and then creates a checkpoint. in_end_date is the date when
the books are to be closed, in_reference and in_description become the 
reference and description of the gl transaction, and in_retention_acc_id is
the retained earnings account id.';


--
-- Name: eoy_create_checkpoint(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eoy_create_checkpoint(in_end_date date) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE ret_val int;
	approval_check int;
	cp_date        date;
BEGIN
	IF in_end_date > now()::date THEN
		RAISE EXCEPTION 'Invalid date:  Must be earlier than present';
	END IF;

	SELECT count(*) into approval_check
	FROM acc_trans ac
	JOIN (
		select id, approved, transdate FROM ar UNION
		SELECT id, approved, transdate FROM gl UNION
		SELECT id, approved, transdate FROM ap
	) gl ON (gl.id = ac.trans_id)
	WHERE (ac.approved IS NOT TRUE AND ac.transdate <= in_end_date) 
		OR (gl.approved IS NOT TRUE AND gl.transdate <= in_end_date);

	if approval_check > 0 THEN
		RAISE EXCEPTION 'Unapproved transactions in closed period';
	END IF;
	
	SELECT max(end_date) INTO cp_date FROM account_checkpoint WHERE
	end_date < in_end_date;

	INSERT INTO 
	account_checkpoint (end_date, account_id, amount, debits, credits)
    SELECT in_end_date, COALESCE(a.chart_id, cp.account_id),
	    COALESCE(SUM (a.amount),0) + coalesce(MAX (cp.amount), 0),
	    COALESCE(SUM (CASE WHEN (a.amount < 0) THEN a.amount ELSE 0 END), 0) +
	     COALESCE( MIN (cp.debits), 0),
	    COALESCE(SUM (CASE WHEN (a.amount > 0) THEN a.amount ELSE 0 END), 0) +
	     COALESCE( MAX (cp.credits), 0)
	FROM 
	(SELECT * FROM acc_trans WHERE transdate <= in_end_date AND
	 transdate > COALESCE(cp_date, '1200-01-01')) a
	FULL OUTER JOIN (
		select account_id, end_date, amount, debits, credits 
		from account_checkpoint
		WHERE end_date = cp_date
		) cp on (a.chart_id = cp.account_id)
	group by COALESCE(a.chart_id, cp.account_id);

	SELECT count(*) INTO ret_val FROM account_checkpoint 
	where end_date = in_end_date;

	return ret_val;
END;
$$;


--
-- Name: FUNCTION eoy_create_checkpoint(in_end_date date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eoy_create_checkpoint(in_end_date date) IS 'Creates checkpoints for each account at a specific date.  Books are considered
closed when they occur before the latest checkpoint timewise.  This means that
balances (and credit/debit amounts) can be calculated starting at a checkpoint
and moving forward (thus providing a mechanism for expunging old data while 
keeping balances correct at some future point).';


--
-- Name: eoy_earnings_accounts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eoy_earnings_accounts() RETURNS SETOF account
    LANGUAGE sql
    AS $$
    SELECT * 
      FROM account
     WHERE category = 'Q'
     ORDER BY accno;
$$;


--
-- Name: FUNCTION eoy_earnings_accounts(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eoy_earnings_accounts() IS ' Lists equity accounts for the retained earnings dropdown.';


--
-- Name: eoy_reopen_books(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eoy_reopen_books(in_end_date date) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
	PERFORM count(*) FROM account_checkpoint WHERE end_date = in_end_date;

	IF NOT FOUND THEN
		RETURN FALSE;
	END IF;

	DELETE FROM account_checkpoint WHERE end_date = in_end_date;

	PERFORM count(*) FROM yearend 
	WHERE transdate = in_end_date and reversed is not true;

	IF FOUND THEN
		INSERT INTO gl (reference, description, approved)
		SELECT 'Reversing ' || reference, 'Reversing ' || description,
			true
		FROM gl WHERE id = (select trans_id from yearend 
			where transdate = in_end_date and reversed is not true);

		INSERT INTO acc_trans (chart_id, amount, transdate, trans_id,
			approved)
		SELECT chart_id, amount * -1, currval('id'), true
		FROM acc_trans where trans_id = (select trans_id from yearend
			where transdate = in_end_date and reversed is not true);

		UPDATE yearend SET reversed = true where transdate = in_end_date
			and reversed is not true;
	END IF;

	DELETE FROM account_checkpoint WHERE end_date = in_end_date;
	RETURN TRUE;
END;
$$;


--
-- Name: FUNCTION eoy_reopen_books(in_end_date date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eoy_reopen_books(in_end_date date) IS ' Removes checkpoints and reverses yearend transactions on in_end_date';


--
-- Name: eoy_zero_accounts(date, text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION eoy_zero_accounts(in_end_date date, in_reference text, in_description text, in_retention_acc_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE ret_val int;
BEGIN
	INSERT INTO gl (transdate, reference, description, approved)
	VALUES (in_end_date, in_reference, in_description, true);

	INSERT INTO yearend (trans_id, transdate) values (currval('id'), in_end_date);
	INSERT INTO acc_trans (transdate, chart_id, trans_id, amount)
	SELECT in_end_date, a.chart_id, currval('id'),
		(sum(a.amount) + coalesce(max(cp.amount), 0)) * -1
	FROM acc_trans a
	LEFT JOIN (
		select account_id, end_date, amount from account_checkpoint
		WHERE end_date = (select max(end_date) from account_checkpoint
				where end_date < in_end_date)
		) cp on (a.chart_id = cp.account_id)
	JOIN account acc ON (acc.id = a.chart_id)
	WHERE a.transdate <= in_end_date 
		AND a.transdate > coalesce(cp.end_date, a.transdate - 1)
		AND acc.category IN ('I', 'E')
	GROUP BY a.chart_id;

	INSERT INTO acc_trans (transdate, trans_id, chart_id, amount)
	SELECT in_end_date, currval('id'), in_retention_acc_id, 
		coalesce(sum(amount) * -1, 0)
	FROM acc_trans WHERE trans_id = currval('id');


	SELECT count(*) INTO ret_val from acc_trans 
	where trans_id = currval('id');

	RETURN ret_val;
end;
$$;


--
-- Name: FUNCTION eoy_zero_accounts(in_end_date date, in_reference text, in_description text, in_retention_acc_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION eoy_zero_accounts(in_end_date date, in_reference text, in_description text, in_retention_acc_id integer) IS ' Posts a transaction which zeroes the income and expense accounts, moving the
net balance there into a retained earnings account identified by 
in_retention_acc_id.';


--
-- Name: file_base; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE file_base (
    content bytea NOT NULL,
    mime_type_id integer NOT NULL,
    file_name text NOT NULL,
    description text,
    uploaded_by integer NOT NULL,
    uploaded_at timestamp without time zone DEFAULT now() NOT NULL,
    id integer NOT NULL,
    ref_key integer NOT NULL,
    file_class integer NOT NULL
);


--
-- Name: TABLE file_base; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE file_base IS 'Abstract table, holds no records.  Inheriting table store actual file
attachment data. Can be queried however to retrieve lists of all files. ';


--
-- Name: COLUMN file_base.ref_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN file_base.ref_key IS 'This column inheriting tables is used to reference the database row for the
attachment.  Inheriting tables MUST set the foreign key here appropriately.

This can also be used to create classifications of other documents, such as by
source of automatic import (where the file is not yet attached) or
even standard,
long-lived documents.';


--
-- Name: file__attach_to_order(bytea, integer, text, text, integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION file__attach_to_order(in_content bytea, in_mime_type_id integer, in_file_name text, in_description text, in_id integer, in_ref_key integer, in_file_class integer) RETURNS file_base
    LANGUAGE plpgsql
    AS $_$
DECLARE retval file_base;
BEGIN
   IF in_id IS NOT NULL THEN
       IF in_content THEN
          RAISE EXCEPTION $e$Conflicting options file_id and content$e$;
       END IF;
       IF in_file_class = 1 THEN
           INSERT INTO file_tx_to_order        
                  (file_id, source_class, ref_key, dest_class, attached_by,
                  attached_at)
           VALUES (in_id, 1, in_ref_key, 2, person__get_my_entity_id(), now());
       ELSIF in_file_class = 2 THEN
           INSERT INTO file_order_to_order
                  (file_id, source_class, ref_key, dest_class, attached_by,
                  attached_at)
           VALUES (in_id, 2, in_ref_key, 2, person__get_my_entity_id(), now());
       ELSE 
           RAISE EXCEPTION $E$Invalid file class$E$;
       END IF;
       SELECT * INTO retval FROM file_base where id = in_id;
       RETURN retval;
   ELSE
       INSERT INTO file_order
                   (content, mime_type_id, file_name, description, ref_key,
                   file_class, uploaded_by, uploaded_at)
            VALUES (in_content, in_mime_type_id, in_file_name, in_description,
                   in_ref_key, in_file_class, person__get_my_entity_id(), 
                   now());
        SELECT * INTO retval FROM file_base 
         where id = currval('file_base_id_seq');

        RETURN retval;
    END IF;
END;
$_$;


--
-- Name: FUNCTION file__attach_to_order(in_content bytea, in_mime_type_id integer, in_file_name text, in_description text, in_id integer, in_ref_key integer, in_file_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION file__attach_to_order(in_content bytea, in_mime_type_id integer, in_file_name text, in_description text, in_id integer, in_ref_key integer, in_file_class integer) IS ' Attaches or links a file to an order.  in_content OR id can be set.
Setting both raises an exception.';


--
-- Name: file__attach_to_part(bytea, integer, text, text, integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION file__attach_to_part(in_content bytea, in_mime_type_id integer, in_file_name text, in_description text, in_id integer, in_ref_key integer, in_file_class integer) RETURNS file_base
    LANGUAGE plpgsql
    AS $_$
DECLARE retval file_base;
BEGIN
   IF in_id IS NOT NULL THEN
       IF in_content THEN
          RAISE EXCEPTION $e$Can't specify id and content in attachment$e$;--'
       END IF;
       RAISE EXCEPTION 'links not implemented';
       RETURN retval;
   ELSE
       INSERT INTO file_part
                   (content, mime_type_id, file_name, description, ref_key,
                   file_class, uploaded_by, uploaded_at)
            VALUES (in_content, in_mime_type_id, in_file_name, in_description,
                   in_ref_key, in_file_class, person__get_my_entity_id(), 
                   now());
        SELECT * INTO retval FROM file_base 
         where id = currval('file_base_id_seq');

        RETURN retval;
    END IF;
END;
$_$;


--
-- Name: FUNCTION file__attach_to_part(in_content bytea, in_mime_type_id integer, in_file_name text, in_description text, in_id integer, in_ref_key integer, in_file_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION file__attach_to_part(in_content bytea, in_mime_type_id integer, in_file_name text, in_description text, in_id integer, in_ref_key integer, in_file_class integer) IS ' Attaches or links a file to a good or service.  in_content OR id can be set.
Setting both raises an exception.

Note that currently links (setting id) is NOT supported because we dont have a
use case of linking files to parts';


--
-- Name: file__attach_to_tx(bytea, integer, text, text, integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION file__attach_to_tx(in_content bytea, in_mime_type_id integer, in_file_name text, in_description text, in_id integer, in_ref_key integer, in_file_class integer) RETURNS file_base
    LANGUAGE plpgsql
    AS $_$
DECLARE retval file_base;
BEGIN
   IF in_id IS NOT NULL THEN
       IF in_content THEN
          RAISE EXCEPTION $e$Can't specify id and content in attachment$e$;--'
       END IF;
       INSERT INTO file_order_to_tx        
              (file_id, source_class, ref_key, dest_class, attached_by,
              attached_at)
       VALUES (in_id, 2, in_ref_key, 1, person__get_my_entity_id(), now());

       SELECT * INTO retval FROM file_base where id = in_id;
       RETURN retval;
   ELSE
       INSERT INTO file_transaction 
                   (content, mime_type_id, file_name, description, ref_key,
                   file_class, uploaded_by, uploaded_at)
            VALUES (in_content, in_mime_type_id, in_file_name, in_description,
                   in_ref_key, in_file_class, person__get_my_entity_id(), 
                   now());
        SELECT * INTO retval FROM file_base 
         where id = currval('file_base_id_seq');

        RETURN retval;
    END IF;
END;
$_$;


--
-- Name: FUNCTION file__attach_to_tx(in_content bytea, in_mime_type_id integer, in_file_name text, in_description text, in_id integer, in_ref_key integer, in_file_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION file__attach_to_tx(in_content bytea, in_mime_type_id integer, in_file_name text, in_description text, in_id integer, in_ref_key integer, in_file_class integer) IS ' Attaches or links a file to a transaction.  in_content OR id can be set.
Setting both raises an exception.';


--
-- Name: file__get(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION file__get(in_id integer, in_file_class integer) RETURNS file_base
    LANGUAGE sql
    AS $_$
SELECT * FROM file_base where id = $1 and file_class = $2;
$_$;


--
-- Name: FUNCTION file__get(in_id integer, in_file_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION file__get(in_id integer, in_file_class integer) IS ' Retrieves the file information specified including content.';


--
-- Name: mime_type; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE mime_type (
    id integer NOT NULL,
    mime_type text NOT NULL
);


--
-- Name: TABLE mime_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE mime_type IS ' This is a lookup table for storing MIME types.';


--
-- Name: file__get_mime_type(integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION file__get_mime_type(in_mime_type_id integer, in_mime_type_text text) RETURNS mime_type
    LANGUAGE sql
    AS $_$
select * from mime_type 
 where ($1 IS NULL OR id = $1) AND ($2 IS NULL OR mime_type = $2);
$_$;


--
-- Name: FUNCTION file__get_mime_type(in_mime_type_id integer, in_mime_type_text text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION file__get_mime_type(in_mime_type_id integer, in_mime_type_text text) IS 'Retrieves mime type information associated with a file object.';


--
-- Name: file__list_by(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION file__list_by(in_ref_key integer, in_file_class integer) RETURNS SETOF file_list_item
    LANGUAGE sql
    AS $_$

SELECT m.mime_type, f.file_name, f.description, f.uploaded_by, e.name, 
       f.uploaded_at, f.id, f.ref_key, f.file_class, 
       case when m.mime_type = 'text/x-uri' THEN f.content ELSE NULL END
  FROM mime_type m
  JOIN file_base f ON f.mime_type_id = m.id
  JOIN entity e ON f.uploaded_by = e.id
 WHERE f.ref_key = $1 and f.file_class = $2;

$_$;


--
-- Name: FUNCTION file__list_by(in_ref_key integer, in_file_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION file__list_by(in_ref_key integer, in_file_class integer) IS ' Returns a list of files attached to a database object.  No content is 
retrieved.';


--
-- Name: id; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: id; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('id', 2, true);


--
-- Name: ap; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE ap (
    id integer DEFAULT nextval('id'::regclass) NOT NULL,
    invnumber text,
    transdate date DEFAULT ('now'::text)::date,
    entity_id integer,
    taxincluded boolean DEFAULT false,
    amount numeric,
    netamount numeric,
    paid numeric,
    datepaid date,
    duedate date,
    invoice boolean DEFAULT false,
    ordnumber text,
    curr character(3),
    notes text,
    person_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer DEFAULT 0,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    shippingpoint text,
    on_hold boolean DEFAULT false,
    approved boolean DEFAULT true,
    reverse boolean DEFAULT false,
    terms smallint DEFAULT 0,
    description text,
    force_closed boolean,
    entity_credit_account integer NOT NULL,
    CONSTRAINT ap_check CHECK ((((amount IS NULL) AND (curr IS NULL)) OR ((amount IS NOT NULL) AND (curr IS NOT NULL))))
);


--
-- Name: TABLE ap; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE ap IS ' Summary/header information for AP transactions and vendor invoices.
Note that some constraints here are hard to enforce because we haven not gotten 
to rewriting the relevant code here.
HV TODO drop entity_id
';


--
-- Name: COLUMN ap.invnumber; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.invnumber IS ' Text identifier for the invoice.  Must be unique.';


--
-- Name: COLUMN ap.amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.amount IS ' This stores the total amount (including taxes) for the transaction.';


--
-- Name: COLUMN ap.netamount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.netamount IS ' Total amount excluding taxes for the transaction.';


--
-- Name: COLUMN ap.invoice; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.invoice IS ' True if the transaction tracks goods/services purchase using the invoice
table.  False otherwise.';


--
-- Name: COLUMN ap.ordnumber; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.ordnumber IS ' Order Number';


--
-- Name: COLUMN ap.curr; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.curr IS ' 3 letters to identify the currency.';


--
-- Name: COLUMN ap.notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.notes IS 'These notes are displayed on the invoice when printed or emailed';


--
-- Name: COLUMN ap.person_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.person_id IS 'Person who created the transaction';


--
-- Name: COLUMN ap.quonumber; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.quonumber IS 'Quotation Number';


--
-- Name: COLUMN ap.intnotes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.intnotes IS 'These notes are not displayed when the invoice is printed or emailed and
may be updated without reposting hte invocie.';


--
-- Name: COLUMN ap.ponumber; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.ponumber IS 'Purchase Order Number';


--
-- Name: COLUMN ap.approved; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.approved IS 'Only show in financial reports if true.';


--
-- Name: COLUMN ap.reverse; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.reverse IS 'If true numbers are displayed after multiplying by -1';


--
-- Name: COLUMN ap.force_closed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.force_closed IS ' Not exposed to the UI, but can be set to prevent an invoice from showing up
for payment or in outstanding reports.';


--
-- Name: COLUMN ap.entity_credit_account; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ap.entity_credit_account IS ' reference for the vendor account used.';


--
-- Name: ar; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE ar (
    id integer DEFAULT nextval('id'::regclass) NOT NULL,
    invnumber text,
    transdate date DEFAULT ('now'::text)::date,
    entity_id integer,
    taxincluded boolean,
    amount numeric,
    netamount numeric,
    paid numeric,
    datepaid date,
    duedate date,
    invoice boolean DEFAULT false,
    shippingpoint text,
    terms smallint DEFAULT 0,
    notes text,
    curr character(3),
    ordnumber text,
    person_id integer,
    till character varying(20),
    quonumber text,
    intnotes text,
    department_id integer DEFAULT 0,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    on_hold boolean DEFAULT false,
    reverse boolean DEFAULT false,
    approved boolean DEFAULT true,
    entity_credit_account integer NOT NULL,
    force_closed boolean,
    description text,
    CONSTRAINT ar_check CHECK ((((amount IS NULL) AND (curr IS NULL)) OR ((amount IS NOT NULL) AND (curr IS NOT NULL))))
);


--
-- Name: TABLE ar; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE ar IS ' Summary/header information for AR transactions and sales invoices.
Note that some constraints here are hard to enforce because we haven not gotten 
to rewriting the relevant code here.
HV TODO drop entity_id
';


--
-- Name: COLUMN ar.invnumber; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.invnumber IS ' Text identifier for the invoice.  Must be unique.';


--
-- Name: COLUMN ar.amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.amount IS ' This stores the total amount (including taxes) for the transaction.';


--
-- Name: COLUMN ar.netamount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.netamount IS ' Total amount excluding taxes for the transaction.';


--
-- Name: COLUMN ar.invoice; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.invoice IS ' True if the transaction tracks goods/services purchase using the invoice
table.  False otherwise.';


--
-- Name: COLUMN ar.notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.notes IS 'These notes are displayed on the invoice when printed or emailed';


--
-- Name: COLUMN ar.curr; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.curr IS ' 3 letters to identify the currency.';


--
-- Name: COLUMN ar.ordnumber; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.ordnumber IS ' Order Number';


--
-- Name: COLUMN ar.person_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.person_id IS 'Person who created the transaction';


--
-- Name: COLUMN ar.quonumber; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.quonumber IS 'Quotation Number';


--
-- Name: COLUMN ar.intnotes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.intnotes IS 'These notes are not displayed when the invoice is printed or emailed and
may be updated without reposting hte invocie.';


--
-- Name: COLUMN ar.ponumber; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.ponumber IS 'Purchase Order Number';


--
-- Name: COLUMN ar.reverse; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.reverse IS 'If true numbers are displayed after multiplying by -1';


--
-- Name: COLUMN ar.approved; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.approved IS 'Only show in financial reports if true.';


--
-- Name: COLUMN ar.entity_credit_account; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.entity_credit_account IS ' reference for the customer account used.';


--
-- Name: COLUMN ar.force_closed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN ar.force_closed IS ' Not exposed to the UI, but can be set to prevent an invoice from showing up
for payment or in outstanding reports.';


--
-- Name: file_secondary_attachment; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE file_secondary_attachment (
    file_id integer NOT NULL,
    source_class integer NOT NULL,
    ref_key integer NOT NULL,
    dest_class integer NOT NULL,
    attached_by integer NOT NULL,
    attached_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE file_secondary_attachment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE file_secondary_attachment IS 'Another abstract table.  This one will use rewrite rules to make inserts safe
because of the difficulty in managing inserts otherwise. Inheriting tables 
provide secondary links between the file and other database objects.

Due to the nature of database inheritance and unique constraints
in PostgreSQL, this must be partitioned in a star format.';


--
-- Name: oe; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE oe (
    id integer NOT NULL,
    ordnumber text,
    transdate date DEFAULT ('now'::text)::date,
    entity_id integer,
    amount numeric,
    netamount numeric,
    reqdate date,
    taxincluded boolean,
    shippingpoint text,
    notes text,
    curr character(3),
    person_id integer,
    closed boolean DEFAULT false,
    quotation boolean DEFAULT false,
    quonumber text,
    intnotes text,
    department_id integer DEFAULT 0,
    shipvia text,
    language_code character varying(6),
    ponumber text,
    terms smallint DEFAULT 0,
    entity_credit_account integer NOT NULL,
    oe_class_id integer NOT NULL
);


--
-- Name: TABLE oe; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE oe IS ' Header information for:
* Sales orders
* Purchase Orders
* Quotations
* Requests for Quotation
';


--
-- Name: oe_class; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE oe_class (
    id smallint,
    oe_class text NOT NULL,
    CONSTRAINT oe_class_id_check CHECK ((id = ANY (ARRAY[1, 2, 3, 4])))
);


--
-- Name: TABLE oe_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE oe_class IS ' Hardwired classifications for orders and quotations. 
Coordinate before adding.';


--
-- Name: file_order_links; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW file_order_links AS
    SELECT sl.file_id, sl.ref_key, oe.ordnumber AS reference, oc.oe_class, sl.dest_class, sl.source_class, sl.ref_key AS dest_ref FROM ((file_secondary_attachment sl JOIN oe ON ((sl.ref_key = oe.id))) JOIN oe_class oc ON ((oe.oe_class_id = oc.id))) WHERE (sl.source_class = 2);


--
-- Name: gl; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE gl (
    id integer DEFAULT nextval('id'::regclass) NOT NULL,
    reference text,
    description text,
    transdate date DEFAULT ('now'::text)::date,
    person_id integer,
    notes text,
    approved boolean DEFAULT true,
    department_id integer DEFAULT 0
);


--
-- Name: TABLE gl; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE gl IS ' This table holds summary information for entries in the general journal.
Does not hold summary information in 1.3 for AR or AP entries.';


--
-- Name: COLUMN gl.person_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN gl.person_id IS ' the person_id of the employee who created
the entry.';


--
-- Name: file_tx_links; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW file_tx_links AS
    SELECT sl.file_id, sl.ref_key, gl.reference, gl.type, sl.dest_class, sl.source_class, sl.ref_key AS dest_ref FROM (file_secondary_attachment sl JOIN ((SELECT gl.id, gl.reference, 'gl'::text AS type FROM gl UNION SELECT ar.id, ar.invnumber, CASE WHEN ar.invoice THEN 'is'::text ELSE 'ar'::text END AS type FROM ar) UNION SELECT ap.id, ap.invnumber, CASE WHEN ap.invoice THEN 'ir'::text ELSE 'ap'::text END AS type FROM ap) gl ON (((sl.ref_key = gl.id) AND (sl.source_class = 1))));


--
-- Name: file_links; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW file_links AS
    SELECT file_tx_links.file_id, file_tx_links.ref_key, file_tx_links.reference, file_tx_links.type, file_tx_links.dest_class, file_tx_links.source_class, file_tx_links.dest_ref FROM file_tx_links UNION SELECT file_order_links.file_id, file_order_links.ref_key, file_order_links.reference, file_order_links.oe_class AS type, file_order_links.dest_class, file_order_links.source_class, file_order_links.dest_ref FROM file_order_links;


--
-- Name: file__list_links(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION file__list_links(in_ref_key integer, in_file_class integer) RETURNS SETOF file_links
    LANGUAGE sql
    AS $_$ select * from file_links where ref_key = $1 and dest_class = $2;
$_$;


--
-- Name: FUNCTION file__list_links(in_ref_key integer, in_file_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION file__list_links(in_ref_key integer, in_file_class integer) IS ' This function retrieves a list of file attachments on a specified object.';


--
-- Name: file_links_vrebuild(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION file_links_vrebuild() RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE 
   viewline file_view_catalog%rowtype;
   stmt text;
BEGIN
   stmt := '';
   FOR viewline IN
       select * from file_view_catalog
   LOOP
       IF stmt = '' THEN
           stmt := 'SELECT * FROM ' || quote_ident(viewline.view_name) || '
';
       ELSE
           stmt := stmt || ' UNION
SELECT * FROM '|| quote_ident(viewline.view_name) || '
';
       END IF; 
   END LOOP;
   EXECUTE 'CREATE OR REPLACE VIEW file_links AS
' || stmt;
   RETURN TRUE;
END;
$$;


--
-- Name: form_check(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION form_check(in_session_id integer, in_form_id integer) RETURNS boolean
    LANGUAGE sql SECURITY DEFINER
    AS $_$
SELECT count(*) = 1 
  FROM open_forms f
  JOIN "session" s USING (session_id)
  JOIN users u ON (s.users_id = u.id)
 WHERE f.session_id = $1 and f.id = $2 and u.username = SESSION_USER;
$_$;


--
-- Name: FUNCTION form_check(in_session_id integer, in_form_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION form_check(in_session_id integer, in_form_id integer) IS ' This checks to see if an open form (record in open_forms) exists with 
the form_id and session_id provided.  Returns true if exists, false if not.';


--
-- Name: form_close(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION form_close(in_session_id integer, in_form_id integer) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE form_test bool;
BEGIN
	form_test := form_check(in_session_id, in_form_id);

	IF form_test is true THEN 
		DELETE FROM open_forms 
		WHERE session_id = in_session_id AND id = in_form_id;

		RETURN TRUE;

	ELSE RETURN FALSE;
	END IF;
END;
$$;


--
-- Name: FUNCTION form_close(in_session_id integer, in_form_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION form_close(in_session_id integer, in_form_id integer) IS ' Closes out the form by deleting it from the open_forms table.

Returns true if found, false if not.
';


--
-- Name: form_open(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION form_open(in_session_id integer) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE usertest bool;
BEGIN
        SELECT count(*) = 1 INTO usertest FROM session 
         WHERE session_id = in_session_id 
               AND users_id IN (select id from users 
                                WHERE username = SESSION_USER);

        IF usertest is not true THEN
            RAISE EXCEPTION 'Invalid session';
        END IF;
      
	INSERT INTO open_forms (session_id) VALUES (in_session_id);
	RETURN currval('open_forms_id_seq');
END;
$$;


--
-- Name: FUNCTION form_open(in_session_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION form_open(in_session_id integer) IS ' This opens a form, and returns the id of the form opened.';


--
-- Name: get_fractional_month(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION get_fractional_month(in_date_first date, in_date_second date) RETURNS numeric
    LANGUAGE sql
    AS $_$
SELECT CASE WHEN is_same_month($1, $2)
            THEN ($2 - $1)::numeric
                 / days_in_month($1)
            ELSE (get_fractional_month(
                   $1, (date_trunc('MONTH', $1) 
                       + '1 month - 1 second'::interval)::date)
                 + get_fractional_month(date_trunc('MONTH', $2)::date, $2)
                 + (extract ('YEAR' from $2) - extract ('YEAR' from $1) * 12)
                 + extract ('MONTH' from $1) - extract ('MONTH' from $2) 
                 - 1)::numeric
            END;
$_$;


--
-- Name: FUNCTION get_fractional_month(in_date_first date, in_date_second date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION get_fractional_month(in_date_first date, in_date_second date) IS ' Returns the number of months between two dates in numeric form.';


--
-- Name: get_fractional_year(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION get_fractional_year(in_date_from date, in_date_to date) RETURNS numeric
    LANGUAGE sql
    AS $_$
   select ($2 - $1
            - leap_days(next_leap_year_calc($1, false), 
                       next_leap_year_calc($2, true)))
            /365::numeric;
$_$;


--
-- Name: FUNCTION get_fractional_year(in_date_from date, in_date_to date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION get_fractional_year(in_date_from date, in_date_to date) IS ' Returns the decimal representation of the fractional year.';


--
-- Name: account_link_description; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE account_link_description (
    description text NOT NULL,
    summary boolean NOT NULL,
    custom boolean NOT NULL
);


--
-- Name: TABLE account_link_description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE account_link_description IS ' This is a lookup table which provide basic information as to categories and
dropdowns of accounts.  In general summary accounts cannot belong to more than 
one category (an AR summary account cannot appear in other dropdowns for 
example).  Custom fields are not overwritten when the account is edited from
the front-end.';


--
-- Name: get_link_descriptions(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION get_link_descriptions() RETURNS SETOF account_link_description
    LANGUAGE sql
    AS $$
    SELECT * FROM account_link_description;
$$;


--
-- Name: FUNCTION get_link_descriptions(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION get_link_descriptions() IS ' Gets a set of all valid account_link descriptions.';


--
-- Name: gl_audit_trail_append(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION gl_audit_trail_append() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
   t_reference text;
   t_row RECORD;
BEGIN

IF TG_OP = 'INSERT' then
   t_row := NEW;
ELSE
   t_row := OLD;
END IF;

IF TG_RELNAME IN ('ar', 'ap') THEN
    t_reference := t_row.invnumber;
ELSE 
    t_reference := t_row.reference;
END IF;

INSERT INTO audittrail (trans_id,tablename,reference, action, person_id)
values (t_row.id,TG_RELNAME,t_reference, TG_OP, person__get_my_entity_id());

return null; -- AFTER TRIGGER ONLY, SAFE
END;
$$;


--
-- Name: FUNCTION gl_audit_trail_append(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION gl_audit_trail_append() IS ' This provides centralized support for insertions into audittrail.
';


--
-- Name: invoice__get_by_vendor_number(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION invoice__get_by_vendor_number(in_meta_nunber text, in_invoice_number text) RETURNS ap
    LANGUAGE plpgsql
    AS $$
DECLARE retval ap;
BEGIN
	SELECT * INTO retval FROM ap WHERE entity_credit_id = 
		(select id from entity_credit_account where entity_class = 1
		AND meta_number = in_meta_number)
		AND invnumber = in_invoice_number;
	RETURN retval;
END;
$$;


--
-- Name: is_leapyear(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION is_leapyear(in_date date) RETURNS boolean
    LANGUAGE sql
    AS $_$
    select extract('day' FROM (
                           (extract('year' FROM $1)::text 
                           || '-02-28')::date + '1 day'::interval)::date) 
           = 29;
$_$;


--
-- Name: FUNCTION is_leapyear(in_date date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION is_leapyear(in_date date) IS ' Returns true if date is in a leapyear.  False if not.  Uses the built-in 
PostgreSQL date handling, and no direct detection is done in our code.';


--
-- Name: is_same_month(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION is_same_month(in_date1 date, in_date2 date) RETURNS boolean
    LANGUAGE sql
    AS $_$
SELECT is_same_year($1, $2) 
       and extract ('MONTH' from $1) = extract ('MONTH' from $2);
$_$;


--
-- Name: FUNCTION is_same_month(in_date1 date, in_date2 date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION is_same_month(in_date1 date, in_date2 date) IS ' Returns true if the two dates are in the same month and year. False 
otherwise.';


--
-- Name: is_same_year(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION is_same_year(in_date1 date, in_date2 date) RETURNS boolean
    LANGUAGE sql
    AS $_$
SELECT  extract ('YEAR' from $1) = extract ('YEAR' from $2);
$_$;


--
-- Name: FUNCTION is_same_year(in_date1 date, in_date2 date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION is_same_year(in_date1 date, in_date2 date) IS ' Returns true if the two dates are in the same year, false otherwise.';


--
-- Name: je_get_default_lines(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION je_get_default_lines() RETURNS character varying
    LANGUAGE sql
    AS $$
SELECT value FROM menu_attribute where node_id = 74 and attribute = 'rowcount';
$$;


--
-- Name: je_set_default_lines(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION je_set_default_lines(in_rowcount integer) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
BEGIN
    UPDATE menu_attribute set value = $1 
     where node_id = 74 and attribute='rowcount';

    IF NOT FOUND THEN
         INSERT INTO menu_attribute (node_id, attribute, value)
              values (74, 'rowcount', $1);
    END IF;
    RETURN $1; 
END;
$_$;


--
-- Name: lastcost(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION lastcost(integer) RETURNS double precision
    LANGUAGE plpgsql
    AS $_$

DECLARE

v_cost float;
v_parts_id alias for $1;

BEGIN

  SELECT INTO v_cost sellprice FROM invoice i
  JOIN ap a ON (a.id = i.trans_id)
  WHERE i.parts_id = v_parts_id
  ORDER BY a.transdate desc, a.id desc
  LIMIT 1;

  IF v_cost IS NULL THEN
    v_cost := 0;
  END IF;

RETURN v_cost;
END;
$_$;


--
-- Name: leap_days(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION leap_days(in_year_from integer, in_year_to integer) RETURNS integer
    LANGUAGE sql
    AS $_$
   SELECT count(*)::int
   FROM generate_series($1, $2)
   WHERE is_leapyear((generate_series::text || '-01-01')::date);
$_$;


--
-- Name: FUNCTION leap_days(in_year_from integer, in_year_to integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION leap_days(in_year_from integer, in_year_to integer) IS 'Returns the number of leap years between the two year inputs, inclusive.';


--
-- Name: country_tax_form; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE country_tax_form (
    country_id integer NOT NULL,
    form_name text NOT NULL,
    id integer NOT NULL,
    default_reportable boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE country_tax_form; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE country_tax_form IS ' This table was designed for holding information relating to reportable
sales or purchases, such as IRS 1099 forms and international equivalents.';


--
-- Name: list_taxforms(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION list_taxforms(in_entity_id integer) RETURNS SETOF country_tax_form
    LANGUAGE plpgsql
    AS $$
DECLARE t_country_tax_form country_tax_form;
BEGIN

	FOR t_country_tax_form IN 

		      SELECT * 
		            FROM country_tax_form where country_id in(SELECT country_id from entity where id=in_entity_id)
        LOOP

	RETURN NEXT t_country_tax_form;
	
	END LOOP;

END;
$$;


--
-- Name: FUNCTION list_taxforms(in_entity_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION list_taxforms(in_entity_id integer) IS 'Returns a list of tax forms for the entity''s country.';


--
-- Name: location; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE location (
    id integer NOT NULL,
    line_one text NOT NULL,
    line_two text,
    line_three text,
    city text NOT NULL,
    state text,
    country_id integer NOT NULL,
    mail_code text NOT NULL,
    created date DEFAULT now() NOT NULL,
    inactive_date timestamp without time zone,
    active boolean DEFAULT true NOT NULL,
    CONSTRAINT location_city_check CHECK ((city ~ '[[:alnum:]_]'::text)),
    CONSTRAINT location_line_one_check CHECK ((line_one ~ '[[:alnum:]_]'::text)),
    CONSTRAINT location_mail_code_check CHECK ((mail_code ~ '[[:alnum:]_]'::text)),
    CONSTRAINT location_state_check CHECK ((state ~ '[[:alnum:]_]'::text))
);


--
-- Name: TABLE location; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE location IS '
This table stores addresses, such as shipto and bill to addresses.
';


--
-- Name: location__get(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION location__get(in_id integer) RETURNS location
    LANGUAGE plpgsql
    AS $$
DECLARE
	out_location location%ROWTYPE;
BEGIN
	SELECT * INTO out_location FROM location WHERE id = in_id;
	RETURN out_location;
END;
$$;


--
-- Name: FUNCTION location__get(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION location__get(in_id integer) IS ' Returns the location specified by in_id.';


--
-- Name: location_delete(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION location_delete(in_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
	DELETE FROM location WHERE id = in_id;
END;
$$;


--
-- Name: FUNCTION location_delete(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION location_delete(in_id integer) IS ' DELETES the location specified by in_id.  Does not return a value.';


--
-- Name: location_list_all(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION location_list_all() RETURNS SETOF location
    LANGUAGE plpgsql
    AS $$
DECLARE 
	out_location location%ROWTYPE;
BEGIN
	FOR out_location IN
		SELECT * FROM location 
		ORDER BY country, state, city
	LOOP
		RETURN NEXT out_location;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION location_list_all(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION location_list_all() IS ' Returns all locations, ordered by country, state, and city. ';


--
-- Name: location_class; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE location_class (
    id integer NOT NULL,
    class text NOT NULL,
    authoritative boolean NOT NULL,
    CONSTRAINT location_class_class_check CHECK ((class ~ '[[:alnum:]_]'::text))
);


--
-- Name: TABLE location_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE location_class IS '
Individuals seeking to add new location classes should coordinate with others.
';


--
-- Name: location_list_class(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION location_list_class() RETURNS SETOF location_class
    LANGUAGE plpgsql
    AS $$
DECLARE out_row RECORD;
BEGIN
	FOR out_row IN
		SELECT * FROM location_class ORDER BY id
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION location_list_class(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION location_list_class() IS ' Lists location classes, by default in order entered.';


--
-- Name: country; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE country (
    id integer NOT NULL,
    name text NOT NULL,
    short_name text NOT NULL,
    itu text,
    CONSTRAINT country_name_check CHECK ((name ~ '[[:alnum:]_]'::text)),
    CONSTRAINT country_short_name_check CHECK ((short_name ~ '[[:alnum:]_]'::text))
);


--
-- Name: COLUMN country.itu; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN country.itu IS ' The ITU Telecommunication Standardization Sector code for calling internationally. For example, the US is 1, Great Britain is 44 ';


--
-- Name: location_list_country(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION location_list_country() RETURNS SETOF country
    LANGUAGE plpgsql
    AS $$
DECLARE out_row RECORD;
BEGIN
	FOR out_row IN
		SELECT * FROM country ORDER BY name
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION location_list_country(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION location_list_country() IS ' Lists countries, by default in alphabetical order.';


--
-- Name: location_save(integer, text, text, text, text, text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION location_save(in_location_id integer, in_address1 text, in_address2 text, in_address3 text, in_city text, in_state text, in_zipcode text, in_country integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	location_id integer;
	location_row RECORD;
BEGIN
	
	IF in_location_id IS NULL THEN
	    SELECT id INTO location_id FROM location
	    WHERE line_one = in_address1 AND line_two = in_address2
	          AND line_three = in_address3 AND in_city = city 
	          AND in_state = state AND in_zipcode = mail_code
	          AND in_country = country_id 
	    LIMIT 1;

	    IF NOT FOUND THEN
	    -- Straight insert.
	    location_id = nextval('location_id_seq');
	    INSERT INTO location (
	        id, 
	        line_one, 
	        line_two,
	        line_three,
	        city,
	        state,
	        mail_code,
	        country_id)
	    VALUES (
	        location_id,
	        in_address1,
	        in_address2,
	        in_address3,
	        in_city,
	        in_state,
	        in_zipcode,
	        in_country
	        );
	    END IF;
	    return location_id;
	ELSE
	    RAISE NOTICE 'Overwriting location id %', in_location_id;
	    -- Test it.
	    SELECT * INTO location_row FROM location WHERE id = in_location_id;
	    IF NOT FOUND THEN
	        -- Tricky users are lying to us.
	        RAISE EXCEPTION 'location_save called with nonexistant location ID %', in_location_id;
	    ELSE
	        -- Okay, we're good.
	        
	        UPDATE location SET
	            line_one = in_address1,
	            line_two = in_address2,
	            line_three = in_address3,
	            city = in_city, 
	            state = in_state,
	            mail_code = in_zipcode,
	            country_id = in_country
	        WHERE id = in_location_id;
	        return in_location_id;
	    END IF;
	END IF;
END;
$$;


--
-- Name: FUNCTION location_save(in_location_id integer, in_address1 text, in_address2 text, in_address3 text, in_city text, in_state text, in_zipcode text, in_country integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION location_save(in_location_id integer, in_address1 text, in_address2 text, in_address3 text, in_city text, in_state text, in_zipcode text, in_country integer) IS ' Note that this does NOT override the data in the database unless in_location_id is specified.
Instead we search for locations matching the desired specifications and if none 
are found, we insert one.  Either way, the return value of the location can be
used for mapping to other things.  This is necessary because locations are 
only loosly coupled with entities, etc.';


--
-- Name: location_search(character varying, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION location_search(in_address1 character varying, in_address2 character varying, in_city character varying, in_state character varying, in_zipcode character varying, in_country character varying) RETURNS SETOF location
    LANGUAGE plpgsql
    AS $$
DECLARE
	out_location location%ROWTYPE;
BEGIN
	FOR out_location IN
		SELECT * FROM location 
		WHERE address1 ilike '%' || in_address1 || '%'
			AND address2 ilike '%' || in_address2 || '%'
			AND in_city ilike '%' || in_city || '%'
			AND in_state ilike '%' || in_state || '%'
			AND in_zipcode ilike '%' || in_zipcode || '%'
			AND in_country ilike '%' || in_country || '%'
	LOOP
		RETURN NEXT out_location;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION location_search(in_address1 character varying, in_address2 character varying, in_city character varying, in_state character varying, in_zipcode character varying, in_country character varying); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION location_search(in_address1 character varying, in_address2 character varying, in_city character varying, in_state character varying, in_zipcode character varying, in_country character varying) IS ' Returns matching locations.  All matches may be partial.';


--
-- Name: lock_record(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION lock_record(in_id integer, in_session_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
declare
   locked int;
begin
   SELECT locked_by into locked from transactions where id = $1;
   IF NOT FOUND THEN
	RETURN FALSE;
   ELSEIF locked is not null AND locked <> $2 THEN
        RETURN FALSE;
   END IF;
   UPDATE transactions set locked_by = $2 where id = $1;
   RETURN TRUE;
end;
$_$;


--
-- Name: FUNCTION lock_record(in_id integer, in_session_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION lock_record(in_id integer, in_session_id integer) IS '
This function seeks to lock a record with an id of in_id to a session with an
id of in_session_id.  If possible, it returns true.  If it is already locked,
false.  These are not hard locks and the application is free to disregard or 
not even ask.  They time out when the session is destroyed.
';


--
-- Name: menu_children(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION menu_children(in_parent_id integer) RETURNS SETOF menu_item
    LANGUAGE plpgsql
    AS $$
declare 
	item menu_item;
	arg menu_attribute%ROWTYPE;
begin
        FOR item IN
		SELECT n.position, n.id, c.level, n.label, c.path, 
                       to_args(array[ma.attribute, ma.value])
		FROM connectby('menu_node', 'id', 'parent', 'position', 
				in_parent_id, 1, ',') 
			c(id integer, parent integer, "level" integer, 
				path text, list_order integer)
		JOIN menu_node n USING(id)
                JOIN menu_attribute ma ON (n.id = ma.node_id)
               WHERE n.id IN (select node_id 
                                FROM menu_acl
                                JOIN (select rolname FROM pg_roles
                                      UNION 
                                      select 'public') pgr 
                                      ON pgr.rolname = role_name
                                WHERE pg_has_role(CASE WHEN coalesce(pgr.rolname,
                                                                    'public') 
                                                                    = 'public'
                                                               THEN current_user
                                                               ELSE pgr.rolname
                                                               END, 'USAGE')
                            GROUP BY node_id
                              HAVING bool_and(CASE WHEN acl_type ilike 'DENY'
                                                   THEN FALSE
                                                   WHEN acl_type ilike 'ALLOW'
                                                   THEN TRUE
                                                END))
                    or exists (select cn.id, cc.path
                                 FROM connectby('menu_node', 'id', 'parent', 
                                                'position', '0', 0, ',')
                                      cc(id integer, parent integer, 
                                         "level" integer, path text,
                                         list_order integer)
                                 JOIN menu_node cn USING(id)
                                WHERE cn.id IN 
                                      (select node_id FROM menu_acl
                                         JOIN (select rolname FROM pg_roles
                                              UNION 
                                              select 'public') pgr 
                                              ON pgr.rolname = role_name
                                        WHERE pg_has_role(CASE WHEN coalesce(pgr.rolname,
                                                                    'public') 
                                                                    = 'public'
                                                               THEN current_user
                                                               ELSE pgr.rolname
                                                               END, 'USAGE')
                                     GROUP BY node_id
                                       HAVING bool_and(CASE WHEN acl_type 
                                                                 ilike 'DENY'
                                                            THEN false
                                                            WHEN acl_type 
                                                                 ilike 'ALLOW'
                                                            THEN TRUE
                                                         END))
                                       and cc.path like c.path || ',%')
            GROUP BY n.position, n.id, c.level, n.label, c.path, c.list_order
            ORDER BY c.list_order
        LOOP
                return next item;
        end loop;
end;
$$;


--
-- Name: FUNCTION menu_children(in_parent_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION menu_children(in_parent_id integer) IS ' This function returns all menu  items which are children of in_parent_id 
(the only input parameter). 

It is thus similar to menu_generate() but it only returns the menu items 
associated with nodes directly descendant from the parent.  It is used for
menues for frameless browsers.';


--
-- Name: menu_generate(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION menu_generate() RETURNS SETOF menu_item
    LANGUAGE plpgsql
    AS $$
DECLARE 
	item menu_item;
	arg menu_attribute%ROWTYPE;
BEGIN
	FOR item IN 
		SELECT n.position, n.id, c.level, n.label, c.path, 
                       to_args(array[ma.attribute, ma.value])
		FROM connectby('menu_node', 'id', 'parent', 'position', '0', 
				0, ',') 
			c(id integer, parent integer, "level" integer, 
				path text, list_order integer)
		JOIN menu_node n USING(id)
                JOIN menu_attribute ma ON (n.id = ma.node_id)
               WHERE n.id IN (select node_id 
                                FROM menu_acl
                                JOIN (select rolname FROM pg_roles
                                      UNION 
                                     select 'public') pgr 
                                     ON pgr.rolname = role_name
                               WHERE pg_has_role(CASE WHEN coalesce(pgr.rolname,
                                                                    'public') 
                                                                    = 'public'
                                                      THEN current_user
                                                      ELSE pgr.rolname
                                                   END, 'USAGE')
                            GROUP BY node_id
                              HAVING bool_and(CASE WHEN acl_type ilike 'DENY'
                                                   THEN FALSE
                                                   WHEN acl_type ilike 'ALLOW'
                                                   THEN TRUE
                                                END))
                    or exists (select cn.id, cc.path
                                 FROM connectby('menu_node', 'id', 'parent', 
                                                'position', '0', 0, ',')
                                      cc(id integer, parent integer, 
                                         "level" integer, path text,
                                         list_order integer)
                                 JOIN menu_node cn USING(id)
                                WHERE cn.id IN 
                                      (select node_id FROM menu_acl
                                        JOIN (select rolname FROM pg_roles
                                              UNION 
                                              select 'public') pgr 
                                              ON pgr.rolname = role_name
                                        WHERE pg_has_role(CASE WHEN coalesce(pgr.rolname,
                                                                    'public') 
                                                                    = 'public'
                                                      THEN current_user
                                                      ELSE pgr.rolname
                                                   END, 'USAGE')
                                     GROUP BY node_id
                                       HAVING bool_and(CASE WHEN acl_type 
                                                                 ilike 'DENY'
                                                            THEN false
                                                            WHEN acl_type 
                                                                 ilike 'ALLOW'
                                                            THEN TRUE
                                                         END))
                                       and cc.path like c.path || ',%')
            GROUP BY n.position, n.id, c.level, n.label, c.path, c.list_order
            ORDER BY c.list_order
                             
	LOOP
		RETURN NEXT item;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION menu_generate(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION menu_generate() IS '
This function returns the complete menu tree.  It is used to generate nested
menus for the web interface.
';


--
-- Name: menu_insert(integer, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION menu_insert(in_parent_id integer, in_position integer, in_label text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	new_id int;
BEGIN
	UPDATE menu_node 
	SET position = position * -1
	WHERE parent = in_parent_id
		AND position >= in_position;

	INSERT INTO menu_node (parent, position, label)
	VALUES (in_parent_id, in_position, in_label);

	SELECT INTO new_id currval('menu_node_id_seq');

	UPDATE menu_node 
	SET position = (position * -1) + 1
	WHERE parent = in_parent_id
		AND position < 0;

	RETURN new_id;
END;
$$;


--
-- Name: FUNCTION menu_insert(in_parent_id integer, in_position integer, in_label text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION menu_insert(in_parent_id integer, in_position integer, in_label text) IS '
This function inserts menu items at arbitrary positions.  The arguments are, in
order:  parent, position, label.  The return value is the id number of the menu
item created. ';


--
-- Name: months_passed(timestamp without time zone, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION months_passed(in_start timestamp without time zone, in_end timestamp without time zone) RETURNS integer
    LANGUAGE sql
    AS $_$

-- The addition of one day is so that it will return '1' when run on the end
-- day of consecutive months.

select (extract (months from age($2 + '1 day', $1 + '1 day'))
       + extract (years from age($2, $1)) * 12)::int;
$_$;


--
-- Name: FUNCTION months_passed(in_start timestamp without time zone, in_end timestamp without time zone); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION months_passed(in_start timestamp without time zone, in_end timestamp without time zone) IS ' Returns the number of months between in_start and in_end.';


--
-- Name: next_leap_year_calc(date, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION next_leap_year_calc(in_date date, is_end boolean) RETURNS integer
    LANGUAGE sql
    AS $_$
SELECT 
          (CASE WHEN extract('doy' FROM $1) < 59
          THEN extract('year' FROM $1)
          ELSE extract('year' FROM $1) + 1
          END)::int
          -
          CASE WHEN $2 THEN 1 ELSE 0 END;
$_$;


--
-- Name: FUNCTION next_leap_year_calc(in_date date, is_end boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION next_leap_year_calc(in_date date, is_end boolean) IS 'Next relevant leap year calculation for a daily depreciation calculation';


--
-- Name: parse_date(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION parse_date(in_date date) RETURNS date
    LANGUAGE sql
    AS $_$ select $1; $_$;


--
-- Name: FUNCTION parse_date(in_date date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION parse_date(in_date date) IS ' Simple way to cast a Perl string to a
date format of known type. ';


--
-- Name: payment__reverse(text, date, integer, text, date, integer, integer, integer, numeric, character); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment__reverse(in_source text, in_date_paid date, in_credit_id integer, in_cash_accno text, in_date_reversed date, in_account_class integer, in_batch_id integer, in_voucher_id integer, in_exchangerate numeric, in_currency character) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	pay_row record;
        t_voucher_id int;
        t_voucher_inserted bool;
        t_currs text[];
        t_rev_fx numeric;
        t_fxgain_id int;
        t_fxloss_id int;
        t_paid_fx numeric;
BEGIN
        SELECT * INTO t_rev_fx FROM currency_get_exchangerate(
              in_currency, in_date_reversed, in_account_class);

        SELECT * INTO t_paid_fx FROM currency_get_exchangerate(
              in_currency, in_date_paid, in_account_class);

       select value::int INTO t_fxgain_id FROM setting_get('fxgain_accno_id');
       select value::int INTO t_fxloss_id FROM setting_get('fxloss_accno_id');

       SELECT string_to_array(value, ':') into t_currs
          from defaults
         where setting_key = 'curr';

        IF in_currency IS NULL OR in_currency = t_currs[1] THEN
                t_rev_fx := 1;
                t_paid_fx := 1;
        ELSIF t_rev_fx IS NULL THEN
                t_rev_fx := in_exchangerate;
                PERFORM payments_set_exchangerate(in_account_class,
                                                  in_exchangerate,
                                                  in_currency,
                                                  in_date_reversed);
        ELSIF t_rev_fx <> in_exchangerate THEN
                RAISE EXCEPTION 'Exchange rate different than on file';
        END IF;
        IF t_rev_fx IS NULL THEN
            RAISE EXCEPTION 'No exchangerate provided and not default currency';
        END IF;


        IF in_batch_id IS NOT NULL THEN
		t_voucher_id := nextval('voucher_id_seq');
		t_voucher_inserted := FALSE;
	END IF;
	FOR pay_row IN 
		SELECT a.*, c.ar_ap_account_id, arap.curr, arap.fxrate
		FROM acc_trans a
		JOIN (select id, curr, entity_credit_account, 
                             CASE WHEN curr = t_currs[1] THEN 1
                                   ELSE buy END as fxrate
			FROM ar 
                   LEFT JOIN exchangerate USING (transdate, curr)
                       WHERE in_account_class = 2
			UNION
			SELECT id, curr, entity_credit_account, 
                               CASE WHEN curr = t_currs[1] THEN 1
                                    ELSE sell END as fxrate
			FROM ap
                   LEFT JOIN exchangerate USING (transdate, curr)
                       WHERE in_account_class = 1
		) arap ON (a.trans_id = arap.id)
		JOIN entity_credit_account c 
			ON (arap.entity_credit_account = c.id)
		JOIN account ch ON (a.chart_id = ch.id)
		WHERE a.source IS NOT DISTINCT FROM in_source
			AND a.transdate = in_date_paid
			AND in_credit_id = arap.entity_credit_account
			AND in_cash_accno = ch.accno
                        and in_voucher_id IS NOT DISTINCT FROM voucher_id
	LOOP
                IF pay_row.curr = t_currs[1] THEN
                   pay_row.fxrate = 1;
                END IF;

		IF in_batch_id IS NOT NULL 
			AND t_voucher_inserted IS NOT TRUE
		THEN
			INSERT INTO voucher 
			(id, trans_id, batch_id, batch_class)
			VALUES
			(t_voucher_id, pay_row.trans_id, in_batch_id,
				CASE WHEN in_account_class = 1 THEN 4
				     WHEN in_account_class = 2 THEN 7
				END);

			t_voucher_inserted := TRUE;
		END IF;

		INSERT INTO acc_trans
		(trans_id, chart_id, amount, transdate, source, memo, approved,
			voucher_id) 
		VALUES 
		(pay_row.trans_id, pay_row.chart_id, 
                        pay_row.amount / t_paid_fx * -1 * t_rev_fx, 
			in_date_reversed, in_source, 'Reversing ' || 
			COALESCE(in_source, ''), 
			case when in_batch_id is not null then false 
			else true end, t_voucher_id),
                 (pay_row.trans_id, pay_row.ar_ap_account_id, 
                        pay_row.amount / t_paid_fx * pay_row.fxrate,
			in_date_reversed, in_source, 'Reversing ' ||
			COALESCE(in_source, ''), 
			case when in_batch_id is not null then false 
			else true end, t_voucher_id),
                 (pay_row.trans_id, 
                  case when pay_row.fxrate > t_rev_fx 
                       THEN t_fxloss_id ELSE t_fxgain_id END, 
                  pay_row.amount / t_paid_fx * (t_rev_fx - pay_row.fxrate),
                  in_date_reversed, in_source, 'Reversing ' ||  
                                                COALESCE(in_source, ''),
                   case when in_batch_id is not null then false
                        else true end, t_voucher_id);

                   
	END LOOP;
	RETURN 1;
END;
$$;


--
-- Name: FUNCTION payment__reverse(in_source text, in_date_paid date, in_credit_id integer, in_cash_accno text, in_date_reversed date, in_account_class integer, in_batch_id integer, in_voucher_id integer, in_exchangerate numeric, in_currency character); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment__reverse(in_source text, in_date_paid date, in_credit_id integer, in_cash_accno text, in_date_reversed date, in_account_class integer, in_batch_id integer, in_voucher_id integer, in_exchangerate numeric, in_currency character) IS '
Reverses a payment.  All fields are mandatory except batch_id and voucher_id
because they determine the identity of the payment to be reversed.
';


--
-- Name: payment__search(text, date, date, integer, text, integer, character); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment__search(in_source text, in_date_from date, in_date_to date, in_credit_id integer, in_cash_accno text, in_account_class integer, in_currency character) RETURNS SETOF payment_record
    LANGUAGE plpgsql
    AS $$
DECLARE 
	out_row payment_record;
BEGIN
	FOR out_row IN 
		select sum(CASE WHEN c.entity_class = 1 then a.amount
				ELSE a.amount * -1 END), c.meta_number, 
			c.id, co.legal_name,
			compound_array(ARRAY[ARRAY[ch.id::text, ch.accno, 
				ch.description]]), a.source, 
			b.control_code, b.description, a.voucher_id, a.transdate
		FROM entity_credit_account c
		JOIN ( select entity_credit_account, id, curr
			FROM ar WHERE in_account_class = 2
			UNION
			SELECT entity_credit_account, id, curr
			FROM ap WHERE in_account_class = 1
			) arap ON (arap.entity_credit_account = c.id)
		JOIN acc_trans a ON (arap.id = a.trans_id)
		JOIN chart ch ON (ch.id = a.chart_id)
		JOIN company co ON (c.entity_id = co.entity_id)
		LEFT JOIN voucher v ON (v.id = a.voucher_id)
		LEFT JOIN batch b ON (b.id = v.batch_id)
		WHERE (ch.accno = in_cash_accno)
                        AND (in_currency IS NULL OR in_currency = arap.curr)
			AND (c.id = in_credit_id OR in_credit_id IS NULL)
			AND (a.transdate >= in_date_from 
				OR in_date_from IS NULL)
			AND (a.transdate <= in_date_to OR in_date_to IS NULL)
			AND (source = in_source OR in_source IS NULL)
		GROUP BY c.meta_number, c.id, co.legal_name, a.transdate, 
			a.source, a.memo, b.id, b.control_code, b.description, 
                        voucher_id
		ORDER BY a.transdate, c.meta_number, a.source
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION payment__search(in_source text, in_date_from date, in_date_to date, in_credit_id integer, in_cash_accno text, in_account_class integer, in_currency character); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment__search(in_source text, in_date_from date, in_date_to date, in_credit_id integer, in_cash_accno text, in_account_class integer, in_currency character) IS 'This searches for payments.  in_date_to and _date_from specify the acceptable
date range.  All other matches are exact except that null matches all values.

Currently (and to support earlier data) we define a payment as a collection of
acc_trans records against the same credit account and cash account, on the same
day with the same source number, and optionally the same voucher id.';


--
-- Name: payment_bulk_post(numeric[], integer, text, numeric, text, text, date, integer, numeric, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_bulk_post(in_transactions numeric[], in_batch_id integer, in_source text, in_total numeric, in_ar_ap_accno text, in_cash_accno text, in_payment_date date, in_account_class integer, in_exchangerate numeric, in_currency text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE 
        out_count int;
        t_voucher_id int;
        t_trans_id int;
        t_amount numeric;
        t_ar_ap_id int;
        t_cash_id int;
        t_currs text[];
        t_exchangerate numeric;
        t_cash_sign int;
BEGIN

        SELECT * INTO t_exchangerate FROM currency_get_exchangerate(
              in_currency, in_payment_date, in_account_class);

        IF in_batch_id IS NULL THEN
                -- t_voucher_id := NULL;
                RAISE EXCEPTION 'Bulk Post Must be from Batch!';
        ELSE
                INSERT INTO voucher (batch_id, batch_class, trans_id)
                values (in_batch_id,
                (SELECT batch_class_id FROM batch WHERE id = in_batch_id),
                in_transactions[1][1]);

                t_voucher_id := currval('voucher_id_seq');
        END IF;

        SELECT string_to_array(value, ':') into t_currs 
          from defaults 
         where setting_key = 'curr';

        IF (in_currency IS NULL OR in_currency = t_currs[1]) THEN
                t_exchangerate := 1;
        ELSIF t_exchangerate IS NULL THEN
                t_exchangerate := in_exchangerate;
                PERFORM payments_set_exchangerate(in_account_class,
                                                  in_exchangerate, 
                                                  in_currency,
                                                  in_payment_date);
        ELSIF t_exchangerate <> in_exchangerate THEN
                RAISE EXCEPTION 'Exchange rate different than on file';
        END IF;
        IF t_exchangerate IS NULL THEN
            RAISE EXCEPTION 'No exchangerate provided and not default currency';
        END IF;

        CREATE TEMPORARY TABLE bulk_payments_in
           (id int, amount numeric, fxrate numeric, gain_loss_accno int);

        select id into t_ar_ap_id from chart where accno = in_ar_ap_accno;
        select id into t_cash_id from chart where accno = in_cash_accno;

        FOR out_count IN 
                        array_lower(in_transactions, 1) ..
                        array_upper(in_transactions, 1)
        LOOP
            -- Fill the bulk payments table
            INSERT INTO bulk_payments_in(id, amount)
            VALUES (in_transactions[out_count][1],
                    in_transactions[out_count][2]);
        END LOOP;

        IF in_account_class = 1 THEN
            t_cash_sign := 1;
        ELSE
            t_cash_sign := -1;
        END IF;

        IF (in_currency IS NULL OR in_currency = t_currs[1]) THEN
            UPDATE bulk_payments_in
               SET fxrate = 1;
        ELSE
            UPDATE bulk_payments_in
               SET fxrate =
                (SELECT CASE WHEN in_account_class = 1 THEN sell
                             ELSE buy
                        END
                   FROM exchangerate e
                   JOIN (SELECT transdate, id, curr FROM ar
                         UNION
                         SELECT transdate, id, curr FROM ap) a
                     ON (e.transdate = a.transdate
                         AND e.curr = a.curr)
                   WHERE a.id = bulk_payments_in.id);
            UPDATE bulk_payments_in
               SET gain_loss_accno =
                (SELECT value::int FROM defaults
                  WHERE setting_key = 'fxgain_accno_id')
             WHERE ((t_exchangerate - bulk_payments_in.fxrate) * t_cash_sign) < 0;
            UPDATE bulk_payments_in
               SET gain_loss_accno = (SELECT value::int FROM defaults
                  WHERE setting_key = 'fxloss_accno_id')
             WHERE ((t_exchangerate - bulk_payments_in.fxrate) * t_cash_sign) > 0;
            -- explicitly leave zero gain/loss accno_id entries at NULL
            -- so we have an easy check for which 
        END IF;

        -- Insert cash side
        INSERT INTO acc_trans
             (trans_id, chart_id, amount, approved,
              voucher_id, transdate, source)
           SELECT id, t_cash_id, amount * t_cash_sign * t_exchangerate/fxrate,
                  CASE WHEN t_voucher_id IS NULL THEN true
                       ELSE false END,
                  t_voucher_id, in_payment_date, in_source
             FROM bulk_payments_in  where amount <> 0;

        -- Insert ar/ap side
        INSERT INTO acc_trans
             (trans_id, chart_id, amount, approved,
              voucher_id, transdate, source)
           SELECT id, t_ar_ap_id,
                  amount * -1 * t_cash_sign,
                  CASE WHEN t_voucher_id IS NULL THEN true
                       ELSE false END,
                  t_voucher_id, in_payment_date, in_source
             FROM bulk_payments_in where amount <> 0;

        -- Insert fx gain/loss effects, if applicable
        INSERT INTO acc_trans
             (trans_id, chart_id, amount, approved,
              voucher_id, transdate, source)
           SELECT id, gain_loss_accno,
                  amount * t_cash_sign * (1 - t_exchangerate/fxrate),
                  CASE WHEN t_voucher_id IS NULL THEN true
                       ELSE false END,
                  t_voucher_id, in_payment_date, in_source
             FROM bulk_payments_in
            WHERE amount <> 0 AND gain_loss_accno IS NOT NULL;

        DROP TABLE bulk_payments_in;
        perform unlock_all();
        return out_count;
END;
$$;


--
-- Name: FUNCTION payment_bulk_post(in_transactions numeric[], in_batch_id integer, in_source text, in_total numeric, in_ar_ap_accno text, in_cash_accno text, in_payment_date date, in_account_class integer, in_exchangerate numeric, in_currency text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment_bulk_post(in_transactions numeric[], in_batch_id integer, in_source text, in_total numeric, in_ar_ap_accno text, in_cash_accno text, in_payment_date date, in_account_class integer, in_exchangerate numeric, in_currency text) IS ' This posts the payments for large batch workflows.

Note that in_transactions is a two-dimensional numeric array.  Of each 
sub-array, the first element is the (integer) transaction id, and the second
is the amount for that transaction.  ';


--
-- Name: payment_gather_header_info(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_gather_header_info(in_account_class integer, in_payment_id integer) RETURNS SETOF payment_header_item
    LANGUAGE plpgsql
    AS $$
 DECLARE out_payment payment_header_item;
 BEGIN
 FOR out_payment IN 
   SELECT p.id as payment_id, p.reference as payment_reference, p.payment_date,  
          c.legal_name as legal_name, am.amount as amount, em.first_name, em.last_name, p.currency, p.notes
   FROM payment p
   JOIN entity_employee ent_em ON (ent_em.entity_id = p.employee_id)
   JOIN person em ON (ent_em.entity_id = em.entity_id)
   JOIN entity_credit_account eca ON (eca.id = p.entity_credit_id)
   JOIN company c ON   (c.entity_id  = eca.entity_id)
   JOIN payment_links pl ON (p.id = pl.payment_id)
   LEFT JOIN (  SELECT sum(a.amount) as amount
 		FROM acc_trans a
 		JOIN account acc ON (a.chart_id = acc.id)
                JOIN account_link al ON (acc.id =al.account_id)
 		JOIN payment_links pl ON (pl.entry_id=a.entry_id)
 		WHERE al.description in  
                       ('AP_paid', 'AP_discount', 'AR_paid', 'AR_discount') 
                       and ((in_account_class = 1 AND al.description like 'AP%')
                       or (in_account_class = 2 AND al.description like 'AR%'))
             ) am ON (true)
   WHERE p.id = in_payment_id
 LOOP
     RETURN NEXT out_payment;
 END LOOP;

 END;
 $$;


--
-- Name: FUNCTION payment_gather_header_info(in_account_class integer, in_payment_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment_gather_header_info(in_account_class integer, in_payment_id integer) IS ' This function finds a payment based on the id and retrieves the record, 
it is usefull for printing payments :) ';


--
-- Name: payment_gather_line_info(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_gather_line_info(in_account_class integer, in_payment_id integer) RETURNS SETOF payment_line_item
    LANGUAGE plpgsql
    AS $$
 DECLARE out_payment_line payment_line_item;
 BEGIN
   FOR out_payment_line IN 
     SELECT pl.payment_id, ac.entry_id, pl.type as link_type, ac.trans_id, a.invnumber as invoice_number,
     ac.chart_id, ch.accno as chart_accno, ch.description as chart_description, ch.link as chart_link,
     ac.amount,  ac.transdate as trans_date, ac.source, ac.cleared_on, ac.fx_transaction, ac.project_id,
     ac.memo, ac.invoice_id, ac.approved, ac.cleared_on, ac.reconciled_on
     FROM acc_trans ac
     JOIN payment_links pl ON (pl.entry_id = ac.entry_id )
     JOIN chart         ch ON (ch.id = ac.chart_id)
     LEFT JOIN (SELECT id,invnumber
                 FROM ar WHERE in_account_class = 2
                 UNION
                 SELECT id,invnumber
                 FROM ap WHERE in_account_class = 1
                ) a ON (ac.trans_id = a.id)
     WHERE pl.payment_id = in_payment_id
   LOOP
      RETURN NEXT out_payment_line;
   END LOOP;  
 END;
 $$;


--
-- Name: FUNCTION payment_gather_line_info(in_account_class integer, in_payment_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment_gather_line_info(in_account_class integer, in_payment_id integer) IS ' This function finds a payment based on the id and retrieves all the line records, 
it is usefull for printing payments and build reports :) ';


--
-- Name: payment_get_all_accounts(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_get_all_accounts(in_account_class integer) RETURNS SETOF entity
    LANGUAGE plpgsql
    AS $$
DECLARE out_entity entity%ROWTYPE;
BEGIN
	FOR out_entity IN
		SELECT  ec.id, 
			e.name, e.entity_class, e.created 
		FROM entity e
		JOIN entity_credit_account ec ON (ec.entity_id = e.id)
				WHERE e.entity_class = in_account_class
	LOOP
		RETURN NEXT out_entity;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION payment_get_all_accounts(in_account_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment_get_all_accounts(in_account_class integer) IS ' This function takes a single argument (1 for vendor, 2 for customer as 
always) and returns all entities with accounts of the appropriate type. ';


--
-- Name: payment_get_all_contact_invoices(integer, integer, character, date, date, integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_get_all_contact_invoices(in_account_class integer, in_business_id integer, in_currency character, in_date_from date, in_date_to date, in_batch_id integer, in_ar_ap_accno text, in_meta_number text) RETURNS SETOF payment_contact_invoice
    LANGUAGE plpgsql
    AS $$
DECLARE payment_item payment_contact_invoice;
BEGIN
	FOR payment_item IN
		  SELECT c.id AS contact_id, e.control_code as econtrol_code, 
			c.description as eca_description, 
			e.name AS contact_name,
		         c.meta_number AS account_number,
			 sum( case when u.username IS NULL or 
				       u.username = SESSION_USER 
			     THEN 
		              coalesce(p.due::numeric, 0) -
		              CASE WHEN c.discount_terms 
		                        > extract('days' FROM age(a.transdate))
		                   THEN 0
		                   ELSE (coalesce(p.due::numeric, 0)) * 
					coalesce(c.discount::numeric, 0) / 100
		              END
			     ELSE 0::numeric
			     END) AS total_due,
		         compound_array(ARRAY[[
		              a.id::text, a.invnumber, a.transdate::text, 
		              a.amount::text, (a.amount - p.due)::text,
		              (CASE WHEN c.discount_terms 
		                        > extract('days' FROM age(a.transdate))
		                   THEN 0
		                   ELSE (a.amount - coalesce((a.amount - p.due), 0)) * coalesce(c.discount, 0) / 100
		              END)::text, 
		              (coalesce(p.due, 0) -
		              (CASE WHEN c.discount_terms 
		                        > extract('days' FROM age(a.transdate))
		                   THEN 0
		                   ELSE (coalesce(p.due, 0)) * coalesce(c.discount, 0) / 100
		              END))::text,
			 	case when u.username IS NOT NULL 
				          and u.username <> SESSION_USER 
				     THEN 0::text
				     ELSE 1::text
				END,
				COALESCE(u.username, 0::text)
				]]),
                              sum(case when a.batch_id = in_batch_id then 1
		                  else 0 END),
		              bool_and(lock_record(a.id, (select max(session_id) 				FROM "session" where users_id = (
					select id from users WHERE username =
					SESSION_USER))))
                           
		    FROM entity e
		    JOIN entity_credit_account c ON (e.id = c.entity_id)
		    JOIN (SELECT ap.id, invnumber, transdate, amount, entity_id, 
				 curr, 1 as invoice_class,
		                 entity_credit_account, on_hold, v.batch_id,
				 approved, paid
		            FROM ap
		       LEFT JOIN (select * from voucher where batch_class = 1) v 
			         ON (ap.id = v.trans_id)
			   WHERE in_account_class = 1
			         AND (v.batch_class = 1 or v.batch_id IS NULL)
		           UNION
		          SELECT ar.id, invnumber, transdate, amount, entity_id,
		                 curr, 2 as invoice_class,
		                 entity_credit_account, on_hold, v.batch_id,
				 approved, paid
		            FROM ar
		       LEFT JOIN (select * from voucher where batch_class = 2) v 
			         ON (ar.id = v.trans_id)
			   WHERE in_account_class = 2
			         AND (v.batch_class = 2 or v.batch_id IS NULL)
			ORDER BY transdate
		         ) a ON (a.entity_credit_account = c.id)
		    JOIN transactions t ON (a.id = t.id)
		    JOIN (SELECT acc_trans.trans_id, 
		                 sum(CASE WHEN in_account_class = 1 THEN amount
		                          WHEN in_account_class = 2 
		                          THEN amount * -1
		                     END) AS due 
		            FROM acc_trans 
		            JOIN account coa ON (coa.id = acc_trans.chart_id)
                            JOIN account_link al ON (al.account_id = coa.id)
		       LEFT JOIN voucher v ON (acc_trans.voucher_id = v.id)
		           WHERE ((al.description = 'AP' AND in_account_class = 1)
		                 OR (al.description = 'AR' AND in_account_class = 2))
			   AND (approved IS TRUE or v.batch_class IN (3, 6))
		        GROUP BY acc_trans.trans_id) p ON (a.id = p.trans_id)
		LEFT JOIN "session" s ON (s."session_id" = t.locked_by)
		LEFT JOIN users u ON (u.id = s.users_id)
		   WHERE (a.batch_id = in_batch_id
		          OR (a.invoice_class = in_account_class
		             AND a.approved
		         AND a.amount <> a.paid 
			 AND NOT a.on_hold
                         AND a.curr = in_currency
		         AND EXISTS (select trans_id FROM acc_trans
		                      WHERE trans_id = a.id AND
		                            chart_id = (SELECT id from account
		                                         WHERE accno
		                                               = in_ar_ap_accno)
		                    )))
		         AND (in_meta_number IS NULL OR 
                             in_meta_number = c.meta_number)
		GROUP BY c.id, e.name, c.meta_number, c.threshold, 
			e.control_code, c.description
		  HAVING  (sum(p.due) >= c.threshold
			OR sum(case when a.batch_id = in_batch_id then 1
                                  else 0 END) > 0)
        ORDER BY c.meta_number ASC
	LOOP
		RETURN NEXT payment_item;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION payment_get_all_contact_invoices(in_account_class integer, in_business_id integer, in_currency character, in_date_from date, in_date_to date, in_batch_id integer, in_ar_ap_accno text, in_meta_number text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment_get_all_contact_invoices(in_account_class integer, in_business_id integer, in_currency character, in_date_from date, in_date_to date, in_batch_id integer, in_ar_ap_accno text, in_meta_number text) IS '
This function takes the following arguments (all prefaced with in_ in the db):
account_class: 1 for vendor, 2 for customer
business_type: integer of business.id.
currency: char(3) of currency (for example ''USD'')
date_from, date_to:  These dates are inclusive.
batch_id:  For payment batches, where fees are concerned.
ar_ap_accno:  The AR/AP account number.

This then returns a set of contact information with a 2 dimensional array 
cnsisting of outstanding invoices.

Note that the payment selection logic is that this returns all invoices which are
either approved or in the batch_id specified.  It also locks the invoices using 
the LedgerSMB discretionary locking framework, and if not possible, returns the 
username of the individual who has the lock.
';


--
-- Name: payment_get_available_overpayment_amount(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_get_available_overpayment_amount(in_account_class integer, in_entity_credit_id integer) RETURNS SETOF payment_overpayments_available_amount
    LANGUAGE plpgsql
    AS $$
DECLARE out_overpayment payment_overpayments_available_amount;
BEGIN
      FOR out_overpayment IN
              SELECT chart_id, accno,   chart_description, abs(sum(available))
              FROM overpayments
              WHERE payment_class  = in_account_class 
              AND entity_credit_id = in_entity_credit_id 
              AND available <> 0
              GROUP BY chart_id, accno, chart_description
      LOOP
           RETURN NEXT out_overpayment;
      END LOOP;
END;
$$;


--
-- Name: payment_get_entity_accounts(integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_get_entity_accounts(in_account_class integer, in_vc_name text, in_vc_idn text) RETURNS SETOF payment_vc_info
    LANGUAGE plpgsql
    AS $$
 DECLARE out_entity payment_vc_info;
 

 BEGIN
 	FOR out_entity IN
              SELECT ec.id, cp.legal_name || 
                     coalesce(':' || ec.description,'') as name, 
                     e.entity_class, ec.discount_account_id, ec.meta_number
 		FROM entity_credit_account ec
 		JOIN entity e ON (ec.entity_id = e.id)
 		JOIN company cp ON (cp.entity_id = e.id)
		WHERE ec.entity_class = in_account_class
		AND (cp.legal_name ilike coalesce('%'||in_vc_name||'%','%%') OR cp.tax_id = in_vc_idn)
	LOOP
		RETURN NEXT out_entity;
	END LOOP;
 END;
 $$;


--
-- Name: FUNCTION payment_get_entity_accounts(in_account_class integer, in_vc_name text, in_vc_idn text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment_get_entity_accounts(in_account_class integer, in_vc_name text, in_vc_idn text) IS ' Returns a minimal set of information about customer or vendor accounts
as needed for discount calculations and the like.';


--
-- Name: payment_get_open_accounts(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_get_open_accounts(in_account_class integer) RETURNS SETOF entity
    LANGUAGE plpgsql
    AS $$
DECLARE out_entity entity%ROWTYPE;
BEGIN
	FOR out_entity IN
		SELECT ec.id, cp.legal_name as name, e.entity_class, e.created 
		FROM entity e
		JOIN entity_credit_account ec ON (ec.entity_id = e.id)
		JOIN company cp ON (cp.entity_id = e.id)
			WHERE ec.entity_class = in_account_class
                        AND CASE WHEN in_account_class = 1 THEN
	           		ec.id IN (SELECT entity_credit_account FROM ap 
	           			WHERE amount <> paid
		   			GROUP BY entity_credit_account)
		    	       WHEN in_account_class = 2 THEN
		   		ec.id IN (SELECT entity_credit_account FROM ar
		   			WHERE amount <> paid
		   			GROUP BY entity_credit_account)
		   	  END
	LOOP
		RETURN NEXT out_entity;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION payment_get_open_accounts(in_account_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment_get_open_accounts(in_account_class integer) IS ' This function takes a single argument (1 for vendor, 2 for customer as 
always) and returns all entities with open accounts of the appropriate type. ';


--
-- Name: payment_get_open_invoice(integer, integer, character, date, date, numeric, numeric, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_get_open_invoice(in_account_class integer, in_entity_credit_id integer, in_curr character, in_datefrom date, in_dateto date, in_amountfrom numeric, in_amountto numeric, in_department_id integer, in_invnumber text) RETURNS SETOF payment_invoice
    LANGUAGE plpgsql
    AS $$
DECLARE payment_inv payment_invoice;
BEGIN
	FOR payment_inv IN
		SELECT * from payment_get_open_invoices(in_account_class, in_entity_credit_id, in_curr, in_datefrom, in_dateto, in_amountfrom,
		in_amountto, in_department_id)
		WHERE (invnumber like in_invnumber OR in_invnumber IS NULL)
	LOOP
		RETURN NEXT payment_inv;
	END LOOP;
END;

$$;


--
-- Name: FUNCTION payment_get_open_invoice(in_account_class integer, in_entity_credit_id integer, in_curr character, in_datefrom date, in_dateto date, in_amountfrom numeric, in_amountto numeric, in_department_id integer, in_invnumber text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment_get_open_invoice(in_account_class integer, in_entity_credit_id integer, in_curr character, in_datefrom date, in_dateto date, in_amountfrom numeric, in_amountto numeric, in_department_id integer, in_invnumber text) IS ' 
This function is based on payment_get_open_invoices and returns only one invoice if the in_invnumber is set. 
if no in_invnumber is passed this function behaves the same as payment_get_open_invoices
';


--
-- Name: payment_get_open_invoices(integer, integer, character, date, date, numeric, numeric, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_get_open_invoices(in_account_class integer, in_entity_credit_id integer, in_curr character, in_datefrom date, in_dateto date, in_amountfrom numeric, in_amountto numeric, in_department_id integer) RETURNS SETOF payment_invoice
    LANGUAGE plpgsql
    AS $$
DECLARE payment_inv payment_invoice;
BEGIN
	FOR payment_inv IN
		SELECT a.id AS invoice_id, a.invnumber AS invnumber,a.invoice AS invoice, 
		       a.transdate AS invoice_date, a.amount AS amount, 
		       a.amount/
		       (CASE WHEN a.curr = (SELECT * from defaults_get_defaultcurrency())
                         THEN 1
		        ELSE
		        (CASE WHEN in_account_class = 2
		              THEN ex.buy
		              ELSE ex.sell END)
		        END) as amount_fx, 
		       (CASE WHEN c.discount_terms < extract('days' FROM age(a.transdate))
		        THEN 0
		        ELSE (coalesce(ac.due, a.amount)) * coalesce(c.discount, 0) / 100
		        END) AS discount,
		        (CASE WHEN c.discount_terms < extract('days' FROM age(a.transdate))
		        THEN 0
		        ELSE (coalesce(ac.due, a.amount)) * coalesce(c.discount, 0) / 100
		        END)/
		        (CASE WHEN a.curr = (SELECT * from defaults_get_defaultcurrency())
                         THEN 1
		        ELSE
		        (CASE WHEN in_account_class = 2
		              THEN ex.buy
		              ELSE ex.sell END)
		        END) as discount_fx,		        
		        ac.due - (CASE WHEN c.discount_terms < extract('days' FROM age(a.transdate))
		        THEN 0
		        ELSE (coalesce(ac.due, a.amount)) * coalesce(c.discount, 0) / 100
		        END) AS due,
		        (ac.due - (CASE WHEN c.discount_terms < extract('days' FROM age(a.transdate))
		        THEN 0 
		        ELSE (coalesce(ac.due, a.amount)) * coalesce(c.discount, 0) / 100
		        END))/
		        (CASE WHEN a.curr = (SELECT * from defaults_get_defaultcurrency())
                         THEN 1
		         ELSE
		         (CASE WHEN in_account_class = 2
		              THEN ex.buy
		              ELSE ex.sell END)
		         END) AS due_fx,
		        (CASE WHEN a.curr = (SELECT * from defaults_get_defaultcurrency())
		         THEN 1
		         ELSE
		        (CASE WHEN in_account_class = 2
		         THEN ex.buy
		         ELSE ex.sell END)
		         END) AS exchangerate
                 --TODO HV prepare drop entity_id from ap,ar
                 --FROM  (SELECT id, invnumber, transdate, amount, entity_id,
                 FROM  (SELECT id, invnumber, invoice, transdate, amount,
		               1 as invoice_class, curr,
		               entity_credit_account, department_id, approved
		          FROM ap
                         UNION
		         --SELECT id, invnumber, transdate, amount, entity_id,
		         SELECT id, invnumber, invoice, transdate, amount,
		               2 AS invoice_class, curr,
		               entity_credit_account, department_id, approved
		         FROM ar
		         ) a 
		JOIN (SELECT trans_id, chart_id, sum(CASE WHEN in_account_class = 1 THEN amount
		                                  WHEN in_account_class = 2 
		                             THEN amount * -1
		                             END) as due
		        FROM acc_trans 
		        GROUP BY trans_id, chart_id) ac ON (ac.trans_id = a.id)
		        JOIN chart ON (chart.id = ac.chart_id)
		        LEFT JOIN exchangerate ex ON ( ex.transdate = a.transdate AND ex.curr = a.curr )         
		        JOIN entity_credit_account c ON (c.id = a.entity_credit_account)
                --        OR (a.entity_credit_account IS NULL and a.entity_id = c.entity_id))
	 	        WHERE ((chart.link = 'AP' AND in_account_class = 1)
		              OR (chart.link = 'AR' AND in_account_class = 2))
              	        AND a.invoice_class = in_account_class
		        AND c.entity_class = in_account_class
		        AND c.id = in_entity_credit_id
                        --### short term: ignore fractional cent differences
		        AND a.curr = in_curr
		        AND (a.transdate >= in_datefrom 
		             OR in_datefrom IS NULL)
		        AND (a.transdate <= in_dateto
		             OR in_dateto IS NULL)
		        AND (a.amount >= in_amountfrom 
		             OR in_amountfrom IS NULL)
		        AND (a.amount <= in_amountto
		             OR in_amountto IS NULL)
		        AND (a.department_id = in_department_id
		             OR in_department_id IS NULL)
		        AND due <> 0 
		        AND a.approved = true         
		        GROUP BY a.invnumber, a.transdate, a.amount, amount_fx, discount, discount_fx, ac.due, a.id, c.discount_terms, ex.buy, ex.sell, a.curr, a.invoice
	LOOP
		RETURN NEXT payment_inv;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION payment_get_open_invoices(in_account_class integer, in_entity_credit_id integer, in_curr character, in_datefrom date, in_dateto date, in_amountfrom numeric, in_amountto numeric, in_department_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment_get_open_invoices(in_account_class integer, in_entity_credit_id integer, in_curr character, in_datefrom date, in_dateto date, in_amountfrom numeric, in_amountto numeric, in_department_id integer) IS ' This function is the base for get_open_invoice and returns all open invoices for the entity_credit_id
it has a lot of options to enable filtering and use the same logic for entity_class_id and currency. ';


--
-- Name: payment_get_open_overpayment_entities(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_get_open_overpayment_entities(in_account_class integer) RETURNS SETOF payment_vc_info
    LANGUAGE plpgsql
    AS $$
 DECLARE out_entity payment_vc_info;
 BEGIN
	FOR out_entity IN
    		SELECT DISTINCT entity_credit_id, legal_name, e.entity_class, discount, o.meta_number
    		FROM overpayments o
    		JOIN entity e ON (e.id=o.entity_id)
    		WHERE available <> 0 AND in_account_class = payment_class
        LOOP
                RETURN NEXT out_entity;
        END LOOP;
 END;
$$;


--
-- Name: acc_trans; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE acc_trans (
    trans_id integer NOT NULL,
    chart_id integer NOT NULL,
    amount numeric,
    transdate date DEFAULT ('now'::text)::date,
    source text,
    cleared boolean DEFAULT false,
    fx_transaction boolean DEFAULT false,
    project_id integer,
    memo text,
    invoice_id integer,
    approved boolean DEFAULT true,
    cleared_on date,
    reconciled_on date,
    voucher_id integer,
    entry_id integer NOT NULL
);


--
-- Name: TABLE acc_trans; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE acc_trans IS 'This table stores line items for financial transactions.  Please note that
payments in 1.3 are not full-fledged transactions.';


--
-- Name: COLUMN acc_trans.source; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN acc_trans.source IS 'Document Source identifier for individual line items, usually used 
for payments.';


--
-- Name: payment; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE payment (
    id integer NOT NULL,
    reference text NOT NULL,
    gl_id integer,
    payment_class integer NOT NULL,
    payment_date date DEFAULT ('now'::text)::date,
    closed boolean DEFAULT false,
    entity_credit_id integer,
    employee_id integer,
    currency character(3),
    notes text,
    department_id integer DEFAULT 0
);


--
-- Name: TABLE payment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE payment IS ' This table will store the main data on a payment, prepayment, overpayment, et';


--
-- Name: COLUMN payment.reference; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN payment.reference IS ' This field will store the code for both receipts and payment order  ';


--
-- Name: COLUMN payment.gl_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN payment.gl_id IS ' A payment should always be linked to a GL movement ';


--
-- Name: COLUMN payment.closed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN payment.closed IS ' This will store the current state of a payment/receipt order ';


--
-- Name: payment_links; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE payment_links (
    payment_id integer,
    entry_id integer,
    type integer
);


--
-- Name: TABLE payment_links; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE payment_links IS '  
 An explanation to the type field.
 * A type 0 means the link is referencing an ar/ap  and was created
   using an overpayment movement after the receipt was created 
 * A type 1 means the link is referencing an ar/ap and  was made 
   on the payment creation, its not the product of an overpayment movement 
 * A type 2 means the link is not referencing an ar/ap and its the product
   of the overpayment logic 

 With this ideas in order we can do the following

 To get the payment amount we will sum the entries with type > 0.
 To get the linked amount we will sum the entries with type < 2.
 The overpayment account can be obtained from the entries with type = 2.

 This reasoning is hacky and i hope it can dissapear when we get to 1.4 - D.M.
';


--
-- Name: overpayments; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW overpayments AS
    SELECT p.id AS payment_id, p.reference AS payment_reference, p.payment_class, p.closed AS payment_closed, p.payment_date, ac.chart_id, c.accno, c.description AS chart_description, p.department_id, abs(sum(ac.amount)) AS available, cmp.legal_name, eca.id AS entity_credit_id, eca.entity_id, eca.discount, eca.meta_number FROM (((((payment p JOIN payment_links pl ON ((pl.payment_id = p.id))) JOIN acc_trans ac ON ((ac.entry_id = pl.entry_id))) JOIN chart c ON ((c.id = ac.chart_id))) JOIN entity_credit_account eca ON ((eca.id = p.entity_credit_id))) JOIN company cmp ON ((cmp.entity_id = eca.entity_id))) WHERE (((p.gl_id IS NOT NULL) AND ((pl.type = 2) OR (pl.type = 0))) AND (c.link ~~ '%overpayment%'::text)) GROUP BY p.id, c.accno, p.reference, p.payment_class, p.closed, p.payment_date, ac.chart_id, c.description, p.department_id, cmp.legal_name, eca.id, eca.entity_id, eca.discount, eca.meta_number;


--
-- Name: payment_get_unused_overpayment(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_get_unused_overpayment(in_account_class integer, in_entity_credit_id integer, in_chart_id integer) RETURNS SETOF overpayments
    LANGUAGE plpgsql
    AS $$
DECLARE out_overpayment overpayments%ROWTYPE;
BEGIN
      FOR out_overpayment IN
              SELECT DISTINCT * 
              FROM overpayments
              WHERE payment_class  = in_account_class 
              AND entity_credit_id = in_entity_credit_id 
              AND available <> 0
              AND (in_chart_id IS NULL OR chart_id = in_chart_id )
              ORDER BY payment_date
            
      LOOP
           RETURN NEXT out_overpayment;
      END LOOP;
END;
$$;


--
-- Name: FUNCTION payment_get_unused_overpayment(in_account_class integer, in_entity_credit_id integer, in_chart_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment_get_unused_overpayment(in_account_class integer, in_entity_credit_id integer, in_chart_id integer) IS ' Returns a list of available overpayments';


--
-- Name: payment_get_vc_info(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_get_vc_info(in_entity_credit_id integer, in_location_class_id integer) RETURNS SETOF payment_location_result
    LANGUAGE plpgsql
    AS $$
DECLARE out_row payment_location_result;
	BEGIN
		FOR out_row IN
                SELECT l.id, l.line_one, l.line_two, l.line_three, l.city,
                       l.state, l.mail_code, c.name, lc.class
                FROM location l
                JOIN company_to_location ctl ON (ctl.location_id = l.id)
                JOIN company cp ON (ctl.company_id = cp.id)
                JOIN location_class lc ON (ctl.location_class = lc.id)
                JOIN country c ON (c.id = l.country_id)
                JOIN entity_credit_account ec ON (ec.entity_id = cp.entity_id)
                WHERE ec.id = in_entity_credit_id AND
                      lc.id = in_location_class_id
                ORDER BY lc.id, l.id, c.name
                LOOP
                	RETURN NEXT out_row;
		END LOOP;
	END;
$$;


--
-- Name: FUNCTION payment_get_vc_info(in_entity_credit_id integer, in_location_class_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment_get_vc_info(in_entity_credit_id integer, in_location_class_id integer) IS ' This function returns vendor or customer info ';


--
-- Name: payment_post(date, integer, integer, character, text, integer, text, integer[], numeric[], boolean[], text[], text[], integer[], numeric[], integer[], text[], text[], integer[], integer[], boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_post(in_datepaid date, in_account_class integer, in_entity_credit_id integer, in_curr character, in_notes text, in_department_id integer, in_gl_description text, in_cash_account_id integer[], in_amount numeric[], in_cash_approved boolean[], in_source text[], in_memo text[], in_transaction_id integer[], in_op_amount numeric[], in_op_cash_account_id integer[], in_op_source text[], in_op_memo text[], in_op_account_id integer[], in_ovp_payment_id integer[], in_approved boolean) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE var_payment_id int;
DECLARE var_gl_id int;
DECLARE var_entry record;
DECLARE var_entry_id int[];
DECLARE out_count int;
DECLARE coa_id record;
DECLARE var_employee int;
DECLARE var_account_id int;
DECLARE default_currency char(3);
DECLARE current_exchangerate numeric;
DECLARE old_exchangerate numeric;
DECLARE fx_gain_loss_amount numeric;
BEGIN
        
        SELECT * INTO default_currency  FROM defaults_get_defaultcurrency(); 
        SELECT * INTO current_exchangerate FROM currency_get_exchangerate(in_curr, in_datepaid, in_account_class);


        SELECT INTO var_employee p.id 
        FROM users u
        JOIN person p ON (u.entity_id=p.entity_id)
        WHERE username = SESSION_USER LIMIT 1;
        -- 
        -- WE HAVE TO INSERT THE PAYMENT, USING THE GL INFORMATION
        -- THE ID IS GENERATED BY payment_id_seq
        --
   	INSERT INTO payment (reference, payment_class, payment_date,
	                      employee_id, currency, notes, department_id, entity_credit_id) 
	VALUES ((CASE WHEN in_account_class = 1 THEN
	                                setting_increment('rcptnumber') -- I FOUND THIS ON sql/modules/Settings.sql 
			             ELSE 						-- and it is very usefull				
			                setting_increment('paynumber') 
			             END),
	         in_account_class, in_datepaid, var_employee,
                 in_curr, in_notes, in_department_id, in_entity_credit_id);
        SELECT currval('payment_id_seq') INTO var_payment_id; -- WE'LL NEED THIS VALUE TO USE payment_link table
        -- WE'LL NEED THIS VALUE TO JOIN WITH PAYMENT
        -- NOW COMES THE HEAVY PART, STORING ALL THE POSSIBLE TRANSACTIONS... 
        --
        -- FIRST WE SHOULD INSERT THE CASH ACCOUNTS
        --
        -- WE SHOULD HAVE THE DATA STORED AS (ACCNO, AMOUNT), SO
     IF (array_upper(in_cash_account_id, 1) > 0) THEN
	FOR out_count IN 
			array_lower(in_cash_account_id, 1) ..
			array_upper(in_cash_account_id, 1)
	LOOP
	        INSERT INTO acc_trans (chart_id, amount,
		                       trans_id, transdate, approved, source, memo)
		VALUES (in_cash_account_id[out_count], 
		        CASE WHEN in_account_class = 1 THEN in_amount[out_count]*current_exchangerate  
		        ELSE (in_amount[out_count]*current_exchangerate)* - 1
		        END,
		        in_transaction_id[out_count], in_datepaid, coalesce(in_approved, true), 
		        in_source[out_count], in_memo[out_count]);
                INSERT INTO payment_links 
		VALUES (var_payment_id, currval('acc_trans_entry_id_seq'), 1);
		IF (in_ovp_payment_id IS NOT NULL AND in_ovp_payment_id[out_count] IS NOT NULL) THEN
                	INSERT INTO payment_links
                	VALUES (in_ovp_payment_id[out_count], currval('acc_trans_entry_id_seq'), 0);
		END IF;
		
	END LOOP;
	-- NOW LETS HANDLE THE AR/AP ACCOUNTS
	-- WE RECEIVED THE TRANSACTIONS_ID AND WE CAN OBTAIN THE ACCOUNT FROM THERE
	FOR out_count IN
		     array_lower(in_transaction_id, 1) ..
		     array_upper(in_transaction_id, 1)
       LOOP
               SELECT INTO var_account_id chart_id FROM acc_trans as ac
	        JOIN chart as c ON (c.id = ac.chart_id) 
       	        WHERE 
       	        trans_id = in_transaction_id[out_count] AND
       	        ( c.link = 'AP' OR c.link = 'AR' );
        -- We need to know the exchangerate of this transaction
	-- ### BUG: we don't have a guarantee that the transaction is
	--          the same currency as in_curr, so, we can't use
	--          current_exchangerate as the basis for fx gain/loss
	--          calculations
        IF (in_curr = default_currency) THEN 
           old_exchangerate := 1;
        ELSIF (in_account_class = 2) THEN
           SELECT buy INTO old_exchangerate 
           FROM exchangerate e
           JOIN ar a ON (a.transdate = e.transdate)
                        AND (a.curr = e.curr)
           WHERE a.id = in_transaction_id[out_count];
        ELSE 
           SELECT sell INTO old_exchangerate 
           FROM exchangerate e
           JOIN ap a ON (a.transdate = e.transdate)
                        AND (a.curr = e.curr)
           WHERE a.id = in_transaction_id[out_count];
        END IF;
        -- Now we post the AP/AR transaction
        INSERT INTO acc_trans (chart_id, amount,
                                trans_id, transdate, approved, source, memo)
		VALUES (var_account_id, 
		        CASE WHEN in_account_class = 1 THEN 
		        
		        (in_amount[out_count]*old_exchangerate) * -1 
		        ELSE in_amount[out_count]*old_exchangerate
		        END,
		        in_transaction_id[out_count], in_datepaid,  coalesce(in_approved, true), 
		        in_source[out_count], in_memo[out_count]);
        -- Lets set the gain/loss, if  fx_gain_loss_amount equals zero then we dont need to post
        -- any transaction
       fx_gain_loss_amount := in_amount[out_count]*current_exchangerate - in_amount[out_count]*old_exchangerate;
       IF (in_account_class = 1) THEN
         -- in case of vendor invoices, the invoice amounts have been negated, do the same with the diff
         fx_gain_loss_amount := fx_gain_loss_amount * -1;
       END IF;

       IF (fx_gain_loss_amount < 0) THEN
           INSERT INTO acc_trans (chart_id, amount, trans_id, transdate, approved, source)
            VALUES ((select value::int from defaults WHERE setting_key = 'fxgain_accno_id'),
                    fx_gain_loss_amount, in_transaction_id[out_count], in_datepaid, coalesce(in_approved, true),
                    in_source[out_count]);
        ELSIF (fx_gain_loss_amount > 0) THEN
            INSERT INTO acc_trans (chart_id, amount, trans_id, transdate, approved, source)
            VALUES ((select value::int from defaults WHERE setting_key = 'fxloss_accno_id'),
                    fx_gain_loss_amount, in_transaction_id[out_count], in_datepaid, coalesce(in_approved, true),
                    in_source[out_count]);
        END IF; 
        -- Now we set the links
         INSERT INTO payment_links 
		VALUES (var_payment_id, currval('acc_trans_entry_id_seq'), 1);
      END LOOP;
     END IF; -- END IF 
--
-- WE NEED TO HANDLE THE OVERPAYMENTS NOW
--
       --
       -- FIRST WE HAVE TO MAKE THE GL TO HOLD THE OVERPAYMENT TRANSACTIONS
       -- THE ID IS GENERATED BY gl_id_seq
       --
       
  IF (array_upper(in_op_cash_account_id, 1) > 0) THEN
       INSERT INTO gl (reference, description, transdate,
                       person_id, notes, approved, department_id) 
              VALUES (setting_increment('glnumber'),
	              in_gl_description, in_datepaid, var_employee,
	              in_notes, in_approved, in_department_id);
       SELECT currval('id') INTO var_gl_id;   
--
-- WE NEED TO SET THE GL_ID FIELD ON PAYMENT'S TABLE
--
       UPDATE payment SET gl_id = var_gl_id 
       WHERE id = var_payment_id;
       -- NOW COMES THE HEAVY PART, STORING ALL THE POSSIBLE TRANSACTIONS... 
       --
       -- FIRST WE SHOULD INSERT THE OVERPAYMENT CASH ACCOUNTS
       --
	FOR out_count IN 
			array_lower(in_op_cash_account_id, 1) ..
			array_upper(in_op_cash_account_id, 1)
	LOOP
	        INSERT INTO acc_trans (chart_id, amount,
		                       trans_id, transdate, approved, source, memo)
		VALUES (in_op_cash_account_id[out_count], 
		        CASE WHEN in_account_class = 1 THEN in_op_amount[out_count]  
		        ELSE in_op_amount[out_count] * - 1
		        END,
		        var_gl_id, in_datepaid, coalesce(in_approved, true), 
		        in_op_source[out_count], in_op_memo[out_count]);
	        INSERT INTO payment_links 
		VALUES (var_payment_id, currval('acc_trans_entry_id_seq'), 2);
		
	END LOOP;
	-- NOW LETS HANDLE THE OVERPAYMENT ACCOUNTS
	FOR out_count IN
		     array_lower(in_op_account_id, 1) ..
		     array_upper(in_op_account_id, 1)
	LOOP
         INSERT INTO acc_trans (chart_id, amount,
                                trans_id, transdate, approved, source, memo)
		VALUES (in_op_account_id[out_count], 
		        CASE WHEN in_account_class = 1 THEN in_op_amount[out_count] * -1 
		        ELSE in_op_amount[out_count]
		        END,
		        var_gl_id, in_datepaid,  coalesce(in_approved, true), 
		        in_op_source[out_count], in_op_memo[out_count]);
		INSERT INTO payment_links 
		VALUES (var_payment_id, currval('acc_trans_entry_id_seq'), 2);
	END LOOP;	        
 END IF;  
 return var_payment_id;
END;
$$;


--
-- Name: FUNCTION payment_post(in_datepaid date, in_account_class integer, in_entity_credit_id integer, in_curr character, in_notes text, in_department_id integer, in_gl_description text, in_cash_account_id integer[], in_amount numeric[], in_cash_approved boolean[], in_source text[], in_memo text[], in_transaction_id integer[], in_op_amount numeric[], in_op_cash_account_id integer[], in_op_source text[], in_op_memo text[], in_op_account_id integer[], in_ovp_payment_id integer[], in_approved boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment_post(in_datepaid date, in_account_class integer, in_entity_credit_id integer, in_curr character, in_notes text, in_department_id integer, in_gl_description text, in_cash_account_id integer[], in_amount numeric[], in_cash_approved boolean[], in_source text[], in_memo text[], in_transaction_id integer[], in_op_amount numeric[], in_op_cash_account_id integer[], in_op_source text[], in_op_memo text[], in_op_account_id integer[], in_ovp_payment_id integer[], in_approved boolean) IS ' Posts a payment.  in_op_* arrays are cross-indexed with eachother.
Other arrays are cross-indexed with eachother.

This API will probably change in 1.4 as we start looking at using more custom
complex types and arrays of those (requires Pg 8.4 or higher).
';


--
-- Name: payment_type; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE payment_type (
    id integer NOT NULL,
    label text NOT NULL
);


--
-- Name: payment_type__get_label(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_type__get_label(in_payment_type_id integer) RETURNS SETOF payment_type
    LANGUAGE plpgsql
    AS $$
DECLARE out_row payment_type%ROWTYPE;
BEGIN
	FOR out_row IN SELECT * FROM payment_type where id=in_payment_type_id LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION payment_type__get_label(in_payment_type_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payment_type__get_label(in_payment_type_id integer) IS ' Returns all information on a payment type by the id.  This should be renamed
to account for its behavior in future versions.';


--
-- Name: payment_type__list(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payment_type__list() RETURNS SETOF payment_type
    LANGUAGE plpgsql
    AS $$
DECLARE out_row payment_type%ROWTYPE;
BEGIN
	FOR out_row IN SELECT * FROM payment_type LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: payments_get_open_currencies(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payments_get_open_currencies(in_account_class integer) RETURNS SETOF character
    LANGUAGE plpgsql
    AS $$
DECLARE result char(3);
BEGIN
select min(curr) into result from ar WHERE in_account_class = 2
union 
select min(curr) from ap WHERE in_account_class = 1;


LOOP
   EXIT WHEN result IS NULL;
   return next result;

   SELECT min(curr) INTO result from ar 
    where in_account_class = 2 and curr > result
            union 
   select min(curr) from ap 
    WHERE in_account_class = 1 and curr > result
    LIMIT 1;

END LOOP;
END;
$$;


--
-- Name: FUNCTION payments_get_open_currencies(in_account_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payments_get_open_currencies(in_account_class integer) IS ' This does a sparse scan to find currencies attached to open invoices.

It should scale per the number of currencies used rather than the size of the 
ar or ap tables.
';


--
-- Name: payments_set_exchangerate(integer, numeric, character, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION payments_set_exchangerate(in_account_class integer, in_exchangerate numeric, in_curr character, in_datepaid date) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE current_exrate  exchangerate%ROWTYPE;
BEGIN
select  * INTO current_exrate
        FROM  exchangerate 
        WHERE transdate = in_datepaid
              AND curr = in_curr;
IF current_exrate.transdate = in_datepaid THEN
   IF in_account_class = 2 THEN 
      UPDATE exchangerate set buy = in_exchangerate  where transdate = in_datepaid;
   ELSE
      UPDATE exchangerate set sell = in_exchangerate where transdate = in_datepaid;
   END IF;
   RETURN 0; 
ELSE
    IF in_account_class = 2 THEN
     INSERT INTO exchangerate (curr, transdate, buy) values (in_curr, in_datepaid, in_exchangerate);
  ELSE   
     INSERT INTO exchangerate (curr, transdate, sell) values (in_curr, in_datepaid, in_exchangerate);
  END IF;                                       
RETURN 0;
END IF;
END;
$$;


--
-- Name: FUNCTION payments_set_exchangerate(in_account_class integer, in_exchangerate numeric, in_curr character, in_datepaid date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION payments_set_exchangerate(in_account_class integer, in_exchangerate numeric, in_curr character, in_datepaid date) IS ' 1.3 only.  This will be replaced by a more generic function in 1.4.

This sets the exchange rate for a class of transactions (payable, receivable) 
to a certain rate for a specific date.';


--
-- Name: periods; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW periods AS
    SELECT 'ytd'::text AS id, 'Year to Date'::text AS label, (now())::date AS date_to, (((date_part('year'::text, now()))::text || '-01-01'::text))::date AS date_from UNION SELECT 'last_year'::text AS id, 'Last Year'::text AS label, ((((date_part('YEAR'::text, now()) - (1)::double precision))::text || '-12-31'::text))::date AS date_to, ((((date_part('YEAR'::text, now()) - (1)::double precision))::text || '-01-01'::text))::date AS date_from;


--
-- Name: periods_get(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION periods_get() RETURNS SETOF periods
    LANGUAGE sql
    AS $$
SELECT * FROM periods ORDER BY id
$$;


--
-- Name: FUNCTION periods_get(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION periods_get() IS ' Returns dates for year to date, and last year.';


--
-- Name: person__delete_contact(integer, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION person__delete_contact(in_person_id integer, in_contact_class_id integer, in_contact text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN

DELETE FROM person_to_contact
 WHERE person_id = in_person_id and contact_class_id = in_contact_class_id
       and contact= in_contact;
RETURN FOUND;

END;

$$;


--
-- Name: FUNCTION person__delete_contact(in_person_id integer, in_contact_class_id integer, in_contact text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION person__delete_contact(in_person_id integer, in_contact_class_id integer, in_contact text) IS ' Deletes a contact record specified for the person.  Returns true if a record
was found and deleted, false if not.';


--
-- Name: person__delete_location(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION person__delete_location(in_person_id integer, in_location_id integer, in_location_class integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN

DELETE FROM person_to_location
 WHERE person_id = in_person_id AND location_id = in_location_id 
       AND location_class = in_location_class;

RETURN FOUND;

END;
$$;


--
-- Name: FUNCTION person__delete_location(in_person_id integer, in_location_id integer, in_location_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION person__delete_location(in_person_id integer, in_location_id integer, in_location_class integer) IS 'Deletes a location mapping to a person.  Returns true if found, false if no
data deleted.';


--
-- Name: person__list_bank_account(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION person__list_bank_account(in_entity_id integer) RETURNS SETOF entity_bank_account
    LANGUAGE plpgsql
    AS $$
DECLARE out_row entity_bank_account%ROWTYPE;
BEGIN
	FOR out_row IN
		SELECT * from entity_bank_account where entity_id = in_entity_id
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION person__list_bank_account(in_entity_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION person__list_bank_account(in_entity_id integer) IS ' Lists bank accounts for a person';


--
-- Name: person__list_contacts(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION person__list_contacts(in_entity_id integer) RETURNS SETOF contact_list
    LANGUAGE plpgsql
    AS $$
DECLARE out_row RECORD;
BEGIN
	FOR out_row IN 
		SELECT cc.class, cc.id, c.description, c.contact
		FROM person_to_contact c
		JOIN contact_class cc ON (c.contact_class_id = cc.id)
		JOIN person p ON (c.person_id = p.id)
		WHERE p.entity_id = in_entity_id
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION person__list_contacts(in_entity_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION person__list_contacts(in_entity_id integer) IS ' Returns a list of contacts attached to the function.';


--
-- Name: language; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE language (
    code character varying(6) NOT NULL,
    description text
);


--
-- Name: TABLE language; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE language IS ' Languages for manual translations and so forth.';


--
-- Name: person__list_languages(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION person__list_languages() RETURNS SETOF language
    LANGUAGE sql
    AS $$ SELECT * FROM language ORDER BY code ASC $$;


--
-- Name: FUNCTION person__list_languages(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION person__list_languages() IS ' Returns a list of languages ordered by code';


--
-- Name: person__list_locations(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION person__list_locations(in_entity_id integer) RETURNS SETOF location_result
    LANGUAGE plpgsql
    AS $$
DECLARE out_row RECORD;
BEGIN
	FOR out_row IN
		SELECT l.id, l.line_one, l.line_two, l.line_three, l.city, 
			l.state, l.mail_code, c.id, c.name, lc.id, lc.class
		FROM location l
		JOIN person_to_location ctl ON (ctl.location_id = l.id)
		JOIN person p ON (ctl.person_id = p.id)
		JOIN location_class lc ON (ctl.location_class = lc.id)
		JOIN country c ON (c.id = l.country_id)
		WHERE p.entity_id = in_entity_id
		ORDER BY lc.id, l.id, c.name
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION person__list_locations(in_entity_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION person__list_locations(in_entity_id integer) IS ' Returns a list of locations specified attached to the person.';


--
-- Name: person__list_notes(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION person__list_notes(in_entity_id integer) RETURNS SETOF entity_note
    LANGUAGE plpgsql
    AS $$
DECLARE out_row record;
BEGIN
	FOR out_row IN
		SELECT *
		FROM entity_note
		WHERE ref_key = in_entity_id
		ORDER BY created
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION person__list_notes(in_entity_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION person__list_notes(in_entity_id integer) IS ' Returns a list of notes attached to a person.';


--
-- Name: person__list_salutations(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION person__list_salutations() RETURNS SETOF salutation
    LANGUAGE sql
    AS $$ SELECT * FROM salutation ORDER BY id ASC $$;


--
-- Name: FUNCTION person__list_salutations(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION person__list_salutations() IS ' Returns a list of salutations ordered by id.';


--
-- Name: person__save(integer, integer, text, text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION person__save(in_entity_id integer, in_salutation_id integer, in_first_name text, in_middle_name text, in_last_name text, in_country_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$

    DECLARE
        e_id int;
        e entity;
        loc location;
        l_id int;
        p_id int;
    BEGIN
    
    select * into e from entity where id = in_entity_id and entity_class = 3;
    e_id := in_entity_id; 
    
    IF FOUND THEN
        UPDATE entity 
           SET name = in_first_name || ' ' || in_last_name,
               country_id = in_country_id
         WHERE id = in_entity_id; 
    ELSE
        INSERT INTO entity (name, entity_class, country_id) 
	values (in_first_name || ' ' || in_last_name, 3, in_country_id);
	e_id := currval('entity_id_seq');
       
    END IF;
    
      
    UPDATE person SET
            salutation_id = in_salutation_id,
            first_name = in_first_name,
            last_name = in_last_name,
            middle_name = in_middle_name
    WHERE
            entity_id = in_entity_id;
    IF FOUND THEN
	RETURN in_entity_id;
    ELSE 
        -- Do an insert
        
        INSERT INTO person (salutation_id, first_name, last_name, entity_id)
	VALUES (in_salutation_id, in_first_name, in_last_name, e_id);

        RETURN e_id;
    
    END IF;
END;
$$;


--
-- Name: FUNCTION person__save(in_entity_id integer, in_salutation_id integer, in_first_name text, in_middle_name text, in_last_name text, in_country_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION person__save(in_entity_id integer, in_salutation_id integer, in_first_name text, in_middle_name text, in_last_name text, in_country_id integer) IS ' Saves the person with the information specified.  Returns the entity_id
of the record saved.';


--
-- Name: person__save_contact(integer, integer, text, text, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION person__save_contact(in_entity_id integer, in_contact_class integer, in_old_contact text, in_contact_new text, in_description text, in_old_contact_class integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE 
    out_id int;
    v_orig person_to_contact;
BEGIN
    
    SELECT cc.* into v_orig 
    FROM person_to_contact cc, person p
    WHERE p.entity_id = in_entity_id 
    and cc.contact_class_id = in_old_contact_class
    AND cc.contact = in_old_contact
    AND cc.person_id = p.id;
    
    IF NOT FOUND THEN
    
        -- create
        INSERT INTO person_to_contact(person_id, contact_class_id, contact, description)
        VALUES (
            (SELECT id FROM person WHERE entity_id = in_entity_id),
            in_contact_class,
            in_contact_new,
            in_description
        );
        return 1;
    ELSE
        -- edit.
        UPDATE person_to_contact
           SET contact = in_contact_new, description = in_description
         WHERE contact = in_old_contact
               AND person_id = v_orig.person_id
               AND contact_class_id = in_old_contact_class;
        return 0;
    END IF;
    
END;
$$;


--
-- Name: FUNCTION person__save_contact(in_entity_id integer, in_contact_class integer, in_old_contact text, in_contact_new text, in_description text, in_old_contact_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION person__save_contact(in_entity_id integer, in_contact_class integer, in_old_contact text, in_contact_new text, in_description text, in_old_contact_class integer) IS ' Saves saves contact info.  Returns 1 if a row was inserted, 0 if it was 
updated. ';


--
-- Name: person__save_location(integer, integer, integer, text, text, text, text, text, text, integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION person__save_location(in_entity_id integer, in_location_id integer, in_location_class integer, in_line_one text, in_line_two text, in_line_three text, in_city text, in_state text, in_mail_code text, in_country_code integer, in_old_location_class integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$

    DECLARE
        l_row location;
        l_id INT;
	    t_person_id int;
    BEGIN
	SELECT id INTO t_person_id
	FROM person WHERE entity_id = in_entity_id;

    UPDATE person_to_location
       SET location_class = in_location_class
     WHERE person_id = t_person_id 
           AND location_class = in_old_location_class
           AND location_id = in_location_id;
    
    
    IF NOT FOUND THEN
        -- Create a new one.
        l_id := location_save(
            in_location_id, 
    	    in_line_one, 
    	    in_line_two, 
    	    in_line_three, 
    	    in_city,
    		in_state, 
    		in_mail_code, 
    		in_country_code);
    	
        INSERT INTO person_to_location 
    		(person_id, location_id, location_class)
    	VALUES  (t_person_id, l_id, in_location_class);
    ELSE
        l_id := location_save(
            in_location_id, 
    	    in_line_one, 
    	    in_line_two, 
    	    in_line_three, 
    	    in_city,
    		in_state, 
    		in_mail_code, 
    		in_country_code);
        -- Update the old one.
    END IF;
    return l_id;
    END;
$$;


--
-- Name: FUNCTION person__save_location(in_entity_id integer, in_location_id integer, in_location_class integer, in_line_one text, in_line_two text, in_line_three text, in_city text, in_state text, in_mail_code text, in_country_code integer, in_old_location_class integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION person__save_location(in_entity_id integer, in_location_id integer, in_location_class integer, in_line_one text, in_line_two text, in_line_three text, in_city text, in_state text, in_mail_code text, in_country_code integer, in_old_location_class integer) IS ' Saves a location mapped to the person with the specified information.
Returns the location id saved.';


--
-- Name: project; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE project (
    id integer NOT NULL,
    projectnumber text,
    description text,
    startdate date,
    enddate date,
    parts_id integer,
    production numeric DEFAULT 0,
    completed numeric DEFAULT 0,
    credit_id integer
);


--
-- Name: COLUMN project.parts_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN project.parts_id IS ' Job costing/manufacturing here not implemented.';


--
-- Name: project_list_open(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION project_list_open(in_date date) RETURNS SETOF project
    LANGUAGE plpgsql
    AS $$
DECLARE out_project project%ROWTYPE;
BEGIN
	FOR out_project IN
		SELECT * from project
		WHERE startdate <= in_date AND enddate >= in_date
		      AND completed = 0
	LOOP
		return next out_project;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION project_list_open(in_date date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION project_list_open(in_date date) IS ' This function returns all projects that were open as on the date provided as
the argument.';


--
-- Name: reconciliation__account_list(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__account_list() RETURNS SETOF recon_accounts
    LANGUAGE sql
    AS $$
    SELECT
        coa.accno || ' ' || coa.description as name,
        coa.accno, coa.id as id
    FROM account coa
         JOIN cr_coa_to_account cta ON cta.chart_id = coa.id
    ORDER BY coa.accno;
$$;


--
-- Name: FUNCTION reconciliation__account_list(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__account_list() IS ' returns set of accounts set up for reconciliation.  Currently we pull the 
account number and description from the account table.';


--
-- Name: reconciliation__add_entry(integer, text, text, timestamp without time zone, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__add_entry(in_report_id integer, in_scn text, in_type text, in_date timestamp without time zone, in_amount numeric) RETURNS integer
    LANGUAGE plpgsql
    AS $$
    
    DECLARE
	in_account int;
        la RECORD;
        t_errorcode INT;
        our_value NUMERIC;
        lid INT;
	in_count int;
	t_scn TEXT;
	t_uid int;
	t_prefix text;
        t_amount numeric;
    BEGIN
        SELECT CASE WHEN a.category in ('A', 'E') THEN in_amount * -1
                    ELSE in_amount
               END into t_amount
          FROM cr_report r JOIN account a ON r.chart_id = a.id
         WHERE r.id = in_report_id; 

	SELECT value into t_prefix FROM defaults WHERE setting_key = 'check_prefix';

	t_uid := person__get_my_entity_id();
	IF in_scn = '' THEN 
		t_scn := NULL;
	ELSE 
		t_scn := t_prefix || in_scn;
	END IF;
	IF t_scn IS NOT NULL THEN
		SELECT count(*) INTO in_count FROM cr_report_line
		WHERE scn ilike t_scn AND report_id = in_report_id 
			AND their_balance = 0;

		IF in_count = 0 THEN
			INSERT INTO cr_report_line
			(report_id, scn, their_balance, our_balance, clear_time,
				"user", trans_type)
			VALUES 
			(in_report_id, t_scn, t_amount, 0, in_date, t_uid,
				in_type);
		ELSIF in_count = 1 THEN
			UPDATE cr_report_line
			SET their_balance = t_amount, clear_time = in_date,
				cleared = true
			WHERE t_scn = scn AND report_id = in_report_id
				AND their_balance = 0;
		ELSE 
			SELECT count(*) INTO in_count FROM cr_report_line
			WHERE t_scn ilike scn AND report_id = in_report_id
				AND our_value = t_amount and their_balance = 0;

			IF in_count = 0 THEN -- no match among many of values
				SELECT id INTO lid FROM cr_report_line
                        	WHERE t_scn ilike scn AND report_id = in_report_id
				ORDER BY our_balance ASC limit 1;

				UPDATE cr_report_line
                                SET their_balance = t_amount, 
					clear_time = in_date,
					trans_type = in_type,
					cleared = true
                                WHERE id = lid;

			ELSIF in_count = 1 THEN -- EXECT MATCH
				UPDATE cr_report_line
				SET their_balance = t_amount, 
					trans_type = in_type,
					clear_time = in_date,
					cleared = true
				WHERE t_scn = scn AND report_id = in_report_id
                                	AND our_value = t_amount 
					AND their_balance = 0;
			ELSE -- More than one match
				SELECT id INTO lid FROM cr_report_line
                        	WHERE t_scn ilike scn AND report_id = in_report_id
                                	AND our_value = t_amount
				ORDER BY id ASC limit 1;

				UPDATE cr_report_line
                                SET their_balance = t_amount,
					trans_type = in_type,
					cleared = true,
					clear_time = in_date
                                WHERE id = lid;
				
			END IF;
		END IF;
	ELSE -- scn IS NULL, check on amount instead
		SELECT count(*) INTO in_count FROM cr_report_line
		WHERE report_id = in_report_id AND our_balance = t_amount
			AND their_balance = 0 and post_date = in_date
			and scn NOT LIKE t_prefix || '%';

		IF in_count = 0 THEN -- no match
			INSERT INTO cr_report_line
			(report_id, scn, their_balance, our_balance, clear_time,
			"user", trans_type)
			VALUES 
			(in_report_id, t_scn, t_amount, 0, in_date, t_uid,
			in_type);
		ELSIF in_count = 1 THEN -- perfect match
			UPDATE cr_report_line SET their_balance = t_amount,
					trans_type = in_type,
					clear_time = in_date,
					cleared = true
			WHERE report_id = in_report_id AND our_balance = t_amount
                        	AND their_balance = 0 and
				in_scn NOT LIKE t_prefix || '%';
		ELSE -- more than one match
			SELECT min(id) INTO lid FROM cr_report_line
			WHERE report_id = in_report_id AND our_balance = t_amount
                        	AND their_balance = 0 and post_date = in_date
				AND scn NOT LIKE t_prefix || '%'
			LIMIT 1;

			UPDATE cr_report_line SET their_balance = t_amount,
					trans_type = in_type,
					clear_time = in_date,
					cleared = true
			WHERE id = lid;
			
		END IF;
	END IF;
        return 1; 
        
    END;    
$$;


--
-- Name: FUNCTION reconciliation__add_entry(in_report_id integer, in_scn text, in_type text, in_date timestamp without time zone, in_amount numeric); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__add_entry(in_report_id integer, in_scn text, in_type text, in_date timestamp without time zone, in_amount numeric) IS ' 
This function is used for automatically matching entries from an external source
like a bank-produced csv file.

This function is very sensitive to ordering of inputs.  NULL or empty in_scn values MUST be submitted after meaningful scns.  It is also highly recommended 
that within each category, one submits in order of amount.  We should therefore
wrap it in another function which can operate on a set, perhaps in 1.4....';


--
-- Name: reconciliation__delete_my_report(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__delete_my_report(in_report_id integer) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    DELETE FROM cr_report_line
     WHERE report_id = in_report_id
           AND report_id IN (SELECT id FROM cr_report
                              WHERE entered_username = SESSION_USER
                                    AND submitted IS NOT TRUE
                                    and approved IS NOT TRUE);
    DELETE FROM cr_report
     WHERE id = in_report_id AND entered_username = SESSION_USER
           AND submitted IS NOT TRUE AND approved IS NOT TRUE;
    RETURN FOUND;
END;
$$;


--
-- Name: FUNCTION reconciliation__delete_my_report(in_report_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__delete_my_report(in_report_id integer) IS 'This function allows a user to delete his or her own unsubmitted, unapproved
reconciliation reports only.  This is designed to allow a user to back out of
the reconciliation process without cluttering up the search results for others.
';


--
-- Name: reconciliation__delete_unapproved(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__delete_unapproved(in_report_id integer) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    DELETE FROM cr_report_line
     WHERE report_id = in_report_id
           AND report_id IN (SELECT id FROM cr_report
                              WHERE approved IS NOT TRUE);
    DELETE FROM cr_report
     WHERE id = in_report_id AND approved IS NOT TRUE;
    RETURN FOUND;
END;
$$;


--
-- Name: FUNCTION reconciliation__delete_unapproved(in_report_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__delete_unapproved(in_report_id integer) IS 'This function deletes any specified unapproved transaction.';


--
-- Name: reconciliation__get_cleared_balance(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__get_cleared_balance(in_chart_id integer) RETURNS numeric
    LANGUAGE sql
    AS $_$
	select CASE WHEN c.category in('A', 'E') THEN sum(ac.amount) * -1 ELSE
		sum(ac.amount) END
	FROM account c
	JOIN acc_trans ac ON (ac.chart_id = c.id)
	JOIN (select id from ar where approved
		union
		select id from ap where approved
		union
		select id from gl where approved) g on (g.id = ac.trans_id)
	WHERE c.id = $1 AND ac.cleared is true and ac.approved is true
		GROUP BY c.id, c.category;
$_$;


--
-- Name: FUNCTION reconciliation__get_cleared_balance(in_chart_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__get_cleared_balance(in_chart_id integer) IS ' Gets the cleared balance of the account specified by chart_id.
This is specified in normal format (i.e. positive numbers for debits for asset
and espense accounts, and positive numbers for credits in other accounts 

Note that currently contra accounts will show negative balances.';


--
-- Name: reconciliation__get_current_balance(integer, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__get_current_balance(in_account_id integer, in_date date) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE outval NUMERIC;
BEGIN
	SELECT CASE WHEN (select category FROM account WHERE id = in_account_id)
			IN ('A', 'E') THEN sum(a.amount) * -1
		ELSE sum(a.amount) END
	FROM acc_trans a
	JOIN (
		SELECT id FROM ar
		WHERE approved is true
		UNION
		SELECT id FROM ap
		WHERE approved is true
		UNION
		SELECT id FROM gl
		WHERE approved is true
	) gl ON a.trans_id = gl.id
	WHERE a.approved IS TRUE 
		AND a.chart_id = in_account_id
		AND a.transdate <= in_date;

	RETURN outval;
END;
$$;


--
-- Name: FUNCTION reconciliation__get_current_balance(in_account_id integer, in_date date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__get_current_balance(in_account_id integer, in_date date) IS ' Gets the current balance of all approved transactions against a specific 
account.  For asset and expense accounts this is the debit balance, for others
this is the credit balance.';


--
-- Name: cr_report; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE cr_report (
    id bigint NOT NULL,
    chart_id integer NOT NULL,
    their_total numeric NOT NULL,
    approved boolean DEFAULT false NOT NULL,
    submitted boolean DEFAULT false NOT NULL,
    end_date date DEFAULT now() NOT NULL,
    updated timestamp without time zone DEFAULT now() NOT NULL,
    entered_by integer DEFAULT person__get_my_entity_id() NOT NULL,
    entered_username text DEFAULT "session_user"() NOT NULL,
    deleted boolean DEFAULT false NOT NULL,
    deleted_by integer,
    approved_by integer,
    approved_username text,
    recon_fx boolean DEFAULT false,
    CONSTRAINT cr_report_check CHECK (((deleted IS NOT TRUE) OR (approved IS NOT TRUE)))
);


--
-- Name: TABLE cr_report; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE cr_report IS 'This table holds header data for cash reports.';


--
-- Name: reconciliation__get_total(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__get_total(in_report_id integer) RETURNS SETOF cr_report
    LANGUAGE plpgsql
    AS $$

    DECLARE
        row cr_report;
    BEGIN
    
        SELECT * INTO row FROM cr_report 
        where id = in_report_id 
        AND scn = -1;
        
        IF NOT FOUND THEN -- I think this is a fairly major error condition
            RAISE EXCEPTION 'Bad report id.';
        ELSE
            return next row;
        END IF;
    END;

$$;


--
-- Name: FUNCTION reconciliation__get_total(in_report_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__get_total(in_report_id integer) IS ' Retrieves all header info from the reconciliation report.';


--
-- Name: reconciliation__new_report_id(integer, numeric, date, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__new_report_id(in_chart_id integer, in_total numeric, in_end_date date, in_recon_fx boolean) RETURNS integer
    LANGUAGE sql
    AS $_$

    INSERT INTO cr_report(chart_id, their_total, end_date, recon_fx) 
    values ($1, $2, $3, $4);
    SELECT currval('cr_report_id_seq')::int;

$_$;


--
-- Name: FUNCTION reconciliation__new_report_id(in_chart_id integer, in_total numeric, in_end_date date, in_recon_fx boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__new_report_id(in_chart_id integer, in_total numeric, in_end_date date, in_recon_fx boolean) IS ' Inserts creates a new report and returns the id.';


--
-- Name: reconciliation__pending_transactions(date, integer, integer, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__pending_transactions(in_end_date date, in_chart_id integer, in_report_id integer, in_their_total numeric) RETURNS integer
    LANGUAGE plpgsql
    AS $$
    
    DECLARE
        gl_row RECORD;
        t_recon_fx BOOL;
    BEGIN
                SELECT recon_fx INTO t_recon_fx FROM cr_report WHERE id = in_report_id;
 
		INSERT INTO cr_report_line (report_id, scn, their_balance, 
			our_balance, "user", voucher_id, ledger_id, post_date)
		SELECT in_report_id, 
		       COALESCE(ac.source, gl.ref),
		       0, 
		       sum(amount / CASE WHEN t_recon_fx IS NOT TRUE OR gl.table = 'gl'
                                         THEN 1
                                         WHEN t_recon_fx and gl.table = 'ap' 
                                         THEN ex.sell
                                         WHEN t_recon_fx and gl.table = 'ar' 
                                         THEN ex.buy
                                    END) AS amount,
				(select entity_id from users 
				where username = CURRENT_USER),
			ac.voucher_id, min(ac.entry_id), ac.transdate
		FROM acc_trans ac
		JOIN transactions t on (ac.trans_id = t.id)
		JOIN (select id, entity_credit_account::text as ref, curr, 
                             transdate, 'ar' as table 
                        FROM ar where approved
			UNION
		      select id, entity_credit_account::text, curr, 
                             transdate, 'ap' as table 
                        FROM ap WHERE approved
			UNION
		      select id, reference, '', 
                             transdate, 'gl' as table 
                        FROM gl WHERE approved) gl 
			ON (gl.table = t.table_name AND gl.id = t.id)
		LEFT JOIN cr_report_line rl ON (rl.report_id = in_report_id
			AND ((rl.ledger_id = ac.entry_id 
				AND ac.voucher_id IS NULL) 
				OR (rl.voucher_id = ac.voucher_id)))
                LEFT JOIN exchangerate ex ON gl.transdate = ex.transdate
		WHERE ac.cleared IS FALSE
			AND ac.approved IS TRUE
			AND ac.chart_id = in_chart_id
			AND ac.transdate <= in_end_date
                        AND ((t_recon_fx is not true 
                                and ac.fx_transaction is not true) 
                            OR (t_recon_fx is true 
                                AND (gl.table <> 'gl' OR ac.fx_transaction
                                                      IS TRUE))) 
		GROUP BY gl.ref, ac.source, ac.transdate,
			ac.memo, ac.voucher_id, gl.table
		HAVING count(rl.id) = 0;

		UPDATE cr_report set updated = now(),
			their_total = coalesce(in_their_total, their_total)
		where id = in_report_id;
    RETURN in_report_id;
    END;
$$;


--
-- Name: FUNCTION reconciliation__pending_transactions(in_end_date date, in_chart_id integer, in_report_id integer, in_their_total numeric); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__pending_transactions(in_end_date date, in_chart_id integer, in_report_id integer, in_their_total numeric) IS 'Ensures that the list of pending transactions in the report is up to date. ';


--
-- Name: reconciliation__report_approve(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__report_approve(in_report_id integer) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
    
    -- Does some basic checks before allowing the approval to go through; 
    -- moves the approval to "cr_report_line", I guess, or some other "final" table.
    --
    -- Pending may just be a single flag in the database to mark that it is
    -- not finalized. Will need to discuss with Chris.
    
    DECLARE
        current_row RECORD;
        completed cr_report_line;
        total_errors INT;
        in_user TEXT;
	ac_entries int[];
    BEGIN
        in_user := current_user;
        
        -- so far, so good. Different user, and no errors remain. Therefore, 
        -- we can move it to completed reports.
        --
        -- User may not be necessary - I would think it better to use the 
        -- in_user, to note who approved the report, than the user who
        -- filed it. This may require clunkier syntax..
        
        -- 
	ac_entries := '{}';
        update cr_report set approved = 't',
		approved_by = person__get_my_entity_id(),
		approved_username = SESSION_USER
	where id = in_report_id;

	FOR current_row IN 
		SELECT compound_array(entries) AS entries FROM (
			select as_array(ac.entry_id) as entries
		FROM acc_trans ac
		JOIN transactions t on (ac.trans_id = t.id)
		JOIN (select id, entity_credit_account::text as ref, 'ar' as table FROM ar
			UNION
		      select id, entity_credit_account::text, 'ap' as table FROM ap
			UNION
		      select id, reference, 'gl' as table FROM gl) gl
			ON (gl.table = t.table_name AND gl.id = t.id)
		LEFT JOIN cr_report_line rl ON (rl.report_id = in_report_id
			AND ((rl.ledger_id = ac.entry_id 
				AND ac.voucher_id IS NULL) 
				OR (rl.voucher_id = ac.voucher_id)) and rl.cleared is true)
		WHERE ac.cleared IS FALSE
			AND ac.chart_id = (select chart_id from cr_report where id = in_report_id)
		GROUP BY gl.ref, ac.source, ac.transdate,
			ac.memo, ac.voucher_id, gl.table
		HAVING count(rl.report_id) > 0) a
	LOOP
		ac_entries := ac_entries || current_row.entries;
	END LOOP;

	UPDATE acc_trans SET cleared = TRUE 
	where entry_id = any(ac_entries);
        
        return 1;        
    END;

$$;


--
-- Name: FUNCTION reconciliation__report_approve(in_report_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__report_approve(in_report_id integer) IS 'Marks the report approved and marks all cleared transactions in it cleared.';


--
-- Name: cr_report_line; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE cr_report_line (
    id bigint NOT NULL,
    report_id integer NOT NULL,
    scn text,
    their_balance numeric,
    our_balance numeric,
    errorcode integer,
    "user" integer NOT NULL,
    clear_time date,
    insert_time timestamp with time zone DEFAULT now() NOT NULL,
    trans_type text,
    post_date date,
    ledger_id integer,
    voucher_id integer,
    overlook boolean DEFAULT false NOT NULL,
    cleared boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE cr_report_line; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE cr_report_line IS ' This stores line item data on transaction lines and whether they are 
cleared.';


--
-- Name: COLUMN cr_report_line.scn; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN cr_report_line.scn IS ' This is the check number.  Maps to acc_trans.source ';


--
-- Name: reconciliation__report_details(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__report_details(in_report_id integer) RETURNS SETOF cr_report_line
    LANGUAGE plpgsql
    AS $$

    DECLARE
        row cr_report_line;
    BEGIN    
        FOR row IN 
		select * from cr_report_line where report_id = in_report_id 
		order by scn, post_date
	LOOP
        
            RETURN NEXT row;
        
        END LOOP;    
    END;

$$;


--
-- Name: FUNCTION reconciliation__report_details(in_report_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__report_details(in_report_id integer) IS ' Returns the details of the report. ';


--
-- Name: recon_payee; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW recon_payee AS
    SELECT n.name AS payee, rr.id, rr.report_id, rr.scn, rr.their_balance, rr.our_balance, rr.errorcode, rr."user", rr.clear_time, rr.insert_time, rr.trans_type, rr.post_date, rr.ledger_id, rr.voucher_id, rr.overlook, rr.cleared FROM (((cr_report_line rr LEFT JOIN acc_trans ac ON ((rr.ledger_id = ac.entry_id))) LEFT JOIN gl ON ((ac.trans_id = gl.id))) LEFT JOIN ((SELECT ap.id, e.name FROM ((ap JOIN entity_credit_account eca ON ((ap.entity_credit_account = eca.id))) JOIN entity e ON ((eca.entity_id = e.id))) UNION SELECT ar.id, e.name FROM ((ar JOIN entity_credit_account eca ON ((ar.entity_credit_account = eca.id))) JOIN entity e ON ((eca.entity_id = e.id)))) UNION SELECT gl.id, gl.description FROM gl) n ON ((n.id = ac.trans_id)));


--
-- Name: reconciliation__report_details_payee(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__report_details_payee(in_report_id integer) RETURNS SETOF recon_payee
    LANGUAGE plpgsql
    AS $$
   DECLARE
        row recon_payee;
    BEGIN    
        FOR row IN 
        	select * from recon_payee where report_id = in_report_id 
        	order by scn, post_date
        LOOP
          RETURN NEXT row;
        END LOOP;    
    END;
$$;


--
-- Name: FUNCTION reconciliation__report_details_payee(in_report_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__report_details_payee(in_report_id integer) IS ' Pulls the payee information for the reconciliation report.';


--
-- Name: reconciliation__report_summary(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__report_summary(in_report_id integer) RETURNS cr_report
    LANGUAGE plpgsql
    AS $$

    DECLARE
        row cr_report;
    BEGIN    
        select * into row from cr_report where id = in_report_id;
        
        RETURN row;
        
    END;

$$;


--
-- Name: reconciliation__save_set(integer, integer[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__save_set(in_report_id integer, in_line_ids integer[]) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE cr_report_line SET cleared = false
	WHERE report_id = in_report_id;

	UPDATE cr_report_line SET cleared = true
	WHERE report_id = in_report_id AND id = ANY(in_line_ids);
	RETURN found;
END;
$$;


--
-- Name: FUNCTION reconciliation__save_set(in_report_id integer, in_line_ids integer[]); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__save_set(in_report_id integer, in_line_ids integer[]) IS 'Sets which lines of the report are cleared.';


--
-- Name: reconciliation__search(date, date, numeric, numeric, integer, boolean, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__search(in_date_from date, in_date_to date, in_balance_from numeric, in_balance_to numeric, in_chart_id integer, in_submitted boolean, in_approved boolean) RETURNS SETOF cr_report
    LANGUAGE plpgsql
    AS $$
DECLARE report cr_report;
BEGIN
	FOR report IN
		SELECT r.* FROM cr_report r
		JOIN account c ON (r.chart_id = c.id)
		WHERE 
			(in_date_from IS NULL OR in_date_from <= end_date) and
			(in_date_to IS NULL OR in_date_to >= end_date) AND
			(in_balance_from IS NULL 
				or in_balance_from <= their_total ) AND
			(in_balance_to IS NULL 
				OR in_balance_to >= their_total) AND
			(in_chart_id IS NULL OR in_chart_id = chart_id) AND
			(in_submitted IS NULL or in_submitted = submitted) AND
			(in_approved IS NULL OR in_approved = approved) AND
			(r.deleted IS FALSE)
		ORDER BY c.accno, end_date, their_total
	LOOP
		RETURN NEXT report;
	END LOOP; 
END;
$$;


--
-- Name: FUNCTION reconciliation__search(in_date_from date, in_date_to date, in_balance_from numeric, in_balance_to numeric, in_chart_id integer, in_submitted boolean, in_approved boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__search(in_date_from date, in_date_to date, in_balance_from numeric, in_balance_to numeric, in_chart_id integer, in_submitted boolean, in_approved boolean) IS ' Searches for reconciliation reports.
NULLs match all values.
in_date_to and in_date_from give a range of reports.  All other inputs are
exact matches.
';


--
-- Name: reconciliation__submit_set(integer, integer[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION reconciliation__submit_set(in_report_id integer, in_line_ids integer[]) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE cr_report set submitted = true where id = in_report_id;
	PERFORM reconciliation__save_set(in_report_id, in_line_ids);

	RETURN FOUND;
END;
$$;


--
-- Name: FUNCTION reconciliation__submit_set(in_report_id integer, in_line_ids integer[]); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION reconciliation__submit_set(in_report_id integer, in_line_ids integer[]) IS 'Submits a reconciliation report for approval. 
in_line_ids is used to specify which report lines are cleared, finalizing the
report.';


--
-- Name: report_invoice_aging(integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION report_invoice_aging(in_entity_id integer, in_entity_class integer) RETURNS SETOF report_aging_item
    LANGUAGE plpgsql
    AS $$
DECLARE
	item report_aging_item;
BEGIN
	IF in_entity_class = 1 THEN
		FOR item IN
			SELECT c.entity_id, 
			       c.meta_number, e.name,
			       l.line_one as address1, l.line_two as address2, 
			       l.line_three as address3,
			       l.city_province, l.mail_code,
			       country.name as country, 
			       '' as contact_name, '' as email,
		               '' as phone, '' as fax, 
		               a.invnumber, a.transdate, a.till, a.ordnumber, 
			       a.ponumber, a.notes, 
			       CASE WHEN 
			                 EXTRACT(days FROM age(a.transdate)/30) 
			                 = 0
			                 THEN (a.amount - a.paid) ELSE 0 END
			            as c0, 
			       CASE WHEN EXTRACT(days FROM age(a.transdate)/30)
			                 = 1
			                 THEN (a.amount - a.paid) ELSE 0 END
			            as c30, 
			       CASE WHEN EXTRACT(days FROM age(a.transdate)/30)
			                 = 2
			                 THEN (a.amount - a.paid) ELSE 0 END
			            as c60, 
			       CASE WHEN EXTRACT(days FROM age(a.transdate)/30)
			                 > 2
			                 THEN (a.amount - a.paid) ELSE 0 END
			            as c90, 
			       a.duedate, a.id, a.curr,
			       COALESCE((SELECT sell FROM exchangerate ex
			         WHERE a.curr = ex.curr
			              AND ex.transdate = a.transdate), 1)
			       AS exchangerate,
				(SELECT compound_array(ARRAY[[p.partnumber,
						i.description, i.qty::text]])
					FROM parts p 
					JOIN invoice i ON (i.parts_id = p.id)
					WHERE i.trans_id = a.id) AS line_items
			  FROM ap a
			  JOIN entity_credit_account c USING (entity_id)
			  JOIN entity e ON (e.id = c.entity_id)
			 CROSS JOIN location l
			  JOIN country ON (country.id = l.country_id)
			 WHERE a.entity_id like coalesce(in_entity_id::text, '%')
				AND l.id = (SELECT min(location_id) 
					FROM company_to_location 
					WHERE company_id = (select min(id) 
						FROM company
						WHERE entity_id = c.entity_id))
			ORDER BY entity_id, curr, transdate, invnumber
		LOOP
			return next item;
		END LOOP;
	ELSIF in_entity_class = 2 THEN
		FOR item IN 
			SELECT c.entity_id, 
			       c.meta_number, e.name,
			       l.line_one as address1, l.line_two as address2, 
			       l.line_three as address3,
			       l.city_province, l.mail_code,
			       country.name as country, 
			       '' as contact_name, '' as email,
		               '' as phone, '' as fax, 
		               a.invnumber, a.transdate, a.till, a.ordnumber, 
			       a.ponumber, a.notes, 
			       CASE WHEN 
			                 EXTRACT(days FROM age(a.transdate)/30) 
			                 = 0
			                 THEN (a.amount - a.paid) ELSE 0 END
			            as c0, 
			       CASE WHEN EXTRACT(days FROM age(a.transdate)/30)
			                 = 1
			                 THEN (a.amount - a.paid) ELSE 0 END
			            as c30, 
			       CASE WHEN EXTRACT(days FROM age(a.transdate)/30)
			                 = 2
			                 THEN (a.amount - a.paid) ELSE 0 END
			            as c60, 
			       CASE WHEN EXTRACT(days FROM age(a.transdate)/30)
			                 > 2
			                 THEN (a.amount - a.paid) ELSE 0 END
			            as c90, 
			       a.duedate, a.id, a.curr,
			       (SELECT buy FROM exchangerate ex
			         WHERE a.curr = ex.curr
			              AND ex.transdate = a.transdate) 
			       AS exchangerate,
				(SELECT compound_array(ARRAY[[p.partnumber,
						i.description, i.qty::text]])
					FROM parts p 
					JOIN invoice i ON (i.parts_id = p.id)
					WHERE i.trans_id = a.id) AS line_items
			  FROM ar a
			  JOIN entity_credit_account c USING (entity_id)
			  JOIN entity e ON (e.id = c.entity_id)
			 CROSS JOIN location l
			  JOIN country ON (country.id = l.country_id)
			 WHERE a.entity_id like coalesce(in_entity_id::text, '%')
				AND l.id = (SELECT min(location_id) 
					FROM company_to_location 
					WHERE company_id = (select min(id) 
						FROM company
						WHERE entity_id = c.entity_id))
			ORDER BY entity_id, curr, transdate, invnumber
		LOOP
			return next item;
		END LOOP;
	ELSE
		RAISE EXCEPTION 'Entity Class % unsupported in aging report', 
			in_entity_class;
	END IF;
END;
$$;


--
-- Name: report_trial_balance(date, date, integer, integer, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION report_trial_balance(in_datefrom date, in_dateto date, in_department_id integer, in_project_id integer, in_gifi boolean) RETURNS SETOF trial_balance_line
    LANGUAGE plpgsql
    AS $$
DECLARE out_row trial_balance_line;
BEGIN
	IF in_department_id IS NULL THEN
		FOR out_row IN
			SELECT c.id, c.accno, c.description, 
				SUM(CASE WHEN ac.transdate < in_datefrom 
				              AND c.category IN ('I', 'L', 'Q')
				    THEN ac.amount
				    ELSE ac.amount * -1
				    END), 
			        SUM(CASE WHEN ac.transdate >= in_date_from 
				              AND ac.amount > 0 
			            THEN ac.amount
			            ELSE 0 END),
			        SUM(CASE WHEN ac.transdate >= in_date_from 
				              AND ac.amount < 0
			            THEN ac.amount
			            ELSE 0 END) * -1,
				SUM(CASE WHEN ac.transdate >= in_date_from
					AND c.charttype IN ('I')
				    THEN ac.amount
				    WHEN ac.transdate >= in_date_from
				              AND c.category IN ('I', 'L', 'Q')
				    THEN ac.amount
				    ELSE ac.amount * -1
				    END)
				FROM acc_trans ac
				JOIN (select id, approved FROM ap
					UNION ALL 
					select id, approved FROM gl
					UNION ALL
					select id, approved FROM ar) g
					ON (g.id = ac.trans_id)
				JOIN chart c ON (c.id = ac.chart_id)
				WHERE ac.transdate <= in_date_to
					AND ac.approved AND g.approved
					AND (in_project_id IS NULL 
						OR in_project_id = ac.project_id)
				GROUP BY c.id, c.accno, c.description
				ORDER BY c.accno
				
		LOOP
			RETURN NEXT out_row;
		END LOOP;
	ELSE 
		FOR out_row IN
			SELECT 1
		LOOP
			RETURN NEXT out_row;
		END LOOP;
	END IF;
END;
$$;


--
-- Name: FUNCTION report_trial_balance(in_datefrom date, in_dateto date, in_department_id integer, in_project_id integer, in_gifi boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION report_trial_balance(in_datefrom date, in_dateto date, in_department_id integer, in_project_id integer, in_gifi boolean) IS ' This is a simple routine to generate trial balances for the full
company, for a project, or for a department.';


--
-- Name: save_taxform(integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION save_taxform(in_country_code integer, in_taxform_name text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
	INSERT INTO country_tax_form(country_id, form_name) 
	values (in_country_code, in_taxform_name);

	RETURN true;
END;
$$;


--
-- Name: FUNCTION save_taxform(in_country_code integer, in_taxform_name text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION save_taxform(in_country_code integer, in_taxform_name text) IS ' Saves tax form information. Returns true or raises exception.';


--
-- Name: session; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE session (
    session_id integer NOT NULL,
    token character varying(32),
    last_used timestamp without time zone DEFAULT now(),
    ttl integer DEFAULT 3600 NOT NULL,
    users_id integer NOT NULL,
    notify_pasword interval DEFAULT '7 days'::interval NOT NULL,
    CONSTRAINT session_token_check CHECK ((length((token)::text) = 32))
);


--
-- Name: TABLE session; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE session IS ' This table is used to track sessions on a database level across page 
requests (discretionary locks,open forms for anti-xsrf measures).
Because of the way LedgerSMB authentication works currently we do 
not time out authentication when the session times out.  We do time out 
highly pessimistic locks used for large batch payment workflows.';


--
-- Name: session_check(integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION session_check(in_session_id integer, in_token text) RETURNS session
    LANGUAGE plpgsql
    AS $$
DECLARE out_row session%ROWTYPE;
BEGIN
	DELETE FROM session
	 WHERE last_used < now() - coalesce((SELECT value FROM defaults
                                    WHERE setting_key = 'timeout')::interval,
	                            '90 minutes'::interval);
        UPDATE session 
           SET last_used = now()
         WHERE session_id = in_session_id
               AND token = in_token
               AND last_used > now() - (SELECT value FROM defaults
				WHERE setting_key = 'timeout')::interval
	       AND users_id = (select id from users 
			where username = SESSION_USER);
	IF FOUND THEN
		SELECT * INTO out_row FROM session WHERE session_id = in_session_id;
	ELSE
		DELETE FROM SESSION 
		WHERE users_id IN (select id from users
                        where username = SESSION_USER); 
		-- the above query also releases all discretionary locks by the
                -- session

		IF NOT FOUND THEN
			PERFORM id FROM users WHERE username = SESSION_USER;
			IF NOT FOUND THEN
				RAISE EXCEPTION 'User Not Known';
			END IF;
			
		END IF;
		INSERT INTO session(users_id, token, last_used)
		SELECT id, md5(random()::text), now()
		  FROM users WHERE username = SESSION_USER;

		SELECT * INTO out_row FROM session 
		 WHERE session_id = currval('session_session_id_seq');
	END IF;
	RETURN out_row;
END;
$$;


--
-- Name: FUNCTION session_check(in_session_id integer, in_token text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION session_check(in_session_id integer, in_token text) IS ' Returns a session row.  If no session exists, creates one.
The row returned is the current, active session.
 ';


--
-- Name: setting__get_currencies(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION setting__get_currencies() RETURNS text[]
    LANGUAGE sql
    AS $$
SELECT string_to_array(value, ':') from defaults where setting_key = 'curr';
$$;


--
-- Name: FUNCTION setting__get_currencies(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION setting__get_currencies() IS ' Returns an array of currencies from the defaults table.';


--
-- Name: defaults; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE defaults (
    setting_key text NOT NULL,
    value text
);


--
-- Name: TABLE defaults; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE defaults IS '  This is a free-form table for managing application settings per company
database.  We use key-value modelling here because this most accurately maps 
the actual semantics of the data.
';


--
-- Name: setting_get(character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION setting_get(in_key character varying) RETURNS defaults
    LANGUAGE sql
    AS $_$
SELECT * FROM defaults WHERE setting_key = $1;
$_$;


--
-- Name: FUNCTION setting_get(in_key character varying); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION setting_get(in_key character varying) IS ' Returns the value of the setting in the defaults table.';


--
-- Name: setting_get_default_accounts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION setting_get_default_accounts() RETURNS SETOF defaults
    LANGUAGE plpgsql
    AS $$
DECLARE
	account defaults%ROWTYPE;
BEGIN
	FOR account IN 
		SELECT * FROM defaults 
		WHERE setting_key like '%accno_id'
                ORDER BY setting_key
	LOOP
		RETURN NEXT account;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION setting_get_default_accounts(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION setting_get_default_accounts() IS ' Returns a set of settings for default accounts.';


--
-- Name: setting_set(character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION setting_set(in_key character varying, in_value character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE defaults SET value = in_value WHERE setting_key = in_key;
        IF NOT FOUND THEN
             INSERT INTO defaults (setting_key, value) 
                  VALUES (in_setting_key, in_value);
        END IF;
	RETURN TRUE;
END;
$$;


--
-- Name: FUNCTION setting_set(in_key character varying, in_value character varying); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION setting_set(in_key character varying, in_value character varying) IS ' sets a value in the defaults thable and returns true if successful.';


--
-- Name: tax_form__get(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION tax_form__get(in_form_id integer) RETURNS country_tax_form
    LANGUAGE sql
    AS $_$
SELECT * FROM country_tax_form where id = $1;
$_$;


--
-- Name: FUNCTION tax_form__get(in_form_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION tax_form__get(in_form_id integer) IS ' Retrieves specified tax form information from the database.';


--
-- Name: tax_form__list_all(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION tax_form__list_all() RETURNS SETOF country_tax_form
    LANGUAGE sql
    AS $$
SELECT * FROM country_tax_form ORDER BY country_id, id;
$$;


--
-- Name: FUNCTION tax_form__list_all(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION tax_form__list_all() IS ' Returns a set of all tax forms, ordered by country_id and id';


--
-- Name: tax_form__list_ext(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION tax_form__list_ext() RETURNS SETOF taxform_list
    LANGUAGE sql
    AS $$
SELECT t.id, t.form_name, t.country_id, c.name, t.default_reportable
  FROM country_tax_form t
  JOIN country c ON c.id = t.country_id
 ORDER BY c.name, t.form_name;
$$;


--
-- Name: FUNCTION tax_form__list_ext(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION tax_form__list_ext() IS ' Returns a list of tax forms with an added field, country_name, to specify the
name of the country.';


--
-- Name: tax_form__save(integer, integer, text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION tax_form__save(in_id integer, in_country_id integer, in_form_name text, in_default_reportable boolean) RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
        UPDATE country_tax_form 
           SET country_id = in_country_id,
               form_name =in_form_name,
               default_reportable = coalesce(in_default_reportable,false)
         WHERE id = in_id;

        IF FOUND THEN
           RETURN in_id;
        END IF;

	insert into country_tax_form(country_id,form_name, default_reportable) 
	values (in_country_id, in_form_name, 
                coalesce(in_default_reportable, false));

	RETURN currval('country_tax_form_id_seq');
END;
$$;


--
-- Name: FUNCTION tax_form__save(in_id integer, in_country_id integer, in_form_name text, in_default_reportable boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION tax_form__save(in_id integer, in_country_id integer, in_form_name text, in_default_reportable boolean) IS 'Saves tax form information to the database.';


--
-- Name: tax_form_details_report(integer, date, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION tax_form_details_report(in_tax_form_id integer, in_begin date, in_end date, in_meta_number text) RETURNS SETOF tax_form_report_detail_item
    LANGUAGE plpgsql
    AS $$
DECLARE
	out_row tax_form_report_detail_item;
BEGIN
	FOR out_row IN 
              SELECT entity_credit_account.id,
                     company.legal_name, company.entity_id, 
                     entity_credit_account.entity_class, entity.control_code, 
                     entity_credit_account.meta_number, 
                     sum(CASE WHEN gl.amount = 0 then 0 
                              when relation = 'acc_trans'
                          THEN ac.reportable_amount * pmt.amount
                                / gl.amount
                          ELSE 0
                      END * CASE WHEN gl.class = 'ap' THEN -1 else 1 end),
                     sum(CASE WHEN gl.amount = 0 then 0
                              WHEN relation = 'invoice'
                          THEN ac.reportable_amount * pmt.amount
                               / gl.amount
                          ELSE 0
                      END * CASE WHEN gl.class = 'ar' THEN -1 else 1 end),
                     SUM(CASE WHEN gl.amount = 0 THEN 0 
                              ELSE ac.reportable_amount * pmt.amount
                               / gl.amount 
                              END
                         * CASE WHEN gl.class = 'ap' THEN -1 else 1 end 
                         * CASE WHEN relation = 'invoice' THEN -1 ELSE 1 END),
                     gl.invnumber, gl.duedate::text, gl.id
                FROM (select id, entity_credit_account, invnumber, duedate, 
                             amount, transdate, 'ar' as class
                        FROM ar 
                       UNION 
                      select id, entity_credit_account, invnumber, duedate, 
                             amount, transdate, 'ap' as class
                        FROM ap
                     ) gl 
                JOIN (select trans_id, 'acc_trans' as relation, 
                             sum(amount) as amount,
                             sum(case when atf.reportable then amount else 0
                                 end) as reportable_amount
                        FROM  acc_trans
                   LEFT JOIN ac_tax_form atf
                          ON (acc_trans.entry_id = atf.entry_id)
                       GROUP BY trans_id
                       UNION
                      select trans_id, 'invoice' as relation, 
                             sum(sellprice * qty) as amount,
                             sum(case when itf.reportable 
                                      then sellprice * qty
                                      else 0
                                 end) as reportable_amount
                        FROM invoice
                   LEFT JOIN invoice_tax_form itf
                          ON (invoice.id = itf.invoice_id)
                       GROUP BY trans_id
                     ) ac ON (ac.trans_id = gl.id)
		JOIN entity_credit_account ON (gl.entity_credit_account = entity_credit_account.id) 
		JOIN entity ON (entity.id = entity_credit_account.entity_id) 
		JOIN company ON (entity.id = company.entity_id)
		JOIN country_tax_form ON (entity_credit_account.taxform_id = country_tax_form.id)
                JOIN (SELECT ac.trans_id, sum(ac.amount) as amount,
                             as_array(entry_id) as entry_ids, 
                             as_array(chart_id) as chart_ids,
                             count(*) as num
                        FROM acc_trans ac
                       where chart_id in (select account_id
                                            from account_link
                                           where description like '%paid')
                          AND transdate BETWEEN in_begin AND in_end
                     group by ac.trans_id
                     ) pmt ON  (pmt.trans_id = gl.id)
		WHERE country_tax_form.id = in_tax_form_id AND meta_number = in_meta_number
		GROUP BY legal_name, meta_number, company.entity_id, entity_credit_account.entity_class, entity.control_code, gl.invnumber, gl.duedate, gl.id, entity_credit_account.id
	LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION tax_form_details_report(in_tax_form_id integer, in_begin date, in_end date, in_meta_number text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION tax_form_details_report(in_tax_form_id integer, in_begin date, in_end date, in_meta_number text) IS ' This provides a list of invoices and transactions that a report hits.  This 
is intended to allow an organization to adjust what is reported on the 1099 
before printing them.';


--
-- Name: tax_form_summary_report(integer, date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION tax_form_summary_report(in_tax_form_id integer, in_begin date, in_end date) RETURNS SETOF tax_form_report_item
    LANGUAGE plpgsql
    AS $$
DECLARE
	out_row tax_form_report_item;
BEGIN
	FOR out_row IN 
              SELECT entity_credit_account.id,
                     company.legal_name, company.entity_id, 
                     entity_credit_account.entity_class, entity.control_code, 
                     entity_credit_account.meta_number, 
                     sum(CASE WHEN gl.amount = 0 THEN 0
                              WHEN relation = 'acc_trans' 
                          THEN ac.reportable_amount * pmt.amount
                                / gl.amount
                          ELSE 0
                      END * CASE WHEN gl.class = 'ap' THEN -1 else 1 end),
                     sum(CASE WHEN gl.amount = 0 THEN 0
                              WHEN relation = 'invoice'
                          THEN ac.reportable_amount * pmt.amount
                               / gl.amount
                          ELSE 0
                      END * CASE WHEN gl.class = 'ar' THEN -1 else 1 end),
                     sum(CASE WHEN gl.amount = 0 THEN 0
                          ELSE ac.reportable_amount * pmt.amount
                                / gl.amount
                      END * CASE WHEN gl.class = 'ap' THEN -1 else 1 end
                      * CASE WHEN ac.relation = 'invoice' then -1 else 1 end)
                         
		FROM (select id, transdate, entity_credit_account, invoice, 
                             amount, 'ar' as class FROM ar 
                       UNION 
                      select id, transdate, entity_credit_account, invoice, 
                              amount, 'ap' as class from ap
                     ) gl
               JOIN (select trans_id, 'acc_trans' as relation, 
                             sum(amount) as amount,
                             sum(case when atf.reportable then amount else 0
                                 end) as reportable_amount
                        FROM  acc_trans
                    LEFT JOIN ac_tax_form atf
                          ON (acc_trans.entry_id = atf.entry_id)
                       GROUP BY trans_id
                       UNION
                      select trans_id, 'invoice' as relation, 
                             sum(sellprice * qty) as amount,
                             sum(case when itf.reportable 
                                      then sellprice * qty
                                      else 0
                                 end) as reportable_amount
                        FROM invoice
                    LEFT JOIN invoice_tax_form itf
                          ON (invoice.id = itf.invoice_id)
                       GROUP BY trans_id
                     ) ac ON (ac.trans_id = gl.id 
                             AND ((gl.invoice is true and ac.relation='invoice')
                                  OR (gl.invoice is false 
                                     and ac.relation='acc_trans')))
                JOIN (SELECT ac.trans_id, sum(ac.amount) as amount,
                             as_array(entry_id) as entry_ids, 
                             as_array(chart_id) as chart_ids,
                             count(*) as num
                        FROM acc_trans ac
                       where chart_id in (select account_id
                                            from account_link
                                           where description like '%paid')
                          AND transdate BETWEEN in_begin AND in_end
                     group by ac.trans_id
                     ) pmt ON  (pmt.trans_id = gl.id)
		JOIN entity_credit_account 
                  ON (gl.entity_credit_account = entity_credit_account.id) 
		JOIN entity ON (entity.id = entity_credit_account.entity_id) 
		JOIN company ON (entity.id = company.entity_id)
		JOIN country_tax_form ON (entity_credit_account.taxform_id = country_tax_form.id)
               WHERE country_tax_form.id = in_tax_form_id
             GROUP BY legal_name, meta_number, company.entity_id, entity_credit_account.entity_class, entity.control_code, entity_credit_account.id
    LOOP
		RETURN NEXT out_row;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION tax_form_summary_report(in_tax_form_id integer, in_begin date, in_end date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION tax_form_summary_report(in_tax_form_id integer, in_begin date, in_end date) IS 'This provides the total reportable value per vendor.  As per 1099 forms, these
are cash-basis documents and show amounts paid.';


--
-- Name: to_args(text[], text[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION to_args(in_base text[], in_args text[]) RETURNS text[]
    LANGUAGE sql
    AS $_$
SELECT CASE WHEN $2[1] IS NULL OR $2[2] IS NULL THEN $1 
            ELSE $1 || ($2[1]::text || '=' || $2[2]::text)
       END;
$_$;


--
-- Name: FUNCTION to_args(in_base text[], in_args text[]); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION to_args(in_base text[], in_args text[]) IS '
This function takes two arguments.  The first is a one-dimensional array 
representing the  base state of the argument array.  The second is a two 
element array of {key, value}.

If either of the args is null, it returns the first argument.  Otherwise it 
returns the first initial array, concatenated with key || ''='' || value.

It primarily exists for the to_args aggregate.
';


--
-- Name: track_global_sequence(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION track_global_sequence() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF tg_op = 'INSERT' THEN
		INSERT INTO transactions (id, table_name) 
		VALUES (new.id, TG_RELNAME);
	ELSEIF tg_op = 'UPDATE' THEN
		IF new.id = old.id THEN
			return new;
		ELSE
			UPDATE transactions SET id = new.id WHERE id = old.id;
		END IF;
	ELSE 
		DELETE FROM transactions WHERE id = old.id;
	END IF;
	RETURN new;
END;
$$;


--
-- Name: FUNCTION track_global_sequence(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION track_global_sequence() IS ' This trigger is used to track the id sequence entries across the 
transactions table, and with the ar, ap, and gl tables.  This is necessary 
because these have not been properly refactored yet.
';


--
-- Name: trigger_parts_short(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION trigger_parts_short() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.onhand >= NEW.rop THEN
    NOTIFY parts_short;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: trigger_pending_job(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION trigger_pending_job() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.success IS NULL THEN
    NOTIFY job_entered;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: unlock(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION unlock(in_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE transactions SET locked_by = NULL WHERE id = in_id 
           AND locked_by IN (SELECT session_id FROM session WHERE users_id =
		(SELECT id FROM users WHERE username = SESSION_USER));
    RETURN FOUND;
END;
$$;


--
-- Name: FUNCTION unlock(in_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION unlock(in_id integer) IS 'Releases a pessimistic locks against a transaction, if that transaciton, as 
identified by in_id exists, and if  it is locked by the current session. 
These locks are again only advisory, and the application may choose to handle 
them or not.

Returns true if the transaction was unlocked by this routine, false 
otherwise.';


--
-- Name: unlock_all(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION unlock_all() RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE transactions SET locked_by = NULL 
    where locked_by IN 
          (select session_id from session WHERE users_id = 
                  (SELECT id FROM users WHERE username = SESSION_USER));

    RETURN FOUND;
END;
$$;


--
-- Name: FUNCTION unlock_all(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION unlock_all() IS 'Releases all pessimistic locks against transactions.  These locks are again
only advisory, and the application may choose to handle them or not.

Returns true if any transactions were unlocked, false otherwise.';


--
-- Name: user__change_password(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION user__change_password(in_new_password text) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
	t_expires timestamp;
        t_password_duration text;
BEGIN
    SELECT value INTO t_password_duration FROM defaults 
     WHERE setting_key = 'password_duration';
    IF t_password_duration IS NULL or t_password_duration='' THEN
        t_expires := 'infinity';
    ELSE
        t_expires := now() 
                     + (t_password_duration::numeric::text || ' days')::interval;
    END IF;


    UPDATE users SET notify_password = DEFAULT where username = SESSION_USER;

    EXECUTE 'ALTER USER ' || quote_ident(SESSION_USER) || 
            ' with ENCRYPTED password ' || quote_literal(in_new_password) ||
                 ' VALID UNTIL '|| quote_literal(t_expires);
    return 1;
END;
$$;


--
-- Name: FUNCTION user__change_password(in_new_password text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION user__change_password(in_new_password text) IS ' Alloes a user to change his or her own password.  The password is set to 
expire setting_get(''password_duration'') days after the password change.';


--
-- Name: user__check_my_expiration(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION user__check_my_expiration() RETURNS interval
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    outval interval;
BEGIN
    SELECT CASE WHEN isfinite(rolvaliduntil) is not true THEN '1 year'::interval
                ELSE rolvaliduntil - now() END AS expiration INTO outval 
    FROM pg_roles WHERE rolname = SESSION_USER;
    RETURN outval;
end;
$$;


--
-- Name: FUNCTION user__check_my_expiration(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION user__check_my_expiration() IS ' Returns the time when password of the current logged in user is set to 
expire.';


--
-- Name: user__expires_soon(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION user__expires_soon() RETURNS boolean
    LANGUAGE sql
    AS $$
   SELECT user__check_my_expiration() < '1 week';
$$;


--
-- Name: FUNCTION user__expires_soon(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION user__expires_soon() IS ' Returns true if the password of the current logged in user is set to expire 
within on week.';


--
-- Name: user_listable; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW user_listable AS
    SELECT u.id, u.username, e.created FROM (entity e JOIN users u ON ((u.entity_id = e.id)));


--
-- Name: user__get_all_users(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION user__get_all_users() RETURNS SETOF user_listable
    LANGUAGE sql
    AS $$
    
    select * from user_listable;
    
$$;


--
-- Name: user_preference; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_preference (
    id integer NOT NULL,
    language character varying(6),
    stylesheet text DEFAULT 'ledgersmb.css'::text NOT NULL,
    printer text,
    dateformat text DEFAULT 'yyyy-mm-dd'::text NOT NULL,
    numberformat text DEFAULT '1000.00'::text NOT NULL
);


--
-- Name: TABLE user_preference; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE user_preference IS ' This table sets the basic preferences for formats, languages, printers, and user-selected stylesheets.';


--
-- Name: user__get_preferences(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION user__get_preferences(in_user_id integer) RETURNS SETOF user_preference
    LANGUAGE plpgsql
    AS $$
    
declare
    v_row user_preference;
BEGIN
    select * into v_row from user_preference where id = in_user_id;
    
    IF NOT FOUND THEN
    
        RAISE EXCEPTION 'Could not find user preferences for id %', in_user_id;
    ELSE
        return next v_row;
    END IF;
END;
$$;


--
-- Name: FUNCTION user__get_preferences(in_user_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION user__get_preferences(in_user_id integer) IS ' Returns the preferences row for the user.';


--
-- Name: user__save_preferences(text, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION user__save_preferences(in_dateformat text, in_numberformat text, in_language text, in_stylesheet text, in_printer text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE user_preference
    SET dateformat = in_dateformat,
        numberformat = in_numberformat,
        language = in_language,
        stylesheet = in_stylesheet,
        printer = in_printer
    WHERE id = (select id from users where username = SESSION_USER);
    RETURN FOUND;
END;
$$;


--
-- Name: FUNCTION user__save_preferences(in_dateformat text, in_numberformat text, in_language text, in_stylesheet text, in_printer text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION user__save_preferences(in_dateformat text, in_numberformat text, in_language text, in_stylesheet text, in_printer text) IS ' Saves user preferences.  Returns true if successful, false if no preferences
were found to update.';


--
-- Name: voucher__delete(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION voucher__delete(in_voucher_id integer) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE 
	voucher_row RECORD;
BEGIN
	SELECT * INTO voucher_row FROM voucher WHERE id = in_voucher_id;
	IF voucher_row.batch_class IN (1, 2, 5) THEN
        DELETE FROM ac_tax_form WHERE entry_id IN (
               SELECT entry_id
                 FROM acc_trans
               WHERE trans_id = voucher_row.trans_id);
 
		DELETE FROM acc_trans WHERE trans_id = voucher_row.trans_id;
		DELETE FROM ar WHERE id = voucher_row.trans_id;
		DELETE FROM ap WHERE id = voucher_row.trans_id;
		DELETE FROM gl WHERE id = voucher_row.trans_id;
		DELETE FROM voucher WHERE id = voucher_row.id;
		-- DELETE FROM transactions WHERE id = voucher_row.trans_id;
	ELSE 
		update ar set paid = amount + 
			(select sum(amount) from acc_trans 
			join chart ON (acc_trans.chart_id = chart.id)
			where link = 'AR' AND trans_id = ar.id
				AND (voucher_id IS NULL 
				OR voucher_id <> voucher_row.id))
		where id in (select trans_id from acc_trans 
				where voucher_id = voucher_row.id);

		update ap set paid = amount - (select sum(amount) from acc_trans 
			join chart ON (acc_trans.chart_id = chart.id)
			where link = 'AP' AND trans_id = ap.id
				AND (voucher_id IS NULL 
				OR voucher_id <> voucher_row.id))
		where id in (select trans_id from acc_trans 
				where voucher_id = voucher_row.id);
                DELETE FROM ac_tax_form WHERE entry_id IN
                       (select entry_id from acc_trans 
                         where voucher_id = voucher_row.id);

		DELETE FROM acc_trans where voucher_id = voucher_row.id;
	END IF;
	RETURN 1;
END;
$$;


--
-- Name: FUNCTION voucher__delete(in_voucher_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION voucher__delete(in_voucher_id integer) IS ' Deletes the specified voucher from the batch.';


--
-- Name: batch; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE batch (
    id integer NOT NULL,
    batch_class_id integer NOT NULL,
    control_code text NOT NULL,
    description text,
    default_date date NOT NULL,
    approved_on date,
    approved_by integer,
    created_by integer,
    locked_by integer,
    created_on date DEFAULT now(),
    CONSTRAINT batch_control_code_check CHECK ((length(control_code) > 0))
);


--
-- Name: TABLE batch; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE batch IS ' Stores batch header info.  Batches are groups of vouchers that are posted
together.';


--
-- Name: COLUMN batch.batch_class_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN batch.batch_class_id IS ' Note that this field is largely used for sorting the vouchers.  A given batch is NOT restricted to this type.';


--
-- Name: voucher_get_batch(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION voucher_get_batch(in_batch_id integer) RETURNS batch
    LANGUAGE plpgsql
    AS $$
DECLARE
	batch_out batch%ROWTYPE;
BEGIN
	SELECT * INTO batch_out FROM batch b WHERE b.id = in_batch_id;
	RETURN batch_out;
END;
$$;


--
-- Name: FUNCTION voucher_get_batch(in_batch_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION voucher_get_batch(in_batch_id integer) IS ' Retrieves basic batch information based on batch_id.';


--
-- Name: voucher_list(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION voucher_list(in_batch_id integer) RETURNS SETOF voucher_list
    LANGUAGE plpgsql
    AS $$
declare voucher_item record;
BEGIN
    	FOR voucher_item IN
		SELECT v.id, a.invnumber, e.name, 
			v.batch_id, v.trans_id, 
			a.amount, a.transdate, 'Payable'
		FROM voucher v
		JOIN ap a ON (v.trans_id = a.id)
		JOIN entity_credit_account eca 
			ON (eca.id = a.entity_credit_account)
		JOIN entity e ON (eca.entity_id = e.id)
		WHERE v.batch_id = in_batch_id 
			AND v.batch_class = (select id from batch_class 
					WHERE class = 'ap')
		UNION
		SELECT v.id, a.invnumber, e.name, 
			v.batch_id, v.trans_id, 
			a.amount, a.transdate, 'Receivable'
		FROM voucher v
		JOIN ar a ON (v.trans_id = a.id)
		JOIN entity_credit_account eca 
			ON (eca.id = a.entity_credit_account)
		JOIN entity e ON (eca.entity_id = e.id)
		WHERE v.batch_id = in_batch_id 
			AND v.batch_class = (select id from batch_class 
					WHERE class = 'ar')
		UNION ALL
		-- TODO:  Add the class labels to the class table.
		SELECT v.id, a.source, 
			cr.meta_number || '--'  || co.legal_name , 
			v.batch_id, v.trans_id, 
			sum(CASE WHEN bc.class LIKE 'payment%' THEN a.amount * -1
			     ELSE a.amount  END), a.transdate, 
			CASE WHEN bc.class = 'payment' THEN 'Payment'
			     WHEN bc.class = 'payment_reversal' 
			     THEN 'Payment Reversal'
			END
		FROM voucher v
		JOIN acc_trans a ON (v.id = a.voucher_id)
                JOIN batch_class bc ON (bc.id = v.batch_class)
		JOIN chart c ON (a.chart_id = c.id)
		JOIN ap ON (ap.id = a.trans_id)
		JOIN entity_credit_account cr 
			ON (ap.entity_credit_account = cr.id)
		JOIN company co ON (cr.entity_id = co.entity_id)
		WHERE v.batch_id = in_batch_id 
			AND a.voucher_id = v.id
			AND (bc.class like 'payment%' AND c.link = 'AP')
		GROUP BY v.id, a.source, cr.meta_number, co.legal_name ,
                        v.batch_id, v.trans_id, a.transdate, bc.class

		UNION ALL
		SELECT v.id, a.source, a.memo, 
			v.batch_id, v.trans_id, 
			CASE WHEN bc.class LIKE 'receipt%' THEN sum(a.amount) * -1
			     ELSE sum(a.amount)  END, a.transdate, 
			CASE WHEN bc.class = 'receipt' THEN 'Receipt'
			     WHEN bc.class = 'receipt_reversal' 
			     THEN 'Receipt Reversal'
			END
		FROM voucher v
		JOIN acc_trans a ON (v.id = a.voucher_id)
                JOIN batch_class bc ON (bc.id = v.batch_class)
		JOIN chart c ON (a.chart_id = c.id)
		JOIN ar ON (ar.id = a.trans_id)
		JOIN entity_credit_account cr 
			ON (ar.entity_credit_account = cr.id)
		JOIN company co ON (cr.entity_id = co.entity_id)
		WHERE v.batch_id = in_batch_id 
			AND a.voucher_id = v.id
			AND (bc.class like 'receipt%' AND c.link = 'AR')
		GROUP BY v.id, a.source, cr.meta_number, co.legal_name ,
                        a.memo, v.batch_id, v.trans_id, a.transdate, bc.class
		UNION ALL
		SELECT v.id, g.reference, g.description, 
			v.batch_id, v.trans_id,
			sum(a.amount), g.transdate, 'GL'
		FROM voucher v
		JOIN gl g ON (g.id = v.trans_id)
		JOIN acc_trans a ON (v.trans_id = a.trans_id)
		WHERE a.amount > 0
			AND v.batch_id = in_batch_id
			AND v.batch_class IN (select id from batch_class 
					where class = 'gl')
		GROUP BY v.id, g.reference, g.description, v.batch_id, 
			v.trans_id, g.transdate
		ORDER BY 7, 1
	LOOP
		RETURN NEXT voucher_item;
	END LOOP;
END;
$$;


--
-- Name: FUNCTION voucher_list(in_batch_id integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION voucher_list(in_batch_id integer) IS ' Retrieves a list of vouchers and amounts attached to the batch.';


--
-- Name: warehouse; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE warehouse (
    id integer NOT NULL,
    description text
);


--
-- Name: warehouse__list_all(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION warehouse__list_all() RETURNS SETOF warehouse
    LANGUAGE sql
    AS $$
SELECT * FROM warehouse order by description;
$$;


--
-- Name: as_array(anyelement); Type: AGGREGATE; Schema: public; Owner: -
--

CREATE AGGREGATE as_array(anyelement) (
    SFUNC = array_append,
    STYPE = anyarray,
    INITCOND = '{}'
);


--
-- Name: AGGREGATE as_array(anyelement); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON AGGREGATE as_array(anyelement) IS ' A basic array aggregate to take elements and return a one-dimensional array.

Example:  SELECT as_array(id) from entity_class;
';


--
-- Name: compound_array(anyarray); Type: AGGREGATE; Schema: public; Owner: -
--

CREATE AGGREGATE compound_array(anyarray) (
    SFUNC = array_cat,
    STYPE = anyarray,
    INITCOND = '{}'
);


--
-- Name: AGGREGATE compound_array(anyarray); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON AGGREGATE compound_array(anyarray) IS ' Returns an n dimensional array.

Example: SELECT as_array(ARRAY[id::text, class]) from contact_class
';


--
-- Name: to_args(text[]); Type: AGGREGATE; Schema: public; Owner: -
--

CREATE AGGREGATE to_args(text[]) (
    SFUNC = public.to_args,
    STYPE = text[],
    INITCOND = '{}'
);


--
-- Name: AGGREGATE to_args(text[]); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON AGGREGATE to_args(text[]) IS ' Turns a setof ARRAY[key,value] into an 
ARRAY[key||''=''||value, key||''=''||value,...]
';


--
-- Name: ac_tax_form; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE ac_tax_form (
    entry_id integer NOT NULL,
    reportable boolean
);


--
-- Name: TABLE ac_tax_form; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE ac_tax_form IS ' Mapping acc_trans to country_tax_form for reporting purposes.';


--
-- Name: acc_trans_entry_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE acc_trans_entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: acc_trans_entry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE acc_trans_entry_id_seq OWNED BY acc_trans.entry_id;


--
-- Name: acc_trans_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('acc_trans_entry_id_seq', 9, true);


--
-- Name: account_checkpoint; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE account_checkpoint (
    end_date date NOT NULL,
    account_id integer NOT NULL,
    amount numeric NOT NULL,
    id integer NOT NULL,
    debits numeric,
    credits numeric
);


--
-- Name: TABLE account_checkpoint; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE account_checkpoint IS ' This table holds account balances at various dates.  Transactions MUST NOT
be posted prior to the latest end_date in this table, and no unapproved 
transactions (vouchers or drafts) can remain in the closed period.';


--
-- Name: account_checkpoint_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE account_checkpoint_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: account_checkpoint_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE account_checkpoint_id_seq OWNED BY account_checkpoint.id;


--
-- Name: account_checkpoint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('account_checkpoint_id_seq', 1, false);


--
-- Name: account_heading_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE account_heading_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: account_heading_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE account_heading_id_seq OWNED BY account_heading.id;


--
-- Name: account_heading_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('account_heading_id_seq', 12, true);


--
-- Name: account_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE account_id_seq OWNED BY account.id;


--
-- Name: account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('account_id_seq', 50, true);


--
-- Name: assembly; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE assembly (
    id integer NOT NULL,
    parts_id integer NOT NULL,
    qty numeric,
    bom boolean,
    adj boolean
);


--
-- Name: TABLE assembly; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE assembly IS 'Holds mapping for parts that are members of assemblies.';


--
-- Name: COLUMN assembly.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN assembly.id IS 'This is the id of the assembly the part is being mapped to.';


--
-- Name: COLUMN assembly.parts_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN assembly.parts_id IS 'ID of part that is a member of the assembly.';


--
-- Name: asset_class_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE asset_class_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asset_class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE asset_class_id_seq OWNED BY asset_class.id;


--
-- Name: asset_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('asset_class_id_seq', 1, false);


--
-- Name: asset_dep_method_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE asset_dep_method_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asset_dep_method_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE asset_dep_method_id_seq OWNED BY asset_dep_method.id;


--
-- Name: asset_dep_method_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('asset_dep_method_id_seq', 3, true);


--
-- Name: asset_disposal_method_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE asset_disposal_method_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asset_disposal_method_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE asset_disposal_method_id_seq OWNED BY asset_disposal_method.id;


--
-- Name: asset_disposal_method_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('asset_disposal_method_id_seq', 2, true);


--
-- Name: asset_item_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE asset_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asset_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE asset_item_id_seq OWNED BY asset_item.id;


--
-- Name: asset_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('asset_item_id_seq', 1, false);


--
-- Name: asset_report_class; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_report_class (
    id integer NOT NULL,
    class text NOT NULL
);


--
-- Name: TABLE asset_report_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE asset_report_class IS '  By default only four types of asset reports are supported.  In the future
others may be added.  Please correspond on the list before adding more types.';


--
-- Name: asset_report_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE asset_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asset_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE asset_report_id_seq OWNED BY asset_report.id;


--
-- Name: asset_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('asset_report_id_seq', 1, false);


--
-- Name: asset_report_line; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_report_line (
    asset_id bigint NOT NULL,
    report_id bigint NOT NULL,
    amount numeric,
    department_id integer,
    warehouse_id integer
);


--
-- Name: COLUMN asset_report_line.department_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN asset_report_line.department_id IS ' In case assets are moved between departments, we have to store this here.';


--
-- Name: asset_rl_to_disposal_method; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_rl_to_disposal_method (
    report_id integer NOT NULL,
    asset_id integer NOT NULL,
    disposal_method_id integer NOT NULL,
    percent_disposed numeric
);


--
-- Name: TABLE asset_rl_to_disposal_method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE asset_rl_to_disposal_method IS ' Maps disposal method to line items in the asset disposal report.';


--
-- Name: asset_unit_class; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE asset_unit_class (
    id integer NOT NULL,
    class text NOT NULL
);


--
-- Name: audittrail; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE audittrail (
    trans_id integer,
    tablename text,
    reference text,
    formname text,
    action text,
    transdate timestamp without time zone DEFAULT now(),
    person_id integer NOT NULL,
    entry_id bigint NOT NULL
);


--
-- Name: TABLE audittrail; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE audittrail IS ' This stores information on who entered or updated rows in the ar, ap, or gl
tables.';


--
-- Name: audittrail_entry_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE audittrail_entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audittrail_entry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE audittrail_entry_id_seq OWNED BY audittrail.entry_id;


--
-- Name: audittrail_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('audittrail_entry_id_seq', 5, true);


--
-- Name: batch_class_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE batch_class_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: batch_class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE batch_class_id_seq OWNED BY batch_class.id;


--
-- Name: batch_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('batch_class_id_seq', 6, true);


--
-- Name: batch_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE batch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: batch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE batch_id_seq OWNED BY batch.id;


--
-- Name: batch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('batch_id_seq', 1, false);


--
-- Name: business_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE business_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: business_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE business_id_seq OWNED BY business.id;


--
-- Name: business_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('business_id_seq', 1, false);


--
-- Name: company_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE company_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE company_id_seq OWNED BY company.id;


--
-- Name: company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('company_id_seq', 3, true);


--
-- Name: company_to_contact; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE company_to_contact (
    company_id integer NOT NULL,
    contact_class_id integer NOT NULL,
    contact text NOT NULL,
    description text,
    CONSTRAINT company_to_contact_contact_check CHECK ((contact ~ '[[:alnum:]_]'::text))
);


--
-- Name: company_to_entity; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE company_to_entity (
    company_id integer NOT NULL,
    entity_id integer NOT NULL,
    related_how text,
    created date DEFAULT ('now'::text)::date NOT NULL,
    CONSTRAINT company_to_entity_check CHECK ((company_id <> entity_id))
);


--
-- Name: TABLE company_to_entity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE company_to_entity IS ' This provides a map so that entities can also be used like groups.';


--
-- Name: company_to_location; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE company_to_location (
    location_id integer NOT NULL,
    location_class integer NOT NULL,
    company_id integer NOT NULL
);


--
-- Name: TABLE company_to_location; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE company_to_location IS ' This table is used for locations generic to companies.  For contract-bound
addresses, use eca_to_location instead ';


--
-- Name: contact_class_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE contact_class_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contact_class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE contact_class_id_seq OWNED BY contact_class.id;


--
-- Name: contact_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('contact_class_id_seq', 17, true);


--
-- Name: country_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE country_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: country_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE country_id_seq OWNED BY country.id;


--
-- Name: country_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('country_id_seq', 250, true);


--
-- Name: country_tax_form_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE country_tax_form_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: country_tax_form_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE country_tax_form_id_seq OWNED BY country_tax_form.id;


--
-- Name: country_tax_form_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('country_tax_form_id_seq', 1, false);


--
-- Name: cr_coa_to_account; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE cr_coa_to_account (
    chart_id integer NOT NULL,
    account text NOT NULL
);


--
-- Name: TABLE cr_coa_to_account; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE cr_coa_to_account IS ' Provides name mapping for the cash reconciliation screen.';


--
-- Name: cr_report_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE cr_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cr_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE cr_report_id_seq OWNED BY cr_report.id;


--
-- Name: cr_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('cr_report_id_seq', 1, false);


--
-- Name: cr_report_line_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE cr_report_line_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cr_report_line_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE cr_report_line_id_seq OWNED BY cr_report_line.id;


--
-- Name: cr_report_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('cr_report_line_id_seq', 1, false);


--
-- Name: custom_field_catalog; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE custom_field_catalog (
    field_id integer NOT NULL,
    table_id integer,
    field_name text
);


--
-- Name: TABLE custom_field_catalog; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE custom_field_catalog IS ' Deprecated, use only with old code.';


--
-- Name: custom_field_catalog_field_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE custom_field_catalog_field_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_field_catalog_field_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE custom_field_catalog_field_id_seq OWNED BY custom_field_catalog.field_id;


--
-- Name: custom_field_catalog_field_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('custom_field_catalog_field_id_seq', 1, false);


--
-- Name: custom_table_catalog; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE custom_table_catalog (
    table_id integer NOT NULL,
    extends text,
    table_name text
);


--
-- Name: TABLE custom_table_catalog; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE custom_table_catalog IS ' Deprecated, use only with old code.';


--
-- Name: custom_table_catalog_table_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE custom_table_catalog_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_table_catalog_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE custom_table_catalog_table_id_seq OWNED BY custom_table_catalog.table_id;


--
-- Name: custom_table_catalog_table_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('custom_table_catalog_table_id_seq', 1, false);


--
-- Name: department_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE department_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE department_id_seq OWNED BY department.id;


--
-- Name: department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('department_id_seq', 1, false);


--
-- Name: dpt_trans; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE dpt_trans (
    trans_id integer NOT NULL,
    department_id integer
);


--
-- Name: TABLE dpt_trans; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE dpt_trans IS 'Department to Transaction Map';


--
-- Name: eca_note; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE eca_note (
    CONSTRAINT eca_note_note_class_check CHECK ((note_class = 3))
)
INHERITS (note);


--
-- Name: TABLE eca_note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE eca_note IS ' Notes for entity_credit_account entries.';


--
-- Name: COLUMN eca_note.ref_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN eca_note.ref_key IS ' references entity_credit_account.id';


--
-- Name: eca_to_contact; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE eca_to_contact (
    credit_id integer NOT NULL,
    contact_class_id integer NOT NULL,
    contact text NOT NULL,
    description text,
    CONSTRAINT eca_to_contact_contact_check CHECK ((contact ~ '[[:alnum:]_]'::text))
);


--
-- Name: TABLE eca_to_contact; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE eca_to_contact IS ' To keep track of the relationship between multiple contact methods and a single vendor or customer account. For generic 
contacts, use company_to_contact or person_to_contact instead.';


--
-- Name: eca_to_location; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE eca_to_location (
    location_id integer NOT NULL,
    location_class integer NOT NULL,
    credit_id integer NOT NULL
);


--
-- Name: TABLE eca_to_location; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE eca_to_location IS ' This table is used for locations bound to contracts.  For generic contact
addresses, use company_to_location instead ';


--
-- Name: entity_bank_account_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE entity_bank_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: entity_bank_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE entity_bank_account_id_seq OWNED BY entity_bank_account.id;


--
-- Name: entity_bank_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('entity_bank_account_id_seq', 1, false);


--
-- Name: entity_class_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE entity_class_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: entity_class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE entity_class_id_seq OWNED BY entity_class.id;


--
-- Name: entity_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('entity_class_id_seq', 7, true);


--
-- Name: entity_class_to_entity; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE entity_class_to_entity (
    entity_class_id integer NOT NULL,
    entity_id integer NOT NULL
);


--
-- Name: TABLE entity_class_to_entity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE entity_class_to_entity IS ' Relation builder for classes to entity ';


--
-- Name: entity_credit_account_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE entity_credit_account_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: entity_credit_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE entity_credit_account_id_seq OWNED BY entity_credit_account.id;


--
-- Name: entity_credit_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('entity_credit_account_id_seq', 4, true);


--
-- Name: entity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE entity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: entity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE entity_id_seq OWNED BY entity.id;


--
-- Name: entity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('entity_id_seq', 3, true);


--
-- Name: entity_other_name; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE entity_other_name (
    entity_id integer NOT NULL,
    other_name text NOT NULL,
    CONSTRAINT entity_other_name_other_name_check CHECK ((other_name ~ '[[:alnum:]_]'::text))
);


--
-- Name: TABLE entity_other_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE entity_other_name IS ' Similar to company_other_name, a person
may be jd, Joshua Drake, linuxpoet... all are the same person.  Currently
unused in the front-end but will likely be added in future versions.';


--
-- Name: exchangerate; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE exchangerate (
    curr character(3) NOT NULL,
    transdate date NOT NULL,
    buy numeric,
    sell numeric
);


--
-- Name: TABLE exchangerate; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE exchangerate IS ' When you receive money in a foreign currency, it is worth to you in your local currency
whatever you can get for it when you sell the acquired currency (sell rate).
When you have to pay someone in a foreign currency, the equivalent amount is the amount
you have to spend to acquire the foreign currency (buy rate).';


--
-- Name: file_base_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE file_base_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: file_base_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE file_base_id_seq OWNED BY file_base.id;


--
-- Name: file_base_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('file_base_id_seq', 1, false);


--
-- Name: file_class; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE file_class (
    id integer NOT NULL,
    class text NOT NULL
);


--
-- Name: TABLE file_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE file_class IS ' File classes are collections of files attached against rows in specific 
tables in the database.  They can be used in the future to implement other form 
of file attachment. ';


--
-- Name: file_class_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE file_class_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: file_class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE file_class_id_seq OWNED BY file_class.id;


--
-- Name: file_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('file_class_id_seq', 1, false);


--
-- Name: file_order; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE file_order (
    CONSTRAINT file_order_file_class_check CHECK ((file_class = 2))
)
INHERITS (file_base);


--
-- Name: TABLE file_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE file_order IS ' File attachments primarily attached to orders and quotations.';


--
-- Name: file_order_to_order; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE file_order_to_order (
    CONSTRAINT file_order_to_order_dest_class_check CHECK ((dest_class = 2)),
    CONSTRAINT file_order_to_order_source_class_check CHECK ((source_class = 2))
)
INHERITS (file_secondary_attachment);


--
-- Name: TABLE file_order_to_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE file_order_to_order IS ' Secondary links from one order to another, for example to support order
consolidation.';


--
-- Name: file_order_to_tx; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE file_order_to_tx (
    CONSTRAINT file_order_to_tx_dest_class_check CHECK ((dest_class = 1)),
    CONSTRAINT file_order_to_tx_source_class_check CHECK ((source_class = 2))
)
INHERITS (file_secondary_attachment);


--
-- Name: TABLE file_order_to_tx; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE file_order_to_tx IS ' Secondary links from orders to transactions, for example to track files when
invoices are generated from orders.';


--
-- Name: file_part; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE file_part (
    CONSTRAINT file_part_file_class_check CHECK ((file_class = 3))
)
INHERITS (file_base);


--
-- Name: TABLE file_part; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE file_part IS ' File attachments primarily attached to orders and quotations.';


--
-- Name: file_transaction; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE file_transaction (
    CONSTRAINT file_transaction_file_class_check CHECK ((file_class = 1))
)
INHERITS (file_base);


--
-- Name: TABLE file_transaction; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE file_transaction IS ' File attachments primarily attached to AR/AP/GL.';


--
-- Name: file_tx_to_order; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE file_tx_to_order (
    CONSTRAINT file_tx_to_order_dest_class_check CHECK ((dest_class = 2)),
    CONSTRAINT file_tx_to_order_source_class_check CHECK ((source_class = 1))
)
INHERITS (file_secondary_attachment);


--
-- Name: TABLE file_tx_to_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE file_tx_to_order IS ' Secondary links from transactions to orders.';


--
-- Name: file_view_catalog; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE file_view_catalog (
    file_class integer NOT NULL,
    view_name text NOT NULL
);


--
-- Name: gifi; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE gifi (
    accno text NOT NULL,
    description text
);


--
-- Name: TABLE gifi; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE gifi IS ' GIFI labels for accounts, used in Canada and some EU countries for tax 
reporting';


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE inventory (
    entity_id integer,
    warehouse_id integer,
    parts_id integer,
    trans_id integer,
    orderitems_id integer,
    qty numeric,
    shippingdate date,
    entry_id integer NOT NULL
);


--
-- Name: TABLE inventory; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE inventory IS ' This table contains inventory mappings to warehouses, not general inventory
management data.';


--
-- Name: inventory_entry_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE inventory_entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_entry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE inventory_entry_id_seq OWNED BY inventory.entry_id;


--
-- Name: inventory_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('inventory_entry_id_seq', 1, false);


--
-- Name: invoice; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE invoice (
    id integer NOT NULL,
    trans_id integer,
    parts_id integer,
    description text,
    qty numeric,
    allocated integer,
    sellprice numeric,
    "precision" integer,
    fxsellprice numeric,
    discount numeric,
    assemblyitem boolean DEFAULT false,
    unit character varying(5),
    project_id integer,
    deliverydate date,
    serialnumber text,
    notes text
);


--
-- Name: TABLE invoice; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE invoice IS 'Line items of invoices with goods/services attached.';


--
-- Name: COLUMN invoice.qty; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN invoice.qty IS 'Positive is normal for sales invoices, negative for vendor invoices.';


--
-- Name: COLUMN invoice.allocated; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN invoice.allocated IS 'Number of allocated items, negative relative to qty.
When qty + allocated = 0, then the item is fully used for purposes of COGS 
calculations.';


--
-- Name: invoice_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE invoice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invoice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE invoice_id_seq OWNED BY invoice.id;


--
-- Name: invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('invoice_id_seq', 2, true);


--
-- Name: invoice_note; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE invoice_note (
)
INHERITS (note);


--
-- Name: invoice_tax_form; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE invoice_tax_form (
    invoice_id integer NOT NULL,
    reportable boolean
);


--
-- Name: TABLE invoice_tax_form; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE invoice_tax_form IS ' Maping invoice to country_tax_form.';


--
-- Name: jcitems; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE jcitems (
    id integer NOT NULL,
    project_id integer,
    parts_id integer,
    description text,
    qty numeric,
    allocated numeric,
    sellprice numeric,
    fxsellprice numeric,
    serialnumber text,
    checkedin timestamp with time zone,
    checkedout timestamp with time zone,
    person_id integer NOT NULL,
    notes text,
    total numeric NOT NULL,
    non_billable numeric DEFAULT 0 NOT NULL
);


--
-- Name: TABLE jcitems; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE jcitems IS ' Time and materials cards. 
Materials cards not implemented.';


--
-- Name: jcitems_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE jcitems_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jcitems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE jcitems_id_seq OWNED BY jcitems.id;


--
-- Name: jcitems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('jcitems_id_seq', 1, false);


--
-- Name: location_class_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE location_class_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: location_class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE location_class_id_seq OWNED BY location_class.id;


--
-- Name: location_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('location_class_id_seq', 4, true);


--
-- Name: location_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE location_id_seq OWNED BY location.id;


--
-- Name: location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('location_id_seq', 1, false);


--
-- Name: lsmb_roles; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE lsmb_roles (
    user_id integer NOT NULL,
    role text NOT NULL
);


--
-- Name: TABLE lsmb_roles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE lsmb_roles IS ' Tracks role assignments in the front end.  Not sure why we need this.  Will
rethink for 1.4.
';


--
-- Name: makemodel; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE makemodel (
    parts_id integer NOT NULL,
    make text,
    model text
);


--
-- Name: TABLE makemodel; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE makemodel IS ' A single parts entry can have multiple make/model entries.  These
store manufacturer/model number info.';


--
-- Name: menu_acl; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE menu_acl (
    id integer NOT NULL,
    role_name character varying NOT NULL,
    acl_type character varying,
    node_id integer NOT NULL,
    CONSTRAINT menu_acl_acl_type_check CHECK ((((acl_type)::text = 'allow'::text) OR ((acl_type)::text = 'deny'::text)))
);


--
-- Name: TABLE menu_acl; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE menu_acl IS 'Provides access control list entries for menu nodes.';


--
-- Name: COLUMN menu_acl.acl_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN menu_acl.acl_type IS ' Nodes are hidden unless a role is found of which the user is a member, and
where the acl_type for that role type and node is set to ''allow'' and no acl is 
found for any role of which the user is a member, where the acl_type is set to
''deny''.';


--
-- Name: menu_acl_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE menu_acl_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menu_acl_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE menu_acl_id_seq OWNED BY menu_acl.id;


--
-- Name: menu_acl_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('menu_acl_id_seq', 293, true);


--
-- Name: menu_attribute; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE menu_attribute (
    node_id integer NOT NULL,
    attribute character varying NOT NULL,
    value character varying NOT NULL,
    id integer NOT NULL
);


--
-- Name: TABLE menu_attribute; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE menu_attribute IS ' This table stores the callback information for each menu item.  The 
attributes are stored in key/value modelling because of the fact that this
best matches the semantic structure of the information.

Each node should have EITHER a menu or a module attribute, menu for a menu with 
sub-items, module for an executiable script.  The module attribute identifies
the perl script to be run.  The action attribute identifies the entry point.

Beyond this, any other attributes that should be passed in can be done as other
attributes.
';


--
-- Name: menu_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE menu_attribute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menu_attribute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE menu_attribute_id_seq OWNED BY menu_attribute.id;


--
-- Name: menu_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('menu_attribute_id_seq', 649, true);


--
-- Name: menu_node; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE menu_node (
    id integer NOT NULL,
    label character varying NOT NULL,
    parent integer,
    "position" integer NOT NULL
);


--
-- Name: TABLE menu_node; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE menu_node IS 'This table stores the tree structure of the menu.';


--
-- Name: menu_friendly; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW menu_friendly AS
    SELECT t.level, t.path, t.list_order, (repeat(' '::text, (2 * t.level)) || (n.label)::text) AS label, n.id, n."position" FROM (connectby('menu_node'::text, 'id'::text, 'parent'::text, 'position'::text, '0'::text, 0, ','::text) t(id integer, parent integer, level integer, path text, list_order integer) JOIN menu_node n USING (id));


--
-- Name: VIEW menu_friendly; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW menu_friendly IS ' A nice human-readable view for investigating the menu tree.  Does not
show menu attributes or acls.';


--
-- Name: menu_node_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE menu_node_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menu_node_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE menu_node_id_seq OWNED BY menu_node.id;


--
-- Name: menu_node_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('menu_node_id_seq', 242, true);


--
-- Name: mime_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE mime_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mime_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE mime_type_id_seq OWNED BY mime_type.id;


--
-- Name: mime_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('mime_type_id_seq', 684, true);


--
-- Name: new_shipto; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE new_shipto (
    id integer NOT NULL,
    trans_id integer,
    oe_id integer,
    location_id integer
);


--
-- Name: TABLE new_shipto; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE new_shipto IS ' Tracks ship_to information for orders and invoices.';


--
-- Name: new_shipto_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE new_shipto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: new_shipto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE new_shipto_id_seq OWNED BY new_shipto.id;


--
-- Name: new_shipto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('new_shipto_id_seq', 1, false);


--
-- Name: note_class; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE note_class (
    id integer NOT NULL,
    class text NOT NULL,
    CONSTRAINT note_class_class_check CHECK ((class ~ '[[:alnum:]_]'::text))
);


--
-- Name: TABLE note_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE note_class IS ' Coordinate with others before adding entries. ';


--
-- Name: note_class_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE note_class_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: note_class_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE note_class_id_seq OWNED BY note_class.id;


--
-- Name: note_class_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('note_class_id_seq', 1, false);


--
-- Name: oe_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE oe_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oe_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE oe_id_seq OWNED BY oe.id;


--
-- Name: oe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('oe_id_seq', 1, false);


--
-- Name: open_forms; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE open_forms (
    id integer NOT NULL,
    session_id integer
);


--
-- Name: TABLE open_forms; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE open_forms IS ' This is our primary anti-xsrf measure, as this allows us to require a full
round trip to the web server in order to save data.';


--
-- Name: open_forms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE open_forms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: open_forms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE open_forms_id_seq OWNED BY open_forms.id;


--
-- Name: open_forms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('open_forms_id_seq', 23, true);


--
-- Name: orderitems; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE orderitems (
    id integer NOT NULL,
    trans_id integer,
    parts_id integer,
    description text,
    qty numeric,
    sellprice numeric,
    "precision" integer,
    discount numeric,
    unit character varying(5),
    project_id integer,
    reqdate date,
    ship numeric,
    serialnumber text,
    notes text
);


--
-- Name: TABLE orderitems; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE orderitems IS ' Line items for sales/purchase orders and quotations.';


--
-- Name: orderitems_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE orderitems_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orderitems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE orderitems_id_seq OWNED BY orderitems.id;


--
-- Name: orderitems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('orderitems_id_seq', 1, false);


--
-- Name: parts; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE parts (
    id integer NOT NULL,
    partnumber text,
    description text,
    unit character varying(5),
    listprice numeric,
    sellprice numeric,
    lastcost numeric,
    priceupdate date DEFAULT ('now'::text)::date,
    weight numeric,
    onhand numeric DEFAULT 0,
    notes text,
    makemodel boolean DEFAULT false,
    assembly boolean DEFAULT false,
    alternate boolean DEFAULT false,
    rop numeric,
    inventory_accno_id integer,
    income_accno_id integer,
    expense_accno_id integer,
    bin text,
    obsolete boolean DEFAULT false,
    bom boolean DEFAULT false,
    image text,
    drawing text,
    microfiche text,
    partsgroup_id integer,
    project_id integer,
    avgcost numeric
);


--
-- Name: TABLE parts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE parts IS 'This stores detail information about goods and services.  The type of part
is currently defined according to the following rules:
* If assembly is true, then an assembly
* If inventory_accno_id, income_accno_id, and expense_accno_id are not null then
  a part.
* If inventory_accno_id is null but the other two are not, then a service.
* Otherwise, a labor/overhead entry.
';


--
-- Name: COLUMN parts.rop; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN parts.rop IS 'Re-order point.  Used to select parts for short inventory report.';


--
-- Name: COLUMN parts.bin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN parts.bin IS 'Text identifier for where a part is stored.';


--
-- Name: COLUMN parts.bom; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN parts.bom IS 'Show on Bill of Materials.';


--
-- Name: COLUMN parts.image; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN parts.image IS 'Hyperlink to product image.';


--
-- Name: parts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE parts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: parts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE parts_id_seq OWNED BY parts.id;


--
-- Name: parts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('parts_id_seq', 2, true);


--
-- Name: translation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE translation (
    trans_id integer NOT NULL,
    language_code character varying(6) NOT NULL,
    description text
);


--
-- Name: TABLE translation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE translation IS 'abstract table for manual translation data. Should have zero rows.';


--
-- Name: parts_translation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE parts_translation (
)
INHERITS (translation);


--
-- Name: TABLE parts_translation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE parts_translation IS ' Translation information for parts.';


--
-- Name: partscustomer; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE partscustomer (
    parts_id integer,
    credit_id integer,
    pricegroup_id integer,
    pricebreak numeric,
    sellprice numeric,
    validfrom date,
    validto date,
    curr character(3),
    entry_id integer NOT NULL
);


--
-- Name: TABLE partscustomer; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE partscustomer IS ' Tracks per-customer pricing.  Discounts can be offered for periods of time
and for pricegroups as well as per customer';


--
-- Name: partscustomer_entry_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE partscustomer_entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: partscustomer_entry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE partscustomer_entry_id_seq OWNED BY partscustomer.entry_id;


--
-- Name: partscustomer_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('partscustomer_entry_id_seq', 1, false);


--
-- Name: partsgroup; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE partsgroup (
    id integer NOT NULL,
    partsgroup text
);


--
-- Name: TABLE partsgroup; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE partsgroup IS ' Groups of parts for Point of Sale screen.';


--
-- Name: partsgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE partsgroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: partsgroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE partsgroup_id_seq OWNED BY partsgroup.id;


--
-- Name: partsgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('partsgroup_id_seq', 1, false);


--
-- Name: partsgroup_translation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE partsgroup_translation (
)
INHERITS (translation);


--
-- Name: TABLE partsgroup_translation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE partsgroup_translation IS ' Translation information for partsgroups.';


--
-- Name: partstax; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE partstax (
    parts_id integer NOT NULL,
    chart_id integer NOT NULL,
    taxcategory_id integer
);


--
-- Name: TABLE partstax; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE partstax IS ' Mapping of parts to taxes.';


--
-- Name: partsvendor; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE partsvendor (
    credit_id integer NOT NULL,
    parts_id integer,
    partnumber text,
    leadtime smallint,
    lastcost numeric,
    curr character(3),
    entry_id integer NOT NULL
);


--
-- Name: TABLE partsvendor; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE partsvendor IS ' Tracks vendor''s pricing, as well as vendor''s part number, lead time 
required and currency.';


--
-- Name: partsvendor_entry_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE partsvendor_entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: partsvendor_entry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE partsvendor_entry_id_seq OWNED BY partsvendor.entry_id;


--
-- Name: partsvendor_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('partsvendor_entry_id_seq', 1, false);


--
-- Name: payment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE payment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE payment_id_seq OWNED BY payment.id;


--
-- Name: payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('payment_id_seq', 2, true);


--
-- Name: payment_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE payment_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE payment_type_id_seq OWNED BY payment_type.id;


--
-- Name: payment_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('payment_type_id_seq', 1, false);


--
-- Name: pending_job; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE pending_job (
    id integer NOT NULL,
    batch_class integer,
    entered_by text DEFAULT "session_user"() NOT NULL,
    entered_at timestamp without time zone DEFAULT now(),
    batch_id integer,
    completed_at timestamp without time zone,
    success boolean,
    error_condition text,
    CONSTRAINT pending_job_check CHECK (((completed_at IS NULL) OR (success IS NOT NULL))),
    CONSTRAINT pending_job_check1 CHECK (((success IS NOT FALSE) OR (error_condition IS NOT NULL)))
);


--
-- Name: TABLE pending_job; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE pending_job IS ' Purpose:  This table stores pending/queued jobs to be processed async.
Additionally, this functions as a log of all such processing for purposes of 
internal audits, performance tuning, and the like. ';


--
-- Name: pending_job_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE pending_job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pending_job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE pending_job_id_seq OWNED BY pending_job.id;


--
-- Name: pending_job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('pending_job_id_seq', 1, false);


--
-- Name: payments_queue; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE payments_queue (
    transactions numeric[],
    batch_id integer,
    source text,
    total numeric,
    ar_ap_accno text,
    cash_accno text,
    payment_date date,
    account_class integer,
    job_id integer DEFAULT currval('pending_job_id_seq'::regclass)
);


--
-- Name: TABLE payments_queue; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE payments_queue IS ' This is a holding table and hence not a candidate for normalization.
Jobs should be deleted from this table when they complete successfully.';


--
-- Name: person_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE person_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: person_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE person_id_seq OWNED BY person.id;


--
-- Name: person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('person_id_seq', 1, true);


--
-- Name: person_to_company; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE person_to_company (
    location_id integer NOT NULL,
    person_id integer NOT NULL,
    company_id integer NOT NULL
);


--
-- Name: TABLE person_to_company; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE person_to_company IS ' currently unused in the front-end, but can be used to map persons
to companies.';


--
-- Name: person_to_contact; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE person_to_contact (
    person_id integer NOT NULL,
    contact_class_id integer NOT NULL,
    contact text NOT NULL,
    description text,
    CONSTRAINT person_to_contact_contact_check CHECK ((contact ~ '[[:alnum:]_]'::text))
);


--
-- Name: TABLE person_to_contact; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE person_to_contact IS ' This table stores contact information for companies';


--
-- Name: person_to_entity; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE person_to_entity (
    person_id integer NOT NULL,
    entity_id integer NOT NULL,
    related_how text,
    created date DEFAULT ('now'::text)::date NOT NULL,
    CONSTRAINT person_to_entity_check CHECK ((entity_id <> person_id))
);


--
-- Name: TABLE person_to_entity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE person_to_entity IS ' This provides a map so that entities can also be used like groups.';


--
-- Name: person_to_location; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE person_to_location (
    location_id integer NOT NULL,
    location_class integer NOT NULL,
    person_id integer NOT NULL
);


--
-- Name: pricegroup; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE pricegroup (
    id integer NOT NULL,
    pricegroup text
);


--
-- Name: TABLE pricegroup; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE pricegroup IS ' Pricegroups are groups of customers who are assigned prices and discounts
together.';


--
-- Name: pricegroup_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE pricegroup_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pricegroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE pricegroup_id_seq OWNED BY pricegroup.id;


--
-- Name: pricegroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('pricegroup_id_seq', 1, false);


--
-- Name: project_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE project_id_seq OWNED BY project.id;


--
-- Name: project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('project_id_seq', 1, false);


--
-- Name: project_translation; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE project_translation (
)
INHERITS (translation);


--
-- Name: TABLE project_translation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE project_translation IS ' Translation information for projects.';


--
-- Name: recurring; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE recurring (
    id integer DEFAULT nextval('id'::regclass) NOT NULL,
    reference text,
    startdate date,
    nextdate date,
    enddate date,
    repeat smallint,
    unit character varying(6),
    howmany integer,
    payment boolean DEFAULT false
);


--
-- Name: TABLE recurring; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE recurring IS ' Stores recurring information on transactions which will recur in the future.
Note that this means that only fully posted transactions can recur. 
I would highly recommend depricating this table and working instead on extending
the template transaction addon to handle recurring information.';


--
-- Name: recurringemail; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE recurringemail (
    id integer NOT NULL,
    formname text NOT NULL,
    format text,
    message text
);


--
-- Name: TABLE recurringemail; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE recurringemail IS 'Email  to be sent out when recurring transaction is posted.';


--
-- Name: recurringprint; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE recurringprint (
    id integer NOT NULL,
    formname text NOT NULL,
    format text,
    printer text
);


--
-- Name: TABLE recurringprint; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE recurringprint IS ' Template, printer etc. to print to when recurring transaction posts.';


--
-- Name: role_view; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW role_view AS
    SELECT m.roleid, m.member, m.grantor, m.admin_option, a.rolname, a.rolsuper, a.rolinherit, a.rolcreaterole, a.rolcreatedb, a.rolcatupdate, a.rolcanlogin, a.rolreplication, a.rolconnlimit, a.rolpassword, a.rolvaliduntil, a.rolconfig, a.oid FROM (pg_auth_members m JOIN pg_roles a ON ((m.roleid = a.oid)));


--
-- Name: salutation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE salutation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: salutation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE salutation_id_seq OWNED BY salutation.id;


--
-- Name: salutation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('salutation_id_seq', 7, true);


--
-- Name: session_session_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE session_session_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: session_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE session_session_id_seq OWNED BY session.session_id;


--
-- Name: session_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('session_session_id_seq', 1, true);


--
-- Name: sic; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE sic (
    code character varying(6) NOT NULL,
    sictype character(1),
    description text
);


--
-- Name: TABLE sic; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE sic IS '
This can be used SIC codes or any equivalent, such as ISIC, NAICS, etc.
';


--
-- Name: status; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE status (
    trans_id integer NOT NULL,
    formname text NOT NULL,
    printed boolean DEFAULT false,
    emailed boolean DEFAULT false,
    spoolfile text
);


--
-- Name: TABLE status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE status IS ' Whether AR/AP transactions and invoices have been emailed and/or printed ';


--
-- Name: tax; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tax (
    chart_id integer NOT NULL,
    rate numeric,
    taxnumber text,
    validto timestamp without time zone DEFAULT 'infinity'::timestamp without time zone NOT NULL,
    pass integer DEFAULT 0 NOT NULL,
    taxmodule_id integer DEFAULT 1 NOT NULL
);


--
-- Name: TABLE tax; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE tax IS 'Information on tax rates.';


--
-- Name: COLUMN tax.pass; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN tax.pass IS 'This is an integer indicating the pass of the tax. This is to support 
cumultative sales tax rules (for example, Quebec charging taxes on the federal
taxes collected).';


--
-- Name: tax_extended; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE tax_extended (
    tax_basis numeric,
    rate numeric,
    entry_id integer NOT NULL
);


--
-- Name: TABLE tax_extended; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE tax_extended IS ' This stores extended information for manual tax calculations.';


--
-- Name: taxcategory; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE taxcategory (
    taxcategory_id integer NOT NULL,
    taxcategoryname text NOT NULL,
    taxmodule_id integer NOT NULL
);


--
-- Name: taxcategory_taxcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE taxcategory_taxcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taxcategory_taxcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE taxcategory_taxcategory_id_seq OWNED BY taxcategory.taxcategory_id;


--
-- Name: taxcategory_taxcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('taxcategory_taxcategory_id_seq', 1, false);


--
-- Name: taxmodule; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE taxmodule (
    taxmodule_id integer NOT NULL,
    taxmodulename text NOT NULL
);


--
-- Name: TABLE taxmodule; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE taxmodule IS 'This is used to store information on tax modules.  the module name is used
to determine the Perl class for the taxes.';


--
-- Name: taxmodule_taxmodule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE taxmodule_taxmodule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: taxmodule_taxmodule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE taxmodule_taxmodule_id_seq OWNED BY taxmodule.taxmodule_id;


--
-- Name: taxmodule_taxmodule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('taxmodule_taxmodule_id_seq', 1, false);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE transactions (
    id integer NOT NULL,
    table_name text,
    locked_by integer,
    approved_by integer,
    approved_at timestamp without time zone
);


--
-- Name: TABLE transactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE transactions IS ' This table provides referential integrity between AR, AP, GL tables on one
hand and acc_trans on the other, pending the refactoring of those tables.  It
also is used to provide discretionary locking of financial transactions across 
database connections, for example in batch payment workflows.';


--
-- Name: COLUMN transactions.locked_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN transactions.locked_by IS ' This should only be used in pessimistic locking measures as required by large
batch work flows. ';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_id_seq', 1, true);


--
-- Name: vendortax; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE vendortax (
    vendor_id integer NOT NULL,
    chart_id integer NOT NULL
);


--
-- Name: TABLE vendortax; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE vendortax IS ' Mapping vendor to taxes.';


--
-- Name: voucher; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE voucher (
    trans_id integer NOT NULL,
    batch_id integer NOT NULL,
    id integer NOT NULL,
    batch_class integer NOT NULL
);


--
-- Name: TABLE voucher; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE voucher IS 'Mapping transactions to batches for batch approval.';


--
-- Name: COLUMN voucher.id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN voucher.id IS ' This is simply a surrogate key for easy reference.';


--
-- Name: COLUMN voucher.batch_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN voucher.batch_class IS ' This is the authoritative class of the 
voucher. ';


--
-- Name: voucher_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE voucher_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: voucher_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE voucher_id_seq OWNED BY voucher.id;


--
-- Name: voucher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('voucher_id_seq', 1, false);


--
-- Name: warehouse_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE warehouse_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: warehouse_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE warehouse_id_seq OWNED BY warehouse.id;


--
-- Name: warehouse_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('warehouse_id_seq', 1, false);


--
-- Name: yearend; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE yearend (
    trans_id integer NOT NULL,
    reversed boolean DEFAULT false,
    transdate date
);


--
-- Name: TABLE yearend; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE yearend IS ' An extension to the gl table to track transactionsactions which close out 
the books at yearend.';


--
-- Name: entry_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE acc_trans ALTER COLUMN entry_id SET DEFAULT nextval('acc_trans_entry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE account ALTER COLUMN id SET DEFAULT nextval('account_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE account_checkpoint ALTER COLUMN id SET DEFAULT nextval('account_checkpoint_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE account_heading ALTER COLUMN id SET DEFAULT nextval('account_heading_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE asset_class ALTER COLUMN id SET DEFAULT nextval('asset_class_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE asset_dep_method ALTER COLUMN id SET DEFAULT nextval('asset_dep_method_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE asset_disposal_method ALTER COLUMN id SET DEFAULT nextval('asset_disposal_method_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE asset_item ALTER COLUMN id SET DEFAULT nextval('asset_item_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE asset_report ALTER COLUMN id SET DEFAULT nextval('asset_report_id_seq'::regclass);


--
-- Name: entry_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE audittrail ALTER COLUMN entry_id SET DEFAULT nextval('audittrail_entry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE batch ALTER COLUMN id SET DEFAULT nextval('batch_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE batch_class ALTER COLUMN id SET DEFAULT nextval('batch_class_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE business ALTER COLUMN id SET DEFAULT nextval('business_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE company ALTER COLUMN id SET DEFAULT nextval('company_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE contact_class ALTER COLUMN id SET DEFAULT nextval('contact_class_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE country ALTER COLUMN id SET DEFAULT nextval('country_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE country_tax_form ALTER COLUMN id SET DEFAULT nextval('country_tax_form_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE cr_report ALTER COLUMN id SET DEFAULT nextval('cr_report_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE cr_report_line ALTER COLUMN id SET DEFAULT nextval('cr_report_line_id_seq'::regclass);


--
-- Name: field_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE custom_field_catalog ALTER COLUMN field_id SET DEFAULT nextval('custom_field_catalog_field_id_seq'::regclass);


--
-- Name: table_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE custom_table_catalog ALTER COLUMN table_id SET DEFAULT nextval('custom_table_catalog_table_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE department ALTER COLUMN id SET DEFAULT nextval('department_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE entity ALTER COLUMN id SET DEFAULT nextval('entity_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE entity_bank_account ALTER COLUMN id SET DEFAULT nextval('entity_bank_account_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE entity_class ALTER COLUMN id SET DEFAULT nextval('entity_class_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE entity_credit_account ALTER COLUMN id SET DEFAULT nextval('entity_credit_account_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE file_base ALTER COLUMN id SET DEFAULT nextval('file_base_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE file_class ALTER COLUMN id SET DEFAULT nextval('file_class_id_seq'::regclass);


--
-- Name: entry_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE inventory ALTER COLUMN entry_id SET DEFAULT nextval('inventory_entry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE invoice ALTER COLUMN id SET DEFAULT nextval('invoice_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE jcitems ALTER COLUMN id SET DEFAULT nextval('jcitems_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE location ALTER COLUMN id SET DEFAULT nextval('location_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE location_class ALTER COLUMN id SET DEFAULT nextval('location_class_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE menu_acl ALTER COLUMN id SET DEFAULT nextval('menu_acl_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE menu_attribute ALTER COLUMN id SET DEFAULT nextval('menu_attribute_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE menu_node ALTER COLUMN id SET DEFAULT nextval('menu_node_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE mime_type ALTER COLUMN id SET DEFAULT nextval('mime_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE new_shipto ALTER COLUMN id SET DEFAULT nextval('new_shipto_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE note ALTER COLUMN id SET DEFAULT nextval('note_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE note_class ALTER COLUMN id SET DEFAULT nextval('note_class_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE oe ALTER COLUMN id SET DEFAULT nextval('oe_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE open_forms ALTER COLUMN id SET DEFAULT nextval('open_forms_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE orderitems ALTER COLUMN id SET DEFAULT nextval('orderitems_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE parts ALTER COLUMN id SET DEFAULT nextval('parts_id_seq'::regclass);


--
-- Name: entry_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE partscustomer ALTER COLUMN entry_id SET DEFAULT nextval('partscustomer_entry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE partsgroup ALTER COLUMN id SET DEFAULT nextval('partsgroup_id_seq'::regclass);


--
-- Name: entry_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE partsvendor ALTER COLUMN entry_id SET DEFAULT nextval('partsvendor_entry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE payment ALTER COLUMN id SET DEFAULT nextval('payment_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE payment_type ALTER COLUMN id SET DEFAULT nextval('payment_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE pending_job ALTER COLUMN id SET DEFAULT nextval('pending_job_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE person ALTER COLUMN id SET DEFAULT nextval('person_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE pricegroup ALTER COLUMN id SET DEFAULT nextval('pricegroup_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE project ALTER COLUMN id SET DEFAULT nextval('project_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE salutation ALTER COLUMN id SET DEFAULT nextval('salutation_id_seq'::regclass);


--
-- Name: session_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE session ALTER COLUMN session_id SET DEFAULT nextval('session_session_id_seq'::regclass);


--
-- Name: taxcategory_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE taxcategory ALTER COLUMN taxcategory_id SET DEFAULT nextval('taxcategory_taxcategory_id_seq'::regclass);


--
-- Name: taxmodule_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE taxmodule ALTER COLUMN taxmodule_id SET DEFAULT nextval('taxmodule_taxmodule_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE voucher ALTER COLUMN id SET DEFAULT nextval('voucher_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE warehouse ALTER COLUMN id SET DEFAULT nextval('warehouse_id_seq'::regclass);


--
-- Data for Name: ac_tax_form; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: acc_trans; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (1, 25, 100, '2012-03-10', NULL, false, false, NULL, NULL, 1, true, NULL, NULL, NULL, 1);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (1, 3, -100, '2012-03-10', NULL, false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 2);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (2, 25, 246.91, '2012-03-10', NULL, false, false, NULL, NULL, 2, true, NULL, NULL, NULL, 3);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (2, 3, -246.91, '2012-03-10', NULL, false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 4);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (1, 1, -100, '2012-03-10', 'check 0002345', false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 5);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (1, 3, 100, '2012-03-10', 'check 0002345', false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 6);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (2, 1, -253.357600, '2012-03-11', 'check 900234', false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 7);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (2, 3, 246.91000, '2012-03-11', 'check 900234', false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 8);
INSERT INTO acc_trans (trans_id, chart_id, amount, transdate, source, cleared, fx_transaction, project_id, memo, invoice_id, approved, cleared_on, reconciled_on, voucher_id, entry_id) VALUES (2, 29, 6.447600, '2012-03-11', 'check 900234', false, false, NULL, NULL, NULL, true, NULL, NULL, NULL, 9);


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (1, '1060', 'Chequing Account', 'A', '1002', 1, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (2, '1065', 'Petty Cash', 'A', '1001', 1, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (3, '1200', 'Accounts Receivables', 'A', '1060', 1, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (4, '1205', 'Allowance for doubtful accounts', 'A', '1063', 1, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (5, '1520', 'Inventory / General', 'A', '1122', 2, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (6, '1530', 'Inventory / Aftermarket Parts', 'A', '1122', 2, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (7, '1540', 'Inventory / Raw Materials', 'A', '1122', 2, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (8, '1820', 'Office Furniture & Equipment', 'A', '1787', 3, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (9, '1825', 'Accum. Amort. -Furn. & Equip.', 'A', '1788', 3, true, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (10, '1840', 'Vehicle', 'A', '1742', 3, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (11, '1845', 'Accum. Amort. -Vehicle', 'A', '1743', 3, true, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (12, '2100', 'Accounts Payable', 'L', '2621', 4, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (13, '2160', 'Federal Taxes Payable', 'L', '2683', 4, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (14, '2170', 'Provincial Taxes Payable', 'L', '2684', 4, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (17, '2380', 'Vacation Pay Payable', 'L', '2624', 4, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (18, '2390', 'WCB Payable', 'L', '2627', 4, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (19, '2410', 'EI Payable', 'L', '2627', 5, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (20, '2420', 'CPP Payable', 'L', '2627', 5, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (21, '2450', 'Income Tax Payable', 'L', '2628', 5, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (22, '2620', 'Bank Loans', 'L', '2701', 6, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (23, '2680', 'Loans from Shareholders', 'L', '2780', 6, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (24, '3350', 'Common Shares', 'Q', '3500', 7, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (25, '4020', 'General Sales', 'I', '8000', 8, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (26, '4030', 'Aftermarket Parts', 'I', '8000', 8, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (27, '4430', 'Shipping & Handling', 'I', '8457', 9, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (28, '4440', 'Interest', 'I', '8090', 9, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (29, '4450', 'Foreign Exchange Gain / (Loss)', 'I', '8231', 9, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (30, '5010', 'Purchases', 'E', '8320', 10, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (31, '5050', 'Aftermarket Parts', 'E', '8320', 10, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (32, '5100', 'Freight', 'E', '8457', 10, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (33, '5410', 'Wages & Salaries', 'E', '9060', 11, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (34, '5420', 'EI Expense', 'E', '8622', 11, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (35, '5430', 'CPP Expense', 'E', '8622', 11, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (36, '5440', 'WCB Expense', 'E', '8622', 11, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (37, '5610', 'Accounting & Legal', 'E', '8862', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (38, '5615', 'Advertising & Promotions', 'E', '8520', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (39, '5620', 'Bad Debts', 'E', '8590', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (40, '5660', 'Amortization Expense', 'E', '8670', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (41, '5680', 'Income Taxes', 'E', '9990', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (42, '5685', 'Insurance', 'E', '9804', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (43, '5690', 'Interest & Bank Charges', 'E', '9805', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (44, '5700', 'Office Supplies', 'E', '8811', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (45, '5760', 'Rent', 'E', '9811', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (46, '5765', 'Repair & Maintenance', 'E', '8964', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (47, '5780', 'Telephone', 'E', '9225', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (48, '5785', 'Travel & Entertainment', 'E', '8523', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (49, '5790', 'Utilities', 'E', '8812', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (50, '5800', 'Licenses', 'E', '8760', 12, false, false);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (16, '2320', 'PST', 'L', '2686', 4, false, true);
INSERT INTO account (id, accno, description, category, gifi_accno, heading, contra, tax) VALUES (15, '2310', 'GST', 'L', '2685', 4, false, true);


--
-- Data for Name: account_checkpoint; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: account_heading; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO account_heading (id, accno, parent_id, description) VALUES (1, '1000', NULL, 'CURRENT ASSETS');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (2, '1500', NULL, 'INVENTORY ASSETS');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (3, '1800', NULL, 'CAPITAL ASSETS');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (4, '2000', NULL, 'CURRENT LIABILITIES');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (5, '2400', NULL, 'PAYROLL DEDUCTIONS');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (6, '2600', NULL, 'LONG TERM LIABILITIES');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (7, '3300', NULL, 'SHARE CAPITAL');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (8, '4000', NULL, 'SALES REVENUE');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (9, '4400', NULL, 'OTHER REVENUE');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (10, '5000', NULL, 'COST OF GOODS SOLD');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (11, '5400', NULL, 'PAYROLL EXPENSES');
INSERT INTO account_heading (id, accno, parent_id, description) VALUES (12, '5600', NULL, 'GENERAL & ADMINISTRATIVE EXPENSES');


--
-- Data for Name: account_link; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO account_link (account_id, description) VALUES (1, 'AR_paid');
INSERT INTO account_link (account_id, description) VALUES (1, 'AP_paid');
INSERT INTO account_link (account_id, description) VALUES (2, 'AR_paid');
INSERT INTO account_link (account_id, description) VALUES (2, 'AP_paid');
INSERT INTO account_link (account_id, description) VALUES (3, 'AR');
INSERT INTO account_link (account_id, description) VALUES (5, 'IC');
INSERT INTO account_link (account_id, description) VALUES (6, 'IC');
INSERT INTO account_link (account_id, description) VALUES (7, 'IC');
INSERT INTO account_link (account_id, description) VALUES (12, 'AP');
INSERT INTO account_link (account_id, description) VALUES (15, 'AR_tax');
INSERT INTO account_link (account_id, description) VALUES (15, 'AP_tax');
INSERT INTO account_link (account_id, description) VALUES (15, 'IC_taxpart');
INSERT INTO account_link (account_id, description) VALUES (15, 'IC_taxservice');
INSERT INTO account_link (account_id, description) VALUES (16, 'AR_tax');
INSERT INTO account_link (account_id, description) VALUES (16, 'AP_tax');
INSERT INTO account_link (account_id, description) VALUES (16, 'IC_taxpart');
INSERT INTO account_link (account_id, description) VALUES (16, 'IC_taxservice');
INSERT INTO account_link (account_id, description) VALUES (23, 'AP_paid');
INSERT INTO account_link (account_id, description) VALUES (25, 'AR_amount');
INSERT INTO account_link (account_id, description) VALUES (25, 'IC_sale');
INSERT INTO account_link (account_id, description) VALUES (25, 'IC_income');
INSERT INTO account_link (account_id, description) VALUES (26, 'AR_amount');
INSERT INTO account_link (account_id, description) VALUES (26, 'IC_sale');
INSERT INTO account_link (account_id, description) VALUES (27, 'IC_income');
INSERT INTO account_link (account_id, description) VALUES (28, 'IC_income');
INSERT INTO account_link (account_id, description) VALUES (30, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (30, 'IC_cogs');
INSERT INTO account_link (account_id, description) VALUES (30, 'IC_expense');
INSERT INTO account_link (account_id, description) VALUES (31, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (31, 'IC_cogs');
INSERT INTO account_link (account_id, description) VALUES (32, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (32, 'IC_expense');
INSERT INTO account_link (account_id, description) VALUES (37, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (38, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (42, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (44, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (45, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (46, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (47, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (49, 'AP_amount');
INSERT INTO account_link (account_id, description) VALUES (50, 'AP_amount');


--
-- Data for Name: account_link_description; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO account_link_description (description, summary, custom) VALUES ('AR', true, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP', true, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC', true, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AR_amount', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AR_tax', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AR_paid', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AR_overpayment', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AR_discount', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP_amount', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP_expense', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP_tax', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP_paid', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP_overpayment', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('AP_discount', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_sale', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_tax', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_cogs', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_taxpart', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_taxservice', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_income', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('IC_expense', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('Asset_Dep', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('Fixed_Asset', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('asset_expense', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('asset_gain', false, false);
INSERT INTO account_link_description (description, summary, custom) VALUES ('asset_loss', false, false);


--
-- Data for Name: ap; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: ar; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO ar (id, invnumber, transdate, entity_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, shippingpoint, terms, notes, curr, ordnumber, person_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, on_hold, reverse, approved, entity_credit_account, force_closed, description) VALUES (1, '2', '2012-03-10', NULL, false, 100, 100, 0, '2012-03-10', '2012-03-10', true, '', 0, '', 'CAD', '', 1, NULL, '', '', 0, '', 'en_US', '', false, false, true, 3, NULL, NULL);
INSERT INTO ar (id, invnumber, transdate, entity_id, taxincluded, amount, netamount, paid, datepaid, duedate, invoice, shippingpoint, terms, notes, curr, ordnumber, person_id, till, quonumber, intnotes, department_id, shipvia, language_code, ponumber, on_hold, reverse, approved, entity_credit_account, force_closed, description) VALUES (2, '3', '2012-03-10', NULL, false, 246.91, 246.91, 0, '2012-03-10', '2012-03-10', true, '', 0, '', 'USD', '', 1, NULL, '', '', 0, '', 'en_US', '', false, false, true, 4, NULL, NULL);


--
-- Data for Name: assembly; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_class; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_dep_method; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO asset_dep_method (id, method, sproc, unit_label, short_name, unit_class) VALUES (1, 'Annual Straight Line Daily', 'asset_dep_straight_line_yr_d', 'in years', 'SLYD', 1);
INSERT INTO asset_dep_method (id, method, sproc, unit_label, short_name, unit_class) VALUES (2, 'Whole Month Straight Line', 'asset_dep_straight_line_whl_m', 'in months', 'SLMM', 1);
INSERT INTO asset_dep_method (id, method, sproc, unit_label, short_name, unit_class) VALUES (3, 'Annual Straight Line Monthly', 'asset_dep_straight_line_yr_m', 'in years', 'SLYM', 1);


--
-- Data for Name: asset_disposal_method; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO asset_disposal_method (label, id, multiple, short_label) VALUES ('Abandonment', 1, 0, 'A');
INSERT INTO asset_disposal_method (label, id, multiple, short_label) VALUES ('Sale', 2, 1, 'S');


--
-- Data for Name: asset_item; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_note; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_report; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_report_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO asset_report_class (id, class) VALUES (1, 'depreciation');
INSERT INTO asset_report_class (id, class) VALUES (2, 'disposal');
INSERT INTO asset_report_class (id, class) VALUES (3, 'import');
INSERT INTO asset_report_class (id, class) VALUES (4, 'partial disposal');


--
-- Data for Name: asset_report_line; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_rl_to_disposal_method; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: asset_unit_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO asset_unit_class (id, class) VALUES (1, 'time');
INSERT INTO asset_unit_class (id, class) VALUES (2, 'production');


--
-- Data for Name: audittrail; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO audittrail (trans_id, tablename, reference, formname, action, transdate, person_id, entry_id) VALUES (1, 'ar', 'Sat Mar 10 20:56:05 201230699', NULL, 'INSERT', '2012-03-10 20:56:05.155729', 1, 1);
INSERT INTO audittrail (trans_id, tablename, reference, formname, action, transdate, person_id, entry_id) VALUES (1, 'ar', 'Sat Mar 10 20:56:05 201230699', NULL, 'UPDATE', '2012-03-10 20:56:05.199057', 1, 2);
INSERT INTO audittrail (trans_id, tablename, reference, formname, action, transdate, person_id, entry_id) VALUES (2, 'ar', 'Sat Mar 10 20:56:53 201230857', NULL, 'INSERT', '2012-03-10 20:56:53.882872', 1, 3);
INSERT INTO audittrail (trans_id, tablename, reference, formname, action, transdate, person_id, entry_id) VALUES (2, 'ar', 'Sat Mar 10 20:56:53 201230857', NULL, 'UPDATE', '2012-03-10 20:56:53.934173', 1, 4);
INSERT INTO audittrail (trans_id, tablename, reference, formname, action, transdate, person_id, entry_id) VALUES (2, 'ar', '3', NULL, 'UPDATE', '2012-03-10 21:08:38.929777', 1, 5);


--
-- Data for Name: batch; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: batch_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO batch_class (id, class) VALUES (1, 'ap');
INSERT INTO batch_class (id, class) VALUES (2, 'ar');
INSERT INTO batch_class (id, class) VALUES (3, 'payment');
INSERT INTO batch_class (id, class) VALUES (4, 'payment_reversal');
INSERT INTO batch_class (id, class) VALUES (5, 'gl');
INSERT INTO batch_class (id, class) VALUES (6, 'receipt');


--
-- Data for Name: business; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO company (id, entity_id, legal_name, tax_id, sic_code, created) VALUES (1, 0, 'Inventory Entity', NULL, NULL, '2012-03-10');
INSERT INTO company (id, entity_id, legal_name, tax_id, sic_code, created) VALUES (2, 2, 'Canadian Customer', NULL, NULL, '2012-03-10');
INSERT INTO company (id, entity_id, legal_name, tax_id, sic_code, created) VALUES (3, 3, 'US Customer', NULL, NULL, '2012-03-10');


--
-- Data for Name: company_to_contact; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: company_to_entity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: company_to_location; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: contact_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO contact_class (id, class) VALUES (1, 'Primary Phone');
INSERT INTO contact_class (id, class) VALUES (2, 'Secondary Phone');
INSERT INTO contact_class (id, class) VALUES (3, 'Cell Phone');
INSERT INTO contact_class (id, class) VALUES (4, 'AIM');
INSERT INTO contact_class (id, class) VALUES (5, 'Yahoo');
INSERT INTO contact_class (id, class) VALUES (6, 'Gtalk');
INSERT INTO contact_class (id, class) VALUES (7, 'MSN');
INSERT INTO contact_class (id, class) VALUES (8, 'IRC');
INSERT INTO contact_class (id, class) VALUES (9, 'Fax');
INSERT INTO contact_class (id, class) VALUES (10, 'Generic Jabber');
INSERT INTO contact_class (id, class) VALUES (11, 'Home Phone');
INSERT INTO contact_class (id, class) VALUES (12, 'Email');
INSERT INTO contact_class (id, class) VALUES (13, 'CC');
INSERT INTO contact_class (id, class) VALUES (14, 'BCC');
INSERT INTO contact_class (id, class) VALUES (15, 'Billing Email');
INSERT INTO contact_class (id, class) VALUES (16, 'Billing CC');
INSERT INTO contact_class (id, class) VALUES (17, 'Billing BCC');


--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO country (id, name, short_name, itu) VALUES (1, 'Ascension Island', 'AC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (2, 'Andorra', 'AD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (3, 'United Arab Emirates', 'AE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (4, 'Afghanistan', 'AF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (5, 'Antigua and Barbuda', 'AG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (6, 'Anguilla', 'AI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (7, 'Albania', 'AL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (8, 'Armenia', 'AM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (9, 'Netherlands Antilles', 'AN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (10, 'Angola', 'AO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (11, 'Antarctica', 'AQ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (12, 'Argentina', 'AR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (13, 'American Samoa', 'AS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (14, 'Austria', 'AT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (15, 'Australia', 'AU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (16, 'Aruba', 'AW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (17, 'Aland Islands', 'AX', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (18, 'Azerbaijan', 'AZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (19, 'Bosnia and Herzegovina', 'BA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (20, 'Barbados', 'BB', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (21, 'Bangladesh', 'BD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (22, 'Belgium', 'BE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (23, 'Burkina Faso', 'BF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (24, 'Bulgaria', 'BG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (25, 'Bahrain', 'BH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (26, 'Burundi', 'BI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (27, 'Benin', 'BJ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (28, 'Bermuda', 'BM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (29, 'Brunei Darussalam', 'BN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (30, 'Bolivia', 'BO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (31, 'Brazil', 'BR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (32, 'Bahamas', 'BS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (33, 'Bhutan', 'BT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (34, 'Bouvet Island', 'BV', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (35, 'Botswana', 'BW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (36, 'Belarus', 'BY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (37, 'Belize', 'BZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (38, 'Canada', 'CA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (39, 'Cocos (Keeling) Islands', 'CC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (40, 'Congo, Democratic Republic', 'CD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (41, 'Central African Republic', 'CF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (42, 'Congo', 'CG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (43, 'Switzerland', 'CH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (44, 'Cote D''Ivoire (Ivory Coast)', 'CI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (45, 'Cook Islands', 'CK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (46, 'Chile', 'CL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (47, 'Cameroon', 'CM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (48, 'China', 'CN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (49, 'Colombia', 'CO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (50, 'Costa Rica', 'CR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (51, 'Czechoslovakia (former)', 'CS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (52, 'Cuba', 'CU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (53, 'Cape Verde', 'CV', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (54, 'Christmas Island', 'CX', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (55, 'Cyprus', 'CY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (56, 'Czech Republic', 'CZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (57, 'Germany', 'DE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (58, 'Djibouti', 'DJ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (59, 'Denmark', 'DK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (60, 'Dominica', 'DM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (61, 'Dominican Republic', 'DO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (62, 'Algeria', 'DZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (63, 'Ecuador', 'EC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (64, 'Estonia', 'EE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (65, 'Egypt', 'EG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (66, 'Western Sahara', 'EH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (67, 'Eritrea', 'ER', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (68, 'Spain', 'ES', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (69, 'Ethiopia', 'ET', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (70, 'Finland', 'FI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (71, 'Fiji', 'FJ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (72, 'Falkland Islands (Malvinas)', 'FK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (73, 'Micronesia', 'FM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (74, 'Faroe Islands', 'FO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (75, 'France', 'FR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (76, 'France, Metropolitan', 'FX', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (77, 'Gabon', 'GA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (78, 'Great Britain (UK)', 'GB', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (79, 'Grenada', 'GD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (80, 'Georgia', 'GE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (81, 'French Guiana', 'GF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (82, 'Ghana', 'GH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (83, 'Gibraltar', 'GI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (84, 'Greenland', 'GL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (85, 'Gambia', 'GM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (86, 'Guinea', 'GN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (87, 'Guadeloupe', 'GP', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (88, 'Equatorial Guinea', 'GQ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (89, 'Greece', 'GR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (90, 'S. Georgia and S. Sandwich Isls.', 'GS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (91, 'Guatemala', 'GT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (92, 'Guam', 'GU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (93, 'Guinea-Bissau', 'GW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (94, 'Guyana', 'GY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (95, 'Hong Kong', 'HK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (96, 'Heard and McDonald Islands', 'HM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (97, 'Honduras', 'HN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (98, 'Croatia (Hrvatska)', 'HR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (99, 'Haiti', 'HT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (100, 'Hungary', 'HU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (101, 'Indonesia', 'ID', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (102, 'Ireland', 'IE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (103, 'Israel', 'IL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (104, 'Isle of Man', 'IM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (105, 'India', 'IN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (106, 'British Indian Ocean Territory', 'IO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (107, 'Iraq', 'IQ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (108, 'Iran', 'IR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (109, 'Iceland', 'IS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (110, 'Italy', 'IT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (111, 'Jersey', 'JE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (112, 'Jamaica', 'JM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (113, 'Jordan', 'JO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (114, 'Japan', 'JP', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (115, 'Kenya', 'KE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (116, 'Kyrgyzstan', 'KG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (117, 'Cambodia', 'KH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (118, 'Kiribati', 'KI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (119, 'Comoros', 'KM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (120, 'Saint Kitts and Nevis', 'KN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (121, 'Korea (North)', 'KP', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (122, 'Korea (South)', 'KR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (123, 'Kuwait', 'KW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (124, 'Cayman Islands', 'KY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (125, 'Kazakhstan', 'KZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (126, 'Laos', 'LA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (127, 'Lebanon', 'LB', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (128, 'Saint Lucia', 'LC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (129, 'Liechtenstein', 'LI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (130, 'Sri Lanka', 'LK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (131, 'Liberia', 'LR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (132, 'Lesotho', 'LS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (133, 'Lithuania', 'LT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (134, 'Luxembourg', 'LU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (135, 'Latvia', 'LV', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (136, 'Libya', 'LY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (137, 'Morocco', 'MA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (138, 'Monaco', 'MC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (139, 'Moldova', 'MD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (140, 'Madagascar', 'MG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (141, 'Marshall Islands', 'MH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (142, 'F.Y.R.O.M. (Macedonia)', 'MK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (143, 'Mali', 'ML', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (144, 'Myanmar', 'MM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (145, 'Mongolia', 'MN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (146, 'Macau', 'MO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (147, 'Northern Mariana Islands', 'MP', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (148, 'Martinique', 'MQ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (149, 'Mauritania', 'MR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (150, 'Montserrat', 'MS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (151, 'Malta', 'MT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (152, 'Mauritius', 'MU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (153, 'Maldives', 'MV', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (154, 'Malawi', 'MW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (155, 'Mexico', 'MX', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (156, 'Malaysia', 'MY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (157, 'Mozambique', 'MZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (158, 'Namibia', 'NA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (159, 'New Caledonia', 'NC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (160, 'Niger', 'NE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (161, 'Norfolk Island', 'NF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (162, 'Nigeria', 'NG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (163, 'Nicaragua', 'NI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (164, 'Netherlands', 'NL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (165, 'Norway', 'NO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (166, 'Nepal', 'NP', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (167, 'Nauru', 'NR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (168, 'Neutral Zone', 'NT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (169, 'Niue', 'NU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (170, 'New Zealand (Aotearoa)', 'NZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (171, 'Oman', 'OM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (172, 'Panama', 'PA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (173, 'Peru', 'PE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (174, 'French Polynesia', 'PF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (175, 'Papua New Guinea', 'PG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (176, 'Philippines', 'PH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (177, 'Pakistan', 'PK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (178, 'Poland', 'PL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (179, 'St. Pierre and Miquelon', 'PM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (180, 'Pitcairn', 'PN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (181, 'Puerto Rico', 'PR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (182, 'Palestinian Territory, Occupied', 'PS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (183, 'Portugal', 'PT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (184, 'Palau', 'PW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (185, 'Paraguay', 'PY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (186, 'Qatar', 'QA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (187, 'Reunion', 'RE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (188, 'Romania', 'RO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (189, 'Serbia', 'RS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (190, 'Russian Federation', 'RU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (191, 'Rwanda', 'RW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (192, 'Saudi Arabia', 'SA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (193, 'Solomon Islands', 'SB', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (194, 'Seychelles', 'SC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (195, 'Sudan', 'SD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (196, 'Sweden', 'SE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (197, 'Singapore', 'SG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (198, 'St. Helena', 'SH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (199, 'Slovenia', 'SI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (200, 'Svalbard & Jan Mayen Islands', 'SJ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (201, 'Slovak Republic', 'SK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (202, 'Sierra Leone', 'SL', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (203, 'San Marino', 'SM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (204, 'Senegal', 'SN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (205, 'Somalia', 'SO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (206, 'Suriname', 'SR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (207, 'Sao Tome and Principe', 'ST', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (208, 'USSR (former)', 'SU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (209, 'El Salvador', 'SV', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (210, 'Syria', 'SY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (211, 'Swaziland', 'SZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (212, 'Turks and Caicos Islands', 'TC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (213, 'Chad', 'TD', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (214, 'French Southern Territories', 'TF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (215, 'Togo', 'TG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (216, 'Thailand', 'TH', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (217, 'Tajikistan', 'TJ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (218, 'Tokelau', 'TK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (219, 'Turkmenistan', 'TM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (220, 'Tunisia', 'TN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (221, 'Tonga', 'TO', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (222, 'East Timor', 'TP', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (223, 'Turkey', 'TR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (224, 'Trinidad and Tobago', 'TT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (225, 'Tuvalu', 'TV', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (226, 'Taiwan', 'TW', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (227, 'Tanzania', 'TZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (228, 'Ukraine', 'UA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (229, 'Uganda', 'UG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (230, 'United Kingdom', 'UK', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (231, 'US Minor Outlying Islands', 'UM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (232, 'United States', 'US', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (233, 'Uruguay', 'UY', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (234, 'Uzbekistan', 'UZ', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (235, 'Vatican City State (Holy See)', 'VA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (236, 'Saint Vincent & the Grenadines', 'VC', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (237, 'Venezuela', 'VE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (238, 'British Virgin Islands', 'VG', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (239, 'Virgin Islands (U.S.)', 'VI', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (240, 'Viet Nam', 'VN', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (241, 'Vanuatu', 'VU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (242, 'Wallis and Futuna Islands', 'WF', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (243, 'Samoa', 'WS', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (244, 'Yemen', 'YE', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (245, 'Mayotte', 'YT', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (246, 'Yugoslavia (former)', 'YU', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (247, 'South Africa', 'ZA', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (248, 'Zambia', 'ZM', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (249, 'Zaire', 'ZR', NULL);
INSERT INTO country (id, name, short_name, itu) VALUES (250, 'Zimbabwe', 'ZW', NULL);


--
-- Data for Name: country_tax_form; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cr_coa_to_account; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO cr_coa_to_account (chart_id, account) VALUES (1, '1060--1060--Chequing Account');
INSERT INTO cr_coa_to_account (chart_id, account) VALUES (2, '1065--1065--Petty Cash');


--
-- Data for Name: cr_report; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cr_report_line; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: custom_field_catalog; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: custom_table_catalog; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: customertax; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: defaults; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO defaults (setting_key, value) VALUES ('timeout', '90 minutes');
INSERT INTO defaults (setting_key, value) VALUES ('yearend', '1');
INSERT INTO defaults (setting_key, value) VALUES ('version', '1.3.12');
INSERT INTO defaults (setting_key, value) VALUES ('closedto', NULL);
INSERT INTO defaults (setting_key, value) VALUES ('revtrans', '1');
INSERT INTO defaults (setting_key, value) VALUES ('ponumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('audittrail', '0');
INSERT INTO defaults (setting_key, value) VALUES ('queue_payments', '0');
INSERT INTO defaults (setting_key, value) VALUES ('poll_frequency', '1');
INSERT INTO defaults (setting_key, value) VALUES ('rcptnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('batch_cc', 'B-11111');
INSERT INTO defaults (setting_key, value) VALUES ('entity_control', 'A-00004');
INSERT INTO defaults (setting_key, value) VALUES ('glnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('vclimit', '200');
INSERT INTO defaults (setting_key, value) VALUES ('sonumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('vinumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('sqnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('rfqnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('partnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('projectnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('employeenumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('customernumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('vendornumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('check_prefix', 'CK');
INSERT INTO defaults (setting_key, value) VALUES ('password_duration', '');
INSERT INTO defaults (setting_key, value) VALUES ('default_email_to', '');
INSERT INTO defaults (setting_key, value) VALUES ('default_email_cc', '');
INSERT INTO defaults (setting_key, value) VALUES ('default_email_bcc', '');
INSERT INTO defaults (setting_key, value) VALUES ('default_email_from', '');
INSERT INTO defaults (setting_key, value) VALUES ('company_name', 'New Company');
INSERT INTO defaults (setting_key, value) VALUES ('company_address', '22 New Street');
INSERT INTO defaults (setting_key, value) VALUES ('company_phone', '');
INSERT INTO defaults (setting_key, value) VALUES ('company_fax', '');
INSERT INTO defaults (setting_key, value) VALUES ('businessnumber', '1');
INSERT INTO defaults (setting_key, value) VALUES ('weightunit', 'kg');
INSERT INTO defaults (setting_key, value) VALUES ('separate_duties', '1');
INSERT INTO defaults (setting_key, value) VALUES ('default_language', 'ar_EG');
INSERT INTO defaults (setting_key, value) VALUES ('inventory_accno_id', '5');
INSERT INTO defaults (setting_key, value) VALUES ('income_accno_id', '25');
INSERT INTO defaults (setting_key, value) VALUES ('expense_accno_id', '30');
INSERT INTO defaults (setting_key, value) VALUES ('fxgain_accno_id', '29');
INSERT INTO defaults (setting_key, value) VALUES ('fxloss_accno_id', '29');
INSERT INTO defaults (setting_key, value) VALUES ('default_country', '');
INSERT INTO defaults (setting_key, value) VALUES ('templates', 'demo');
INSERT INTO defaults (setting_key, value) VALUES ('curr', 'CAD:USD:EUR');
INSERT INTO defaults (setting_key, value) VALUES ('sinumber', '3');
INSERT INTO defaults (setting_key, value) VALUES ('paynumber', '3');


--
-- Data for Name: department; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: dpt_trans; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: eca_note; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: eca_to_contact; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: eca_to_location; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: entity; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO entity (id, name, entity_class, created, control_code, country_id) VALUES (0, 'Inventory Entity', 1, '2012-03-10', 'AUTO-01', 232);
INSERT INTO entity (id, name, entity_class, created, control_code, country_id) VALUES (1, 'Guy Smiley', 3, '2012-03-10', 'A-00002', 38);
INSERT INTO entity (id, name, entity_class, created, control_code, country_id) VALUES (2, 'Canadian Customer', 2, '2012-03-10', 'A-00003', 38);
INSERT INTO entity (id, name, entity_class, created, control_code, country_id) VALUES (3, 'US Customer', 2, '2012-03-10', 'A-00004', 232);


--
-- Data for Name: entity_bank_account; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: entity_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO entity_class (id, class, country_id, active) VALUES (1, 'Vendor', NULL, true);
INSERT INTO entity_class (id, class, country_id, active) VALUES (2, 'Customer', NULL, true);
INSERT INTO entity_class (id, class, country_id, active) VALUES (3, 'Employee', NULL, true);
INSERT INTO entity_class (id, class, country_id, active) VALUES (4, 'Contact', NULL, true);
INSERT INTO entity_class (id, class, country_id, active) VALUES (5, 'Lead', NULL, true);
INSERT INTO entity_class (id, class, country_id, active) VALUES (6, 'Referral', NULL, true);


--
-- Data for Name: entity_class_to_entity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: entity_credit_account; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO entity_credit_account (id, entity_id, entity_class, pay_to_name, discount, description, discount_terms, discount_account_id, taxincluded, creditlimit, terms, meta_number, business_id, language_code, pricegroup_id, curr, startdate, enddate, threshold, employee_id, primary_contact, ar_ap_account_id, cash_account_id, bank_account, taxform_id) VALUES (1, 0, 1, NULL, NULL, NULL, 0, NULL, false, 0, 0, '00000', NULL, 'en', NULL, NULL, '2012-03-10', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO entity_credit_account (id, entity_id, entity_class, pay_to_name, discount, description, discount_terms, discount_account_id, taxincluded, creditlimit, terms, meta_number, business_id, language_code, pricegroup_id, curr, startdate, enddate, threshold, employee_id, primary_contact, ar_ap_account_id, cash_account_id, bank_account, taxform_id) VALUES (2, 0, 2, NULL, NULL, NULL, 0, NULL, false, 0, 0, '00000', NULL, 'en', NULL, NULL, '2012-03-10', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO entity_credit_account (id, entity_id, entity_class, pay_to_name, discount, description, discount_terms, discount_account_id, taxincluded, creditlimit, terms, meta_number, business_id, language_code, pricegroup_id, curr, startdate, enddate, threshold, employee_id, primary_contact, ar_ap_account_id, cash_account_id, bank_account, taxform_id) VALUES (3, 2, 2, NULL, NULL, 'Canadian Customer', NULL, NULL, NULL, NULL, NULL, '1', NULL, 'en_US', NULL, 'CAD', NULL, NULL, 0, NULL, NULL, 3, 1, NULL, NULL);
INSERT INTO entity_credit_account (id, entity_id, entity_class, pay_to_name, discount, description, discount_terms, discount_account_id, taxincluded, creditlimit, terms, meta_number, business_id, language_code, pricegroup_id, curr, startdate, enddate, threshold, employee_id, primary_contact, ar_ap_account_id, cash_account_id, bank_account, taxform_id) VALUES (4, 3, 2, NULL, NULL, 'US customer', NULL, NULL, NULL, NULL, NULL, '2', NULL, 'en_US', NULL, 'USD', NULL, NULL, 0, NULL, NULL, 3, 1, NULL, NULL);


--
-- Data for Name: entity_employee; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO entity_employee (entity_id, startdate, enddate, role, ssn, sales, manager_id, employeenumber, dob) VALUES (1, '2012-03-10', NULL, 'user', NULL, false, NULL, NULL, NULL);


--
-- Data for Name: entity_note; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: entity_other_name; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: exchangerate; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO exchangerate (curr, transdate, buy, sell) VALUES ('USD', '2012-03-10', 1.23455, 0);
INSERT INTO exchangerate (curr, transdate, buy, sell) VALUES ('USD', '2012-03-11', 1.266788, NULL);


--
-- Data for Name: file_base; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO file_class (id, class) VALUES (1, 'transaction');
INSERT INTO file_class (id, class) VALUES (2, 'order');
INSERT INTO file_class (id, class) VALUES (3, 'part');


--
-- Data for Name: file_order; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_order_to_order; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_order_to_tx; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_part; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_secondary_attachment; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_transaction; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_tx_to_order; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: file_view_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO file_view_catalog (file_class, view_name) VALUES (1, 'file_tx_links');
INSERT INTO file_view_catalog (file_class, view_name) VALUES (2, 'file_order_links');


--
-- Data for Name: gifi; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: gl; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO invoice (id, trans_id, parts_id, description, qty, allocated, sellprice, "precision", fxsellprice, discount, assemblyitem, unit, project_id, deliverydate, serialnumber, notes) VALUES (1, 1, 1, '', 1, 0, 100, 2, 100, 0, false, '20', NULL, NULL, '', '');
INSERT INTO invoice (id, trans_id, parts_id, description, qty, allocated, sellprice, "precision", fxsellprice, discount, assemblyitem, unit, project_id, deliverydate, serialnumber, notes) VALUES (2, 2, 2, '', 1, 0, 246.91, 2, 200, 0, false, '30', NULL, NULL, '', '');


--
-- Data for Name: invoice_note; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: invoice_tax_form; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO invoice_tax_form (invoice_id, reportable) VALUES (1, false);
INSERT INTO invoice_tax_form (invoice_id, reportable) VALUES (2, false);


--
-- Data for Name: jcitems; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: language; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO language (code, description) VALUES ('ar_EG', 'Arabic (Egypt)');
INSERT INTO language (code, description) VALUES ('bg', 'Bulgarian');
INSERT INTO language (code, description) VALUES ('ca', 'Catalan');
INSERT INTO language (code, description) VALUES ('cs', 'Czech');
INSERT INTO language (code, description) VALUES ('da', 'Danish');
INSERT INTO language (code, description) VALUES ('de', 'German');
INSERT INTO language (code, description) VALUES ('de_CH', 'German (Switzerland)');
INSERT INTO language (code, description) VALUES ('el', 'Greek');
INSERT INTO language (code, description) VALUES ('en', 'English');
INSERT INTO language (code, description) VALUES ('en_US', 'English (US)');
INSERT INTO language (code, description) VALUES ('en_GB', 'English (UK)');
INSERT INTO language (code, description) VALUES ('es', 'Spanish');
INSERT INTO language (code, description) VALUES ('es_CO', 'Spanish (Colombia)');
INSERT INTO language (code, description) VALUES ('es_EC', 'Spanish (Ecuador)');
INSERT INTO language (code, description) VALUES ('es_MX', 'Spanish (Mexico)');
INSERT INTO language (code, description) VALUES ('es_PA', 'Spanish (Panama)');
INSERT INTO language (code, description) VALUES ('es_PY', 'Spanish (Paraguay)');
INSERT INTO language (code, description) VALUES ('es_VE', 'Spanish (Venezuela)');
INSERT INTO language (code, description) VALUES ('et', 'Estonian');
INSERT INTO language (code, description) VALUES ('fi', 'Finnish');
INSERT INTO language (code, description) VALUES ('fr', 'French');
INSERT INTO language (code, description) VALUES ('fr_BE', 'French (Belgium)');
INSERT INTO language (code, description) VALUES ('fr_CA', 'French (Canada)');
INSERT INTO language (code, description) VALUES ('hu', 'Hungarian');
INSERT INTO language (code, description) VALUES ('id', 'Indonesian');
INSERT INTO language (code, description) VALUES ('is', 'Icelandic');
INSERT INTO language (code, description) VALUES ('it', 'Italian');
INSERT INTO language (code, description) VALUES ('lt', 'Latvian');
INSERT INTO language (code, description) VALUES ('nb', 'Norwegian');
INSERT INTO language (code, description) VALUES ('nl', 'Dutch');
INSERT INTO language (code, description) VALUES ('nl_BE', 'Dutch (Belgium)');
INSERT INTO language (code, description) VALUES ('pl', 'Polish');
INSERT INTO language (code, description) VALUES ('pt', 'Portuguese');
INSERT INTO language (code, description) VALUES ('pt_BR', 'Portuguese (Brazil)');
INSERT INTO language (code, description) VALUES ('ru', 'Russian');
INSERT INTO language (code, description) VALUES ('sv', 'Swedish');
INSERT INTO language (code, description) VALUES ('tr', 'Turkish');
INSERT INTO language (code, description) VALUES ('uk', 'Ukranian');
INSERT INTO language (code, description) VALUES ('zh_CN', 'Chinese (China)');
INSERT INTO language (code, description) VALUES ('zh_TW', 'Chinese (Taiwan)');


--
-- Data for Name: location; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: location_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO location_class (id, class, authoritative) VALUES (1, 'Billing', true);
INSERT INTO location_class (id, class, authoritative) VALUES (2, 'Sales', true);
INSERT INTO location_class (id, class, authoritative) VALUES (3, 'Shipping', true);


--
-- Data for Name: lsmb_roles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__account_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__account_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__account_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_all_transactions');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_all_vouchers');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_invoice_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_invoice_create_voucher');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_transaction_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_transaction_create_voucher');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ap_transaction_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ar_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ar_invoice_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ar_transaction_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ar_transaction_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ar_transaction_create_voucher');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__ar_transaction_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__assembly_stock');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__assets_administer');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__assets_approve');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__assets_depreciate');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__assets_enter');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__audit_trail_maintenance');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__auditor');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__backup');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__batch_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__batch_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__batch_post');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__business_type_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__business_type_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__business_type_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__cash_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__close_till');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__contact_all_rights');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__contact_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__contact_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__contact_read');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__department_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__department_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__department_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__draft_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__employees_manage');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__exchangerate_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__file_attach_order');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__file_attach_part');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__file_attach_tx');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__file_read');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__financial_reports');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__gifi_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__gifi_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__gl_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__gl_reports');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__gl_transaction_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__gl_voucher_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__inventory_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__inventory_receive');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__inventory_reports');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__inventory_ship');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__inventory_transfer');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__language_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__language_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__list_all_open');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__manual_translation_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__orders_generate');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__orders_manage');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__orders_purchase_consolidate');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__orders_sales_consolidate');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__orders_sales_to_purchase');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__part_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__part_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__part_translation_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__partsgroup_translation_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__payment_process');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__pos_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__pos_cashier');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__pos_enter');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__pricegroup_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__pricegroup_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__print_jobs');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__print_jobs_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__project_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__project_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__project_order_generate');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__project_timecard_add');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__project_timecard_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__project_translation_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__purchase_order_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__purchase_order_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__purchase_order_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__receipt_process');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__reconciliation_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__reconciliation_approve');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__reconciliation_enter');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__recurring');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__rfq_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__rfq_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sales_order_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sales_order_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sales_order_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sales_quotation_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sales_quotation_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sic_all');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sic_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__sic_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__system_admin');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__system_settings_change');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__system_settings_list');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__tax_form_save');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__taxes_set');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__template_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__users_manage');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__voucher_delete');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__warehouse_create');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__warehouse_edit');
INSERT INTO lsmb_roles (user_id, role) VALUES (1, 'lsmb_newco__yearend_run');


--
-- Data for Name: makemodel; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: menu_acl; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (1, 'lsmb_newco__contact_read', 'allow', 1);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (2, 'lsmb_newco__contact_read', 'allow', 11);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (3, 'lsmb_newco__contact_read', 'allow', 14);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (4, 'lsmb_newco__contact_read', 'allow', 21);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (5, 'lsmb_newco__contact_read', 'allow', 30);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (6, 'lsmb_newco__contact_read', 'allow', 33);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (7, 'lsmb_newco__contact_create', 'allow', 1);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (8, 'lsmb_newco__contact_create', 'allow', 11);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (9, 'lsmb_newco__contact_create', 'allow', 12);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (10, 'lsmb_newco__contact_create', 'allow', 21);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (11, 'lsmb_newco__contact_create', 'allow', 30);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (12, 'lsmb_newco__contact_create', 'allow', 31);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (13, 'lsmb_newco__employees_manage', 'allow', 48);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (14, 'lsmb_newco__ar_transaction_create', 'allow', 1);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (15, 'lsmb_newco__ar_transaction_create', 'allow', 2);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (16, 'lsmb_newco__ar_transaction_create', 'allow', 194);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (17, 'lsmb_newco__ar_transaction_create', 'allow', 4);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (18, 'lsmb_newco__ar_transaction_create_voucher', 'allow', 198);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (19, 'lsmb_newco__ar_invoice_create', 'allow', 3);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (20, 'lsmb_newco__ar_invoice_create', 'allow', 195);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (21, 'lsmb_newco__ar_transaction_list', 'allow', 1);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (22, 'lsmb_newco__ar_transaction_list', 'allow', 4);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (23, 'lsmb_newco__ar_transaction_list', 'allow', 5);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (24, 'lsmb_newco__ar_transaction_list', 'allow', 6);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (25, 'lsmb_newco__ar_transaction_list', 'allow', 7);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (26, 'lsmb_newco__ar_transaction_list', 'allow', 9);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (27, 'lsmb_newco__ar_transaction_list', 'allow', 10);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (28, 'lsmb_newco__ar_transaction_list', 'allow', 11);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (29, 'lsmb_newco__ar_transaction_list', 'allow', 13);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (30, 'lsmb_newco__ar_transaction_list', 'allow', 15);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (31, 'lsmb_newco__sales_order_create', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (32, 'lsmb_newco__sales_order_create', 'allow', 51);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (33, 'lsmb_newco__sales_quotation_create', 'allow', 67);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (34, 'lsmb_newco__sales_quotation_create', 'allow', 68);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (35, 'lsmb_newco__sales_order_list', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (36, 'lsmb_newco__sales_order_list', 'allow', 53);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (37, 'lsmb_newco__sales_order_list', 'allow', 54);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (38, 'lsmb_newco__sales_quotation_list', 'allow', 67);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (39, 'lsmb_newco__sales_quotation_list', 'allow', 70);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (40, 'lsmb_newco__sales_quotation_list', 'allow', 71);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (41, 'lsmb_newco__ap_transaction_create', 'allow', 21);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (42, 'lsmb_newco__ap_transaction_create', 'allow', 22);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (43, 'lsmb_newco__ap_transaction_create', 'allow', 196);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (44, 'lsmb_newco__ap_transaction_create_voucher', 'allow', 199);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (45, 'lsmb_newco__ap_invoice_create', 'allow', 23);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (46, 'lsmb_newco__ap_transaction_create', 'allow', 197);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (47, 'lsmb_newco__ap_transaction_list', 'allow', 21);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (48, 'lsmb_newco__ap_transaction_list', 'allow', 24);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (49, 'lsmb_newco__ap_transaction_list', 'allow', 25);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (50, 'lsmb_newco__ap_transaction_list', 'allow', 26);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (51, 'lsmb_newco__ap_transaction_list', 'allow', 27);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (52, 'lsmb_newco__ap_transaction_list', 'allow', 28);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (53, 'lsmb_newco__ap_transaction_list', 'allow', 29);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (54, 'lsmb_newco__ap_transaction_list', 'allow', 30);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (55, 'lsmb_newco__ap_transaction_list', 'allow', 32);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (56, 'lsmb_newco__ap_transaction_list', 'allow', 34);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (57, 'lsmb_newco__purchase_order_create', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (58, 'lsmb_newco__purchase_order_create', 'allow', 52);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (59, 'lsmb_newco__rfq_create', 'allow', 67);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (60, 'lsmb_newco__rfq_create', 'allow', 69);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (61, 'lsmb_newco__purchase_order_list', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (62, 'lsmb_newco__purchase_order_list', 'allow', 53);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (63, 'lsmb_newco__purchase_order_list', 'allow', 55);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (64, 'lsmb_newco__rfq_list', 'allow', 67);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (65, 'lsmb_newco__rfq_list', 'allow', 70);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (66, 'lsmb_newco__rfq_list', 'allow', 72);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (67, 'lsmb_newco__pos_enter', 'allow', 16);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (68, 'lsmb_newco__pos_enter', 'allow', 17);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (69, 'lsmb_newco__pos_enter', 'allow', 18);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (70, 'lsmb_newco__close_till', 'allow', 16);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (71, 'lsmb_newco__close_till', 'allow', 20);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (72, 'lsmb_newco__list_all_open', 'allow', 16);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (73, 'lsmb_newco__list_all_open', 'allow', 18);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (74, 'lsmb_newco__reconciliation_enter', 'allow', 35);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (75, 'lsmb_newco__reconciliation_enter', 'allow', 45);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (76, 'lsmb_newco__reconciliation_approve', 'allow', 35);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (77, 'lsmb_newco__reconciliation_approve', 'allow', 41);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (78, 'lsmb_newco__reconciliation_approve', 'allow', 44);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (79, 'lsmb_newco__reconciliation_approve', 'allow', 211);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (80, 'lsmb_newco__payment_process', 'allow', 35);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (81, 'lsmb_newco__payment_process', 'allow', 38);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (82, 'lsmb_newco__payment_process', 'allow', 43);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (83, 'lsmb_newco__payment_process', 'allow', 201);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (84, 'lsmb_newco__payment_process', 'allow', 202);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (85, 'lsmb_newco__payment_process', 'allow', 223);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (86, 'lsmb_newco__receipt_process', 'allow', 35);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (87, 'lsmb_newco__receipt_process', 'allow', 36);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (88, 'lsmb_newco__receipt_process', 'allow', 37);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (89, 'lsmb_newco__receipt_process', 'allow', 42);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (90, 'lsmb_newco__receipt_process', 'allow', 47);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (91, 'lsmb_newco__receipt_process', 'allow', 203);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (92, 'lsmb_newco__receipt_process', 'allow', 204);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (93, 'lsmb_newco__part_create', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (94, 'lsmb_newco__part_create', 'allow', 78);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (95, 'lsmb_newco__part_create', 'allow', 79);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (96, 'lsmb_newco__part_create', 'allow', 80);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (97, 'lsmb_newco__part_create', 'allow', 81);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (98, 'lsmb_newco__part_create', 'allow', 82);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (99, 'lsmb_newco__part_edit', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (100, 'lsmb_newco__part_edit', 'allow', 85);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (101, 'lsmb_newco__part_edit', 'allow', 86);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (102, 'lsmb_newco__part_edit', 'allow', 87);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (103, 'lsmb_newco__part_edit', 'allow', 88);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (104, 'lsmb_newco__part_edit', 'allow', 89);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (105, 'lsmb_newco__part_edit', 'allow', 90);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (106, 'lsmb_newco__part_edit', 'allow', 91);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (107, 'lsmb_newco__part_edit', 'allow', 93);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (108, 'lsmb_newco__inventory_reports', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (109, 'lsmb_newco__inventory_reports', 'allow', 85);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (110, 'lsmb_newco__inventory_reports', 'allow', 88);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (111, 'lsmb_newco__inventory_reports', 'allow', 94);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (112, 'lsmb_newco__pricegroup_create', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (113, 'lsmb_newco__pricegroup_create', 'allow', 83);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (114, 'lsmb_newco__pricegroup_edit', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (115, 'lsmb_newco__pricegroup_edit', 'allow', 85);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (116, 'lsmb_newco__pricegroup_edit', 'allow', 92);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (117, 'lsmb_newco__assembly_stock', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (118, 'lsmb_newco__assembly_stock', 'allow', 84);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (119, 'lsmb_newco__inventory_ship', 'allow', 63);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (120, 'lsmb_newco__inventory_ship', 'allow', 64);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (121, 'lsmb_newco__inventory_receive', 'allow', 63);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (122, 'lsmb_newco__inventory_receive', 'allow', 65);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (123, 'lsmb_newco__inventory_transfer', 'allow', 63);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (124, 'lsmb_newco__inventory_transfer', 'allow', 66);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (125, 'lsmb_newco__warehouse_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (126, 'lsmb_newco__warehouse_create', 'allow', 141);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (127, 'lsmb_newco__warehouse_create', 'allow', 142);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (128, 'lsmb_newco__warehouse_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (129, 'lsmb_newco__warehouse_edit', 'allow', 141);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (130, 'lsmb_newco__warehouse_edit', 'allow', 143);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (131, 'lsmb_newco__gl_transaction_create', 'allow', 73);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (132, 'lsmb_newco__gl_transaction_create', 'allow', 74);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (133, 'lsmb_newco__gl_transaction_create', 'allow', 75);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (134, 'lsmb_newco__gl_transaction_create', 'allow', 35);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (135, 'lsmb_newco__gl_transaction_create', 'allow', 40);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (136, 'lsmb_newco__gl_reports', 'allow', 73);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (137, 'lsmb_newco__gl_reports', 'allow', 76);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (138, 'lsmb_newco__gl_reports', 'allow', 105);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (139, 'lsmb_newco__gl_reports', 'allow', 114);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (140, 'lsmb_newco__yearend_run', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (141, 'lsmb_newco__yearend_run', 'allow', 132);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (142, 'lsmb_newco__project_create', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (143, 'lsmb_newco__project_create', 'allow', 99);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (144, 'lsmb_newco__project_edit', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (145, 'lsmb_newco__project_edit', 'allow', 103);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (146, 'lsmb_newco__project_edit', 'allow', 104);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (147, 'lsmb_newco__project_timecard_add', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (148, 'lsmb_newco__project_timecard_add', 'allow', 100);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (149, 'lsmb_newco__project_timecard_add', 'allow', 103);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (150, 'lsmb_newco__project_timecard_add', 'allow', 106);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (151, 'lsmb_newco__project_timecard_list', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (152, 'lsmb_newco__project_timecard_list', 'allow', 103);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (153, 'lsmb_newco__project_timecard_list', 'allow', 106);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (154, 'lsmb_newco__project_order_generate', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (155, 'lsmb_newco__project_order_generate', 'allow', 101);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (156, 'lsmb_newco__project_order_generate', 'allow', 102);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (157, 'lsmb_newco__orders_sales_to_purchase', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (158, 'lsmb_newco__orders_sales_to_purchase', 'allow', 56);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (159, 'lsmb_newco__orders_sales_to_purchase', 'allow', 57);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (160, 'lsmb_newco__orders_sales_to_purchase', 'allow', 58);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (161, 'lsmb_newco__orders_purchase_consolidate', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (162, 'lsmb_newco__orders_purchase_consolidate', 'allow', 60);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (163, 'lsmb_newco__orders_purchase_consolidate', 'allow', 62);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (164, 'lsmb_newco__orders_sales_consolidate', 'allow', 50);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (165, 'lsmb_newco__orders_sales_consolidate', 'allow', 60);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (166, 'lsmb_newco__orders_sales_consolidate', 'allow', 61);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (167, 'lsmb_newco__financial_reports', 'allow', 109);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (168, 'lsmb_newco__financial_reports', 'allow', 110);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (169, 'lsmb_newco__financial_reports', 'allow', 111);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (170, 'lsmb_newco__financial_reports', 'allow', 112);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (171, 'lsmb_newco__financial_reports', 'allow', 113);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (172, 'lsmb_newco__financial_reports', 'allow', 114);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (173, 'lsmb_newco__print_jobs_list', 'allow', 115);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (174, 'lsmb_newco__print_jobs_list', 'allow', 116);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (175, 'lsmb_newco__print_jobs_list', 'allow', 117);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (176, 'lsmb_newco__print_jobs_list', 'allow', 118);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (177, 'lsmb_newco__print_jobs_list', 'allow', 119);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (178, 'lsmb_newco__print_jobs_list', 'allow', 120);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (179, 'lsmb_newco__print_jobs_list', 'allow', 121);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (180, 'lsmb_newco__print_jobs_list', 'allow', 122);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (181, 'lsmb_newco__print_jobs_list', 'allow', 123);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (182, 'lsmb_newco__print_jobs_list', 'allow', 124);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (183, 'lsmb_newco__print_jobs_list', 'allow', 125);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (184, 'lsmb_newco__print_jobs_list', 'allow', 126);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (185, 'lsmb_newco__print_jobs_list', 'allow', 127);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (186, 'lsmb_newco__tax_form_save', 'allow', 218);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (187, 'lsmb_newco__tax_form_save', 'allow', 225);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (188, 'lsmb_newco__tax_form_save', 'allow', 226);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (189, 'lsmb_newco__system_settings_list', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (190, 'lsmb_newco__system_settings_list', 'allow', 129);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (191, 'lsmb_newco__system_settings_list', 'allow', 131);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (192, 'lsmb_newco__taxes_set', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (193, 'lsmb_newco__taxes_set', 'allow', 130);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (194, 'lsmb_newco__account_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (195, 'lsmb_newco__account_create', 'allow', 136);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (196, 'lsmb_newco__account_create', 'allow', 137);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (197, 'lsmb_newco__account_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (198, 'lsmb_newco__account_edit', 'allow', 136);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (199, 'lsmb_newco__account_edit', 'allow', 138);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (200, 'lsmb_newco__gifi_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (201, 'lsmb_newco__gifi_create', 'allow', 136);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (202, 'lsmb_newco__gifi_create', 'allow', 139);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (203, 'lsmb_newco__gifi_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (204, 'lsmb_newco__gifi_edit', 'allow', 136);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (205, 'lsmb_newco__gifi_edit', 'allow', 140);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (206, 'lsmb_newco__department_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (207, 'lsmb_newco__department_create', 'allow', 144);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (208, 'lsmb_newco__department_create', 'allow', 145);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (209, 'lsmb_newco__department_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (210, 'lsmb_newco__department_edit', 'allow', 144);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (211, 'lsmb_newco__department_edit', 'allow', 146);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (212, 'lsmb_newco__business_type_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (213, 'lsmb_newco__business_type_create', 'allow', 147);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (214, 'lsmb_newco__business_type_create', 'allow', 148);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (215, 'lsmb_newco__business_type_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (216, 'lsmb_newco__business_type_edit', 'allow', 147);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (217, 'lsmb_newco__business_type_edit', 'allow', 149);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (218, 'lsmb_newco__sic_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (219, 'lsmb_newco__sic_create', 'allow', 153);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (220, 'lsmb_newco__sic_create', 'allow', 154);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (221, 'lsmb_newco__sic_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (222, 'lsmb_newco__sic_edit', 'allow', 153);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (223, 'lsmb_newco__sic_edit', 'allow', 155);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (224, 'lsmb_newco__template_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (225, 'lsmb_newco__template_edit', 'allow', 156);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (226, 'lsmb_newco__template_edit', 'allow', 157);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (227, 'lsmb_newco__template_edit', 'allow', 158);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (228, 'lsmb_newco__template_edit', 'allow', 159);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (229, 'lsmb_newco__template_edit', 'allow', 160);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (230, 'lsmb_newco__template_edit', 'allow', 161);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (231, 'lsmb_newco__template_edit', 'allow', 162);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (232, 'lsmb_newco__template_edit', 'allow', 163);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (233, 'lsmb_newco__template_edit', 'allow', 164);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (234, 'lsmb_newco__template_edit', 'allow', 165);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (235, 'lsmb_newco__template_edit', 'allow', 166);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (236, 'lsmb_newco__template_edit', 'allow', 167);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (237, 'lsmb_newco__template_edit', 'allow', 168);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (238, 'lsmb_newco__template_edit', 'allow', 169);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (239, 'lsmb_newco__template_edit', 'allow', 170);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (240, 'lsmb_newco__template_edit', 'allow', 171);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (241, 'lsmb_newco__template_edit', 'allow', 172);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (242, 'lsmb_newco__template_edit', 'allow', 173);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (243, 'lsmb_newco__template_edit', 'allow', 174);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (244, 'lsmb_newco__template_edit', 'allow', 175);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (245, 'lsmb_newco__template_edit', 'allow', 176);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (246, 'lsmb_newco__template_edit', 'allow', 177);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (247, 'lsmb_newco__template_edit', 'allow', 178);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (248, 'lsmb_newco__template_edit', 'allow', 179);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (249, 'lsmb_newco__template_edit', 'allow', 180);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (250, 'lsmb_newco__template_edit', 'allow', 181);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (251, 'lsmb_newco__template_edit', 'allow', 182);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (252, 'lsmb_newco__template_edit', 'allow', 183);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (253, 'lsmb_newco__template_edit', 'allow', 184);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (254, 'lsmb_newco__template_edit', 'allow', 185);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (255, 'lsmb_newco__template_edit', 'allow', 186);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (256, 'lsmb_newco__template_edit', 'allow', 187);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (257, 'lsmb_newco__template_edit', 'allow', 188);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (258, 'lsmb_newco__template_edit', 'allow', 189);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (259, 'lsmb_newco__template_edit', 'allow', 190);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (260, 'lsmb_newco__template_edit', 'allow', 241);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (261, 'lsmb_newco__template_edit', 'allow', 242);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (262, 'lsmb_newco__users_manage', 'allow', 220);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (263, 'lsmb_newco__users_manage', 'allow', 221);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (264, 'lsmb_newco__users_manage', 'allow', 222);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (265, 'lsmb_newco__language_create', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (266, 'lsmb_newco__language_create', 'allow', 150);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (267, 'lsmb_newco__language_create', 'allow', 151);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (268, 'lsmb_newco__language_edit', 'allow', 128);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (269, 'lsmb_newco__language_edit', 'allow', 150);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (270, 'lsmb_newco__language_edit', 'allow', 152);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (271, 'lsmb_newco__part_translation_create', 'allow', 77);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (272, 'lsmb_newco__part_translation_create', 'allow', 95);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (273, 'lsmb_newco__part_translation_create', 'allow', 96);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (274, 'lsmb_newco__part_translation_create', 'allow', 97);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (275, 'lsmb_newco__project_translation_create', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (276, 'lsmb_newco__project_translation_create', 'allow', 107);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (277, 'lsmb_newco__project_translation_create', 'allow', 108);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (278, 'lsmb_newco__partsgroup_translation_create', 'allow', 98);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (279, 'lsmb_newco__partsgroup_translation_create', 'allow', 107);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (280, 'lsmb_newco__partsgroup_translation_create', 'allow', 108);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (281, 'lsmb_newco__assets_enter', 'allow', 237);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (282, 'lsmb_newco__assets_enter', 'allow', 230);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (283, 'lsmb_newco__assets_enter', 'allow', 231);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (284, 'lsmb_newco__assets_enter', 'allow', 232);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (285, 'lsmb_newco__assets_enter', 'allow', 233);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (286, 'lsmb_newco__assets_enter', 'allow', 235);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (287, 'lsmb_newco__assets_depreciate', 'allow', 238);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (288, 'lsmb_newco__assets_depreciate', 'allow', 234);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (289, 'lsmb_newco__assets_approve', 'allow', 239);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (290, 'lsmb_newco__assets_approve', 'allow', 240);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (291, 'public', 'allow', 191);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (292, 'public', 'allow', 192);
INSERT INTO menu_acl (id, role_name, acl_type, node_id) VALUES (293, 'public', 'allow', 193);


--
-- Data for Name: menu_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (26, 'outstanding', '1', 584);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (205, 'menu', '1', 574);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (206, 'module', 'vouchers.pl', 575);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (206, 'action', 'search_batch', 576);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (1, 'menu', '1', 1);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (2, 'module', 'ar.pl', 2);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (2, 'action', 'add', 3);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (3, 'action', 'add', 4);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (3, 'module', 'is.pl', 5);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (3, 'type', 'invoice', 6);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (4, 'menu', '1', 7);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (5, 'module', 'ar.pl', 8);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (5, 'action', 'search', 9);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (5, 'nextsub', 'transactions', 10);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (6, 'module', 'ar.pl', 12);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (6, 'action', 'search', 13);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (6, 'nextsub', 'transactions', 14);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (7, 'module', 'rp.pl', 15);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (7, 'action', 'report', 16);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (7, 'report', 'ar_aging', 17);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (6, 'outstanding', '1', 18);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (9, 'module', 'rp.pl', 21);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (9, 'action', 'report', 22);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (9, 'report', 'tax_collected', 23);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (10, 'module', 'rp.pl', 24);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (10, 'action', 'report', 25);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (10, 'report', 'nontaxable_sales', 26);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (11, 'menu', '1', 27);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (12, 'module', 'customer.pl', 28);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (12, 'action', 'add', 29);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (13, 'menu', '1', 31);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (14, 'module', 'customer.pl', 32);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (14, 'action', 'search', 36);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (15, 'db', 'customer', 37);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (15, 'action', 'history', 33);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (16, 'menu', '1', 38);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (17, 'module', 'ps.pl', 39);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (17, 'action', 'add', 40);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (17, 'nextsub', 'openinvoices', 41);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (18, 'action', 'openinvoices', 42);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (18, 'module', 'ps.pl', 43);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (19, 'module', 'ps.pl', 44);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (19, 'action', 'receipts', 46);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (20, 'module', 'ps.pl', 47);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (20, 'action', 'till_closing', 48);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (20, 'pos', 'true', 49);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (21, 'menu', '1', 50);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (22, 'action', 'add', 52);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (22, 'module', 'ap.pl', 51);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (23, 'action', 'add', 53);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (23, 'type', 'invoice', 55);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (23, 'module', 'ir.pl', 54);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (24, 'menu', '1', 56);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (25, 'action', 'search', 58);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (25, 'nextsub', 'transactions', 59);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (25, 'module', 'ap.pl', 57);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (26, 'action', 'search', 61);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (26, 'nextsub', 'transactions', 62);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (26, 'module', 'ap.pl', 60);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (27, 'module', 'rp.pl', 63);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (27, 'action', 'report', 64);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (28, 'module', 'rp.pl', 66);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (28, 'action', 'report', 67);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (28, 'report', 'tax_collected', 68);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (27, 'report', 'tax_paid', 65);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (29, 'module', 'rp.pl', 69);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (29, 'action', 'report', 70);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (29, 'report', 'nontaxable_purchases', 71);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (30, 'menu', '1', 72);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (31, 'module', 'vendor.pl', 73);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (31, 'action', 'add', 74);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (31, 'db', 'vendor', 75);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (32, 'menu', '1', 76);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (33, 'module', 'vendor.pl', 77);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (33, 'action', 'search', 79);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (33, 'db', 'vendor', 78);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (34, 'module', 'vendor.pl', 80);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (34, 'action', 'history', 81);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (34, 'db', 'vendor', 82);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (35, 'menu', '1', 83);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (36, 'module', 'payment.pl', 84);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (36, 'action', 'payment', 85);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (36, 'type', 'receipt', 86);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (36, 'account_class', '2', 551);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (37, 'module', 'payment.pl', 87);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (37, 'account_class', '2', 89);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (37, 'action', 'use_overpayment', 88);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (223, 'module', 'payment.pl', 607);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (223, 'account_class', '1', 608);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (223, 'action', 'use_overpayment', 609);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (38, 'module', 'payment.pl', 90);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (38, 'action', 'payment', 91);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (38, 'type', 'check', 92);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (38, 'account_class', '1', 554);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (194, 'module', 'ar.pl', 538);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (194, 'action', 'add', 539);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (40, 'module', 'gl.pl', 96);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (40, 'action', 'add', 97);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (40, 'transfer', '1', 98);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (41, 'menu', '1', 99);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (42, 'module', 'rp.pl', 100);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (42, 'action', 'report', 101);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (42, 'report', 'receipts', 102);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (43, 'module', 'rp.pl', 103);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (43, 'action', 'report', 104);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (43, 'report', 'payments', 105);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (44, 'report', '1', 110);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (46, 'menu', '1', 111);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (47, 'menu', '1', 112);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (48, 'module', 'employee.pl', 113);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (48, 'action', 'add', 114);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'action', 'search', 117);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (50, 'menu', '1', 119);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (51, 'module', 'oe.pl', 120);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (51, 'action', 'add', 121);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (51, 'type', 'sales_order', 122);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (52, 'module', 'oe.pl', 123);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (52, 'action', 'add', 124);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (52, 'type', 'purchase_order', 125);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (53, 'menu', '1', 126);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (54, 'module', 'oe.pl', 127);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (54, 'type', 'sales_order', 129);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (54, 'action', 'search', 128);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (55, 'module', 'oe.pl', 130);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (55, 'type', 'purchase_order', 132);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (55, 'action', 'search', 131);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (56, 'menu', '1', 133);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (57, 'module', 'oe.pl', 134);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (57, 'action', 'search', 136);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (58, 'module', 'oe.pl', 137);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (58, 'action', 'search', 139);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (57, 'type', 'generate_sales_order', 135);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (58, 'type', 'generate_purchase_order', 138);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (60, 'menu', '1', 550);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (61, 'module', 'oe.pl', 140);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (61, 'action', 'search', 141);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (62, 'module', 'oe.pl', 143);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (62, 'action', 'search', 144);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (62, 'type', 'consolidate_purchase_order', 145);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (61, 'type', 'consolidate_sales_order', 142);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (63, 'menu', '1', 146);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (64, 'module', 'oe.pl', 147);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (64, 'action', 'search', 148);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (65, 'module', 'oe.pl', 150);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (65, 'action', 'search', 151);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (66, 'module', 'oe.pl', 153);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (66, 'action', 'search_transfer', 154);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (67, 'menu', '1', 155);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (68, 'module', 'oe.pl', 156);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (68, 'action', 'add', 157);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (69, 'module', 'oe.pl', 159);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (69, 'action', 'add', 160);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'module', 'employee.pl', 118);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (68, 'type', 'sales_quotation', 158);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (65, 'type', 'receive_order', 149);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (64, 'type', 'ship_order', 149);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (69, 'type', 'request_quotation', 161);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (70, 'menu', '1', 162);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (71, 'module', 'oe.pl', 163);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (71, 'type', 'sales_quotation', 165);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (71, 'action', 'search', 164);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (72, 'module', 'oe.pl', 166);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (72, 'action', 'search', 168);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (72, 'type', 'request_quotation', 167);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (73, 'menu', '1', 169);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (74, 'module', 'gl.pl', 170);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (74, 'action', 'add', 171);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (75, 'module', 'gl.pl', 172);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (75, 'action', 'add_pos_adjust', 174);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (75, 'rowcount', '3', 175);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (75, 'pos_adjust', '1', 176);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (75, 'reference', 'Adjusting Till: (Till)  Source: (Source)', 177);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (75, 'descripton', 'Adjusting till due to data entry error', 178);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (76, 'module', 'gl.pl', 180);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (76, 'action', 'search', 181);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (77, 'menu', '1', 182);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (78, 'module', 'ic.pl', 183);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (78, 'action', 'add', 184);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (78, 'item', 'part', 185);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (79, 'module', 'ic.pl', 186);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (79, 'action', 'add', 187);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (79, 'item', 'service', 188);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (80, 'module', 'ic.pl', 189);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (80, 'action', 'add', 190);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (81, 'module', 'ic.pl', 192);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (81, 'action', 'add', 193);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (81, 'item', 'labor', 194);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (80, 'item', 'assembly', 191);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (82, 'action', 'add', 195);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (82, 'module', 'pe.pl', 196);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (83, 'action', 'add', 198);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (83, 'module', 'pe.pl', 199);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (84, 'module', 'ic.pl', 202);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (84, 'action', 'stock_assembly', 203);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (85, 'menu', '1', 204);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (86, 'module', 'ic.pl', 205);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (86, 'action', 'search', 610);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (86, 'searchitems', 'all', 611);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (87, 'module', 'ic.pl', 612);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (87, 'action', 'search', 206);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (87, 'searchitems', 'part', 210);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (88, 'module', 'ic.pl', 211);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (88, 'action', 'requirements', 212);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (89, 'action', 'search', 213);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (89, 'module', 'ic.pl', 214);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (89, 'searchitems', 'service', 215);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (90, 'action', 'search', 216);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (90, 'module', 'ic.pl', 217);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (90, 'searchitems', 'labor', 218);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (91, 'module', 'pe.pl', 221);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (91, 'action', 'search', 220);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (92, 'module', 'pe.pl', 224);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (92, 'action', 'search', 223);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (93, 'action', 'search', 226);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (93, 'module', 'ic.pl', 227);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (93, 'searchitems', 'assembly', 228);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (94, 'action', 'search', 229);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (94, 'module', 'ic.pl', 230);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (94, 'searchitems', 'component', 231);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (95, 'menu', '1', 232);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (96, 'module', 'pe.pl', 233);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (96, 'action', 'translation', 234);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (96, 'translation', 'description', 235);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (97, 'module', 'pe.pl', 236);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (97, 'action', 'translation', 237);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (97, 'translation', 'partsgroup', 238);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (98, 'menu', '1', 239);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (99, 'module', 'pe.pl', 240);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (99, 'action', 'add', 241);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (99, 'type', 'project', 242);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (100, 'module', 'jc.pl', 243);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (100, 'action', 'add', 244);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (99, 'project', 'project', 245);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (100, 'project', 'project', 246);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (100, 'type', 'timecard', 247);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (101, 'menu', '1', 248);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (102, 'module', 'pe.pl', 249);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (102, 'action', 'project_sales_order', 250);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (103, 'menu', '1', 255);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (104, 'module', 'pe.pl', 256);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (104, 'type', 'project', 258);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (104, 'action', 'search', 257);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (105, 'action', 'report', 260);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (105, 'report', 'projects', 261);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (105, 'module', 'rp.pl', 262);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (106, 'module', 'jc.pl', 263);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (106, 'action', 'search', 264);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (106, 'type', 'timecard', 265);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (106, 'project', 'project', 266);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (107, 'menu', '1', 268);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (108, 'module', 'pe.pl', 269);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (108, 'action', 'translation', 270);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (108, 'translation', 'project', 271);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (109, 'menu', '1', 272);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (110, 'module', 'ca.pl', 273);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (110, 'action', 'chart_of_accounts', 274);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (111, 'action', 'report', 275);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (111, 'module', 'rp.pl', 276);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (111, 'report', 'trial_balance', 277);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (112, 'action', 'report', 278);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (112, 'module', 'rp.pl', 279);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (112, 'report', 'income_statement', 280);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (113, 'action', 'report', 281);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (113, 'module', 'rp.pl', 282);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (113, 'report', 'balance_sheet', 283);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (114, 'action', 'report', 284);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (114, 'module', 'rp.pl', 285);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (114, 'report', 'inv_activity', 286);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (115, 'action', 'recurring_transactions', 287);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (115, 'module', 'am.pl', 288);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (116, 'menu', '1', 289);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (119, 'module', 'bp.pl', 290);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (119, 'action', 'search', 291);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (119, 'type', 'check', 292);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (119, 'vc', 'vendor', 293);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (117, 'module', 'bp.pl', 294);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (117, 'action', 'search', 295);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (117, 'vc', 'customer', 297);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (118, 'module', 'bp.pl', 298);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (118, 'action', 'search', 299);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (118, 'vc', 'customer', 300);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (120, 'module', 'bp.pl', 302);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (120, 'action', 'search', 303);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (120, 'vc', 'customer', 304);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (121, 'module', 'bp.pl', 306);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (121, 'action', 'search', 307);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (121, 'vc', 'customer', 308);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (122, 'module', 'bp.pl', 310);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (122, 'action', 'search', 311);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (122, 'vc', 'customer', 312);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (120, 'type', 'work_order', 305);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (121, 'type', 'sales_quotation', 309);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (122, 'type', 'packing_list', 313);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (123, 'module', 'bp.pl', 314);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (123, 'action', 'search', 315);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (123, 'vc', 'customer', 316);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (123, 'type', 'pick_list', 317);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (124, 'module', 'bp.pl', 318);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (124, 'action', 'search', 319);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (124, 'vc', 'vendor', 321);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (124, 'type', 'purchase_order', 320);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (125, 'module', 'bp.pl', 322);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (125, 'action', 'search', 323);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (125, 'vc', 'vendor', 325);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (126, 'module', 'bp.pl', 326);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (117, 'type', 'invoice', 296);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (118, 'type', 'sales_order', 301);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (126, 'action', 'search', 327);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (126, 'vc', 'vendor', 329);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (127, 'module', 'bp.pl', 330);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (127, 'action', 'search', 331);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (127, 'type', 'timecard', 332);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (125, 'type', 'bin_list', 324);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (126, 'type', 'request_quotation', 328);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (127, 'vc', 'employee', 333);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (128, 'menu', '1', 334);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (129, 'module', 'am.pl', 337);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (130, 'module', 'am.pl', 338);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (131, 'module', 'am.pl', 339);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (129, 'action', 'audit_control', 340);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (130, 'taxes', 'audit_control', 341);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (131, 'action', 'defaults', 342);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (130, 'action', 'taxes', 343);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (132, 'module', 'account.pl', 346);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (132, 'action', 'yearend_info', 347);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (138, 'module', 'am.pl', 356);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (139, 'module', 'am.pl', 357);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (140, 'module', 'am.pl', 358);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (138, 'action', 'list_account', 360);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (139, 'action', 'add_gifi', 361);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (140, 'action', 'list_gifi', 362);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (141, 'menu', '1', 363);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (142, 'module', 'am.pl', 364);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (143, 'module', 'am.pl', 365);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (142, 'action', 'add_warehouse', 366);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (143, 'action', 'list_warehouse', 367);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (145, 'module', 'am.pl', 368);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (146, 'module', 'am.pl', 369);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (145, 'action', 'add_department', 370);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (146, 'action', 'list_department', 371);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (147, 'menu', '1', 372);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (148, 'module', 'am.pl', 373);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (149, 'module', 'am.pl', 374);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (148, 'action', 'add_business', 375);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (149, 'action', 'list_business', 376);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (150, 'menu', '1', 377);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (151, 'module', 'am.pl', 378);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (152, 'module', 'am.pl', 379);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (151, 'action', 'add_language', 380);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (152, 'action', 'list_language', 381);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (153, 'menu', '1', 382);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (154, 'module', 'am.pl', 383);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (155, 'module', 'am.pl', 384);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (154, 'action', 'add_sic', 385);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (155, 'action', 'list_sic', 386);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (156, 'menu', '1', 387);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (157, 'module', 'am.pl', 388);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (158, 'module', 'am.pl', 389);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (159, 'module', 'am.pl', 390);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (160, 'module', 'am.pl', 391);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (161, 'module', 'am.pl', 392);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (162, 'module', 'am.pl', 393);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (163, 'module', 'am.pl', 394);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (164, 'module', 'am.pl', 395);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (165, 'module', 'am.pl', 396);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (166, 'module', 'am.pl', 397);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (167, 'module', 'am.pl', 398);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (168, 'module', 'am.pl', 399);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (169, 'module', 'am.pl', 400);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (170, 'module', 'am.pl', 401);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (171, 'module', 'am.pl', 402);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (241, 'module', 'am.pl', 642);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (157, 'action', 'list_templates', 403);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (158, 'action', 'list_templates', 404);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (159, 'action', 'list_templates', 405);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (160, 'action', 'list_templates', 406);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (161, 'action', 'list_templates', 407);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (162, 'action', 'list_templates', 408);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (163, 'action', 'list_templates', 409);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (164, 'action', 'list_templates', 410);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (165, 'action', 'list_templates', 411);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (166, 'action', 'list_templates', 412);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (167, 'action', 'list_templates', 413);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (168, 'action', 'list_templates', 414);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (169, 'action', 'list_templates', 415);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (170, 'action', 'list_templates', 416);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (171, 'action', 'list_templates', 417);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (241, 'action', 'list_templates', 643);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (157, 'template', 'income_statement', 418);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (158, 'template', 'balance_sheet', 419);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (159, 'template', 'invoice', 420);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (160, 'template', 'ar_transaction', 421);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (161, 'template', 'ap_transaction', 422);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (162, 'template', 'packing_list', 423);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (163, 'template', 'pick_list', 424);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (164, 'template', 'sales_order', 425);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (165, 'template', 'work_order', 426);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (166, 'template', 'purchase_order', 427);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (167, 'template', 'bin_list', 428);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (168, 'template', 'statement', 429);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (169, 'template', 'quotation', 430);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (170, 'template', 'rfq', 431);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (171, 'template', 'timecard', 432);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (241, 'template', 'letterhead', 644);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (157, 'format', 'HTML', 433);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (158, 'format', 'HTML', 434);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (159, 'format', 'HTML', 435);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (160, 'format', 'HTML', 436);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (161, 'format', 'HTML', 437);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (162, 'format', 'HTML', 438);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (163, 'format', 'HTML', 439);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (164, 'format', 'HTML', 440);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (165, 'format', 'HTML', 441);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (166, 'format', 'HTML', 442);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (167, 'format', 'HTML', 443);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (168, 'format', 'HTML', 444);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (169, 'format', 'HTML', 445);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (170, 'format', 'HTML', 446);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (171, 'format', 'HTML', 447);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (241, 'format', 'HTML', 645);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (172, 'menu', '1', 448);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (173, 'action', 'list_templates', 449);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (174, 'action', 'list_templates', 450);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (175, 'action', 'list_templates', 451);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (176, 'action', 'list_templates', 452);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (177, 'action', 'list_templates', 453);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (178, 'action', 'list_templates', 454);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (179, 'action', 'list_templates', 455);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (180, 'action', 'list_templates', 456);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (181, 'action', 'list_templates', 457);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (182, 'action', 'list_templates', 458);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (183, 'action', 'list_templates', 459);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (184, 'action', 'list_templates', 460);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (185, 'action', 'list_templates', 461);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (186, 'action', 'list_templates', 462);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (187, 'action', 'list_templates', 463);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (242, 'action', 'list_templates', 646);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (173, 'module', 'am.pl', 464);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (174, 'module', 'am.pl', 465);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (175, 'module', 'am.pl', 466);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (176, 'module', 'am.pl', 467);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (177, 'module', 'am.pl', 468);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (178, 'module', 'am.pl', 469);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (179, 'module', 'am.pl', 470);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (180, 'module', 'am.pl', 471);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (181, 'module', 'am.pl', 472);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (182, 'module', 'am.pl', 473);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (183, 'module', 'am.pl', 474);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (184, 'module', 'am.pl', 475);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (185, 'module', 'am.pl', 476);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (186, 'module', 'am.pl', 477);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (187, 'module', 'am.pl', 478);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (242, 'module', 'am.pl', 647);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (173, 'format', 'LATEX', 479);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (174, 'format', 'LATEX', 480);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (175, 'format', 'LATEX', 481);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (176, 'format', 'LATEX', 482);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (177, 'format', 'LATEX', 483);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (178, 'format', 'LATEX', 484);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (179, 'format', 'LATEX', 485);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (180, 'format', 'LATEX', 486);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (181, 'format', 'LATEX', 487);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (182, 'format', 'LATEX', 488);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (183, 'format', 'LATEX', 489);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (184, 'format', 'LATEX', 490);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (185, 'format', 'LATEX', 491);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (186, 'format', 'LATEX', 492);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (187, 'format', 'LATEX', 493);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (242, 'format', 'LATEX', 648);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (173, 'template', 'invoice', 506);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (174, 'template', 'ar_transaction', 507);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (175, 'template', 'ap_transaction', 508);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (176, 'template', 'packing_list', 509);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (177, 'template', 'pick_list', 510);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (178, 'template', 'sales_order', 511);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (179, 'template', 'work_order', 512);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (180, 'template', 'purchase_order', 513);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (181, 'template', 'bin_list', 514);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (182, 'template', 'statement', 515);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (185, 'template', 'quotation', 518);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (186, 'template', 'rfq', 519);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (187, 'template', 'timecard', 520);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (183, 'template', 'check', 516);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (184, 'template', 'receipt', 517);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (242, 'template', 'letterhead', 649);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (188, 'menu', '1', 521);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (189, 'module', 'am.pl', 522);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (189, 'action', 'list_templates', 523);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (189, 'template', 'pos_invoice', 524);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (189, 'format', 'TEXT', 525);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (190, 'action', 'display_stylesheet', 526);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (190, 'module', 'am.pl', 527);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (193, 'module', 'login.pl', 532);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (193, 'action', 'logout', 533);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (193, 'target', '_top', 534);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (192, 'menu', '1', 530);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (192, 'new', '1', 531);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (0, 'menu', '1', 535);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (136, 'menu', '1', 536);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (144, 'menu', '1', 537);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (195, 'action', 'add', 540);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (195, 'module', 'is.pl', 541);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (196, 'action', 'add', 543);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (196, 'module', 'ap.pl', 544);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (197, 'action', 'add', 545);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (197, 'module', 'ir.pl', 547);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (196, 'type', 'debit_note', 549);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (194, 'type', 'credit_note', 548);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (195, 'type', 'credit_invoice', 542);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (197, 'type', 'debit_invoice', 546);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (202, 'batch_type', 'payment_reversal', 570);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (204, 'batch_type', 'receipt_reversal', 573);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (200, 'menu', '1', 552);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (198, 'action', 'create_batch', 554);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (198, 'module', 'vouchers.pl', 553);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (199, 'module', 'vouchers.pl', 559);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (199, 'action', 'create_batch', 560);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (201, 'module', 'vouchers.pl', 562);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (201, 'action', 'create_batch', 563);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (203, 'module', 'vouchers.pl', 565);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (203, 'action', 'create_batch', 566);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (202, 'module', 'vouchers.pl', 568);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (202, 'action', 'create_batch', 569);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (204, 'module', 'vouchers.pl', 571);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (204, 'action', 'create_batch', 572);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (201, 'batch_type', 'payment', 564);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (210, 'action', 'search', 585);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (210, 'module', 'drafts.pl', 586);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (199, 'batch_type', 'ap', 561);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (15, 'module', 'customer.pl', 35);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (45, 'module', 'recon.pl', 106);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (45, 'action', 'new_report', 107);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (44, 'module', 'recon.pl', 108);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (44, 'action', 'search', 109);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (211, 'module', 'recon.pl', 587);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (211, 'action', 'search', 588);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (211, 'hide_status', '1', 589);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (211, 'approved', '0', 590);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (211, 'submitted', '1', 591);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (198, 'batch_type', 'ar', 555);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (191, 'module', 'user.pl', 528);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (191, 'action', 'preference_screen', 529);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (217, 'menu', '1', 597);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (218, 'action', 'add_taxform', 598);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (218, 'module', 'taxform.pl', 599);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (137, 'module', 'account.pl', 355);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (137, 'action', 'new', 359);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (219, 'menu', '1', 600);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (220, 'module', 'admin.pl', 601);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (220, 'action', 'new_user', 602);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (221, 'module', 'admin.pl', 603);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (221, 'action', 'search_users', 604);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (222, 'module', 'admin.pl', 605);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (222, 'action', 'list_sessions', 606);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'l_last_name', '1', 115);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'l_employeenumber', '1', 116);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'l_first_name', '1', 613);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'l_id', '1', 614);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'l_startdate', '1', 615);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (49, 'l_enddate', '1', 616);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (225, 'module', 'taxform.pl', 613);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (225, 'action', 'list_all', 614);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (226, 'module', 'taxform.pl', 615);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (227, 'menu', '1', 616);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (228, 'menu', '1', 617);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (229, 'menu', '1', 618);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (230, 'action', 'asset_category_screen', 620);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (231, 'action', 'asset_category_search', 622);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (232, 'action', 'asset_screen', 624);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (233, 'action', 'asset_search', 626);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (234, 'module', 'asset.pl', 627);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (234, 'action', 'new_report', 628);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (235, 'module', 'asset.pl', 630);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (236, 'menu', '1', 632);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (237, 'module', 'asset.pl', 633);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (237, 'action', 'display_nbv', 634);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (232, 'module', 'asset.pl', 623);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (230, 'module', 'asset.pl', 619);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (231, 'module', 'asset.pl', 621);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (233, 'module', 'asset.pl', 625);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (234, 'depreciation', '1', 629);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (238, 'action', 'new_report', 636);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (238, 'module', 'asset.pl', 635);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (239, 'module', 'asset.pl', 637);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (239, 'action', 'search_reports', 638);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (239, 'depreciation', '1', 639);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (240, 'module', 'asset.pl', 640);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (240, 'action', 'search_reports', 641);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (83, 'type', 'pricegroup', 200);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (82, 'type', 'partsgroup', 197);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (91, 'type', 'partsgroup', 222);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (92, 'type', 'pricegroup', 225);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (235, 'action', 'begin_import', 631);
INSERT INTO menu_attribute (node_id, attribute, value, id) VALUES (203, 'batch_type', 'receipt', 567);


--
-- Data for Name: menu_node; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO menu_node (id, label, parent, "position") VALUES (205, 'Transaction Approval', 0, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (206, 'Batches', 205, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (46, 'HR', 0, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (50, 'Order Entry', 0, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (63, 'Shipping', 0, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (67, 'Quotations', 0, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (73, 'General Journal', 0, 10);
INSERT INTO menu_node (id, label, parent, "position") VALUES (77, 'Goods and Services', 0, 11);
INSERT INTO menu_node (id, label, parent, "position") VALUES (0, 'Top-level', NULL, 0);
INSERT INTO menu_node (id, label, parent, "position") VALUES (1, 'AR', 0, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (2, 'Add Transaction', 1, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (5, 'Transactions', 4, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (6, 'Outstanding', 4, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (7, 'AR Aging', 4, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (9, 'Taxable Sales', 4, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (10, 'Non-Taxable', 4, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (12, 'Add Customer', 11, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (13, 'Reports', 11, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (14, 'Search', 13, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (15, 'History', 13, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (16, 'Point of Sale', 0, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (17, 'Sale', 16, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (18, 'Open', 16, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (19, 'Receipts', 16, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (20, 'Close Till', 16, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (21, 'AP', 0, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (22, 'Add Transaction', 21, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (145, 'Add Department', 144, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (25, 'Transactions', 24, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (26, 'Outstanding', 24, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (27, 'AP Aging', 24, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (28, 'Taxable', 24, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (29, 'Non-taxable', 24, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (31, 'Add Vendor', 30, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (32, 'Reports', 30, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (33, 'Search', 32, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (34, 'History', 32, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (35, 'Cash', 0, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (36, 'Receipt', 35, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (38, 'Payment', 35, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (223, 'Use Overpayment', 35, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (37, 'Use AR Overpayment', 35, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (146, 'List Departments', 144, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (42, 'Receipts', 41, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (43, 'Payments', 41, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (44, 'Reconciliation', 41, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (47, 'Employees', 46, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (48, 'Add Employee', 47, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (49, 'Search', 47, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (51, 'Sales Order', 50, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (52, 'Purchase Order', 50, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (53, 'Reports', 50, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (54, 'Sales Orders', 53, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (55, 'Purchase Orders', 53, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (57, 'Sales Orders', 56, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (58, 'Purchase Orders', 56, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (56, 'Generate', 50, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (60, 'Consolidate', 50, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (61, 'Sales Orders', 60, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (62, 'Purchase Orders', 60, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (64, 'Ship', 63, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (65, 'Receive', 63, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (66, 'Transfer', 63, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (68, 'Quotation', 67, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (69, 'RFQ', 67, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (70, 'Reports', 67, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (71, 'Quotations', 70, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (72, 'RFQs', 70, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (74, 'Journal Entry', 73, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (75, 'Adjust Till', 73, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (76, 'Reports', 73, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (78, 'Add Part', 77, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (79, 'Add Service', 77, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (80, 'Add Assembly', 77, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (81, 'Add Overhead', 77, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (82, 'Add Group', 77, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (83, 'Add Pricegroup', 77, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (84, 'Stock Assembly', 77, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (85, 'Reports', 77, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (86, 'All Items', 85, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (87, 'Parts', 85, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (88, 'Requirements', 85, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (89, 'Services', 85, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (90, 'Labor', 85, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (91, 'Groups', 85, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (92, 'Pricegroups', 85, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (93, 'Assembly', 85, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (94, 'Components', 85, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (95, 'Translations', 77, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (96, 'Description', 95, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (97, 'Partsgroup', 95, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (99, 'Add Project', 98, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (100, 'Add Timecard', 98, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (101, 'Generate', 98, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (102, 'Sales Orders', 101, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (103, 'Reports', 98, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (104, 'Search', 103, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (105, 'Transactions', 103, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (106, 'Time Cards', 103, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (107, 'Translations', 98, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (108, 'Description', 107, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (110, 'Chart of Accounts', 109, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (111, 'Trial Balance', 109, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (112, 'Income Statement', 109, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (113, 'Balance Sheet', 109, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (114, 'Inventory Activity', 109, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (117, 'Sales Invoices', 116, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (118, 'Sales Orders', 116, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (119, 'Checks', 116, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (120, 'Work Orders', 116, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (121, 'Quotations', 116, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (122, 'Packing Lists', 116, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (123, 'Pick Lists', 116, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (124, 'Purchase Orders', 116, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (125, 'Bin Lists', 116, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (126, 'RFQs', 116, 10);
INSERT INTO menu_node (id, label, parent, "position") VALUES (127, 'Time Cards', 116, 11);
INSERT INTO menu_node (id, label, parent, "position") VALUES (129, 'Audit Control', 128, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (130, 'Taxes', 128, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (131, 'Defaults', 128, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (132, 'Yearend', 128, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (137, 'Add Accounts', 136, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (138, 'List Accounts', 136, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (139, 'Add GIFI', 136, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (140, 'List GIFI', 136, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (142, 'Add Warehouse', 141, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (143, 'List Warehouse', 141, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (148, 'Add Business', 147, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (149, 'List Businesses', 147, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (151, 'Add Language', 150, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (152, 'List Languages', 150, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (154, 'Add SIC', 153, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (155, 'List SIC', 153, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (157, 'Income Statement', 156, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (158, 'Balance Sheet', 156, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (159, 'Invoice', 156, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (160, 'AR Transaction', 156, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (161, 'AP Transaction', 156, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (162, 'Packing List', 156, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (163, 'Pick List', 156, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (164, 'Sales Order', 156, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (165, 'Work Order', 156, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (166, 'Purchase Order', 156, 10);
INSERT INTO menu_node (id, label, parent, "position") VALUES (167, 'Bin List', 156, 11);
INSERT INTO menu_node (id, label, parent, "position") VALUES (168, 'Statement', 156, 12);
INSERT INTO menu_node (id, label, parent, "position") VALUES (169, 'Quotation', 156, 13);
INSERT INTO menu_node (id, label, parent, "position") VALUES (170, 'RFQ', 156, 14);
INSERT INTO menu_node (id, label, parent, "position") VALUES (171, 'Timecard', 156, 15);
INSERT INTO menu_node (id, label, parent, "position") VALUES (241, 'Letterhead', 156, 16);
INSERT INTO menu_node (id, label, parent, "position") VALUES (173, 'Invoice', 172, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (174, 'AR Transaction', 172, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (175, 'AP Transaction', 172, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (176, 'Packing List', 172, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (177, 'Pick List', 172, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (178, 'Sales Order', 172, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (179, 'Work Order', 172, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (180, 'Purchase Order', 172, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (181, 'Bin List', 172, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (182, 'Statement', 172, 10);
INSERT INTO menu_node (id, label, parent, "position") VALUES (183, 'Check', 172, 11);
INSERT INTO menu_node (id, label, parent, "position") VALUES (184, 'Receipt', 172, 12);
INSERT INTO menu_node (id, label, parent, "position") VALUES (185, 'Quotation', 172, 13);
INSERT INTO menu_node (id, label, parent, "position") VALUES (186, 'RFQ', 172, 14);
INSERT INTO menu_node (id, label, parent, "position") VALUES (187, 'Timecard', 172, 15);
INSERT INTO menu_node (id, label, parent, "position") VALUES (242, 'Letterhead', 172, 16);
INSERT INTO menu_node (id, label, parent, "position") VALUES (189, 'POS Invoice', 188, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (198, 'AR Voucher', 1, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (3, 'Sales Invoice', 1, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (11, 'Customers', 1, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (4, 'Reports', 1, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (194, 'Credit Note', 1, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (195, 'Credit Invoice', 1, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (199, 'AP Voucher', 21, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (23, 'Vendor Invoice', 21, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (24, 'Reports', 21, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (30, 'Vendors', 21, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (196, 'Debit Note', 21, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (197, 'Debit Invoice', 21, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (200, 'Vouchers', 35, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (40, 'Transfer', 35, 6);
INSERT INTO menu_node (id, label, parent, "position") VALUES (41, 'Reports', 35, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (45, 'Reconciliation', 35, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (203, 'Receipts', 200, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (204, 'Reverse Receipts', 200, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (201, 'Payments', 200, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (202, 'Reverse Payment', 200, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (98, 'Projects', 0, 12);
INSERT INTO menu_node (id, label, parent, "position") VALUES (109, 'Reports', 0, 13);
INSERT INTO menu_node (id, label, parent, "position") VALUES (115, 'Recurring Transactions', 0, 14);
INSERT INTO menu_node (id, label, parent, "position") VALUES (210, 'Drafts', 205, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (211, 'Reconciliation', 205, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (217, 'Tax Forms', 0, 15);
INSERT INTO menu_node (id, label, parent, "position") VALUES (218, 'Add Tax Form', 217, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (219, 'Admin Users', 128, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (188, 'Text Templates', 128, 15);
INSERT INTO menu_node (id, label, parent, "position") VALUES (172, 'LaTeX Templates', 128, 14);
INSERT INTO menu_node (id, label, parent, "position") VALUES (156, 'HTML Templates', 128, 13);
INSERT INTO menu_node (id, label, parent, "position") VALUES (153, 'SIC', 128, 12);
INSERT INTO menu_node (id, label, parent, "position") VALUES (150, 'Language', 128, 11);
INSERT INTO menu_node (id, label, parent, "position") VALUES (147, 'Type of Business', 128, 10);
INSERT INTO menu_node (id, label, parent, "position") VALUES (144, 'Departments', 128, 9);
INSERT INTO menu_node (id, label, parent, "position") VALUES (141, 'Warehouses', 128, 8);
INSERT INTO menu_node (id, label, parent, "position") VALUES (136, 'Chart of Accounts', 128, 7);
INSERT INTO menu_node (id, label, parent, "position") VALUES (220, 'Add User', 219, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (221, 'Search Users', 219, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (222, 'Sessions', 219, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (225, 'List Tax Forms', 217, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (226, 'Reports', 217, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (227, 'Fixed Assets', 0, 17);
INSERT INTO menu_node (id, label, parent, "position") VALUES (193, 'Logout', 0, 23);
INSERT INTO menu_node (id, label, parent, "position") VALUES (192, 'New Window', 0, 22);
INSERT INTO menu_node (id, label, parent, "position") VALUES (191, 'Preferences', 0, 21);
INSERT INTO menu_node (id, label, parent, "position") VALUES (190, 'Stylesheet', 0, 20);
INSERT INTO menu_node (id, label, parent, "position") VALUES (128, 'System', 0, 19);
INSERT INTO menu_node (id, label, parent, "position") VALUES (116, 'Batch Printing', 0, 18);
INSERT INTO menu_node (id, label, parent, "position") VALUES (228, 'Asset Classes', 227, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (229, 'Assets', 227, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (230, 'Add Class', 228, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (231, 'List Classes', 228, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (232, 'Add Assets', 229, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (233, 'Search Assets', 229, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (235, 'Import', 229, 3);
INSERT INTO menu_node (id, label, parent, "position") VALUES (234, 'Depreciate', 229, 4);
INSERT INTO menu_node (id, label, parent, "position") VALUES (237, 'Net Book Value', 236, 1);
INSERT INTO menu_node (id, label, parent, "position") VALUES (238, 'Disposal', 229, 5);
INSERT INTO menu_node (id, label, parent, "position") VALUES (236, 'Reports', 229, 11);
INSERT INTO menu_node (id, label, parent, "position") VALUES (239, 'Depreciation', 236, 2);
INSERT INTO menu_node (id, label, parent, "position") VALUES (240, 'Disposal', 236, 3);


--
-- Data for Name: mime_type; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO mime_type (id, mime_type) VALUES (1, 'all/all');
INSERT INTO mime_type (id, mime_type) VALUES (2, 'all/allfiles');
INSERT INTO mime_type (id, mime_type) VALUES (3, 'audio/x-flac');
INSERT INTO mime_type (id, mime_type) VALUES (4, 'audio/x-ape');
INSERT INTO mime_type (id, mime_type) VALUES (5, 'audio/x-scpls');
INSERT INTO mime_type (id, mime_type) VALUES (6, 'audio/mp4');
INSERT INTO mime_type (id, mime_type) VALUES (7, 'audio/mpeg');
INSERT INTO mime_type (id, mime_type) VALUES (8, 'audio/x-iriver-pla');
INSERT INTO mime_type (id, mime_type) VALUES (9, 'audio/x-speex+ogg');
INSERT INTO mime_type (id, mime_type) VALUES (10, 'audio/x-mod');
INSERT INTO mime_type (id, mime_type) VALUES (11, 'audio/x-tta');
INSERT INTO mime_type (id, mime_type) VALUES (12, 'audio/annodex');
INSERT INTO mime_type (id, mime_type) VALUES (13, 'audio/x-mo3');
INSERT INTO mime_type (id, mime_type) VALUES (14, 'audio/midi');
INSERT INTO mime_type (id, mime_type) VALUES (15, 'audio/mp2');
INSERT INTO mime_type (id, mime_type) VALUES (16, 'audio/x-musepack');
INSERT INTO mime_type (id, mime_type) VALUES (17, 'audio/x-minipsf');
INSERT INTO mime_type (id, mime_type) VALUES (18, 'audio/x-mpegurl');
INSERT INTO mime_type (id, mime_type) VALUES (19, 'audio/x-aiff');
INSERT INTO mime_type (id, mime_type) VALUES (20, 'audio/x-xm');
INSERT INTO mime_type (id, mime_type) VALUES (21, 'audio/x-aifc');
INSERT INTO mime_type (id, mime_type) VALUES (22, 'audio/x-m4b');
INSERT INTO mime_type (id, mime_type) VALUES (23, 'audio/aac');
INSERT INTO mime_type (id, mime_type) VALUES (24, 'audio/x-psflib');
INSERT INTO mime_type (id, mime_type) VALUES (25, 'audio/x-pn-realaudio-plugin');
INSERT INTO mime_type (id, mime_type) VALUES (26, 'audio/basic');
INSERT INTO mime_type (id, mime_type) VALUES (27, 'audio/x-ms-wma');
INSERT INTO mime_type (id, mime_type) VALUES (28, 'audio/AMR-WB');
INSERT INTO mime_type (id, mime_type) VALUES (29, 'audio/x-riff');
INSERT INTO mime_type (id, mime_type) VALUES (30, 'audio/x-psf');
INSERT INTO mime_type (id, mime_type) VALUES (31, 'audio/x-adpcm');
INSERT INTO mime_type (id, mime_type) VALUES (32, 'audio/ogg');
INSERT INTO mime_type (id, mime_type) VALUES (33, 'audio/x-wav');
INSERT INTO mime_type (id, mime_type) VALUES (34, 'audio/x-matroska');
INSERT INTO mime_type (id, mime_type) VALUES (35, 'audio/x-voc');
INSERT INTO mime_type (id, mime_type) VALUES (36, 'audio/ac3');
INSERT INTO mime_type (id, mime_type) VALUES (37, 'audio/x-flac+ogg');
INSERT INTO mime_type (id, mime_type) VALUES (38, 'audio/x-aiffc');
INSERT INTO mime_type (id, mime_type) VALUES (39, 'audio/x-it');
INSERT INTO mime_type (id, mime_type) VALUES (40, 'audio/AMR');
INSERT INTO mime_type (id, mime_type) VALUES (41, 'audio/x-s3m');
INSERT INTO mime_type (id, mime_type) VALUES (42, 'audio/x-speex');
INSERT INTO mime_type (id, mime_type) VALUES (43, 'audio/x-wavpack');
INSERT INTO mime_type (id, mime_type) VALUES (44, 'audio/x-xi');
INSERT INTO mime_type (id, mime_type) VALUES (45, 'audio/x-xmf');
INSERT INTO mime_type (id, mime_type) VALUES (46, 'audio/x-wavpack-correction');
INSERT INTO mime_type (id, mime_type) VALUES (47, 'audio/prs.sid');
INSERT INTO mime_type (id, mime_type) VALUES (48, 'audio/x-gsm');
INSERT INTO mime_type (id, mime_type) VALUES (49, 'audio/x-ms-asx');
INSERT INTO mime_type (id, mime_type) VALUES (50, 'audio/x-vorbis+ogg');
INSERT INTO mime_type (id, mime_type) VALUES (51, 'audio/x-stm');
INSERT INTO mime_type (id, mime_type) VALUES (52, 'x-epoc/x-sisx-app');
INSERT INTO mime_type (id, mime_type) VALUES (53, 'image/x-fpx');
INSERT INTO mime_type (id, mime_type) VALUES (54, 'image/x-panasonic-raw');
INSERT INTO mime_type (id, mime_type) VALUES (55, 'image/x-xwindowdump');
INSERT INTO mime_type (id, mime_type) VALUES (56, 'image/x-nikon-nef');
INSERT INTO mime_type (id, mime_type) VALUES (57, 'image/x-niff');
INSERT INTO mime_type (id, mime_type) VALUES (58, 'image/x-pict');
INSERT INTO mime_type (id, mime_type) VALUES (59, 'image/svg+xml-compressed');
INSERT INTO mime_type (id, mime_type) VALUES (60, 'image/jp2');
INSERT INTO mime_type (id, mime_type) VALUES (61, 'image/x-msod');
INSERT INTO mime_type (id, mime_type) VALUES (62, 'image/x-dds');
INSERT INTO mime_type (id, mime_type) VALUES (63, 'image/x-olympus-orf');
INSERT INTO mime_type (id, mime_type) VALUES (64, 'image/x-portable-graymap');
INSERT INTO mime_type (id, mime_type) VALUES (65, 'image/x-skencil');
INSERT INTO mime_type (id, mime_type) VALUES (66, 'image/x-sony-srf');
INSERT INTO mime_type (id, mime_type) VALUES (67, 'image/x-dib');
INSERT INTO mime_type (id, mime_type) VALUES (68, 'image/x-emf');
INSERT INTO mime_type (id, mime_type) VALUES (69, 'image/x-eps');
INSERT INTO mime_type (id, mime_type) VALUES (70, 'image/ief');
INSERT INTO mime_type (id, mime_type) VALUES (71, 'image/x-pcx');
INSERT INTO mime_type (id, mime_type) VALUES (72, 'image/x-gzeps');
INSERT INTO mime_type (id, mime_type) VALUES (73, 'image/x-xcf');
INSERT INTO mime_type (id, mime_type) VALUES (74, 'image/x-portable-pixmap');
INSERT INTO mime_type (id, mime_type) VALUES (75, 'image/x-kde-raw');
INSERT INTO mime_type (id, mime_type) VALUES (76, 'image/openraster');
INSERT INTO mime_type (id, mime_type) VALUES (77, 'image/x-macpaint');
INSERT INTO mime_type (id, mime_type) VALUES (78, 'image/x-wmf');
INSERT INTO mime_type (id, mime_type) VALUES (79, 'image/x-win-bitmap');
INSERT INTO mime_type (id, mime_type) VALUES (80, 'image/x-sgi');
INSERT INTO mime_type (id, mime_type) VALUES (81, 'image/x-ilbm');
INSERT INTO mime_type (id, mime_type) VALUES (82, 'image/x-sony-sr2');
INSERT INTO mime_type (id, mime_type) VALUES (83, 'image/x-sigma-x3f');
INSERT INTO mime_type (id, mime_type) VALUES (84, 'image/x-bzeps');
INSERT INTO mime_type (id, mime_type) VALUES (85, 'image/x-icns');
INSERT INTO mime_type (id, mime_type) VALUES (86, 'image/g3fax');
INSERT INTO mime_type (id, mime_type) VALUES (87, 'image/x-applix-graphics');
INSERT INTO mime_type (id, mime_type) VALUES (88, 'image/x-xcursor');
INSERT INTO mime_type (id, mime_type) VALUES (89, 'image/x-kodak-dcr');
INSERT INTO mime_type (id, mime_type) VALUES (90, 'image/x-hdr');
INSERT INTO mime_type (id, mime_type) VALUES (91, 'image/x-cmu-raster');
INSERT INTO mime_type (id, mime_type) VALUES (92, 'image/x-sun-raster');
INSERT INTO mime_type (id, mime_type) VALUES (93, 'image/fax-g3');
INSERT INTO mime_type (id, mime_type) VALUES (94, 'image/x-kodak-kdc');
INSERT INTO mime_type (id, mime_type) VALUES (95, 'image/jpeg');
INSERT INTO mime_type (id, mime_type) VALUES (96, 'image/tiff');
INSERT INTO mime_type (id, mime_type) VALUES (97, 'image/dpx');
INSERT INTO mime_type (id, mime_type) VALUES (98, 'image/x-dcraw');
INSERT INTO mime_type (id, mime_type) VALUES (99, 'image/x-adobe-dng');
INSERT INTO mime_type (id, mime_type) VALUES (100, 'image/x-canon-crw');
INSERT INTO mime_type (id, mime_type) VALUES (101, 'image/bmp');
INSERT INTO mime_type (id, mime_type) VALUES (102, 'image/x-xfig');
INSERT INTO mime_type (id, mime_type) VALUES (103, 'image/x-lwo');
INSERT INTO mime_type (id, mime_type) VALUES (104, 'image/x-fuji-raf');
INSERT INTO mime_type (id, mime_type) VALUES (105, 'image/x-xbitmap');
INSERT INTO mime_type (id, mime_type) VALUES (106, 'image/x-pentax-pef');
INSERT INTO mime_type (id, mime_type) VALUES (107, 'image/x-exr');
INSERT INTO mime_type (id, mime_type) VALUES (108, 'image/rle');
INSERT INTO mime_type (id, mime_type) VALUES (109, 'image/x-3ds');
INSERT INTO mime_type (id, mime_type) VALUES (110, 'image/svg+xml');
INSERT INTO mime_type (id, mime_type) VALUES (111, 'image/x-lws');
INSERT INTO mime_type (id, mime_type) VALUES (112, 'image/x-tga');
INSERT INTO mime_type (id, mime_type) VALUES (113, 'image/x-compressed-xcf');
INSERT INTO mime_type (id, mime_type) VALUES (114, 'image/fits');
INSERT INTO mime_type (id, mime_type) VALUES (115, 'image/x-kodak-k25');
INSERT INTO mime_type (id, mime_type) VALUES (116, 'image/x-portable-bitmap');
INSERT INTO mime_type (id, mime_type) VALUES (117, 'image/x-quicktime');
INSERT INTO mime_type (id, mime_type) VALUES (118, 'image/x-sony-arw');
INSERT INTO mime_type (id, mime_type) VALUES (119, 'image/x-xpixmap');
INSERT INTO mime_type (id, mime_type) VALUES (120, 'image/gif');
INSERT INTO mime_type (id, mime_type) VALUES (121, 'image/x-portable-anymap');
INSERT INTO mime_type (id, mime_type) VALUES (122, 'image/x-jng');
INSERT INTO mime_type (id, mime_type) VALUES (123, 'image/x-iff');
INSERT INTO mime_type (id, mime_type) VALUES (124, 'image/x-canon-cr2');
INSERT INTO mime_type (id, mime_type) VALUES (125, 'image/cgm');
INSERT INTO mime_type (id, mime_type) VALUES (126, 'image/x-photo-cd');
INSERT INTO mime_type (id, mime_type) VALUES (127, 'image/png');
INSERT INTO mime_type (id, mime_type) VALUES (128, 'image/x-minolta-mrw');
INSERT INTO mime_type (id, mime_type) VALUES (129, 'image/x-rgb');
INSERT INTO mime_type (id, mime_type) VALUES (130, 'image/x-pic');
INSERT INTO mime_type (id, mime_type) VALUES (131, 'message/disposition-notification');
INSERT INTO mime_type (id, mime_type) VALUES (132, 'message/news');
INSERT INTO mime_type (id, mime_type) VALUES (133, 'message/partial');
INSERT INTO mime_type (id, mime_type) VALUES (134, 'message/x-gnu-rmail');
INSERT INTO mime_type (id, mime_type) VALUES (135, 'message/delivery-status');
INSERT INTO mime_type (id, mime_type) VALUES (136, 'message/external-body');
INSERT INTO mime_type (id, mime_type) VALUES (137, 'message/rfc822');
INSERT INTO mime_type (id, mime_type) VALUES (138, 'uri/mmst');
INSERT INTO mime_type (id, mime_type) VALUES (139, 'uri/rtspu');
INSERT INTO mime_type (id, mime_type) VALUES (140, 'uri/pnm');
INSERT INTO mime_type (id, mime_type) VALUES (141, 'uri/mmsu');
INSERT INTO mime_type (id, mime_type) VALUES (142, 'uri/rtspt');
INSERT INTO mime_type (id, mime_type) VALUES (143, 'uri/mms');
INSERT INTO mime_type (id, mime_type) VALUES (144, 'text/x-tcl');
INSERT INTO mime_type (id, mime_type) VALUES (145, 'text/directory');
INSERT INTO mime_type (id, mime_type) VALUES (146, 'text/htmlh');
INSERT INTO mime_type (id, mime_type) VALUES (147, 'text/x-literate-haskell');
INSERT INTO mime_type (id, mime_type) VALUES (148, 'text/xmcd');
INSERT INTO mime_type (id, mime_type) VALUES (149, 'text/x-ms-regedit');
INSERT INTO mime_type (id, mime_type) VALUES (150, 'text/x-microdvd');
INSERT INTO mime_type (id, mime_type) VALUES (151, 'text/x-erlang');
INSERT INTO mime_type (id, mime_type) VALUES (152, 'text/x-ssa');
INSERT INTO mime_type (id, mime_type) VALUES (153, 'text/plain');
INSERT INTO mime_type (id, mime_type) VALUES (154, 'text/spreadsheet');
INSERT INTO mime_type (id, mime_type) VALUES (155, 'text/sgml');
INSERT INTO mime_type (id, mime_type) VALUES (156, 'text/x-uil');
INSERT INTO mime_type (id, mime_type) VALUES (157, 'text/x-troff-mm');
INSERT INTO mime_type (id, mime_type) VALUES (158, 'text/x-gettext-translation');
INSERT INTO mime_type (id, mime_type) VALUES (159, 'text/x-vhdl');
INSERT INTO mime_type (id, mime_type) VALUES (160, 'text/x-java');
INSERT INTO mime_type (id, mime_type) VALUES (161, 'text/x-nfo');
INSERT INTO mime_type (id, mime_type) VALUES (162, 'text/csv');
INSERT INTO mime_type (id, mime_type) VALUES (163, 'text/x-install');
INSERT INTO mime_type (id, mime_type) VALUES (164, 'text/x-c++src');
INSERT INTO mime_type (id, mime_type) VALUES (165, 'text/x-subviewer');
INSERT INTO mime_type (id, mime_type) VALUES (166, 'text/x-adasrc');
INSERT INTO mime_type (id, mime_type) VALUES (167, 'text/x-dsl');
INSERT INTO mime_type (id, mime_type) VALUES (168, 'text/x-chdr');
INSERT INTO mime_type (id, mime_type) VALUES (169, 'text/calendar');
INSERT INTO mime_type (id, mime_type) VALUES (170, 'text/x-csharp');
INSERT INTO mime_type (id, mime_type) VALUES (171, 'text/x-lua');
INSERT INTO mime_type (id, mime_type) VALUES (172, 'text/x-ocaml');
INSERT INTO mime_type (id, mime_type) VALUES (173, 'text/x-iMelody');
INSERT INTO mime_type (id, mime_type) VALUES (174, 'text/enriched');
INSERT INTO mime_type (id, mime_type) VALUES (175, 'text/richtext');
INSERT INTO mime_type (id, mime_type) VALUES (176, 'text/x-objchdr');
INSERT INTO mime_type (id, mime_type) VALUES (177, 'text/x-makefile');
INSERT INTO mime_type (id, mime_type) VALUES (178, 'text/x-copying');
INSERT INTO mime_type (id, mime_type) VALUES (179, 'text/x-pascal');
INSERT INTO mime_type (id, mime_type) VALUES (180, 'text/x-credits');
INSERT INTO mime_type (id, mime_type) VALUES (181, 'text/x-mup');
INSERT INTO mime_type (id, mime_type) VALUES (182, 'text/x-opml+xml');
INSERT INTO mime_type (id, mime_type) VALUES (183, 'text/x-rpm-spec');
INSERT INTO mime_type (id, mime_type) VALUES (184, 'text/x-xmi');
INSERT INTO mime_type (id, mime_type) VALUES (185, 'text/x-dsrc');
INSERT INTO mime_type (id, mime_type) VALUES (186, 'text/x-patch');
INSERT INTO mime_type (id, mime_type) VALUES (187, 'text/x-authors');
INSERT INTO mime_type (id, mime_type) VALUES (188, 'text/x-ldif');
INSERT INTO mime_type (id, mime_type) VALUES (189, 'text/x-moc');
INSERT INTO mime_type (id, mime_type) VALUES (190, 'text/x-tex');
INSERT INTO mime_type (id, mime_type) VALUES (191, 'text/x-dcl');
INSERT INTO mime_type (id, mime_type) VALUES (192, 'text/x-python');
INSERT INTO mime_type (id, mime_type) VALUES (193, 'text/x-lilypond');
INSERT INTO mime_type (id, mime_type) VALUES (194, 'text/x-katefilelist');
INSERT INTO mime_type (id, mime_type) VALUES (195, 'text/troff');
INSERT INTO mime_type (id, mime_type) VALUES (196, 'text/x-hex');
INSERT INTO mime_type (id, mime_type) VALUES (197, 'text/x-google-video-pointer');
INSERT INTO mime_type (id, mime_type) VALUES (198, 'text/x-haskell');
INSERT INTO mime_type (id, mime_type) VALUES (199, 'text/x-ocl');
INSERT INTO mime_type (id, mime_type) VALUES (200, 'text/x-idl');
INSERT INTO mime_type (id, mime_type) VALUES (201, 'text/x-troff-me');
INSERT INTO mime_type (id, mime_type) VALUES (202, 'text/x-bibtex');
INSERT INTO mime_type (id, mime_type) VALUES (203, 'text/x-sql');
INSERT INTO mime_type (id, mime_type) VALUES (204, 'text/x-emacs-lisp');
INSERT INTO mime_type (id, mime_type) VALUES (205, 'text/x-eiffel');
INSERT INTO mime_type (id, mime_type) VALUES (206, 'text/css');
INSERT INTO mime_type (id, mime_type) VALUES (207, 'text/x-fortran');
INSERT INTO mime_type (id, mime_type) VALUES (208, 'text/x-xslfo');
INSERT INTO mime_type (id, mime_type) VALUES (209, 'text/x-matlab');
INSERT INTO mime_type (id, mime_type) VALUES (210, 'text/x-uri');
INSERT INTO mime_type (id, mime_type) VALUES (211, 'text/x-setext');
INSERT INTO mime_type (id, mime_type) VALUES (212, 'text/x-readme');
INSERT INTO mime_type (id, mime_type) VALUES (213, 'text/x-troff-ms');
INSERT INTO mime_type (id, mime_type) VALUES (214, 'text/x-cmake');
INSERT INTO mime_type (id, mime_type) VALUES (215, 'text/tab-separated-values');
INSERT INTO mime_type (id, mime_type) VALUES (216, 'text/x-log');
INSERT INTO mime_type (id, mime_type) VALUES (217, 'text/x-mpsub');
INSERT INTO mime_type (id, mime_type) VALUES (218, 'text/x-mof');
INSERT INTO mime_type (id, mime_type) VALUES (219, 'text/html');
INSERT INTO mime_type (id, mime_type) VALUES (220, 'text/x-txt2tags');
INSERT INTO mime_type (id, mime_type) VALUES (221, 'text/x-csrc');
INSERT INTO mime_type (id, mime_type) VALUES (222, 'text/rfc822-headers');
INSERT INTO mime_type (id, mime_type) VALUES (223, 'text/x-mrml');
INSERT INTO mime_type (id, mime_type) VALUES (224, 'text/x-vala');
INSERT INTO mime_type (id, mime_type) VALUES (225, 'text/x-iptables');
INSERT INTO mime_type (id, mime_type) VALUES (226, 'text/x-c++hdr');
INSERT INTO mime_type (id, mime_type) VALUES (227, 'text/x-scheme');
INSERT INTO mime_type (id, mime_type) VALUES (228, 'text/x-texinfo');
INSERT INTO mime_type (id, mime_type) VALUES (229, 'text/x-objcsrc');
INSERT INTO mime_type (id, mime_type) VALUES (230, 'text/x-changelog');
INSERT INTO mime_type (id, mime_type) VALUES (231, 'x-content/audio-dvd');
INSERT INTO mime_type (id, mime_type) VALUES (232, 'x-content/video-svcd');
INSERT INTO mime_type (id, mime_type) VALUES (233, 'x-content/video-hddvd');
INSERT INTO mime_type (id, mime_type) VALUES (234, 'x-content/blank-dvd');
INSERT INTO mime_type (id, mime_type) VALUES (235, 'x-content/video-vcd');
INSERT INTO mime_type (id, mime_type) VALUES (236, 'x-content/unix-software');
INSERT INTO mime_type (id, mime_type) VALUES (237, 'x-content/blank-cd');
INSERT INTO mime_type (id, mime_type) VALUES (238, 'x-content/audio-cdda');
INSERT INTO mime_type (id, mime_type) VALUES (239, 'x-content/win32-software');
INSERT INTO mime_type (id, mime_type) VALUES (240, 'x-content/blank-hddvd');
INSERT INTO mime_type (id, mime_type) VALUES (241, 'x-content/audio-player');
INSERT INTO mime_type (id, mime_type) VALUES (242, 'x-content/video-dvd');
INSERT INTO mime_type (id, mime_type) VALUES (243, 'x-content/image-picturecd');
INSERT INTO mime_type (id, mime_type) VALUES (244, 'x-content/blank-bd');
INSERT INTO mime_type (id, mime_type) VALUES (245, 'x-content/video-bluray');
INSERT INTO mime_type (id, mime_type) VALUES (246, 'x-content/image-dcf');
INSERT INTO mime_type (id, mime_type) VALUES (247, 'x-content/software');
INSERT INTO mime_type (id, mime_type) VALUES (248, 'model/vrml');
INSERT INTO mime_type (id, mime_type) VALUES (249, 'fonts/package');
INSERT INTO mime_type (id, mime_type) VALUES (250, 'application/x-hwp');
INSERT INTO mime_type (id, mime_type) VALUES (251, 'application/x-pkcs7-certificates');
INSERT INTO mime_type (id, mime_type) VALUES (252, 'application/x-shockwave-flash');
INSERT INTO mime_type (id, mime_type) VALUES (253, 'application/x-turtle');
INSERT INTO mime_type (id, mime_type) VALUES (254, 'application/x-rar');
INSERT INTO mime_type (id, mime_type) VALUES (255, 'application/x-bittorrent');
INSERT INTO mime_type (id, mime_type) VALUES (256, 'application/prs.plucker');
INSERT INTO mime_type (id, mime_type) VALUES (257, 'application/smil');
INSERT INTO mime_type (id, mime_type) VALUES (258, 'application/x-abiword');
INSERT INTO mime_type (id, mime_type) VALUES (259, 'application/x-blender');
INSERT INTO mime_type (id, mime_type) VALUES (260, 'application/x-oleo');
INSERT INTO mime_type (id, mime_type) VALUES (261, 'application/x-font-sunos-news');
INSERT INTO mime_type (id, mime_type) VALUES (262, 'application/x-tex-gf');
INSERT INTO mime_type (id, mime_type) VALUES (263, 'application/x-netshow-channel');
INSERT INTO mime_type (id, mime_type) VALUES (264, 'application/x-m4');
INSERT INTO mime_type (id, mime_type) VALUES (265, 'application/x-kexiproject-sqlite2');
INSERT INTO mime_type (id, mime_type) VALUES (266, 'application/x-kpovmodeler');
INSERT INTO mime_type (id, mime_type) VALUES (267, 'application/illustrator');
INSERT INTO mime_type (id, mime_type) VALUES (268, 'application/x-font-snf');
INSERT INTO mime_type (id, mime_type) VALUES (269, 'application/x-gedcom');
INSERT INTO mime_type (id, mime_type) VALUES (270, 'application/x-kexiproject-shortcut');
INSERT INTO mime_type (id, mime_type) VALUES (271, 'application/andrew-inset');
INSERT INTO mime_type (id, mime_type) VALUES (272, 'application/x-bzdvi');
INSERT INTO mime_type (id, mime_type) VALUES (273, 'application/x-siag');
INSERT INTO mime_type (id, mime_type) VALUES (274, 'application/x-ktheme');
INSERT INTO mime_type (id, mime_type) VALUES (275, 'application/x-kspread');
INSERT INTO mime_type (id, mime_type) VALUES (276, 'application/x-cbr');
INSERT INTO mime_type (id, mime_type) VALUES (277, 'application/x-cmakecache');
INSERT INTO mime_type (id, mime_type) VALUES (278, 'application/x-font-framemaker');
INSERT INTO mime_type (id, mime_type) VALUES (279, 'application/x-msx-rom');
INSERT INTO mime_type (id, mime_type) VALUES (280, 'application/x-font-vfont');
INSERT INTO mime_type (id, mime_type) VALUES (281, 'application/x-font-ttx');
INSERT INTO mime_type (id, mime_type) VALUES (282, 'application/x-uml');
INSERT INTO mime_type (id, mime_type) VALUES (283, 'application/x-cdrdao-toc');
INSERT INTO mime_type (id, mime_type) VALUES (284, 'application/x-kpresenter');
INSERT INTO mime_type (id, mime_type) VALUES (285, 'application/x-kseg');
INSERT INTO mime_type (id, mime_type) VALUES (286, 'application/x-dvi');
INSERT INTO mime_type (id, mime_type) VALUES (287, 'application/x-java-applet');
INSERT INTO mime_type (id, mime_type) VALUES (288, 'application/x-palm-database');
INSERT INTO mime_type (id, mime_type) VALUES (289, 'application/pgp-encrypted');
INSERT INTO mime_type (id, mime_type) VALUES (290, 'application/x-pocket-word');
INSERT INTO mime_type (id, mime_type) VALUES (291, 'application/x-kmplot');
INSERT INTO mime_type (id, mime_type) VALUES (292, 'application/x-core');
INSERT INTO mime_type (id, mime_type) VALUES (293, 'application/x-profile');
INSERT INTO mime_type (id, mime_type) VALUES (294, 'application/x-mswinurl');
INSERT INTO mime_type (id, mime_type) VALUES (295, 'application/x-lha');
INSERT INTO mime_type (id, mime_type) VALUES (296, 'application/x-netcdf');
INSERT INTO mime_type (id, mime_type) VALUES (297, 'application/msword');
INSERT INTO mime_type (id, mime_type) VALUES (298, 'application/x-dar');
INSERT INTO mime_type (id, mime_type) VALUES (299, 'application/pgp-signature');
INSERT INTO mime_type (id, mime_type) VALUES (300, 'application/x-dmod');
INSERT INTO mime_type (id, mime_type) VALUES (301, 'application/x-fictionbook+xml');
INSERT INTO mime_type (id, mime_type) VALUES (302, 'application/x-gettext-translation');
INSERT INTO mime_type (id, mime_type) VALUES (303, 'application/x-ace');
INSERT INTO mime_type (id, mime_type) VALUES (304, 'application/x-macbinary');
INSERT INTO mime_type (id, mime_type) VALUES (305, 'application/x-nintendo-ds-rom');
INSERT INTO mime_type (id, mime_type) VALUES (306, 'application/x-troff-man-compressed');
INSERT INTO mime_type (id, mime_type) VALUES (307, 'application/x-java');
INSERT INTO mime_type (id, mime_type) VALUES (308, 'application/x-mimearchive');
INSERT INTO mime_type (id, mime_type) VALUES (309, 'application/xml-dtd');
INSERT INTO mime_type (id, mime_type) VALUES (310, 'application/x-smaf');
INSERT INTO mime_type (id, mime_type) VALUES (311, 'application/x-pw');
INSERT INTO mime_type (id, mime_type) VALUES (312, 'application/x-lhz');
INSERT INTO mime_type (id, mime_type) VALUES (313, 'application/x-dia-diagram');
INSERT INTO mime_type (id, mime_type) VALUES (314, 'application/x-kugar');
INSERT INTO mime_type (id, mime_type) VALUES (315, 'application/x-sv4cpio');
INSERT INTO mime_type (id, mime_type) VALUES (316, 'application/x-kcachegrind');
INSERT INTO mime_type (id, mime_type) VALUES (317, 'application/x-gnumeric');
INSERT INTO mime_type (id, mime_type) VALUES (318, 'application/x-fluid');
INSERT INTO mime_type (id, mime_type) VALUES (319, 'application/x-quattropro');
INSERT INTO mime_type (id, mime_type) VALUES (320, 'application/x-gzip');
INSERT INTO mime_type (id, mime_type) VALUES (321, 'application/x-shared-library-la');
INSERT INTO mime_type (id, mime_type) VALUES (322, 'application/x-gba-rom');
INSERT INTO mime_type (id, mime_type) VALUES (323, 'application/x-sc');
INSERT INTO mime_type (id, mime_type) VALUES (324, 'application/x-glade');
INSERT INTO mime_type (id, mime_type) VALUES (325, 'application/x-catalog');
INSERT INTO mime_type (id, mime_type) VALUES (326, 'application/x-php');
INSERT INTO mime_type (id, mime_type) VALUES (327, 'application/x-kexiproject-sqlite3');
INSERT INTO mime_type (id, mime_type) VALUES (328, 'application/x-asp');
INSERT INTO mime_type (id, mime_type) VALUES (329, 'application/x-sqlite2');
INSERT INTO mime_type (id, mime_type) VALUES (330, 'application/x-tzo');
INSERT INTO mime_type (id, mime_type) VALUES (331, 'application/x-wais-source');
INSERT INTO mime_type (id, mime_type) VALUES (332, 'application/x-jbuilder-project');
INSERT INTO mime_type (id, mime_type) VALUES (333, 'application/x-package-list');
INSERT INTO mime_type (id, mime_type) VALUES (334, 'application/annodex');
INSERT INTO mime_type (id, mime_type) VALUES (335, 'application/x-toutdoux');
INSERT INTO mime_type (id, mime_type) VALUES (336, 'application/x-stuffit');
INSERT INTO mime_type (id, mime_type) VALUES (337, 'application/pkcs10');
INSERT INTO mime_type (id, mime_type) VALUES (338, 'application/x-sv4crc');
INSERT INTO mime_type (id, mime_type) VALUES (339, 'application/x-java-keystore');
INSERT INTO mime_type (id, mime_type) VALUES (340, 'application/x-kommander');
INSERT INTO mime_type (id, mime_type) VALUES (341, 'application/x-sami');
INSERT INTO mime_type (id, mime_type) VALUES (342, 'application/xspf+xml');
INSERT INTO mime_type (id, mime_type) VALUES (343, 'application/x-killustrator');
INSERT INTO mime_type (id, mime_type) VALUES (344, 'application/x-kgetlist');
INSERT INTO mime_type (id, mime_type) VALUES (345, 'application/x-hdf');
INSERT INTO mime_type (id, mime_type) VALUES (346, 'application/x-mobipocket-ebook');
INSERT INTO mime_type (id, mime_type) VALUES (347, 'application/x-shellscript');
INSERT INTO mime_type (id, mime_type) VALUES (348, 'application/xhtml+xml');
INSERT INTO mime_type (id, mime_type) VALUES (349, 'application/x-compressed-tar');
INSERT INTO mime_type (id, mime_type) VALUES (350, 'application/x-nzb');
INSERT INTO mime_type (id, mime_type) VALUES (351, 'application/x-markaby');
INSERT INTO mime_type (id, mime_type) VALUES (352, 'application/x-sms-rom');
INSERT INTO mime_type (id, mime_type) VALUES (353, 'application/rtf');
INSERT INTO mime_type (id, mime_type) VALUES (354, 'application/x-tuberling');
INSERT INTO mime_type (id, mime_type) VALUES (355, 'application/x-kgeo');
INSERT INTO mime_type (id, mime_type) VALUES (356, 'application/x-n64-rom');
INSERT INTO mime_type (id, mime_type) VALUES (357, 'application/x-smb-server');
INSERT INTO mime_type (id, mime_type) VALUES (358, 'application/pkix-crl');
INSERT INTO mime_type (id, mime_type) VALUES (359, 'application/x-dbf');
INSERT INTO mime_type (id, mime_type) VALUES (360, 'application/x-webarchive');
INSERT INTO mime_type (id, mime_type) VALUES (361, 'application/x-smb-workgroup');
INSERT INTO mime_type (id, mime_type) VALUES (362, 'application/x-gnome-theme-package');
INSERT INTO mime_type (id, mime_type) VALUES (363, 'application/epub+zip');
INSERT INTO mime_type (id, mime_type) VALUES (364, 'application/x-kchart');
INSERT INTO mime_type (id, mime_type) VALUES (365, 'application/x-aportisdoc');
INSERT INTO mime_type (id, mime_type) VALUES (366, 'application/x-cisco-vpn-settings');
INSERT INTO mime_type (id, mime_type) VALUES (367, 'application/x-egon');
INSERT INTO mime_type (id, mime_type) VALUES (368, 'application/x-kword');
INSERT INTO mime_type (id, mime_type) VALUES (369, 'application/x-xbel');
INSERT INTO mime_type (id, mime_type) VALUES (370, 'application/x-font-type1');
INSERT INTO mime_type (id, mime_type) VALUES (371, 'application/x-lzip');
INSERT INTO mime_type (id, mime_type) VALUES (372, 'application/x-gdbm');
INSERT INTO mime_type (id, mime_type) VALUES (373, 'application/x-executable');
INSERT INTO mime_type (id, mime_type) VALUES (374, 'application/x-font-linux-psf');
INSERT INTO mime_type (id, mime_type) VALUES (375, 'application/x-font-tex-tfm');
INSERT INTO mime_type (id, mime_type) VALUES (376, 'application/x-font-afm');
INSERT INTO mime_type (id, mime_type) VALUES (377, 'application/x-kcsrc');
INSERT INTO mime_type (id, mime_type) VALUES (378, 'application/x-kontour');
INSERT INTO mime_type (id, mime_type) VALUES (379, 'application/x-msi');
INSERT INTO mime_type (id, mime_type) VALUES (380, 'application/x-cd-image');
INSERT INTO mime_type (id, mime_type) VALUES (381, 'application/x-font-libgrx');
INSERT INTO mime_type (id, mime_type) VALUES (382, 'application/x-designer');
INSERT INTO mime_type (id, mime_type) VALUES (383, 'application/x-nautilus-link');
INSERT INTO mime_type (id, mime_type) VALUES (384, 'application/x-zerosize');
INSERT INTO mime_type (id, mime_type) VALUES (385, 'application/x-superkaramba');
INSERT INTO mime_type (id, mime_type) VALUES (386, 'application/x-quanta');
INSERT INTO mime_type (id, mime_type) VALUES (387, 'application/ram');
INSERT INTO mime_type (id, mime_type) VALUES (388, 'application/javascript');
INSERT INTO mime_type (id, mime_type) VALUES (389, 'application/rdf+xml');
INSERT INTO mime_type (id, mime_type) VALUES (390, 'application/x-spss-por');
INSERT INTO mime_type (id, mime_type) VALUES (391, 'application/x-gnuplot');
INSERT INTO mime_type (id, mime_type) VALUES (392, 'application/x-kformula');
INSERT INTO mime_type (id, mime_type) VALUES (393, 'application/x-mif');
INSERT INTO mime_type (id, mime_type) VALUES (394, 'application/x-amipro');
INSERT INTO mime_type (id, mime_type) VALUES (395, 'application/x-slp');
INSERT INTO mime_type (id, mime_type) VALUES (396, 'application/x-audacity-project');
INSERT INTO mime_type (id, mime_type) VALUES (397, 'application/x-archive');
INSERT INTO mime_type (id, mime_type) VALUES (398, 'application/x-windows-themepack');
INSERT INTO mime_type (id, mime_type) VALUES (399, 'application/x-t602');
INSERT INTO mime_type (id, mime_type) VALUES (400, 'application/x-mswrite');
INSERT INTO mime_type (id, mime_type) VALUES (401, 'application/dicom');
INSERT INTO mime_type (id, mime_type) VALUES (402, 'application/x-gzdvi');
INSERT INTO mime_type (id, mime_type) VALUES (403, 'application/x-chm');
INSERT INTO mime_type (id, mime_type) VALUES (404, 'application/x-lzma-compressed-tar');
INSERT INTO mime_type (id, mime_type) VALUES (405, 'application/x-7z-compressed');
INSERT INTO mime_type (id, mime_type) VALUES (406, 'application/postscript');
INSERT INTO mime_type (id, mime_type) VALUES (407, 'application/x-gtktalog');
INSERT INTO mime_type (id, mime_type) VALUES (408, 'application/x-alz');
INSERT INTO mime_type (id, mime_type) VALUES (409, 'application/x-ustar');
INSERT INTO mime_type (id, mime_type) VALUES (410, 'application/x-troff-man');
INSERT INTO mime_type (id, mime_type) VALUES (411, 'application/xml');
INSERT INTO mime_type (id, mime_type) VALUES (412, 'application/sieve');
INSERT INTO mime_type (id, mime_type) VALUES (413, 'application/x-konsole');
INSERT INTO mime_type (id, mime_type) VALUES (414, 'application/x-dc-rom');
INSERT INTO mime_type (id, mime_type) VALUES (415, 'application/xsd');
INSERT INTO mime_type (id, mime_type) VALUES (416, 'application/pkcs7-mime');
INSERT INTO mime_type (id, mime_type) VALUES (417, 'application/x-xz');
INSERT INTO mime_type (id, mime_type) VALUES (418, 'application/x-cda');
INSERT INTO mime_type (id, mime_type) VALUES (419, 'application/x-abicollab');
INSERT INTO mime_type (id, mime_type) VALUES (420, 'application/x-cpio');
INSERT INTO mime_type (id, mime_type) VALUES (421, 'application/x-tgif');
INSERT INTO mime_type (id, mime_type) VALUES (422, 'application/x-class-file');
INSERT INTO mime_type (id, mime_type) VALUES (423, 'application/x-desktop');
INSERT INTO mime_type (id, mime_type) VALUES (424, 'application/x-reject');
INSERT INTO mime_type (id, mime_type) VALUES (425, 'application/x-xz-compressed-tar');
INSERT INTO mime_type (id, mime_type) VALUES (426, 'application/x-kivio');
INSERT INTO mime_type (id, mime_type) VALUES (427, 'application/x-kopete-emoticons');
INSERT INTO mime_type (id, mime_type) VALUES (428, 'application/x-kexi-connectiondata');
INSERT INTO mime_type (id, mime_type) VALUES (429, 'application/x-compress');
INSERT INTO mime_type (id, mime_type) VALUES (430, 'application/x-gmc-link');
INSERT INTO mime_type (id, mime_type) VALUES (431, 'application/x-krita');
INSERT INTO mime_type (id, mime_type) VALUES (432, 'application/x-java-archive');
INSERT INTO mime_type (id, mime_type) VALUES (433, 'application/x-theme');
INSERT INTO mime_type (id, mime_type) VALUES (434, 'application/x-deb');
INSERT INTO mime_type (id, mime_type) VALUES (435, 'application/x-gnucash');
INSERT INTO mime_type (id, mime_type) VALUES (436, 'application/x-cabri');
INSERT INTO mime_type (id, mime_type) VALUES (437, 'application/x-font-otf');
INSERT INTO mime_type (id, mime_type) VALUES (438, 'application/x-kexiproject-sqlite');
INSERT INTO mime_type (id, mime_type) VALUES (439, 'application/x-lzma');
INSERT INTO mime_type (id, mime_type) VALUES (440, 'application/rss+xml');
INSERT INTO mime_type (id, mime_type) VALUES (441, 'application/x-khtml-adaptor');
INSERT INTO mime_type (id, mime_type) VALUES (442, 'application/x-gzpostscript');
INSERT INTO mime_type (id, mime_type) VALUES (443, 'application/x-bzip');
INSERT INTO mime_type (id, mime_type) VALUES (444, 'application/mathml+xml');
INSERT INTO mime_type (id, mime_type) VALUES (445, 'application/x-chess-pgn');
INSERT INTO mime_type (id, mime_type) VALUES (446, 'application/x-remote-connection');
INSERT INTO mime_type (id, mime_type) VALUES (447, 'application/x-gameboy-rom');
INSERT INTO mime_type (id, mime_type) VALUES (448, 'application/pkix-pkipath');
INSERT INTO mime_type (id, mime_type) VALUES (449, 'application/x-shorten');
INSERT INTO mime_type (id, mime_type) VALUES (450, 'application/x-snes-rom');
INSERT INTO mime_type (id, mime_type) VALUES (451, 'application/x-quicktime-media-link');
INSERT INTO mime_type (id, mime_type) VALUES (452, 'application/x-ruby');
INSERT INTO mime_type (id, mime_type) VALUES (453, 'application/x-tarz');
INSERT INTO mime_type (id, mime_type) VALUES (454, 'application/ogg');
INSERT INTO mime_type (id, mime_type) VALUES (455, 'application/x-ole-storage');
INSERT INTO mime_type (id, mime_type) VALUES (456, 'application/x-shar');
INSERT INTO mime_type (id, mime_type) VALUES (457, 'application/x-ksysv-package');
INSERT INTO mime_type (id, mime_type) VALUES (458, 'application/x-x509-ca-cert');
INSERT INTO mime_type (id, mime_type) VALUES (459, 'application/x-par2');
INSERT INTO mime_type (id, mime_type) VALUES (460, 'application/x-linguist');
INSERT INTO mime_type (id, mime_type) VALUES (461, 'application/x-trig');
INSERT INTO mime_type (id, mime_type) VALUES (462, 'application/mac-binhex40');
INSERT INTO mime_type (id, mime_type) VALUES (463, 'application/x-qw');
INSERT INTO mime_type (id, mime_type) VALUES (464, 'application/xml-external-parsed-entity');
INSERT INTO mime_type (id, mime_type) VALUES (465, 'application/octet-stream');
INSERT INTO mime_type (id, mime_type) VALUES (466, 'application/x-matroska');
INSERT INTO mime_type (id, mime_type) VALUES (467, 'application/x-applix-spreadsheet');
INSERT INTO mime_type (id, mime_type) VALUES (468, 'application/x-plasma');
INSERT INTO mime_type (id, mime_type) VALUES (469, 'application/x-e-theme');
INSERT INTO mime_type (id, mime_type) VALUES (470, 'application/x-cbz');
INSERT INTO mime_type (id, mime_type) VALUES (471, 'application/x-java-jnlp-file');
INSERT INTO mime_type (id, mime_type) VALUES (472, 'application/x-kns');
INSERT INTO mime_type (id, mime_type) VALUES (473, 'application/x-win-lnk');
INSERT INTO mime_type (id, mime_type) VALUES (474, 'application/x-ufraw');
INSERT INTO mime_type (id, mime_type) VALUES (475, 'application/x-drgeo');
INSERT INTO mime_type (id, mime_type) VALUES (476, 'application/x-perl');
INSERT INTO mime_type (id, mime_type) VALUES (477, 'application/pkcs7-signature');
INSERT INTO mime_type (id, mime_type) VALUES (478, 'application/x-ms-dos-executable');
INSERT INTO mime_type (id, mime_type) VALUES (479, 'application/x-font-tex');
INSERT INTO mime_type (id, mime_type) VALUES (480, 'application/x-kolf');
INSERT INTO mime_type (id, mime_type) VALUES (481, 'application/x-planperfect');
INSERT INTO mime_type (id, mime_type) VALUES (482, 'application/x-go-sgf');
INSERT INTO mime_type (id, mime_type) VALUES (483, 'application/x-kwallet');
INSERT INTO mime_type (id, mime_type) VALUES (484, 'application/x-rpm');
INSERT INTO mime_type (id, mime_type) VALUES (485, 'application/sdp');
INSERT INTO mime_type (id, mime_type) VALUES (486, 'application/x-java-pack200');
INSERT INTO mime_type (id, mime_type) VALUES (487, 'application/relaxng');
INSERT INTO mime_type (id, mime_type) VALUES (488, 'application/x-servicepack');
INSERT INTO mime_type (id, mime_type) VALUES (489, 'application/x-font-bdf');
INSERT INTO mime_type (id, mime_type) VALUES (490, 'application/pkix-cert');
INSERT INTO mime_type (id, mime_type) VALUES (491, 'application/x-ipod-firmware');
INSERT INTO mime_type (id, mime_type) VALUES (492, 'application/x-object');
INSERT INTO mime_type (id, mime_type) VALUES (493, 'application/x-ica');
INSERT INTO mime_type (id, mime_type) VALUES (494, 'application/x-it87');
INSERT INTO mime_type (id, mime_type) VALUES (495, 'application/x-zoo');
INSERT INTO mime_type (id, mime_type) VALUES (496, 'application/x-gzpdf');
INSERT INTO mime_type (id, mime_type) VALUES (497, 'application/x-magicpoint');
INSERT INTO mime_type (id, mime_type) VALUES (498, 'application/docbook+xml');
INSERT INTO mime_type (id, mime_type) VALUES (499, 'application/x-csh');
INSERT INTO mime_type (id, mime_type) VALUES (500, 'application/x-nes-rom');
INSERT INTO mime_type (id, mime_type) VALUES (501, 'application/x-graphite');
INSERT INTO mime_type (id, mime_type) VALUES (502, 'application/x-spss-sav');
INSERT INTO mime_type (id, mime_type) VALUES (503, 'application/x-tar');
INSERT INTO mime_type (id, mime_type) VALUES (504, 'application/x-kvtml');
INSERT INTO mime_type (id, mime_type) VALUES (505, 'application/metalink+xml');
INSERT INTO mime_type (id, mime_type) VALUES (506, 'application/ecmascript');
INSERT INTO mime_type (id, mime_type) VALUES (507, 'application/x-hwt');
INSERT INTO mime_type (id, mime_type) VALUES (508, 'application/x-pak');
INSERT INTO mime_type (id, mime_type) VALUES (509, 'application/x-sqlite3');
INSERT INTO mime_type (id, mime_type) VALUES (510, 'application/x-trash');
INSERT INTO mime_type (id, mime_type) VALUES (511, 'application/x-arj');
INSERT INTO mime_type (id, mime_type) VALUES (512, 'application/x-k3b');
INSERT INTO mime_type (id, mime_type) VALUES (513, 'application/x-font-pcf');
INSERT INTO mime_type (id, mime_type) VALUES (514, 'application/oda');
INSERT INTO mime_type (id, mime_type) VALUES (515, 'application/x-genesis-rom');
INSERT INTO mime_type (id, mime_type) VALUES (516, 'application/x-font-ttf');
INSERT INTO mime_type (id, mime_type) VALUES (517, 'application/zip');
INSERT INTO mime_type (id, mime_type) VALUES (518, 'application/x-cbt');
INSERT INTO mime_type (id, mime_type) VALUES (519, 'application/x-kspread-crypt');
INSERT INTO mime_type (id, mime_type) VALUES (520, 'application/x-pef-executable');
INSERT INTO mime_type (id, mime_type) VALUES (521, 'application/x-brasero');
INSERT INTO mime_type (id, mime_type) VALUES (522, 'application/x-cb7');
INSERT INTO mime_type (id, mime_type) VALUES (523, 'application/x-frame');
INSERT INTO mime_type (id, mime_type) VALUES (524, 'application/x-lyx');
INSERT INTO mime_type (id, mime_type) VALUES (525, 'application/x-lzop');
INSERT INTO mime_type (id, mime_type) VALUES (526, 'application/x-planner');
INSERT INTO mime_type (id, mime_type) VALUES (527, 'application/x-vnc');
INSERT INTO mime_type (id, mime_type) VALUES (528, 'application/atom+xml');
INSERT INTO mime_type (id, mime_type) VALUES (529, 'application/x-gz-font-linux-psf');
INSERT INTO mime_type (id, mime_type) VALUES (530, 'application/x-xliff');
INSERT INTO mime_type (id, mime_type) VALUES (531, 'application/mathematica');
INSERT INTO mime_type (id, mime_type) VALUES (532, 'application/xslt+xml');
INSERT INTO mime_type (id, mime_type) VALUES (533, 'application/x-sharedlib');
INSERT INTO mime_type (id, mime_type) VALUES (534, 'application/x-kwordquiz');
INSERT INTO mime_type (id, mime_type) VALUES (535, 'application/x-bzpostscript');
INSERT INTO mime_type (id, mime_type) VALUES (536, 'application/x-pkcs12');
INSERT INTO mime_type (id, mime_type) VALUES (537, 'application/x-mozilla-bookmarks');
INSERT INTO mime_type (id, mime_type) VALUES (538, 'application/x-awk');
INSERT INTO mime_type (id, mime_type) VALUES (539, 'application/x-navi-animation');
INSERT INTO mime_type (id, mime_type) VALUES (540, 'application/x-cpio-compressed');
INSERT INTO mime_type (id, mime_type) VALUES (541, 'application/x-arc');
INSERT INTO mime_type (id, mime_type) VALUES (542, 'application/x-icq');
INSERT INTO mime_type (id, mime_type) VALUES (543, 'application/x-bzpdf');
INSERT INTO mime_type (id, mime_type) VALUES (544, 'application/mbox');
INSERT INTO mime_type (id, mime_type) VALUES (545, 'application/x-ksysguard');
INSERT INTO mime_type (id, mime_type) VALUES (546, 'application/x-java-jce-keystore');
INSERT INTO mime_type (id, mime_type) VALUES (547, 'application/x-subrip');
INSERT INTO mime_type (id, mime_type) VALUES (548, 'application/x-karbon');
INSERT INTO mime_type (id, mime_type) VALUES (549, 'application/x-python-bytecode');
INSERT INTO mime_type (id, mime_type) VALUES (550, 'application/x-font-dos');
INSERT INTO mime_type (id, mime_type) VALUES (551, 'application/pgp-keys');
INSERT INTO mime_type (id, mime_type) VALUES (552, 'application/x-font-speedo');
INSERT INTO mime_type (id, mime_type) VALUES (553, 'application/pdf');
INSERT INTO mime_type (id, mime_type) VALUES (554, 'application/x-cue');
INSERT INTO mime_type (id, mime_type) VALUES (555, 'application/x-gnome-saved-search');
INSERT INTO mime_type (id, mime_type) VALUES (556, 'application/x-bcpio');
INSERT INTO mime_type (id, mime_type) VALUES (557, 'application/x-applix-word');
INSERT INTO mime_type (id, mime_type) VALUES (558, 'application/mxf');
INSERT INTO mime_type (id, mime_type) VALUES (559, 'application/x-wpg');
INSERT INTO mime_type (id, mime_type) VALUES (560, 'application/x-bzip-compressed-tar');
INSERT INTO mime_type (id, mime_type) VALUES (561, 'application/x-kword-crypt');
INSERT INTO mime_type (id, mime_type) VALUES (562, 'application/x-kig');
INSERT INTO mime_type (id, mime_type) VALUES (563, 'application/gnunet-directory');
INSERT INTO mime_type (id, mime_type) VALUES (564, 'application/x-kourse');
INSERT INTO mime_type (id, mime_type) VALUES (565, 'application/x-kudesigner');
INSERT INTO mime_type (id, mime_type) VALUES (566, 'application/x-tex-pk');
INSERT INTO mime_type (id, mime_type) VALUES (567, 'video/x-ms-asf');
INSERT INTO mime_type (id, mime_type) VALUES (568, 'video/mp4');
INSERT INTO mime_type (id, mime_type) VALUES (569, 'video/mpeg');
INSERT INTO mime_type (id, mime_type) VALUES (570, 'video/annodex');
INSERT INTO mime_type (id, mime_type) VALUES (571, 'video/x-sgi-movie');
INSERT INTO mime_type (id, mime_type) VALUES (572, 'video/isivideo');
INSERT INTO mime_type (id, mime_type) VALUES (573, 'video/x-ogm+ogg');
INSERT INTO mime_type (id, mime_type) VALUES (574, 'video/x-mng');
INSERT INTO mime_type (id, mime_type) VALUES (575, 'video/x-flv');
INSERT INTO mime_type (id, mime_type) VALUES (576, 'video/x-flic');
INSERT INTO mime_type (id, mime_type) VALUES (577, 'video/x-theora+ogg');
INSERT INTO mime_type (id, mime_type) VALUES (578, 'video/3gpp');
INSERT INTO mime_type (id, mime_type) VALUES (579, 'video/x-ms-wmv');
INSERT INTO mime_type (id, mime_type) VALUES (580, 'video/ogg');
INSERT INTO mime_type (id, mime_type) VALUES (581, 'video/dv');
INSERT INTO mime_type (id, mime_type) VALUES (582, 'video/x-matroska');
INSERT INTO mime_type (id, mime_type) VALUES (583, 'video/vivo');
INSERT INTO mime_type (id, mime_type) VALUES (584, 'video/quicktime');
INSERT INTO mime_type (id, mime_type) VALUES (585, 'video/x-ms-wmp');
INSERT INTO mime_type (id, mime_type) VALUES (586, 'video/x-msvideo');
INSERT INTO mime_type (id, mime_type) VALUES (587, 'video/x-anim');
INSERT INTO mime_type (id, mime_type) VALUES (588, 'video/wavelet');
INSERT INTO mime_type (id, mime_type) VALUES (589, 'video/x-nsv');
INSERT INTO mime_type (id, mime_type) VALUES (590, 'interface/x-winamp-skin');
INSERT INTO mime_type (id, mime_type) VALUES (591, 'multipart/encrypted');
INSERT INTO mime_type (id, mime_type) VALUES (592, 'multipart/x-mixed-replace');
INSERT INTO mime_type (id, mime_type) VALUES (593, 'multipart/related');
INSERT INTO mime_type (id, mime_type) VALUES (594, 'multipart/report');
INSERT INTO mime_type (id, mime_type) VALUES (595, 'multipart/signed');
INSERT INTO mime_type (id, mime_type) VALUES (596, 'multipart/appledouble');
INSERT INTO mime_type (id, mime_type) VALUES (597, 'multipart/mixed');
INSERT INTO mime_type (id, mime_type) VALUES (598, 'multipart/alternative');
INSERT INTO mime_type (id, mime_type) VALUES (599, 'multipart/digest');
INSERT INTO mime_type (id, mime_type) VALUES (600, 'audio/vnd.rn-realaudio');
INSERT INTO mime_type (id, mime_type) VALUES (601, 'image/vnd.dwg');
INSERT INTO mime_type (id, mime_type) VALUES (602, 'image/vnd.djvu');
INSERT INTO mime_type (id, mime_type) VALUES (603, 'image/vnd.rn-realpix');
INSERT INTO mime_type (id, mime_type) VALUES (604, 'image/vnd.dxf');
INSERT INTO mime_type (id, mime_type) VALUES (605, 'image/vnd.wap.wbmp');
INSERT INTO mime_type (id, mime_type) VALUES (606, 'image/vnd.ms-modi');
INSERT INTO mime_type (id, mime_type) VALUES (607, 'image/vnd.microsoft.icon');
INSERT INTO mime_type (id, mime_type) VALUES (608, 'image/vnd.adobe.photoshop');
INSERT INTO mime_type (id, mime_type) VALUES (609, 'text/vnd.wap.wml');
INSERT INTO mime_type (id, mime_type) VALUES (610, 'text/vnd.wap.wmlscript');
INSERT INTO mime_type (id, mime_type) VALUES (611, 'text/vnd.sun.j2me.app-descriptor');
INSERT INTO mime_type (id, mime_type) VALUES (612, 'text/vnd.abc');
INSERT INTO mime_type (id, mime_type) VALUES (613, 'text/vnd.rn-realtext');
INSERT INTO mime_type (id, mime_type) VALUES (614, 'text/vnd.graphviz');
INSERT INTO mime_type (id, mime_type) VALUES (615, 'application/vnd.mozilla.xul+xml');
INSERT INTO mime_type (id, mime_type) VALUES (616, 'application/vnd.oasis.opendocument.text-web');
INSERT INTO mime_type (id, mime_type) VALUES (617, 'application/x-vnd.kde.kexi');
INSERT INTO mime_type (id, mime_type) VALUES (618, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
INSERT INTO mime_type (id, mime_type) VALUES (619, 'application/vnd.ms-word.document.macroenabled.12');
INSERT INTO mime_type (id, mime_type) VALUES (620, 'application/vnd.scribus');
INSERT INTO mime_type (id, mime_type) VALUES (621, 'application/vnd.sun.xml.writer.global');
INSERT INTO mime_type (id, mime_type) VALUES (622, 'application/vnd.emusic-emusic_package');
INSERT INTO mime_type (id, mime_type) VALUES (623, 'application/vnd.hp-pcl');
INSERT INTO mime_type (id, mime_type) VALUES (624, 'application/vnd.stardivision.mail');
INSERT INTO mime_type (id, mime_type) VALUES (625, 'application/vnd.google-earth.kml+xml');
INSERT INTO mime_type (id, mime_type) VALUES (626, 'application/x-vnd.kde.plan');
INSERT INTO mime_type (id, mime_type) VALUES (627, 'application/vnd.kde.okular-archive');
INSERT INTO mime_type (id, mime_type) VALUES (628, 'application/vnd.openxmlformats-officedocument.presentationml.presentation');
INSERT INTO mime_type (id, mime_type) VALUES (629, 'application/vnd.ms-wpl');
INSERT INTO mime_type (id, mime_type) VALUES (630, 'application/vnd.oasis.opendocument.formula');
INSERT INTO mime_type (id, mime_type) VALUES (631, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
INSERT INTO mime_type (id, mime_type) VALUES (632, 'application/vnd.oasis.opendocument.text-flat-xml');
INSERT INTO mime_type (id, mime_type) VALUES (633, 'application/vnd.oasis.opendocument.chart');
INSERT INTO mime_type (id, mime_type) VALUES (634, 'application/x-vnd.kde.plan.work');
INSERT INTO mime_type (id, mime_type) VALUES (635, 'application/vnd.ms-excel.sheet.macroenabled.12');
INSERT INTO mime_type (id, mime_type) VALUES (636, 'application/vnd.lotus-1-2-3');
INSERT INTO mime_type (id, mime_type) VALUES (637, 'application/vnd.hp-hpgl');
INSERT INTO mime_type (id, mime_type) VALUES (638, 'application/vnd.sun.xml.writer');
INSERT INTO mime_type (id, mime_type) VALUES (639, 'application/vnd.oasis.opendocument.text-master');
INSERT INTO mime_type (id, mime_type) VALUES (640, 'application/vnd.corel-draw');
INSERT INTO mime_type (id, mime_type) VALUES (641, 'application/vnd.stardivision.draw');
INSERT INTO mime_type (id, mime_type) VALUES (642, 'application/vnd.oasis.opendocument.spreadsheet');
INSERT INTO mime_type (id, mime_type) VALUES (643, 'application/vnd.stardivision.calc');
INSERT INTO mime_type (id, mime_type) VALUES (644, 'application/vnd.ms-powerpoint.presentation.macroenabled.12');
INSERT INTO mime_type (id, mime_type) VALUES (645, 'application/x-vnd.kde.kplato');
INSERT INTO mime_type (id, mime_type) VALUES (646, 'application/vnd.oasis.opendocument.text');
INSERT INTO mime_type (id, mime_type) VALUES (647, 'application/vnd.stardivision.math');
INSERT INTO mime_type (id, mime_type) VALUES (648, 'application/vnd.stardivision.writer');
INSERT INTO mime_type (id, mime_type) VALUES (649, 'application/vnd.oasis.opendocument.graphics-flat-xml');
INSERT INTO mime_type (id, mime_type) VALUES (650, 'application/vnd.sun.xml.impress');
INSERT INTO mime_type (id, mime_type) VALUES (651, 'application/vnd.oasis.opendocument.spreadsheet-flat-xml');
INSERT INTO mime_type (id, mime_type) VALUES (652, 'application/vnd.htmldoc-book');
INSERT INTO mime_type (id, mime_type) VALUES (653, 'application/vnd.symbian.install');
INSERT INTO mime_type (id, mime_type) VALUES (654, 'application/vnd.ms-excel.sheet.binary.macroenabled.12');
INSERT INTO mime_type (id, mime_type) VALUES (655, 'application/vnd.google-earth.kmz');
INSERT INTO mime_type (id, mime_type) VALUES (656, 'application/x-vnd.kde.kplato.work');
INSERT INTO mime_type (id, mime_type) VALUES (657, 'application/vnd.ms-excel');
INSERT INTO mime_type (id, mime_type) VALUES (658, 'application/vnd.kde.kphotoalbum-import');
INSERT INTO mime_type (id, mime_type) VALUES (659, 'application/vnd.sun.xml.draw');
INSERT INTO mime_type (id, mime_type) VALUES (660, 'application/vnd.openxmlformats-officedocument.presentationml.slideshow');
INSERT INTO mime_type (id, mime_type) VALUES (661, 'application/vnd.sun.xml.calc');
INSERT INTO mime_type (id, mime_type) VALUES (662, 'application/vnd.ms-cab-compressed');
INSERT INTO mime_type (id, mime_type) VALUES (663, 'application/vnd.sun.xml.base');
INSERT INTO mime_type (id, mime_type) VALUES (664, 'application/vnd.sun.xml.math');
INSERT INTO mime_type (id, mime_type) VALUES (665, 'application/vnd.ms-powerpoint');
INSERT INTO mime_type (id, mime_type) VALUES (666, 'application/vnd.apple.mpegurl');
INSERT INTO mime_type (id, mime_type) VALUES (667, 'application/vnd.ms-works');
INSERT INTO mime_type (id, mime_type) VALUES (668, 'application/vnd.oasis.opendocument.image');
INSERT INTO mime_type (id, mime_type) VALUES (669, 'application/x-vnd.kde.contactgroup');
INSERT INTO mime_type (id, mime_type) VALUES (670, 'application/vnd.oasis.opendocument.presentation');
INSERT INTO mime_type (id, mime_type) VALUES (671, 'application/vnd.rn-realmedia');
INSERT INTO mime_type (id, mime_type) VALUES (672, 'application/vnd.oasis.opendocument.database');
INSERT INTO mime_type (id, mime_type) VALUES (673, 'application/vnd.stardivision.impress');
INSERT INTO mime_type (id, mime_type) VALUES (674, 'application/vnd.ms-access');
INSERT INTO mime_type (id, mime_type) VALUES (675, 'application/vnd.openofficeorg.extension');
INSERT INTO mime_type (id, mime_type) VALUES (676, 'application/vnd.ms-xpsdocument');
INSERT INTO mime_type (id, mime_type) VALUES (677, 'application/vnd.oasis.opendocument.presentation-flat-xml');
INSERT INTO mime_type (id, mime_type) VALUES (678, 'application/vnd.stardivision.chart');
INSERT INTO mime_type (id, mime_type) VALUES (679, 'application/vnd.wordperfect');
INSERT INTO mime_type (id, mime_type) VALUES (680, 'application/x-vnd.kde.kugar.mixed');
INSERT INTO mime_type (id, mime_type) VALUES (681, 'application/vnd.iccprofile');
INSERT INTO mime_type (id, mime_type) VALUES (682, 'application/vnd.oasis.opendocument.graphics');
INSERT INTO mime_type (id, mime_type) VALUES (683, 'application/vnd.ms-tnef');
INSERT INTO mime_type (id, mime_type) VALUES (684, 'video/vnd.rn-realvideo');


--
-- Data for Name: new_shipto; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: note_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO note_class (id, class) VALUES (1, 'Entity');
INSERT INTO note_class (id, class) VALUES (2, 'Invoice');
INSERT INTO note_class (id, class) VALUES (3, 'Entity Credit Account');
INSERT INTO note_class (id, class) VALUES (4, 'Asset');


--
-- Data for Name: oe; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: oe_class; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO oe_class (id, oe_class) VALUES (1, 'Sales Order');
INSERT INTO oe_class (id, oe_class) VALUES (2, 'Purchase Order');
INSERT INTO oe_class (id, oe_class) VALUES (3, 'Quotation');
INSERT INTO oe_class (id, oe_class) VALUES (4, 'RFQ');


--
-- Data for Name: open_forms; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO open_forms (id, session_id) VALUES (1, 1);
INSERT INTO open_forms (id, session_id) VALUES (2, 1);
INSERT INTO open_forms (id, session_id) VALUES (5, 1);
INSERT INTO open_forms (id, session_id) VALUES (8, 1);
INSERT INTO open_forms (id, session_id) VALUES (9, 1);
INSERT INTO open_forms (id, session_id) VALUES (10, 1);
INSERT INTO open_forms (id, session_id) VALUES (11, 1);
INSERT INTO open_forms (id, session_id) VALUES (13, 1);
INSERT INTO open_forms (id, session_id) VALUES (15, 1);
INSERT INTO open_forms (id, session_id) VALUES (22, 1);
INSERT INTO open_forms (id, session_id) VALUES (23, 1);


--
-- Data for Name: orderitems; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: parts; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO parts (id, partnumber, description, unit, listprice, sellprice, lastcost, priceupdate, weight, onhand, notes, makemodel, assembly, alternate, rop, inventory_accno_id, income_accno_id, expense_accno_id, bin, obsolete, bom, image, drawing, microfiche, partsgroup_id, project_id, avgcost) VALUES (1, 'consulting', '', '', 0, 0, 0, '2012-03-10', 0, 0, '', false, false, false, 0, NULL, 25, 30, NULL, false, false, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO parts (id, partnumber, description, unit, listprice, sellprice, lastcost, priceupdate, weight, onhand, notes, makemodel, assembly, alternate, rop, inventory_accno_id, income_accno_id, expense_accno_id, bin, obsolete, bom, image, drawing, microfiche, partsgroup_id, project_id, avgcost) VALUES (2, 'us-consult', '', '', 0, 0, 0, '2012-03-10', 0, 0, '', false, false, false, 0, NULL, 25, 30, NULL, false, false, NULL, NULL, NULL, 0, NULL, NULL);


--
-- Data for Name: parts_translation; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partscustomer; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partsgroup; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partsgroup_translation; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partstax; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO partstax (parts_id, chart_id, taxcategory_id) VALUES (1, 15, NULL);
INSERT INTO partstax (parts_id, chart_id, taxcategory_id) VALUES (1, 16, NULL);


--
-- Data for Name: partsvendor; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO payment (id, reference, gl_id, payment_class, payment_date, closed, entity_credit_id, employee_id, currency, notes, department_id) VALUES (1, '2', NULL, 2, '2012-03-10', false, 3, 1, 'CAD', NULL, NULL);
INSERT INTO payment (id, reference, gl_id, payment_class, payment_date, closed, entity_credit_id, employee_id, currency, notes, department_id) VALUES (2, '3', NULL, 2, '2012-03-11', false, 4, 1, 'USD', NULL, NULL);


--
-- Data for Name: payment_links; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO payment_links (payment_id, entry_id, type) VALUES (1, 5, 1);
INSERT INTO payment_links (payment_id, entry_id, type) VALUES (1, 6, 1);
INSERT INTO payment_links (payment_id, entry_id, type) VALUES (2, 7, 1);
INSERT INTO payment_links (payment_id, entry_id, type) VALUES (2, 9, 1);


--
-- Data for Name: payment_type; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: payments_queue; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pending_job; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO person (id, entity_id, salutation_id, first_name, middle_name, last_name, created) VALUES (1, 1, 3, 'Guy', NULL, 'Smiley', '2012-03-10');


--
-- Data for Name: person_to_company; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: person_to_contact; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: person_to_entity; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: person_to_location; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pricegroup; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: project_translation; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recurring; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recurringemail; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recurringprint; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: salutation; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO salutation (id, salutation) VALUES (1, 'Dr.');
INSERT INTO salutation (id, salutation) VALUES (2, 'Miss.');
INSERT INTO salutation (id, salutation) VALUES (3, 'Mr.');
INSERT INTO salutation (id, salutation) VALUES (4, 'Mrs.');
INSERT INTO salutation (id, salutation) VALUES (5, 'Ms.');
INSERT INTO salutation (id, salutation) VALUES (6, 'Sir.');


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO session (session_id, token, last_used, ttl, users_id, notify_pasword) VALUES (1, '3c6d9e460f1df5dced00bbac8532f19e', '2012-03-10 21:09:01.329328', 3600, 1, '7 days');


--
-- Data for Name: sic; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: tax; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO tax (chart_id, rate, taxnumber, validto, pass, taxmodule_id) VALUES (15, 0.05, NULL, 'infinity', 0, 1);
INSERT INTO tax (chart_id, rate, taxnumber, validto, pass, taxmodule_id) VALUES (16, 0.08, NULL, 'infinity', 0, 1);


--
-- Data for Name: tax_extended; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: taxcategory; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: taxmodule; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO taxmodule (taxmodule_id, taxmodulename) VALUES (1, 'Simple');


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO transactions (id, table_name, locked_by, approved_by, approved_at) VALUES (1, 'ar', NULL, NULL, NULL);
INSERT INTO transactions (id, table_name, locked_by, approved_by, approved_at) VALUES (2, 'ar', NULL, NULL, NULL);


--
-- Data for Name: translation; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_preference; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO user_preference (id, language, stylesheet, printer, dateformat, numberformat) VALUES (1, NULL, 'ledgersmb.css', 'Laser', 'yyyy-mm-dd', '1000.00');


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO users (id, username, notify_password, entity_id) VALUES (1, 'guy', '7 days', 1);


--
-- Data for Name: vendortax; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: voucher; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: warehouse; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: yearend; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Name: ac_tax_form_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY ac_tax_form
    ADD CONSTRAINT ac_tax_form_pkey PRIMARY KEY (entry_id);


--
-- Name: acc_trans_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY acc_trans
    ADD CONSTRAINT acc_trans_pkey PRIMARY KEY (entry_id);


--
-- Name: account_checkpoint_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY account_checkpoint
    ADD CONSTRAINT account_checkpoint_id_key UNIQUE (id);


--
-- Name: account_checkpoint_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY account_checkpoint
    ADD CONSTRAINT account_checkpoint_pkey PRIMARY KEY (end_date, account_id);


--
-- Name: account_heading_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY account_heading
    ADD CONSTRAINT account_heading_id_key UNIQUE (id);


--
-- Name: account_heading_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY account_heading
    ADD CONSTRAINT account_heading_pkey PRIMARY KEY (accno);


--
-- Name: account_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY account
    ADD CONSTRAINT account_id_key UNIQUE (id);


--
-- Name: account_link_description_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY account_link_description
    ADD CONSTRAINT account_link_description_pkey PRIMARY KEY (description);


--
-- Name: account_link_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY account_link
    ADD CONSTRAINT account_link_pkey PRIMARY KEY (account_id, description);


--
-- Name: account_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY account
    ADD CONSTRAINT account_pkey PRIMARY KEY (accno);


--
-- Name: ap_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY ap
    ADD CONSTRAINT ap_pkey PRIMARY KEY (id);


--
-- Name: ar_invnumber_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY ar
    ADD CONSTRAINT ar_invnumber_key UNIQUE (invnumber);


--
-- Name: ar_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY ar
    ADD CONSTRAINT ar_pkey PRIMARY KEY (id);


--
-- Name: assembly_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY assembly
    ADD CONSTRAINT assembly_pkey PRIMARY KEY (id, parts_id);


--
-- Name: asset_class_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_class
    ADD CONSTRAINT asset_class_id_key UNIQUE (id);


--
-- Name: asset_class_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_class
    ADD CONSTRAINT asset_class_pkey PRIMARY KEY (label);


--
-- Name: asset_dep_method_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_dep_method
    ADD CONSTRAINT asset_dep_method_id_key UNIQUE (id);


--
-- Name: asset_dep_method_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_dep_method
    ADD CONSTRAINT asset_dep_method_pkey PRIMARY KEY (method);


--
-- Name: asset_dep_method_short_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_dep_method
    ADD CONSTRAINT asset_dep_method_short_name_key UNIQUE (short_name);


--
-- Name: asset_dep_method_sproc_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_dep_method
    ADD CONSTRAINT asset_dep_method_sproc_key UNIQUE (sproc);


--
-- Name: asset_disposal_method_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_disposal_method
    ADD CONSTRAINT asset_disposal_method_id_key UNIQUE (id);


--
-- Name: asset_disposal_method_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_disposal_method
    ADD CONSTRAINT asset_disposal_method_pkey PRIMARY KEY (label);


--
-- Name: asset_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_item
    ADD CONSTRAINT asset_item_pkey PRIMARY KEY (id);


--
-- Name: asset_item_tag_obsolete_by_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_item
    ADD CONSTRAINT asset_item_tag_obsolete_by_key UNIQUE (tag, obsolete_by);


--
-- Name: asset_report_class_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_report_class
    ADD CONSTRAINT asset_report_class_id_key UNIQUE (id);


--
-- Name: asset_report_class_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_report_class
    ADD CONSTRAINT asset_report_class_pkey PRIMARY KEY (class);


--
-- Name: asset_report_gl_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_report
    ADD CONSTRAINT asset_report_gl_id_key UNIQUE (gl_id);


--
-- Name: asset_report_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_report_line
    ADD CONSTRAINT asset_report_line_pkey PRIMARY KEY (asset_id, report_id);


--
-- Name: asset_report_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_report
    ADD CONSTRAINT asset_report_pkey PRIMARY KEY (id);


--
-- Name: asset_rl_to_disposal_method_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_rl_to_disposal_method
    ADD CONSTRAINT asset_rl_to_disposal_method_pkey PRIMARY KEY (report_id, asset_id, disposal_method_id);


--
-- Name: asset_unit_class_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_unit_class
    ADD CONSTRAINT asset_unit_class_id_key UNIQUE (id);


--
-- Name: asset_unit_class_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY asset_unit_class
    ADD CONSTRAINT asset_unit_class_pkey PRIMARY KEY (class);


--
-- Name: audittrail_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY audittrail
    ADD CONSTRAINT audittrail_pkey PRIMARY KEY (entry_id);


--
-- Name: batch_class_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY batch_class
    ADD CONSTRAINT batch_class_id_key UNIQUE (id);


--
-- Name: batch_class_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY batch_class
    ADD CONSTRAINT batch_class_pkey PRIMARY KEY (class);


--
-- Name: batch_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY batch
    ADD CONSTRAINT batch_pkey PRIMARY KEY (id);


--
-- Name: business_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY business
    ADD CONSTRAINT business_pkey PRIMARY KEY (id);


--
-- Name: company_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY company
    ADD CONSTRAINT company_id_key UNIQUE (id);


--
-- Name: company_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY company
    ADD CONSTRAINT company_pkey PRIMARY KEY (entity_id, legal_name);


--
-- Name: company_to_contact_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY company_to_contact
    ADD CONSTRAINT company_to_contact_pkey PRIMARY KEY (company_id, contact_class_id, contact);


--
-- Name: company_to_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY company_to_entity
    ADD CONSTRAINT company_to_entity_pkey PRIMARY KEY (company_id, entity_id);


--
-- Name: company_to_location_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY company_to_location
    ADD CONSTRAINT company_to_location_pkey PRIMARY KEY (location_id, company_id, location_class);


--
-- Name: contact_class_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY contact_class
    ADD CONSTRAINT contact_class_id_key UNIQUE (id);


--
-- Name: contact_class_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY contact_class
    ADD CONSTRAINT contact_class_pkey PRIMARY KEY (class);


--
-- Name: country_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY country
    ADD CONSTRAINT country_pkey PRIMARY KEY (id);


--
-- Name: country_tax_form_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY country_tax_form
    ADD CONSTRAINT country_tax_form_id_key UNIQUE (id);


--
-- Name: country_tax_form_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY country_tax_form
    ADD CONSTRAINT country_tax_form_pkey PRIMARY KEY (country_id, form_name);


--
-- Name: cr_report_line_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY cr_report_line
    ADD CONSTRAINT cr_report_line_pkey PRIMARY KEY (id);


--
-- Name: cr_report_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY cr_report
    ADD CONSTRAINT cr_report_pkey PRIMARY KEY (id);


--
-- Name: custom_field_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY custom_field_catalog
    ADD CONSTRAINT custom_field_catalog_pkey PRIMARY KEY (field_id);


--
-- Name: custom_table_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY custom_table_catalog
    ADD CONSTRAINT custom_table_catalog_pkey PRIMARY KEY (table_id);


--
-- Name: customertax_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY customertax
    ADD CONSTRAINT customertax_pkey PRIMARY KEY (customer_id, chart_id);


--
-- Name: defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY defaults
    ADD CONSTRAINT defaults_pkey PRIMARY KEY (setting_key);


--
-- Name: department_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY department
    ADD CONSTRAINT department_pkey PRIMARY KEY (id);


--
-- Name: dpt_trans_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY dpt_trans
    ADD CONSTRAINT dpt_trans_pkey PRIMARY KEY (trans_id);


--
-- Name: eca_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY eca_note
    ADD CONSTRAINT eca_note_pkey PRIMARY KEY (id);


--
-- Name: eca_to_contact_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY eca_to_contact
    ADD CONSTRAINT eca_to_contact_pkey PRIMARY KEY (credit_id, contact_class_id, contact);


--
-- Name: eca_to_location_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY eca_to_location
    ADD CONSTRAINT eca_to_location_pkey PRIMARY KEY (location_id, credit_id, location_class);


--
-- Name: entity_bank_account_bic_iban_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY entity_bank_account
    ADD CONSTRAINT entity_bank_account_bic_iban_key UNIQUE (bic, iban);


--
-- Name: entity_bank_account_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY entity_bank_account
    ADD CONSTRAINT entity_bank_account_id_key UNIQUE (id);


--
-- Name: entity_class_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY entity_class
    ADD CONSTRAINT entity_class_pkey PRIMARY KEY (id);


--
-- Name: entity_class_to_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY entity_class_to_entity
    ADD CONSTRAINT entity_class_to_entity_pkey PRIMARY KEY (entity_class_id, entity_id);


--
-- Name: entity_control_code_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY entity
    ADD CONSTRAINT entity_control_code_key UNIQUE (control_code);


--
-- Name: entity_credit_account_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY entity_credit_account
    ADD CONSTRAINT entity_credit_account_id_key UNIQUE (id);


--
-- Name: entity_credit_account_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY entity_credit_account
    ADD CONSTRAINT entity_credit_account_pkey PRIMARY KEY (entity_id, meta_number, entity_class);


--
-- Name: entity_employee_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY entity_employee
    ADD CONSTRAINT entity_employee_pkey PRIMARY KEY (entity_id);


--
-- Name: entity_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY entity
    ADD CONSTRAINT entity_id_key UNIQUE (id);


--
-- Name: entity_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY entity_note
    ADD CONSTRAINT entity_note_pkey PRIMARY KEY (id);


--
-- Name: entity_other_name_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY entity_other_name
    ADD CONSTRAINT entity_other_name_pkey PRIMARY KEY (other_name, entity_id);


--
-- Name: entity_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY entity
    ADD CONSTRAINT entity_pkey PRIMARY KEY (control_code, entity_class);


--
-- Name: exchangerate_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY exchangerate
    ADD CONSTRAINT exchangerate_pkey PRIMARY KEY (curr, transdate);


--
-- Name: file_base_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_base
    ADD CONSTRAINT file_base_id_key UNIQUE (id);


--
-- Name: file_base_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_base
    ADD CONSTRAINT file_base_pkey PRIMARY KEY (ref_key, file_name, file_class);


--
-- Name: file_class_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_class
    ADD CONSTRAINT file_class_id_key UNIQUE (id);


--
-- Name: file_class_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_class
    ADD CONSTRAINT file_class_pkey PRIMARY KEY (class);


--
-- Name: file_order_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_order
    ADD CONSTRAINT file_order_id_key UNIQUE (id);


--
-- Name: file_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_order
    ADD CONSTRAINT file_order_pkey PRIMARY KEY (ref_key, file_name, file_class);


--
-- Name: file_order_to_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_order_to_order
    ADD CONSTRAINT file_order_to_order_pkey PRIMARY KEY (file_id, source_class, dest_class, ref_key);


--
-- Name: file_order_to_tx_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_order_to_tx
    ADD CONSTRAINT file_order_to_tx_pkey PRIMARY KEY (file_id, source_class, dest_class, ref_key);


--
-- Name: file_part_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_part
    ADD CONSTRAINT file_part_id_key UNIQUE (id);


--
-- Name: file_part_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_part
    ADD CONSTRAINT file_part_pkey PRIMARY KEY (ref_key, file_name, file_class);


--
-- Name: file_secondary_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_secondary_attachment
    ADD CONSTRAINT file_secondary_attachment_pkey PRIMARY KEY (file_id, source_class, dest_class, ref_key);


--
-- Name: file_transaction_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_transaction
    ADD CONSTRAINT file_transaction_id_key UNIQUE (id);


--
-- Name: file_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_transaction
    ADD CONSTRAINT file_transaction_pkey PRIMARY KEY (ref_key, file_name, file_class);


--
-- Name: file_tx_to_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_tx_to_order
    ADD CONSTRAINT file_tx_to_order_pkey PRIMARY KEY (file_id, source_class, dest_class, ref_key);


--
-- Name: file_view_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_view_catalog
    ADD CONSTRAINT file_view_catalog_pkey PRIMARY KEY (file_class);


--
-- Name: file_view_catalog_view_name_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY file_view_catalog
    ADD CONSTRAINT file_view_catalog_view_name_key UNIQUE (view_name);


--
-- Name: gifi_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY gifi
    ADD CONSTRAINT gifi_pkey PRIMARY KEY (accno);


--
-- Name: gl_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY gl
    ADD CONSTRAINT gl_pkey PRIMARY KEY (id);


--
-- Name: inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (entry_id);


--
-- Name: invoice_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY invoice_note
    ADD CONSTRAINT invoice_note_pkey PRIMARY KEY (id);


--
-- Name: invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (id);


--
-- Name: invoice_tax_form_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY invoice_tax_form
    ADD CONSTRAINT invoice_tax_form_pkey PRIMARY KEY (invoice_id);


--
-- Name: jcitems_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY jcitems
    ADD CONSTRAINT jcitems_pkey PRIMARY KEY (id);


--
-- Name: language_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY language
    ADD CONSTRAINT language_pkey PRIMARY KEY (code);


--
-- Name: location_class_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY location_class
    ADD CONSTRAINT location_class_id_key UNIQUE (id);


--
-- Name: location_class_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY location_class
    ADD CONSTRAINT location_class_pkey PRIMARY KEY (class, authoritative);


--
-- Name: location_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY location
    ADD CONSTRAINT location_pkey PRIMARY KEY (id);


--
-- Name: makemodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY makemodel
    ADD CONSTRAINT makemodel_pkey PRIMARY KEY (parts_id);


--
-- Name: menu_acl_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY menu_acl
    ADD CONSTRAINT menu_acl_pkey PRIMARY KEY (node_id, role_name);


--
-- Name: menu_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY menu_attribute
    ADD CONSTRAINT menu_attribute_pkey PRIMARY KEY (node_id, attribute);


--
-- Name: menu_node_parent_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY menu_node
    ADD CONSTRAINT menu_node_parent_key UNIQUE (parent, "position");


--
-- Name: menu_node_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY menu_node
    ADD CONSTRAINT menu_node_pkey PRIMARY KEY (id);


--
-- Name: mime_type_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY mime_type
    ADD CONSTRAINT mime_type_id_key UNIQUE (id);


--
-- Name: mime_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY mime_type
    ADD CONSTRAINT mime_type_pkey PRIMARY KEY (mime_type);


--
-- Name: new_shipto_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY new_shipto
    ADD CONSTRAINT new_shipto_pkey PRIMARY KEY (id);


--
-- Name: note_class_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY note_class
    ADD CONSTRAINT note_class_pkey PRIMARY KEY (id);


--
-- Name: note_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY note
    ADD CONSTRAINT note_pkey PRIMARY KEY (id);


--
-- Name: oe_class_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY oe_class
    ADD CONSTRAINT oe_class_id_key UNIQUE (id);


--
-- Name: oe_class_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY oe_class
    ADD CONSTRAINT oe_class_pkey PRIMARY KEY (oe_class);


--
-- Name: oe_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY oe
    ADD CONSTRAINT oe_pkey PRIMARY KEY (id);


--
-- Name: open_forms_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY open_forms
    ADD CONSTRAINT open_forms_pkey PRIMARY KEY (id);


--
-- Name: orderitems_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY orderitems
    ADD CONSTRAINT orderitems_pkey PRIMARY KEY (id);


--
-- Name: parts_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY parts
    ADD CONSTRAINT parts_pkey PRIMARY KEY (id);


--
-- Name: parts_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY parts_translation
    ADD CONSTRAINT parts_translation_pkey PRIMARY KEY (trans_id, language_code);


--
-- Name: partscustomer_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY partscustomer
    ADD CONSTRAINT partscustomer_pkey PRIMARY KEY (entry_id);


--
-- Name: partsgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY partsgroup
    ADD CONSTRAINT partsgroup_pkey PRIMARY KEY (id);


--
-- Name: partsgroup_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY partsgroup_translation
    ADD CONSTRAINT partsgroup_translation_pkey PRIMARY KEY (trans_id, language_code);


--
-- Name: partstax_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY partstax
    ADD CONSTRAINT partstax_pkey PRIMARY KEY (parts_id, chart_id);


--
-- Name: partsvendor_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY partsvendor
    ADD CONSTRAINT partsvendor_pkey PRIMARY KEY (entry_id);


--
-- Name: payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (id);


--
-- Name: payment_type_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY payment_type
    ADD CONSTRAINT payment_type_id_key UNIQUE (id);


--
-- Name: payment_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY payment_type
    ADD CONSTRAINT payment_type_pkey PRIMARY KEY (label);


--
-- Name: pending_job_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY pending_job
    ADD CONSTRAINT pending_job_id_key UNIQUE (id);


--
-- Name: person_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY person
    ADD CONSTRAINT person_entity_id_key UNIQUE (entity_id);


--
-- Name: person_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY person
    ADD CONSTRAINT person_pkey PRIMARY KEY (id);


--
-- Name: person_to_company_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY person_to_company
    ADD CONSTRAINT person_to_company_pkey PRIMARY KEY (location_id, person_id);


--
-- Name: person_to_contact_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY person_to_contact
    ADD CONSTRAINT person_to_contact_pkey PRIMARY KEY (person_id, contact_class_id, contact);


--
-- Name: person_to_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY person_to_entity
    ADD CONSTRAINT person_to_entity_pkey PRIMARY KEY (person_id, entity_id);


--
-- Name: person_to_location_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY person_to_location
    ADD CONSTRAINT person_to_location_pkey PRIMARY KEY (location_id, person_id);


--
-- Name: pricegroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY pricegroup
    ADD CONSTRAINT pricegroup_pkey PRIMARY KEY (id);


--
-- Name: project_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: project_translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY project_translation
    ADD CONSTRAINT project_translation_pkey PRIMARY KEY (trans_id, language_code);


--
-- Name: recurring_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY recurring
    ADD CONSTRAINT recurring_pkey PRIMARY KEY (id);


--
-- Name: recurringemail_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY recurringemail
    ADD CONSTRAINT recurringemail_pkey PRIMARY KEY (id, formname);


--
-- Name: recurringprint_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY recurringprint
    ADD CONSTRAINT recurringprint_pkey PRIMARY KEY (id, formname);


--
-- Name: salutation_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salutation
    ADD CONSTRAINT salutation_id_key UNIQUE (id);


--
-- Name: salutation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY salutation
    ADD CONSTRAINT salutation_pkey PRIMARY KEY (salutation);


--
-- Name: session_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY session
    ADD CONSTRAINT session_pkey PRIMARY KEY (session_id);


--
-- Name: sic_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY sic
    ADD CONSTRAINT sic_pkey PRIMARY KEY (code);


--
-- Name: status_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY status
    ADD CONSTRAINT status_pkey PRIMARY KEY (trans_id, formname);


--
-- Name: tax_extended_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tax_extended
    ADD CONSTRAINT tax_extended_pkey PRIMARY KEY (entry_id);


--
-- Name: tax_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY tax
    ADD CONSTRAINT tax_pkey PRIMARY KEY (chart_id, validto);


--
-- Name: taxcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY taxcategory
    ADD CONSTRAINT taxcategory_pkey PRIMARY KEY (taxcategory_id);


--
-- Name: taxmodule_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY taxmodule
    ADD CONSTRAINT taxmodule_pkey PRIMARY KEY (taxmodule_id);


--
-- Name: transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: translation_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY translation
    ADD CONSTRAINT translation_pkey PRIMARY KEY (trans_id, language_code);


--
-- Name: user_preference_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_preference
    ADD CONSTRAINT user_preference_pkey PRIMARY KEY (id);


--
-- Name: users_id_key; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_id_key UNIQUE (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (username);


--
-- Name: vendortax_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY vendortax
    ADD CONSTRAINT vendortax_pkey PRIMARY KEY (vendor_id, chart_id);


--
-- Name: voucher_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY voucher
    ADD CONSTRAINT voucher_pkey PRIMARY KEY (id);


--
-- Name: warehouse_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY warehouse
    ADD CONSTRAINT warehouse_pkey PRIMARY KEY (id);


--
-- Name: yearend_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY yearend
    ADD CONSTRAINT yearend_pkey PRIMARY KEY (trans_id);


--
-- Name: acc_trans_chart_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX acc_trans_chart_id_key ON acc_trans USING btree (chart_id);


--
-- Name: acc_trans_source_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX acc_trans_source_key ON acc_trans USING btree (lower(source));


--
-- Name: acc_trans_trans_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX acc_trans_trans_id_key ON acc_trans USING btree (trans_id);


--
-- Name: acc_trans_transdate_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX acc_trans_transdate_key ON acc_trans USING btree (transdate);


--
-- Name: acc_trans_voucher_id_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX acc_trans_voucher_id_idx ON acc_trans USING btree (voucher_id);


--
-- Name: ap_approved_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ap_approved_idx ON ap USING btree (approved);


--
-- Name: ap_curr_idz; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ap_curr_idz ON ap USING btree (curr);


--
-- Name: ap_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ap_id_key ON ap USING btree (id);


--
-- Name: ap_invnumber_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ap_invnumber_key ON ap USING btree (invnumber);


--
-- Name: ap_ordnumber_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ap_ordnumber_key ON ap USING btree (ordnumber);


--
-- Name: ap_quonumber_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ap_quonumber_key ON ap USING btree (quonumber);


--
-- Name: ap_transdate_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ap_transdate_key ON ap USING btree (transdate);


--
-- Name: ar_approved_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ar_approved_idx ON ar USING btree (approved);


--
-- Name: ar_curr_idz; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ar_curr_idz ON ar USING btree (curr);


--
-- Name: ar_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ar_id_key ON ar USING btree (id);


--
-- Name: ar_ordnumber_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ar_ordnumber_key ON ar USING btree (ordnumber);


--
-- Name: ar_quonumber_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ar_quonumber_key ON ar USING btree (quonumber);


--
-- Name: ar_transdate_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX ar_transdate_key ON ar USING btree (transdate);


--
-- Name: assembly_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX assembly_id_key ON assembly USING btree (id);


--
-- Name: asset_item_active_tag_u; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX asset_item_active_tag_u ON asset_item USING btree (tag) WHERE (obsolete_by IS NULL);


--
-- Name: audittrail_trans_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX audittrail_trans_id_key ON audittrail USING btree (trans_id);


--
-- Name: contact_class_class_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX contact_class_class_idx ON contact_class USING btree (lower(class));


--
-- Name: country_name_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX country_name_idx ON country USING btree (lower(name));


--
-- Name: customer_customer_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX customer_customer_id_key ON customertax USING btree (customer_id);


--
-- Name: department_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX department_id_key ON department USING btree (id);


--
-- Name: eba_iban_null_bic_u; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX eba_iban_null_bic_u ON entity_bank_account USING btree (iban) WHERE (bic IS NULL);


--
-- Name: eca_to_location_billing_u; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX eca_to_location_billing_u ON eca_to_location USING btree (credit_id) WHERE (location_class = 1);


--
-- Name: entity_class_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX entity_class_idx ON entity_class USING btree (lower(class));


--
-- Name: entity_credit_ar_accno_idx_u; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX entity_credit_ar_accno_idx_u ON entity_credit_account USING btree (meta_number) WHERE (entity_class = 2);


--
-- Name: INDEX entity_credit_ar_accno_idx_u; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX entity_credit_ar_accno_idx_u IS 'This index is used to ensure that AR accounts are not reused.';


--
-- Name: entity_note_class_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX entity_note_class_idx ON note_class USING btree (lower(class));


--
-- Name: entity_note_id_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX entity_note_id_idx ON entity_note USING btree (id);


--
-- Name: entity_note_vectors_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX entity_note_vectors_idx ON entity_note USING gist (vector);


--
-- Name: exchangerate_ct_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX exchangerate_ct_key ON exchangerate USING btree (curr, transdate);


--
-- Name: gifi_accno_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX gifi_accno_key ON gifi USING btree (accno);


--
-- Name: gl_approved_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX gl_approved_idx ON gl USING btree (approved);


--
-- Name: gl_description_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX gl_description_key ON gl USING btree (lower(description));


--
-- Name: gl_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX gl_id_key ON gl USING btree (id);


--
-- Name: gl_reference_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX gl_reference_key ON gl USING btree (reference);


--
-- Name: gl_transdate_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX gl_transdate_key ON gl USING btree (transdate);


--
-- Name: invoice_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX invoice_id_key ON invoice USING btree (id);


--
-- Name: invoice_note_class_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX invoice_note_class_idx ON note_class USING btree (lower(class));


--
-- Name: invoice_note_id_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX invoice_note_id_idx ON invoice_note USING btree (id);


--
-- Name: invoice_note_vectors_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX invoice_note_vectors_idx ON invoice_note USING gist (vector);


--
-- Name: invoice_trans_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX invoice_trans_id_key ON invoice USING btree (trans_id);


--
-- Name: jcitems_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX jcitems_id_key ON jcitems USING btree (id);


--
-- Name: language_code_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX language_code_key ON language USING btree (code);


--
-- Name: lower_class_unique; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX lower_class_unique ON location_class USING btree (lower(class));


--
-- Name: makemodel_make_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX makemodel_make_key ON makemodel USING btree (lower(make));


--
-- Name: makemodel_model_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX makemodel_model_key ON makemodel USING btree (lower(model));


--
-- Name: makemodel_parts_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX makemodel_parts_id_key ON makemodel USING btree (parts_id);


--
-- Name: note_class_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX note_class_idx ON note_class USING btree (lower(class));


--
-- Name: notes_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX notes_idx ON entity_note USING gist (note gist_trgm_ops);


--
-- Name: oe_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX oe_id_key ON oe USING btree (id);


--
-- Name: oe_ordnumber_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX oe_ordnumber_key ON oe USING btree (ordnumber);


--
-- Name: oe_transdate_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX oe_transdate_key ON oe USING btree (transdate);


--
-- Name: orderitems_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX orderitems_id_key ON orderitems USING btree (id);


--
-- Name: orderitems_trans_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX orderitems_trans_id_key ON orderitems USING btree (trans_id);


--
-- Name: parts_description_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX parts_description_key ON parts USING btree (lower(description));


--
-- Name: parts_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX parts_id_key ON parts USING btree (id);


--
-- Name: parts_partnumber_index_u; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX parts_partnumber_index_u ON parts USING btree (partnumber) WHERE (obsolete IS FALSE);


--
-- Name: parts_partnumber_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX parts_partnumber_key ON parts USING btree (lower(partnumber));


--
-- Name: partsgroup_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX partsgroup_id_key ON partsgroup USING btree (id);


--
-- Name: partsgroup_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX partsgroup_key ON partsgroup USING btree (partsgroup);


--
-- Name: partstax_parts_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX partstax_parts_id_key ON partstax USING btree (parts_id);


--
-- Name: partsvendor_parts_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX partsvendor_parts_id_key ON partsvendor USING btree (parts_id);


--
-- Name: payment_id_idx; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX payment_id_idx ON payment USING btree (id);


--
-- Name: payments_queue_job_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX payments_queue_job_id ON payments_queue USING btree (job_id);


--
-- Name: pending_job_batch_id_pending; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX pending_job_batch_id_pending ON pending_job USING btree (batch_id) WHERE (success IS NULL);


--
-- Name: pending_job_entered_by; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX pending_job_entered_by ON pending_job USING btree (entered_by);


--
-- Name: pricegroup_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX pricegroup_id_key ON pricegroup USING btree (id);


--
-- Name: pricegroup_pricegroup_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX pricegroup_pricegroup_key ON pricegroup USING btree (pricegroup);


--
-- Name: project_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX project_id_key ON project USING btree (id);


--
-- Name: projectnumber_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX projectnumber_key ON project USING btree (projectnumber);


--
-- Name: status_trans_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX status_trans_id_key ON status USING btree (trans_id);


--
-- Name: transactions_locked_by_i; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX transactions_locked_by_i ON transactions USING btree (locked_by);


--
-- Name: translation_trans_id_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX translation_trans_id_key ON translation USING btree (trans_id);


--
-- Name: chart_i; Type: RULE; Schema: public; Owner: -
--

CREATE RULE chart_i AS ON INSERT TO chart DO INSTEAD SELECT CASE WHEN (new.charttype = 'H'::text) THEN account_heading_save(new.id, new.accno, new.description, NULL::integer) ELSE account_save(new.id, new.accno, new.description, new.category, new.gifi_accno, NULL::integer, CASE WHEN (new.contra IS NULL) THEN false ELSE new.contra END, CASE WHEN (new.tax IS NULL) THEN false ELSE new.tax END, string_to_array(new.link, ':'::text)) END AS account_save;


--
-- Name: file_sec_insert_oe_oe; Type: RULE; Schema: public; Owner: -
--

CREATE RULE file_sec_insert_oe_oe AS ON INSERT TO file_secondary_attachment WHERE ((new.source_class = 2) AND (new.dest_class = 2)) DO INSTEAD INSERT INTO file_order_to_order (file_id, source_class, ref_key, dest_class, attached_by, attached_at) VALUES (new.file_id, 2, new.ref_key, 2, new.attached_by, COALESCE((new.attached_at)::timestamp with time zone, now()));


--
-- Name: file_sec_insert_oe_tx; Type: RULE; Schema: public; Owner: -
--

CREATE RULE file_sec_insert_oe_tx AS ON INSERT TO file_secondary_attachment WHERE ((new.source_class = 2) AND (new.dest_class = 1)) DO INSTEAD INSERT INTO file_order_to_order (file_id, source_class, ref_key, dest_class, attached_by, attached_at) VALUES (new.file_id, 2, new.ref_key, 1, new.attached_by, COALESCE((new.attached_at)::timestamp with time zone, now()));


--
-- Name: file_sec_insert_tx_oe; Type: RULE; Schema: public; Owner: -
--

CREATE RULE file_sec_insert_tx_oe AS ON INSERT TO file_secondary_attachment WHERE ((new.source_class = 1) AND (new.dest_class = 2)) DO INSTEAD INSERT INTO file_tx_to_order (file_id, source_class, ref_key, dest_class, attached_by, attached_at) VALUES (new.file_id, 1, new.ref_key, 2, new.attached_by, COALESCE((new.attached_at)::timestamp with time zone, now()));


--
-- Name: ap_audit_trail; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ap_audit_trail AFTER INSERT OR DELETE OR UPDATE ON ap FOR EACH ROW EXECUTE PROCEDURE gl_audit_trail_append();


--
-- Name: ap_track_global_sequence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ap_track_global_sequence BEFORE INSERT OR UPDATE ON ap FOR EACH ROW EXECUTE PROCEDURE track_global_sequence();


--
-- Name: ar_audit_trail; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ar_audit_trail AFTER INSERT OR DELETE OR UPDATE ON ar FOR EACH ROW EXECUTE PROCEDURE gl_audit_trail_append();


--
-- Name: ar_track_global_sequence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ar_track_global_sequence BEFORE INSERT OR UPDATE ON ar FOR EACH ROW EXECUTE PROCEDURE track_global_sequence();


--
-- Name: block_change_when_approved; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER block_change_when_approved BEFORE DELETE OR UPDATE ON cr_report FOR EACH ROW EXECUTE PROCEDURE cr_report_block_changing_approved();


--
-- Name: check_department; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER check_department AFTER INSERT OR UPDATE ON ar FOR EACH ROW EXECUTE PROCEDURE check_department();


--
-- Name: check_department; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER check_department AFTER INSERT OR UPDATE ON ap FOR EACH ROW EXECUTE PROCEDURE check_department();


--
-- Name: check_department; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER check_department AFTER INSERT OR UPDATE ON gl FOR EACH ROW EXECUTE PROCEDURE check_department();


--
-- Name: check_department; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER check_department AFTER INSERT OR UPDATE ON oe FOR EACH ROW EXECUTE PROCEDURE check_department();


--
-- Name: del_department; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER del_department AFTER DELETE ON ar FOR EACH ROW EXECUTE PROCEDURE del_department();


--
-- Name: del_department; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER del_department AFTER DELETE ON ap FOR EACH ROW EXECUTE PROCEDURE del_department();


--
-- Name: del_department; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER del_department AFTER DELETE ON gl FOR EACH ROW EXECUTE PROCEDURE del_department();


--
-- Name: del_department; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER del_department AFTER DELETE ON oe FOR EACH ROW EXECUTE PROCEDURE del_department();


--
-- Name: del_exchangerate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER del_exchangerate BEFORE DELETE ON ar FOR EACH ROW EXECUTE PROCEDURE del_exchangerate();


--
-- Name: del_exchangerate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER del_exchangerate BEFORE DELETE ON ap FOR EACH ROW EXECUTE PROCEDURE del_exchangerate();


--
-- Name: del_exchangerate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER del_exchangerate BEFORE DELETE ON oe FOR EACH ROW EXECUTE PROCEDURE del_exchangerate();


--
-- Name: del_recurring; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER del_recurring AFTER DELETE ON ar FOR EACH ROW EXECUTE PROCEDURE del_recurring();


--
-- Name: del_recurring; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER del_recurring AFTER DELETE ON ap FOR EACH ROW EXECUTE PROCEDURE del_recurring();


--
-- Name: del_recurring; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER del_recurring AFTER DELETE ON gl FOR EACH ROW EXECUTE PROCEDURE del_recurring();


--
-- Name: del_yearend; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER del_yearend AFTER DELETE ON gl FOR EACH ROW EXECUTE PROCEDURE del_yearend();


--
-- Name: gl_audit_trail; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER gl_audit_trail AFTER INSERT OR DELETE OR UPDATE ON gl FOR EACH ROW EXECUTE PROCEDURE gl_audit_trail_append();


--
-- Name: gl_track_global_sequence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER gl_track_global_sequence BEFORE INSERT OR UPDATE ON gl FOR EACH ROW EXECUTE PROCEDURE track_global_sequence();


--
-- Name: notify_pending_jobs; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_pending_jobs BEFORE INSERT OR UPDATE ON pending_job FOR EACH ROW EXECUTE PROCEDURE trigger_pending_job();


--
-- Name: parts_short; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER parts_short AFTER UPDATE ON parts FOR EACH ROW EXECUTE PROCEDURE trigger_parts_short();


--
-- Name: ac_tax_form_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ac_tax_form
    ADD CONSTRAINT ac_tax_form_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES acc_trans(entry_id);


--
-- Name: acc_trans_chart_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY acc_trans
    ADD CONSTRAINT acc_trans_chart_id_fkey FOREIGN KEY (chart_id) REFERENCES account(id);


--
-- Name: acc_trans_trans_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY acc_trans
    ADD CONSTRAINT acc_trans_trans_id_fkey FOREIGN KEY (trans_id) REFERENCES transactions(id);


--
-- Name: acc_trans_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY acc_trans
    ADD CONSTRAINT acc_trans_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES voucher(id);


--
-- Name: account_checkpoint_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY account_checkpoint
    ADD CONSTRAINT account_checkpoint_account_id_fkey FOREIGN KEY (account_id) REFERENCES account(id);


--
-- Name: account_heading_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY account
    ADD CONSTRAINT account_heading_fkey FOREIGN KEY (heading) REFERENCES account_heading(id);


--
-- Name: account_heading_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY account_heading
    ADD CONSTRAINT account_heading_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES account_heading(id);


--
-- Name: account_link_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY account_link
    ADD CONSTRAINT account_link_account_id_fkey FOREIGN KEY (account_id) REFERENCES account(id);


--
-- Name: account_link_description_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY account_link
    ADD CONSTRAINT account_link_description_fkey FOREIGN KEY (description) REFERENCES account_link_description(description);


--
-- Name: ap_entity_credit_account_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ap
    ADD CONSTRAINT ap_entity_credit_account_fkey FOREIGN KEY (entity_credit_account) REFERENCES entity_credit_account(id);


--
-- Name: ap_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ap
    ADD CONSTRAINT ap_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: ap_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ap
    ADD CONSTRAINT ap_id_fkey FOREIGN KEY (id) REFERENCES transactions(id);


--
-- Name: ap_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ap
    ADD CONSTRAINT ap_person_id_fkey FOREIGN KEY (person_id) REFERENCES entity_employee(entity_id);


--
-- Name: ar_entity_credit_account_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ar
    ADD CONSTRAINT ar_entity_credit_account_fkey FOREIGN KEY (entity_credit_account) REFERENCES entity_credit_account(id);


--
-- Name: ar_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ar
    ADD CONSTRAINT ar_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: ar_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ar
    ADD CONSTRAINT ar_id_fkey FOREIGN KEY (id) REFERENCES transactions(id);


--
-- Name: ar_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY ar
    ADD CONSTRAINT ar_person_id_fkey FOREIGN KEY (person_id) REFERENCES entity_employee(entity_id);


--
-- Name: assembly_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY assembly
    ADD CONSTRAINT assembly_id_fkey FOREIGN KEY (id) REFERENCES parts(id);


--
-- Name: assembly_parts_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY assembly
    ADD CONSTRAINT assembly_parts_id_fkey FOREIGN KEY (parts_id) REFERENCES parts(id);


--
-- Name: asset_class_asset_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_class
    ADD CONSTRAINT asset_class_asset_account_id_fkey FOREIGN KEY (asset_account_id) REFERENCES account(id);


--
-- Name: asset_class_dep_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_class
    ADD CONSTRAINT asset_class_dep_account_id_fkey FOREIGN KEY (dep_account_id) REFERENCES account(id);


--
-- Name: asset_class_method_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_class
    ADD CONSTRAINT asset_class_method_fkey FOREIGN KEY (method) REFERENCES asset_dep_method(id);


--
-- Name: asset_dep_method_unit_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_dep_method
    ADD CONSTRAINT asset_dep_method_unit_class_fkey FOREIGN KEY (unit_class) REFERENCES asset_unit_class(id);


--
-- Name: asset_item_asset_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_item
    ADD CONSTRAINT asset_item_asset_account_id_fkey FOREIGN KEY (asset_account_id) REFERENCES account(id);


--
-- Name: asset_item_asset_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_item
    ADD CONSTRAINT asset_item_asset_class_id_fkey FOREIGN KEY (asset_class_id) REFERENCES asset_class(id);


--
-- Name: asset_item_dep_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_item
    ADD CONSTRAINT asset_item_dep_account_id_fkey FOREIGN KEY (dep_account_id) REFERENCES account(id);


--
-- Name: asset_item_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_item
    ADD CONSTRAINT asset_item_department_id_fkey FOREIGN KEY (department_id) REFERENCES department(id);


--
-- Name: asset_item_exp_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_item
    ADD CONSTRAINT asset_item_exp_account_id_fkey FOREIGN KEY (exp_account_id) REFERENCES account(id);


--
-- Name: asset_item_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_item
    ADD CONSTRAINT asset_item_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES ap(id);


--
-- Name: asset_item_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_item
    ADD CONSTRAINT asset_item_location_id_fkey FOREIGN KEY (location_id) REFERENCES warehouse(id);


--
-- Name: asset_item_obsolete_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_item
    ADD CONSTRAINT asset_item_obsolete_by_fkey FOREIGN KEY (obsolete_by) REFERENCES asset_item(id);


--
-- Name: asset_note_ref_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_note
    ADD CONSTRAINT asset_note_ref_key_fkey FOREIGN KEY (ref_key) REFERENCES asset_item(id);


--
-- Name: asset_report_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_report
    ADD CONSTRAINT asset_report_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES entity(id);


--
-- Name: asset_report_asset_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_report
    ADD CONSTRAINT asset_report_asset_class_fkey FOREIGN KEY (asset_class) REFERENCES asset_class(id);


--
-- Name: asset_report_entered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_report
    ADD CONSTRAINT asset_report_entered_by_fkey FOREIGN KEY (entered_by) REFERENCES entity(id);


--
-- Name: asset_report_gl_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_report
    ADD CONSTRAINT asset_report_gl_id_fkey FOREIGN KEY (gl_id) REFERENCES gl(id);


--
-- Name: asset_report_line_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_report_line
    ADD CONSTRAINT asset_report_line_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES asset_item(id);


--
-- Name: asset_report_line_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_report_line
    ADD CONSTRAINT asset_report_line_department_id_fkey FOREIGN KEY (department_id) REFERENCES department(id);


--
-- Name: asset_report_line_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_report_line
    ADD CONSTRAINT asset_report_line_report_id_fkey FOREIGN KEY (report_id) REFERENCES asset_report(id);


--
-- Name: asset_report_line_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_report_line
    ADD CONSTRAINT asset_report_line_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES warehouse(id);


--
-- Name: asset_report_report_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_report
    ADD CONSTRAINT asset_report_report_class_fkey FOREIGN KEY (report_class) REFERENCES asset_report_class(id);


--
-- Name: asset_rl_to_disposal_method_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_rl_to_disposal_method
    ADD CONSTRAINT asset_rl_to_disposal_method_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES asset_item(id);


--
-- Name: asset_rl_to_disposal_method_disposal_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_rl_to_disposal_method
    ADD CONSTRAINT asset_rl_to_disposal_method_disposal_method_id_fkey FOREIGN KEY (disposal_method_id) REFERENCES asset_disposal_method(id);


--
-- Name: asset_rl_to_disposal_method_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY asset_rl_to_disposal_method
    ADD CONSTRAINT asset_rl_to_disposal_method_report_id_fkey FOREIGN KEY (report_id) REFERENCES asset_report(id);


--
-- Name: audittrail_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY audittrail
    ADD CONSTRAINT audittrail_person_id_fkey FOREIGN KEY (person_id) REFERENCES person(entity_id);


--
-- Name: batch_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY batch
    ADD CONSTRAINT batch_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES entity_employee(entity_id);


--
-- Name: batch_batch_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY batch
    ADD CONSTRAINT batch_batch_class_id_fkey FOREIGN KEY (batch_class_id) REFERENCES batch_class(id);


--
-- Name: batch_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY batch
    ADD CONSTRAINT batch_created_by_fkey FOREIGN KEY (created_by) REFERENCES entity_employee(entity_id);


--
-- Name: batch_locked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY batch
    ADD CONSTRAINT batch_locked_by_fkey FOREIGN KEY (locked_by) REFERENCES session(session_id);


--
-- Name: company_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company
    ADD CONSTRAINT company_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: company_to_contact_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_to_contact
    ADD CONSTRAINT company_to_contact_company_id_fkey FOREIGN KEY (company_id) REFERENCES company(id) ON DELETE CASCADE;


--
-- Name: company_to_contact_contact_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_to_contact
    ADD CONSTRAINT company_to_contact_contact_class_id_fkey FOREIGN KEY (contact_class_id) REFERENCES contact_class(id);


--
-- Name: company_to_entity_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_to_entity
    ADD CONSTRAINT company_to_entity_company_id_fkey FOREIGN KEY (company_id) REFERENCES company(id) ON DELETE CASCADE;


--
-- Name: company_to_entity_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_to_entity
    ADD CONSTRAINT company_to_entity_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id) ON DELETE CASCADE;


--
-- Name: company_to_location_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_to_location
    ADD CONSTRAINT company_to_location_company_id_fkey FOREIGN KEY (company_id) REFERENCES company(id) ON DELETE CASCADE;


--
-- Name: company_to_location_location_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_to_location
    ADD CONSTRAINT company_to_location_location_class_fkey FOREIGN KEY (location_class) REFERENCES location_class(id);


--
-- Name: company_to_location_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY company_to_location
    ADD CONSTRAINT company_to_location_location_id_fkey FOREIGN KEY (location_id) REFERENCES location(id);


--
-- Name: country_tax_form_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY country_tax_form
    ADD CONSTRAINT country_tax_form_country_id_fkey FOREIGN KEY (country_id) REFERENCES country(id);


--
-- Name: cr_coa_to_account_chart_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cr_coa_to_account
    ADD CONSTRAINT cr_coa_to_account_chart_id_fkey FOREIGN KEY (chart_id) REFERENCES account(id);


--
-- Name: cr_report_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cr_report
    ADD CONSTRAINT cr_report_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES entity(id);


--
-- Name: cr_report_chart_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cr_report
    ADD CONSTRAINT cr_report_chart_id_fkey FOREIGN KEY (chart_id) REFERENCES account(id);


--
-- Name: cr_report_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cr_report
    ADD CONSTRAINT cr_report_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES entity(id);


--
-- Name: cr_report_entered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cr_report
    ADD CONSTRAINT cr_report_entered_by_fkey FOREIGN KEY (entered_by) REFERENCES entity(id);


--
-- Name: cr_report_line_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cr_report_line
    ADD CONSTRAINT cr_report_line_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES acc_trans(entry_id);


--
-- Name: cr_report_line_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cr_report_line
    ADD CONSTRAINT cr_report_line_report_id_fkey FOREIGN KEY (report_id) REFERENCES cr_report(id);


--
-- Name: cr_report_line_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cr_report_line
    ADD CONSTRAINT cr_report_line_user_fkey FOREIGN KEY ("user") REFERENCES entity(id);


--
-- Name: cr_report_line_voucher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY cr_report_line
    ADD CONSTRAINT cr_report_line_voucher_id_fkey FOREIGN KEY (voucher_id) REFERENCES voucher(id);


--
-- Name: custom_field_catalog_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY custom_field_catalog
    ADD CONSTRAINT custom_field_catalog_table_id_fkey FOREIGN KEY (table_id) REFERENCES custom_table_catalog(table_id);


--
-- Name: customertax_chart_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customertax
    ADD CONSTRAINT customertax_chart_id_fkey FOREIGN KEY (chart_id) REFERENCES account(id);


--
-- Name: customertax_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY customertax
    ADD CONSTRAINT customertax_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES entity_credit_account(id) ON DELETE CASCADE;


--
-- Name: eca_note_ref_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY eca_note
    ADD CONSTRAINT eca_note_ref_key_fkey FOREIGN KEY (ref_key) REFERENCES entity_credit_account(id) ON DELETE CASCADE;


--
-- Name: eca_to_contact_contact_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY eca_to_contact
    ADD CONSTRAINT eca_to_contact_contact_class_id_fkey FOREIGN KEY (contact_class_id) REFERENCES contact_class(id);


--
-- Name: eca_to_contact_credit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY eca_to_contact
    ADD CONSTRAINT eca_to_contact_credit_id_fkey FOREIGN KEY (credit_id) REFERENCES entity_credit_account(id) ON DELETE CASCADE;


--
-- Name: eca_to_location_credit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY eca_to_location
    ADD CONSTRAINT eca_to_location_credit_id_fkey FOREIGN KEY (credit_id) REFERENCES entity_credit_account(id) ON DELETE CASCADE;


--
-- Name: eca_to_location_location_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY eca_to_location
    ADD CONSTRAINT eca_to_location_location_class_fkey FOREIGN KEY (location_class) REFERENCES location_class(id);


--
-- Name: eca_to_location_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY eca_to_location
    ADD CONSTRAINT eca_to_location_location_id_fkey FOREIGN KEY (location_id) REFERENCES location(id);


--
-- Name: entity_bank_account_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_bank_account
    ADD CONSTRAINT entity_bank_account_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id) ON DELETE CASCADE;


--
-- Name: entity_class_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_class
    ADD CONSTRAINT entity_class_country_id_fkey FOREIGN KEY (country_id) REFERENCES country(id);


--
-- Name: entity_class_to_entity_entity_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_class_to_entity
    ADD CONSTRAINT entity_class_to_entity_entity_class_id_fkey FOREIGN KEY (entity_class_id) REFERENCES entity_class(id) ON DELETE CASCADE;


--
-- Name: entity_class_to_entity_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_class_to_entity
    ADD CONSTRAINT entity_class_to_entity_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id) ON DELETE CASCADE;


--
-- Name: entity_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity
    ADD CONSTRAINT entity_country_id_fkey FOREIGN KEY (country_id) REFERENCES country(id);


--
-- Name: entity_credit_account_ar_ap_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_credit_account
    ADD CONSTRAINT entity_credit_account_ar_ap_account_id_fkey FOREIGN KEY (ar_ap_account_id) REFERENCES account(id);


--
-- Name: entity_credit_account_bank_account_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_credit_account
    ADD CONSTRAINT entity_credit_account_bank_account_fkey FOREIGN KEY (bank_account) REFERENCES entity_bank_account(id);


--
-- Name: entity_credit_account_cash_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_credit_account
    ADD CONSTRAINT entity_credit_account_cash_account_id_fkey FOREIGN KEY (cash_account_id) REFERENCES account(id);


--
-- Name: entity_credit_account_discount_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_credit_account
    ADD CONSTRAINT entity_credit_account_discount_account_id_fkey FOREIGN KEY (discount_account_id) REFERENCES account(id);


--
-- Name: entity_credit_account_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_credit_account
    ADD CONSTRAINT entity_credit_account_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES entity_employee(entity_id);


--
-- Name: entity_credit_account_entity_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_credit_account
    ADD CONSTRAINT entity_credit_account_entity_class_fkey FOREIGN KEY (entity_class) REFERENCES entity_class(id);


--
-- Name: entity_credit_account_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_credit_account
    ADD CONSTRAINT entity_credit_account_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id) ON DELETE CASCADE;


--
-- Name: entity_credit_account_language_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_credit_account
    ADD CONSTRAINT entity_credit_account_language_code_fkey FOREIGN KEY (language_code) REFERENCES language(code);


--
-- Name: entity_credit_account_pricegroup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_credit_account
    ADD CONSTRAINT entity_credit_account_pricegroup_id_fkey FOREIGN KEY (pricegroup_id) REFERENCES pricegroup(id);


--
-- Name: entity_credit_account_primary_contact_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_credit_account
    ADD CONSTRAINT entity_credit_account_primary_contact_fkey FOREIGN KEY (primary_contact) REFERENCES person(id);


--
-- Name: entity_credit_account_taxform_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_credit_account
    ADD CONSTRAINT entity_credit_account_taxform_id_fkey FOREIGN KEY (taxform_id) REFERENCES country_tax_form(id);


--
-- Name: entity_employee_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_employee
    ADD CONSTRAINT entity_employee_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: entity_employee_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_employee
    ADD CONSTRAINT entity_employee_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES entity(id);


--
-- Name: entity_entity_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity
    ADD CONSTRAINT entity_entity_class_fkey FOREIGN KEY (entity_class) REFERENCES entity_class(id);


--
-- Name: entity_entity_class_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity
    ADD CONSTRAINT entity_entity_class_fkey1 FOREIGN KEY (entity_class) REFERENCES entity_class(id);


--
-- Name: entity_note_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_note
    ADD CONSTRAINT entity_note_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: entity_note_ref_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_note
    ADD CONSTRAINT entity_note_ref_key_fkey FOREIGN KEY (ref_key) REFERENCES entity(id) ON DELETE CASCADE;


--
-- Name: entity_other_name_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY entity_other_name
    ADD CONSTRAINT entity_other_name_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id) ON DELETE CASCADE;


--
-- Name: file_base_file_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_base
    ADD CONSTRAINT file_base_file_class_fkey FOREIGN KEY (file_class) REFERENCES file_class(id);


--
-- Name: file_base_mime_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_base
    ADD CONSTRAINT file_base_mime_type_id_fkey FOREIGN KEY (mime_type_id) REFERENCES mime_type(id);


--
-- Name: file_base_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_base
    ADD CONSTRAINT file_base_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES entity(id);


--
-- Name: file_order_ref_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_order
    ADD CONSTRAINT file_order_ref_key_fkey FOREIGN KEY (ref_key) REFERENCES oe(id);


--
-- Name: file_order_to_order_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_order_to_order
    ADD CONSTRAINT file_order_to_order_file_id_fkey FOREIGN KEY (file_id) REFERENCES file_order(id);


--
-- Name: file_order_to_order_ref_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_order_to_order
    ADD CONSTRAINT file_order_to_order_ref_key_fkey FOREIGN KEY (ref_key) REFERENCES oe(id);


--
-- Name: file_order_to_tx_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_order_to_tx
    ADD CONSTRAINT file_order_to_tx_file_id_fkey FOREIGN KEY (file_id) REFERENCES file_order(id);


--
-- Name: file_order_to_tx_ref_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_order_to_tx
    ADD CONSTRAINT file_order_to_tx_ref_key_fkey FOREIGN KEY (ref_key) REFERENCES transactions(id);


--
-- Name: file_part_ref_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_part
    ADD CONSTRAINT file_part_ref_key_fkey FOREIGN KEY (ref_key) REFERENCES parts(id);


--
-- Name: file_secondary_attachment_attached_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_secondary_attachment
    ADD CONSTRAINT file_secondary_attachment_attached_by_fkey FOREIGN KEY (attached_by) REFERENCES entity(id);


--
-- Name: file_secondary_attachment_dest_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_secondary_attachment
    ADD CONSTRAINT file_secondary_attachment_dest_class_fkey FOREIGN KEY (dest_class) REFERENCES file_class(id);


--
-- Name: file_secondary_attachment_source_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_secondary_attachment
    ADD CONSTRAINT file_secondary_attachment_source_class_fkey FOREIGN KEY (source_class) REFERENCES file_class(id);


--
-- Name: file_transaction_ref_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_transaction
    ADD CONSTRAINT file_transaction_ref_key_fkey FOREIGN KEY (ref_key) REFERENCES transactions(id);


--
-- Name: file_tx_to_order_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_tx_to_order
    ADD CONSTRAINT file_tx_to_order_file_id_fkey FOREIGN KEY (file_id) REFERENCES file_transaction(id);


--
-- Name: file_tx_to_order_ref_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_tx_to_order
    ADD CONSTRAINT file_tx_to_order_ref_key_fkey FOREIGN KEY (ref_key) REFERENCES oe(id);


--
-- Name: file_view_catalog_file_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY file_view_catalog
    ADD CONSTRAINT file_view_catalog_file_class_fkey FOREIGN KEY (file_class) REFERENCES file_class(id);


--
-- Name: gl_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY gl
    ADD CONSTRAINT gl_id_fkey FOREIGN KEY (id) REFERENCES transactions(id);


--
-- Name: gl_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY gl
    ADD CONSTRAINT gl_person_id_fkey FOREIGN KEY (person_id) REFERENCES person(id);


--
-- Name: inventory_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY inventory
    ADD CONSTRAINT inventory_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity_employee(entity_id);


--
-- Name: invoice_note_ref_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY invoice_note
    ADD CONSTRAINT invoice_note_ref_key_fkey FOREIGN KEY (ref_key) REFERENCES invoice(id);


--
-- Name: invoice_parts_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT invoice_parts_id_fkey FOREIGN KEY (parts_id) REFERENCES parts(id);


--
-- Name: invoice_tax_form_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY invoice_tax_form
    ADD CONSTRAINT invoice_tax_form_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES invoice(id);


--
-- Name: invoice_trans_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT invoice_trans_id_fkey FOREIGN KEY (trans_id) REFERENCES transactions(id);


--
-- Name: jcitems_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY jcitems
    ADD CONSTRAINT jcitems_person_id_fkey FOREIGN KEY (person_id) REFERENCES person(id);


--
-- Name: location_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY location
    ADD CONSTRAINT location_country_id_fkey FOREIGN KEY (country_id) REFERENCES country(id);


--
-- Name: lsmb_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY lsmb_roles
    ADD CONSTRAINT lsmb_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;


--
-- Name: menu_acl_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY menu_acl
    ADD CONSTRAINT menu_acl_node_id_fkey FOREIGN KEY (node_id) REFERENCES menu_node(id);


--
-- Name: menu_attribute_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY menu_attribute
    ADD CONSTRAINT menu_attribute_node_id_fkey FOREIGN KEY (node_id) REFERENCES menu_node(id);


--
-- Name: menu_node_parent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY menu_node
    ADD CONSTRAINT menu_node_parent_fkey FOREIGN KEY (parent) REFERENCES menu_node(id);


--
-- Name: new_shipto_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY new_shipto
    ADD CONSTRAINT new_shipto_location_id_fkey FOREIGN KEY (location_id) REFERENCES location(id);


--
-- Name: new_shipto_oe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY new_shipto
    ADD CONSTRAINT new_shipto_oe_id_fkey FOREIGN KEY (oe_id) REFERENCES oe(id);


--
-- Name: new_shipto_trans_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY new_shipto
    ADD CONSTRAINT new_shipto_trans_id_fkey FOREIGN KEY (trans_id) REFERENCES transactions(id);


--
-- Name: note_note_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY note
    ADD CONSTRAINT note_note_class_fkey FOREIGN KEY (note_class) REFERENCES note_class(id);


--
-- Name: oe_entity_credit_account_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY oe
    ADD CONSTRAINT oe_entity_credit_account_fkey FOREIGN KEY (entity_credit_account) REFERENCES entity_credit_account(id);


--
-- Name: oe_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY oe
    ADD CONSTRAINT oe_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: oe_oe_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY oe
    ADD CONSTRAINT oe_oe_class_id_fkey FOREIGN KEY (oe_class_id) REFERENCES oe_class(id);


--
-- Name: oe_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY oe
    ADD CONSTRAINT oe_person_id_fkey FOREIGN KEY (person_id) REFERENCES person(id);


--
-- Name: open_forms_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY open_forms
    ADD CONSTRAINT open_forms_session_id_fkey FOREIGN KEY (session_id) REFERENCES session(session_id) ON DELETE CASCADE;


--
-- Name: parts_translation_trans_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY parts_translation
    ADD CONSTRAINT parts_translation_trans_id_fkey FOREIGN KEY (trans_id) REFERENCES parts(id);


--
-- Name: partscustomer_credit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partscustomer
    ADD CONSTRAINT partscustomer_credit_id_fkey FOREIGN KEY (credit_id) REFERENCES entity_credit_account(id) ON DELETE CASCADE;


--
-- Name: partscustomer_pricegroup_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partscustomer
    ADD CONSTRAINT partscustomer_pricegroup_id_fkey FOREIGN KEY (pricegroup_id) REFERENCES pricegroup(id);


--
-- Name: partsgroup_translation_trans_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partsgroup_translation
    ADD CONSTRAINT partsgroup_translation_trans_id_fkey FOREIGN KEY (trans_id) REFERENCES partsgroup(id);


--
-- Name: partstax_chart_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partstax
    ADD CONSTRAINT partstax_chart_id_fkey FOREIGN KEY (chart_id) REFERENCES account(id);


--
-- Name: partstax_parts_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partstax
    ADD CONSTRAINT partstax_parts_id_fkey FOREIGN KEY (parts_id) REFERENCES parts(id) ON DELETE CASCADE;


--
-- Name: partstax_taxcategory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partstax
    ADD CONSTRAINT partstax_taxcategory_id_fkey FOREIGN KEY (taxcategory_id) REFERENCES taxcategory(taxcategory_id);


--
-- Name: partsvendor_credit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY partsvendor
    ADD CONSTRAINT partsvendor_credit_id_fkey FOREIGN KEY (credit_id) REFERENCES entity_credit_account(id) ON DELETE CASCADE;


--
-- Name: payment_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY payment
    ADD CONSTRAINT payment_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES person(id);


--
-- Name: payment_entity_credit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY payment
    ADD CONSTRAINT payment_entity_credit_id_fkey FOREIGN KEY (entity_credit_id) REFERENCES entity_credit_account(id);


--
-- Name: payment_gl_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY payment
    ADD CONSTRAINT payment_gl_id_fkey FOREIGN KEY (gl_id) REFERENCES gl(id);


--
-- Name: payment_links_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY payment_links
    ADD CONSTRAINT payment_links_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES acc_trans(entry_id);


--
-- Name: payment_links_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY payment_links
    ADD CONSTRAINT payment_links_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES payment(id);


--
-- Name: payments_queue_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY payments_queue
    ADD CONSTRAINT payments_queue_job_id_fkey FOREIGN KEY (job_id) REFERENCES pending_job(id);


--
-- Name: pending_job_batch_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY pending_job
    ADD CONSTRAINT pending_job_batch_class_fkey FOREIGN KEY (batch_class) REFERENCES batch_class(id);


--
-- Name: pending_job_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY pending_job
    ADD CONSTRAINT pending_job_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES batch(id);


--
-- Name: pending_job_entered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY pending_job
    ADD CONSTRAINT pending_job_entered_by_fkey FOREIGN KEY (entered_by) REFERENCES users(username);


--
-- Name: person_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY person
    ADD CONSTRAINT person_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id);


--
-- Name: person_salutation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY person
    ADD CONSTRAINT person_salutation_id_fkey FOREIGN KEY (salutation_id) REFERENCES salutation(id);


--
-- Name: person_to_company_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY person_to_company
    ADD CONSTRAINT person_to_company_company_id_fkey FOREIGN KEY (company_id) REFERENCES company(id) ON DELETE CASCADE;


--
-- Name: person_to_company_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY person_to_company
    ADD CONSTRAINT person_to_company_location_id_fkey FOREIGN KEY (location_id) REFERENCES location(id);


--
-- Name: person_to_company_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY person_to_company
    ADD CONSTRAINT person_to_company_person_id_fkey FOREIGN KEY (person_id) REFERENCES person(id) ON DELETE CASCADE;


--
-- Name: person_to_contact_contact_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY person_to_contact
    ADD CONSTRAINT person_to_contact_contact_class_id_fkey FOREIGN KEY (contact_class_id) REFERENCES contact_class(id);


--
-- Name: person_to_contact_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY person_to_contact
    ADD CONSTRAINT person_to_contact_person_id_fkey FOREIGN KEY (person_id) REFERENCES person(id) ON DELETE CASCADE;


--
-- Name: person_to_entity_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY person_to_entity
    ADD CONSTRAINT person_to_entity_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id) ON DELETE CASCADE;


--
-- Name: person_to_entity_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY person_to_entity
    ADD CONSTRAINT person_to_entity_person_id_fkey FOREIGN KEY (person_id) REFERENCES person(id) ON DELETE CASCADE;


--
-- Name: person_to_location_location_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY person_to_location
    ADD CONSTRAINT person_to_location_location_class_fkey FOREIGN KEY (location_class) REFERENCES location_class(id);


--
-- Name: person_to_location_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY person_to_location
    ADD CONSTRAINT person_to_location_location_id_fkey FOREIGN KEY (location_id) REFERENCES location(id);


--
-- Name: person_to_location_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY person_to_location
    ADD CONSTRAINT person_to_location_person_id_fkey FOREIGN KEY (person_id) REFERENCES person(id) ON DELETE CASCADE;


--
-- Name: project_credit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_credit_id_fkey FOREIGN KEY (credit_id) REFERENCES entity_credit_account(id);


--
-- Name: project_translation_trans_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY project_translation
    ADD CONSTRAINT project_translation_trans_id_fkey FOREIGN KEY (trans_id) REFERENCES project(id);


--
-- Name: session_users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY session
    ADD CONSTRAINT session_users_id_fkey FOREIGN KEY (users_id) REFERENCES users(id);


--
-- Name: tax_chart_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tax
    ADD CONSTRAINT tax_chart_id_fkey FOREIGN KEY (chart_id) REFERENCES account(id);


--
-- Name: tax_chart_id_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tax
    ADD CONSTRAINT tax_chart_id_fkey1 FOREIGN KEY (chart_id) REFERENCES account(id);


--
-- Name: tax_extended_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tax_extended
    ADD CONSTRAINT tax_extended_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES acc_trans(entry_id);


--
-- Name: tax_taxmodule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY tax
    ADD CONSTRAINT tax_taxmodule_id_fkey FOREIGN KEY (taxmodule_id) REFERENCES taxmodule(taxmodule_id);


--
-- Name: taxcategory_taxmodule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY taxcategory
    ADD CONSTRAINT taxcategory_taxmodule_id_fkey FOREIGN KEY (taxmodule_id) REFERENCES taxmodule(taxmodule_id);


--
-- Name: transactions_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY transactions
    ADD CONSTRAINT transactions_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES entity(id);


--
-- Name: transactions_locked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY transactions
    ADD CONSTRAINT transactions_locked_by_fkey FOREIGN KEY (locked_by) REFERENCES session(session_id) ON DELETE SET NULL;


--
-- Name: user_preference_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_preference
    ADD CONSTRAINT user_preference_id_fkey FOREIGN KEY (id) REFERENCES users(id);


--
-- Name: user_preference_language_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_preference
    ADD CONSTRAINT user_preference_language_fkey FOREIGN KEY (language) REFERENCES language(code);


--
-- Name: users_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_entity_id_fkey FOREIGN KEY (entity_id) REFERENCES entity(id) ON DELETE CASCADE;


--
-- Name: vendortax_chart_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY vendortax
    ADD CONSTRAINT vendortax_chart_id_fkey FOREIGN KEY (chart_id) REFERENCES account(id);


--
-- Name: vendortax_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY vendortax
    ADD CONSTRAINT vendortax_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES entity_credit_account(id) ON DELETE CASCADE;


--
-- Name: voucher_batch_class_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY voucher
    ADD CONSTRAINT voucher_batch_class_fkey FOREIGN KEY (batch_class) REFERENCES batch_class(id);


--
-- Name: voucher_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY voucher
    ADD CONSTRAINT voucher_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES batch(id);


--
-- Name: voucher_trans_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY voucher
    ADD CONSTRAINT voucher_trans_id_fkey FOREIGN KEY (trans_id) REFERENCES transactions(id);


--
-- Name: yearend_trans_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY yearend
    ADD CONSTRAINT yearend_trans_id_fkey FOREIGN KEY (trans_id) REFERENCES gl(id);


--
-- PostgreSQL database dump complete
--

